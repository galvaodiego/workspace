export const environment = {
  production: false,
  version: 'DEV',
  mapa_key_google: 'AIzaSyD3-YFwQBzXxbEn9zfn51dGXp-w2k9w7WI',
  socket_end_point: 'https://dash-backend.kmm.com.br',
  // socket_end_point: 'http://localhost:30042',
  // socket_end_point: 'https://kmm-bi.herokuapp.com',
  end_point_base_dev: 'AXON', // USO EM AMBIENTE DE DEV PARA DEFINIR A BASE NO SOCKET.
};
