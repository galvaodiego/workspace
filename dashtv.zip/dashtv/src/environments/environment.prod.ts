export const environment = {
  production: true,
  version: '2.5.28',
  mapa_key_google: 'AIzaSyD3-YFwQBzXxbEn9zfn51dGXp-w2k9w7WI',
  socket_end_point: 'https://dash-backend.kmm.com.br',
  // socket_end_point: 'https://kmm-bi.herokuapp.com',
  end_point_base_dev: '', // USO EM AMBIENTE DE DEV PARA DEFINIR A BASE NO SOCKET.
};
