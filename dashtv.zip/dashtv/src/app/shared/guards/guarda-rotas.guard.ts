import { ActivatedRouteSnapshot, CanActivate } from '@angular/router';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

import { Usuario } from '../models/usuario.model';
import { Http } from '@angular/http';
import { environment } from 'src/environments/environment';
import { ClienteService } from '../services/cliente.service';


@Injectable({ providedIn: 'root' })
export class GuardaRotas implements CanActivate {

    private _user: Usuario = Usuario.instance;

    constructor(
        private _router: Router,
        private _clienteS: ClienteService,
        // tslint:disable-next-line: deprecation
        private http: Http,
    ) { }

    /**
     * Protege as Rotas dos Módulos
     */
    canActivate(route: ActivatedRouteSnapshot) {
        if (this._user.isLogged) {
            const org = JSON.parse(localStorage.getItem('kmm_bi-dash|' + this._clienteS.discover() + '-organizacional'));
            const clienteSelecionado = JSON.parse(localStorage.getItem('cliente-selecionado'));

            const params = {
                base: (clienteSelecionado.ref ? clienteSelecionado.ref : null),
                usuario: org.usuario.usuario,
                modulo: route.data.modulo,
                rota: route.routeConfig.path
            };
            // console.log('canActivate', params);

            this.http.post(environment.socket_end_point + '/validate_route', params).subscribe(data => {
                // console.log('validate_route ENV:', params);
                // console.log('validate_route RET:', data);
            });

            return true;
        } else {
            this._router.navigate(['']);
            return false;
        }
    }
}