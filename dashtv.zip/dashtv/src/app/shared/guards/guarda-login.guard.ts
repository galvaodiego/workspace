import { CanActivate } from '@angular/router';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

import { Usuario } from '../models/usuario.model';


@Injectable({ providedIn: 'root' })
export class AuthLoginGuard implements CanActivate {

    private _user: Usuario = Usuario.instance;

    constructor(
        private _router: Router
    ) { }

    /**
    *  Protege a rota do Login 
    */
    canActivate() {
        if (this._user.isLogged == false) {
            return true;
        } else {
            this._router.navigate([this._user.listaDashboards[0].path]);
            return false;
        }
    }
}