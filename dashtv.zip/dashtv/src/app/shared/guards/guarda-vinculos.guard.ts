import { Injectable } from '@angular/core';
import { CanActivate } from '@angular/router';
import { Router } from '@angular/router';

import { Usuario } from '../models/usuario.model';

@Injectable({ providedIn: 'root' })
export class RouterVinculosGuard implements CanActivate {

    private _user: Usuario = Usuario.instance;

    constructor(
        private _router: Router
    ) { }

    /**
    * Verifica se a URL acessada contém na lista de Dashs do usuário
    */
    canActivate() {
        if (this._user.isLogged) {
            const hasDash = this._user.listaDashboards.some(
                (dash) => {
                    const path = '/' + dash.path;
                    return path === window.location.pathname
                }
            );
            return true
        } else {
            this._router.navigate(['']);
        }
    }
}   