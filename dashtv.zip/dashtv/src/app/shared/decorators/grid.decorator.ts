/**
 *
 * @param context Referencia do componente de Grid para injetar a coluna
 * @param type Tipo de coluna a ser injetada
 * @param component Componente que contem a coluna
 */
export function GridColumn2(context: string, type: string, component?: any, options: Object = {}) {
    return function (target: any, propertyKey: string) {
       Object.defineProperty(target, '__gridColumn_' + propertyKey, {
          enumerable: true,
          value: {
             context: context,
             type: type,
             template: propertyKey,
             editorOptions: options
          }
       });
 
       if (component) {
          Object.assign(target['__gridColumn_' + propertyKey], {
             component: component
          });
       }
 
       if (options) {
          Object.assign(target['__gridColumn_' + propertyKey], options);
       }
    };
 }
 
 /**
  *
  * @param context Referencia do componente de Grid para injetar o detail
  * @param type Tipo de coluna a ser injetada
  * @param component Componente que contem a coluna
  */
 export function GridDetail(context: string, component: any) {
    return function (target: any, propertyKey: string) {
       Object.defineProperty(target, '__gridDetail_' + propertyKey, {
          enumerable: true,
          value: {
             context: context,
             template: propertyKey
          }
       });
 
       if (component) {
          Object.assign(target['__gridDetail_' + propertyKey], {
             component: component
          });
       }
    };
 }
 