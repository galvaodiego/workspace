export class Label {

    text: string;
    visible = true;
    alignment = 'left';

    constructor(values: Object = {}, text?, visible?, alignment?) {
        if (text) {
            this.text = text;
        }

        if (visible) {
            this.visible = visible;
        }

        if (alignment) {
            this.alignment = alignment;
        }

        Object.assign(this, values);
    }

}

export enum FormsTypes {
    PAGE = 0,
    POPUP = 1
}

export class FormTypeModel {

    type: FormsTypes;
    url: string;

    constructor() { }

}


export function FormType(formType: FormTypeModel) {
    return (target) => {
        Object.assign(target.prototype, {
            formType: formType['type'],
            formUrl: formType['url']
        });
    };
}

export function label(text: string, position?: string, visible?: boolean) {
    return function (target: any, key: string) {

        const l = new Label({ text: text });

        if (position) {
            Object.assign(l, {
                alignment: position
            });

        }

        if (visible !== undefined) {
            Object.assign(l, {
                visible: visible
            });
        }

        Object.defineProperty(target, 'label_' + key, {
            value: l
        });
    };
}

export function nestedLabel(text: any[]) {
    return function (target: any, key: string) {
        text.forEach((item, index) => {
            Object.defineProperty(target, 'label_' + key + '_' + item['field'], {
                value: new Label({ text: item['text'] })
            });

            if (item['position']) {
                Object.assign(target['label_' + key + '_' + item['field']], {
                    alignment: item['position']
                });
            }

            if (item['visible']) {
                Object.assign(target['label_' + key + '_' + item['field']], {
                    visible: item['visible']
                });
            }
        });
    };
}
