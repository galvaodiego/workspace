import { label, FormType } from '../directives/form.directive';

export enum FormsTypes {
    PAGE = 0,
    POPUP = 1
}


@FormType({
    type: FormsTypes.PAGE,
    url: ''
})
export abstract class Model<T> {

    obj: string;

    private _ativo: boolean = true;

    @label('Inserido em')
    date_insert: Date;

    @label('Alterado em')
    date_update: Date;

    @label('Inserido por')
    user_insert: Date;

    @label('Alterado por')
    user_update: Date;

    @label('Observações')
    observacao: string;

    operation?: string;

    // Propriedades do grid
    @label('Opções')
    optionsTemplate: string;

    abstract getList(json: Array<any>, options?: Object): Array<T>;

    /**
    * Getter ativo
    * @return { boolean }
    */
    @label('Ativo')
    public get ativo(): any {
        return this._ativo;
    }

    /**
     * Setter ativo
     * @param { boolean } value
     */
    public set ativo(value: any) {
        if (typeof value === 'boolean') {
            this._ativo = value;
        } else {
            this._ativo = value === 1 ? true : false;
        }
    }

    // tslint:disable-next-line:member-ordering
    public static clone(obj: any, prototype?: any) {
        if (prototype) {
            return Object.assign({ __proto__: prototype }, obj);
        } else {
            return Object.assign({ __proto__: obj.__proto__ }, obj);
        }
    }

}
