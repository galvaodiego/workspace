export class GridColumn {

    context?: any;
    dataField?: string;
    visible?: boolean = true;
    caption?: string = undefined;
    columns?: Array<GridColumn> = [];
    alignment?: string = undefined;
    encodeHtml?: boolean = false;
    editorOptions?: Object = {};
    visibleIndex?: number = undefined;
    width?: any = undefined;
    format?: string = undefined;
    fixedPosition?: string = 'right';
    fixed?: boolean = true;
    template?: string;
    groupCellTemplate?: string;
    component?: any = undefined;
    cellTemplate?: string = '';
    allowEditing?: boolean = false;
    allowSorting?: boolean = false;
    allowFiltering?: boolean = false;
    calculateCellValue?: Function;
    calculateDisplayValue?: Function;
    calculateFilterExpression?: Function;
    calculateSortValue?: Function | string;
    calculateGroupValue?: Function | string;
    dataType?: string;

    constructor(values: Object = {}) {
        Object.assign(this, values);
    }

    static ID(options: GridColumn) {
        const column = new GridColumn(options);

        return {
            alignment: 'right' || column.alignment,
            caption: 'ID' || column.caption,
            dataField: column.dataField,
            dataType: 'number',
            encodeHtml: false,
            visible: column.visible,
            visibleIndex: column.visibleIndex,
            width: column.width || 70,
            calculateCellValue: column.calculateCellValue // function (data) { return data[column.dataField]; }
        };
    }

    static Text(options: GridColumn) {
        const column = new GridColumn(options);

        return {
            alignment: column.alignment || 'center',
            caption: column.caption,
            dataField: column.dataField,
            dataType: 'string',
            encodeHtml: column.encodeHtml || false,
            editorOptions: column.editorOptions,
            visible: column.visible,
            visibleIndex: column.visibleIndex,
            width: column.width,
            calculateCellValue: column.calculateCellValue, // function (data) { return data[column.dataField]; }
            calculateDisplayValue: column.calculateDisplayValue,
            calculateSortValue: column.calculateSortValue,
            calculateGroupValue: column.calculateGroupValue,
        };
    }

    static Boolean(options: GridColumn) {
        const column = new GridColumn(options);

        return {
            dataField: column.dataField,
            visible: column.visible,
            caption: column.caption,
            alignment: column.alignment || 'center',
            visibleIndex: column.visibleIndex,
            editorOptions: column.editorOptions,
            dataType: 'boolean',
            falseText: 'Não',
            trueText: 'Sim',
            showEditorAlways: false,
            width: column.width,
            calculateCellValue: column.calculateCellValue // function (data) { return data[column.dataField]; }
        };
    }

    static Group(options: GridColumn) {
        const column = new GridColumn(options);

        return {
            alignment: column.alignment || 'center',
            caption: column.caption,
            editorOptxions: column.editorOptions,
            visible: column.visible,
            visibleIndex: column.visibleIndex,
            width: column.width,
            columns: column.columns
        };
    }

    static Number(options: GridColumn, precision?: number) {
        const column = new GridColumn(options);

        const format = precision ? {
            type: 'fixedPoint',
            precision: precision
        } : undefined;

        return {
            dataField: column.dataField,
            visible: column.visible,
            caption: column.caption,
            alignment: column.alignment || 'right',
            visibleIndex: column.visibleIndex,
            editorOptions: column.editorOptions,
            dataType: 'number',
            format: format,
            width: column.width,
            calculateCellValue: column.calculateCellValue // function (data) { return data[column.dataField]; }
        };
    }

    static Currency(options: GridColumn) {
        const column = new GridColumn(options);

        return {
            dataField: column.dataField,
            visible: column.visible,
            caption: column.caption,
            alignment: column.alignment || 'right',
            visibleIndex: column.visibleIndex,
            editorOptions: column.editorOptions,
            dataType: 'number',
            format: 'currency',
            width: column.width,
            calculateCellValue: column.calculateCellValue // function (data) { return data[column.dataField]; }
        };
    }

    static Date(options: GridColumn) {
        const column = new GridColumn(options);

        return {
            dataField: column.dataField,
            visible: column.visible,
            caption: column.caption,
            alignment: column.alignment || 'center',
            visibleIndex: column.visibleIndex,
            editorOptions: column.editorOptions,
            dataType: 'date',
            format: column.format,
            width: column.width,
            calculateCellValue: column.calculateCellValue // function (data) { return data[column.dataField]; }
        };
    }

    static Datetime(options: GridColumn) {
        const column = new GridColumn(options);

        return {
            dataField: column.dataField,
            visible: column.visible,
            caption: column.caption,
            alignment: column.alignment || 'center',
            visibleIndex: column.visibleIndex,
            editorOptions: column.editorOptions,
            dataType: 'datetime',
            format: 'dd/MM/yyyy HH:mm:ss',
            width: column.width,
            calculateCellValue: column.calculateCellValue // function (data) { return data[column.dataField]; }
        };
    }

    static Template(options: GridColumn) {
        const column = new GridColumn(options);

        return {
            allowSorting: column.allowSorting,
            allowFiltering: column.allowFiltering,
            calculateCellValue: column.calculateCellValue,
            calculateFilterExpression: column.calculateFilterExpression,
            caption: column.caption || 'Opções',
            cellTemplate: !!column.template ? column.template : column.cellTemplate,
            groupCellTemplate: column.groupCellTemplate,
            component: column.component,
            context: column.context,
            dataField: column.dataField || column.template,
            dataType: column.dataType,
            editorOptions: column.editorOptions,
            fixed: column.fixed,
            alignment: column.alignment || 'center',
            fixedPosition: column.fixedPosition,
            width: column.width
        };
    }

}
