export class ChartjsModel {
   private _labels: Array<any>;
   private _datasets: Array<any>;

   constructor() {
      this._labels = [];
      this._datasets = [];
   }

   public get labels() {
      return this._labels;
   }

   public set labels(value: any) {
      this._labels = value;
   }

   public get datasets() {
      return this._datasets;
   }

   public set datasets(value: any) {
      this._datasets = value;
   }

   public addLabelItem(value: string) {
      this._labels.push(value);
   }

   public addDatasetItem(value: any) {
      this._datasets.push(value);
   }

}