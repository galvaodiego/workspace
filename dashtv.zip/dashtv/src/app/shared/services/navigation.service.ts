import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import SetInterval from 'set-interval';


// KMM
import { Usuario } from '../models/usuario.model';
import { UsuarioService } from '../services/usuario.service';

@Injectable({ providedIn: 'root' })
export class NavigationService {

   public _user: Usuario = Usuario.instance;

   ///////////////////////////////////////////
   //          LOADER DAS TELAS             //
   //////////////////////////////////////////
   public loaderTela = true;

   ///////////////////////////////////////////
   //         CONTROLE DE TIMER TELA        //
   ///////////////////////////////////////////
   public trocaTela: any; // Recebe o SetInterval da Tela

   ///////////////////////////////////////////
   //            BARRA DE TIMER             //
   ///////////////////////////////////////////
   public pauseTela = false; // Controla se está Pausada ou não a Tela
   public tempoProgress: any; // Recebe o SetInterval da Barrinha
   public timer: number; // Incrementa o Timer da Barrinha
   public valueTime: number; // Incrementa o Timer da Barrinha
   public hideTimeBar = false; // Esconde barra de timer

   timer_troca_tela: number; // tempo real de troca de tela em milisegundos.

   constructor(
      private _router: Router,
      private _userProvider: UsuarioService
   ) {
      this.timer = 0;
      this.timer_troca_tela = 600000; // valor padrão
   }

   /*
      Objetivo:
         Avançar entre os painéis disponíveis no getVinculos();
   */
   public next() {
      for (let i = 0; i < this._user.listaDashboards.length; i++) {
         if (this._user.listaDashboards[i].dash_id == this._user.selectedDashboard) {
            // se for o ultimo objeto do array, volta pro primeiro
            if (this._user.listaDashboards.indexOf(this._user.listaDashboards[i]) == this._user.listaDashboards.length - 1) {
               this._user.selectedDashboard = this._user.listaDashboards[0].dash_id;
               this._userProvider.save();
               this._router.navigate([this._user.listaDashboards[0].path]);
               break;
            } else {
               this._user.selectedDashboard = this._user.listaDashboards[i + 1].dash_id;
               this._userProvider.save();
               this._router.navigate([this._user.listaDashboards[i + 1].path]);
               break;
            }
         }
      }
   }

   /*
   Objetivo:
   Retroceder entre os painéis disponíveis no getVinculos();
   */
   public previous() {
      for (let i = 0; i < this._user.listaDashboards.length; i++) {
         if (this._user.listaDashboards[i].dash_id == this._user.selectedDashboard) {

            // se for o primeiro objeto do array, volta pro ultimo
            if (this._user.listaDashboards.indexOf(this._user.listaDashboards[i]) == this._user.listaDashboards.length - 1) {
               this._user.selectedDashboard = this._user.listaDashboards[0].dash_id;
               this._userProvider.save();
               this._router.navigate([this._user.listaDashboards[0].path]);
               break;
            } else {
               this._user.selectedDashboard = this._user.listaDashboards[i - 1].dash_id;
               this._userProvider.save();
               this._router.navigate([this._user.listaDashboards[i - 1].path]);
               break;
            }
         }
      }
   }

   /**
    * Objetivo:
    *      Pausar o Timer da Tela
    */
   public stopTela() {
      this.pauseTela = true;
      SetInterval.clear('trocaTela');
      SetInterval.clear('tempoProgress');
      // clearInterval(this.tempoProgress);
      // clearInterval(this.trocaTela);
      this.timer = 0;
      this.valueTime = 0;
   }

   /**
    * Objetivo:
    *        Inicar Barra de Timer da Tela
    * @param valueTimer :: Valor em ms
    */
   public playTela(valueTimer?: number) {
      this.valueTime = valueTimer;
      this.pauseTela = false;
      this.timer = 0;
      // this.tempoProgress = setInterval(() => {
      //    this.timer++;
      // }, this.valueTime ? this.valueTime : 20);
      SetInterval.start(() => {
         this.timer++;
      }, this.valueTime ? this.valueTime : 20, 'tempoProgress');
   }

   /**
    * Controla o Play e Pause das Telas
    * @param valueTimer :: Valor em ms
    */
   public controlTela(valueTimer?: number) {
      this.pauseTela == false ? this.playTela(valueTimer) : this.stopTela();
   }


   /**
    * Refresh na Tela para o Timer Reiniciar
    */
   public InitTela() {
      location.reload();
   }


   /**
    * Modifica o Estado da ProgressBar e Salva no Storage
    * @param e
    */

   public stateProgressBar(e) {
      this._user.showProgressBar = e;
      this._userProvider.save();
   }

   trocaDash() {
      this.timer_troca_tela = 600000; // 10 MIN PARA TODOS OS DASHB.
      // console.log('this._user.listaDashboards', this._user.listaDashboards);

      SetInterval.start(() => {
         if (this._user.listaDashboards.length > 1) {
            SetInterval.clear('trocaTela');
            this.next();
         } else {
            location.reload();
         }
      }, this.timer_troca_tela, 'trocaTela');
      // }, 600000, 'trocaTela');
   }
}
