import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
@Injectable({
    providedIn: 'root'
})
export class TemplateService {
    headers: HttpHeaders = new HttpHeaders();
    constructor(
        private http: HttpClient,
    ) {
        this.headers = this.headers.append('Content-Type', 'application/json');
    }

    backendCall(dados, verbo, operacao) {
        const url = environment.socket_end_point + '/template/' + operacao;
        return new Promise((resolvePai, rejectPai) => {
            this.send(verbo, url, dados, this.headers).then(
                (data) => {
                    // data = data.json();
                    if (data.result != null) {
                        resolvePai(data.result);
                    } else {
                        resolvePai(data);
                    }
                }
            ).catch(dataError => {
                // dataError = dataError.json();
                console.log('dataError', dataError);

                // Não autorizado - Quando o token é inválido ou expirado
                if (dataError.code === 401) {
                    // this.user.logout();
                } else if (dataError.code === 403) {
                    // console.log('dataError', dataError);
                    // this.user.logout();
                    // this.router.navigate(['']);
                    rejectPai(dataError);
                } else if (dataError.code === 404) {
                    // this.user.logout();
                } else {
                    try {
                        console.log('dataError', dataError);
                    } catch (er) { }
                    rejectPai(dataError); // Chama o reject do promise de retorno
                }
            }
            );
        });
    }

    // tslint:disable-next-line: deprecation
    public send(verbo: string, url: string, requestData: any, headers: HttpHeaders): Promise<any> {
        return new Promise((resolve, reject) => {
            switch (verbo) {
                case 'get':
                    this.http.get(url, { headers }).subscribe(
                        data => resolve(data),
                        err => reject(err));
                    break;
                case 'post':
                    this.http.post(url, JSON.stringify(requestData), { headers }).subscribe(
                        data => resolve(data),
                        err => reject(err));
                    break;
            }
        });
    }

}
