import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

import { Usuario } from '../models/usuario.model';

import notify from 'devextreme/ui/notify';

@Injectable({ providedIn: 'root' })
export class AcessoService {

    private _user: Usuario = Usuario.instance;

    constructor(private _router: Router) { }


    /**
     * Valida o Token que esta gravado no Banco(recebido nas requisições)
     * com o Token gravado no LocalStorage
     *      Objetivo:: Impedir acesso Simultâneo de Usuários
     * @param token token de acesso
     */
    public verificaToken(token) {
        if (this._user.token === token) {
            return true
        } else {
            notify({
                message: 'Esse Usuario já está Logado!',
                type: 'error',
                displayTime: 100000,
                closeOnClick: true,
                width: () => window.innerWidth / 1.8
            });
            this._router.navigate(['']);
        }
    }

}