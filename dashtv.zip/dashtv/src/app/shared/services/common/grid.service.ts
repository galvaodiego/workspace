import { Injectable, Output, EventEmitter } from '@angular/core';

import { GridColumn } from '../../models/grid-column.model';
import { Observable } from 'rxjs';
// import { AppService } from '../app.service';
import { map } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class GridService {

    gridContext: any[] = [];
    customColumns: any = [];
    masterDetails: any = [];

    @Output() refreshGrid: EventEmitter<boolean> = new EventEmitter();

    constructor(
        // protected _appService: AppService
    ) { }

    setCustomColumns(component: any) {
        const columns = [];
        const masterDetails = [];
        let context;
        Object.keys(component['__proto__']).forEach((item, index) => {
            if (item.search('__gridColumn_') !== -1) {
                context = component[item].context;

                const template = {
                    template: component[item].template,
                    component: component[item].component
                };

                const column = GridColumn[component[item].type](template);

                Object.assign(column, component[item].editorOptions);

                columns.push(column);
            }

            if (item.search('__gridDetail_') !== -1) {
                context = component[item].context;

                const template = {
                    template: component[item].template,
                    component: component[item].component
                };

                masterDetails.push(template);
            }
        });

        if (columns.length > 0) {
            component[context].customColumns = columns;
        }

        if (masterDetails.length > 0) {
            component[context].masterDetails = masterDetails;
        }
    }

    getAction(context: string, action: string): Observable<any> {
        return this.gridContext[context][action];
    }

    callRefresh() {
        this.refreshGrid.emit(true);
    }

    altModelo(params): Observable<any> {
        return
        //   return this._appService.backendCall(this._appService.modules.gestao_cadastro, 'altModelo', params);
    }

    saveModelo(params): Observable<any> {
        return
        //   return this._appService.backendCall(this._appService.modules.gestao_cadastro, 'insModelo', params);
    }

    delModelo(params): Observable<any> {
        return
        //   return this._appService.backendCall(this._appService.modules.gestao_cadastro, 'delModelo', params);
    }

    getModelos(params): Observable<any> {
        return
        //   return this._appService.backendCall(this._appService.modules.gestao_cadastro, 'getModelo', params)
        //      .pipe(
        //         map(result => {
        //            const data = result['modelo'];

        //            return data;
        //         })
        //      );
    }
}
