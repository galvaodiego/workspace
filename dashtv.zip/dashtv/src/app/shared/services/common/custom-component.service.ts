import { Observable } from 'rxjs';
import { Injectable, EventEmitter } from '@angular/core';


@Injectable({ providedIn: 'root' })
export class CustomComponentService {

   customComponentContext: any[] = [];
   params: any[] = [];
   action: EventEmitter<any> = new EventEmitter();

   toggleAction(action: string) {
      this.action.emit(action);
   }

   getAction(context: string, action: any): Observable<any> {
      return this.customComponentContext[context][action];
   }

}
