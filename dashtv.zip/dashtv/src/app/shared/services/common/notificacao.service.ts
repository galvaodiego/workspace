import { Injectable } from '@angular/core';
import notify from 'devextreme/ui/notify';

@Injectable({
   providedIn: 'root'
})
export class NotificacaoService {

   constructor() { }

   toast(msg, cor?, tempo?) {
      notify({
         message: msg,
         type: cor ? cor : 'success',
         displayTime: tempo ? tempo : 3000,
         closeOnClick: true,
         elementAttr: { class: 'dx-notify-default' },
      });
   }
}
