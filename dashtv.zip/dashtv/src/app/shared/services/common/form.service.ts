import { Injectable, EventEmitter, Output, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
// import { MessageService } from './message.service';
import { Model } from '../../models/model';

@Injectable({ providedIn: 'root' })
export class FormService {

   protected popupVisible = false;
   private _customFields: any[];
   private _dataModel: any;

   formContext: any[] = [];
   queryParams: any;
   subContext: any[] = [];
   requests: Function;
   params: any = [];
   prevFormContext: any;

   notifyComponent: EventEmitter<any> = new EventEmitter();

   @Output() changePopupVisible: EventEmitter<boolean> = new EventEmitter();
   @Output() customFieldsChange: EventEmitter<any[]> = new EventEmitter();
   @Output() dataModelChange: EventEmitter<any> = new EventEmitter();
   @Output() queryParamsChange: EventEmitter<any> = new EventEmitter();
   @Output() editorOption: EventEmitter<any> = new EventEmitter();
   @Output() downloadFile: EventEmitter<any> = new EventEmitter();
   @Output() deleteFile: EventEmitter<any> = new EventEmitter();
   @Output() actionBtn: EventEmitter<any> = new EventEmitter();
   @Output() editBtn: EventEmitter<any> = new EventEmitter();
   @Output() cancelBtn: EventEmitter<any> = new EventEmitter();
   @Output() formBusy: EventEmitter<any> = new EventEmitter();

   constructor(
    //   protected _messageService: MessageService
   ) {
   }

   /**
    * @author Andre Silva
    */
   eventAction(context: string, action: string, params?: any, callback?: any) {
      if (`__event_${action}_action__` in this.formContext[context]['__proto__']) {
         this.formContext[context]['__proto__'][`__event_${action}_action__`] = true;
      }

      this.formContext[context]['__proto__'][`__event_${action}_params__`] = params;

      if (callback) {
         callback.function.call(callback.context, ...callback.params);
      }
   }

   requestError() {
      this.formContext.forEach(item => {
        //  MessageService.log(item);
      });
   }

   getDataModel(context: string, copy: boolean = false): any {
      if (copy) {
         return Model.clone(this.formContext[context].formComponent.dataModel);
      } else {
         return this.formContext[context].formComponent.dataModel;
      }
   }

   setDataModel(context: string, dataModel: any): any {
      this.formContext[context].dataModel = dataModel;
      this.formContext[context].formComponent.dataModel = dataModel;
   }

   assignDataModel(context: string, obj: any) {
      const dataModel = this.formContext[context].formComponent.dataModel;
      Object.assign(dataModel, obj);
      this.setDataModel(context, dataModel);
   }

   getAction(context: string, action: string): Observable<any> {
      if (this.formContext[context].formComponent) {
         return this.formContext[context].formComponent[action];
      } else {
         return this.formContext[context][action];
      }
   }

   getSubmitAction(context: string): Observable<any> {
      return this.formContext[context].formComponent.submitAction;
   }

   getCancelAction(context: string): Observable<any> {
      return this.formContext[context].formComponent.cancelAction;
   }

   setEditMode(context: string, mode: boolean) {
      this.formContext[context].editMode = mode;
      this.formContext[context].formComponent.editMode = mode;
   }

   getEditMode(context: string): boolean {
      return this.formContext[context].formComponent.editMode;
   }

   togglePopup(param: boolean) {
      this.popupVisible = param;

      this.changePopupVisible.emit(this.popupVisible);
   }

   editorOptionChange(datafield: string, value: any) {
      this.editorOption.emit({ dataField: datafield, value: value });
   }

   notify(sender, receiver, msg?: any, options: any = {}) {
      this.notifyComponent.emit({ sender: sender, receiver: receiver, msg: msg, options: options });
   }

   set dataModel(dataModel: any) {
      this._dataModel = dataModel;

      this.dataModelChange.emit(dataModel);
   }

   get dataModel(): any {
      return this._dataModel;
   }

   set customFields(customFields: any[]) {
      this._customFields = customFields;

      this.customFieldsChange.emit(this._customFields);
   }

   get customFields(): any[] {
      return this._customFields;
   }

   toggleActionBtn() {
      this.actionBtn.emit();
   }

   toggleEditBtn() {
      this.editBtn.emit();
   }

   toggleCancelBtn() {
      this.cancelBtn.emit();
   }

}
