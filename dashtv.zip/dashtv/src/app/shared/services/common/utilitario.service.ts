import { Injectable } from '@angular/core';
import * as moment from 'moment';


@Injectable({
  providedIn: 'root'
})
export class UtilitarioService {

  constructor() { }

  convertTime(sec: number) {
   const tempTime = moment.duration(sec, 'seconds');
   const mo = tempTime.months();
   const d = tempTime.days();
   const h = tempTime.hours();
   const m = tempTime.minutes();
   const s = tempTime.seconds();

   let month = mo.toString();
   let day = d.toString();
   let hora = h.toString();
   let minutes = m.toString();
   let segundos = s.toString();

   if (mo < 10) {
      month = '0' + mo.toString();
   }

   if (d < 10) {
      day = '0' + d.toString();
   }

   if (h < 10) {
      hora = '0' + h.toString();
   }

   if (m < 10) {
      minutes = '0' + m.toString();
   }

   if (s < 10) {
      segundos = '0' + s.toString();
   }
   // return moment.utc(moment.duration(sec, 'seconds').asMilliseconds()).format('D [dia(s)] HH:mm:ss');
   let retorno = '';

   if (day === '00') {
      retorno = hora + ':' + minutes + ':' + segundos;
   } else if (day === '01') {
      retorno = day + ' dia  ' + hora + ':' + minutes + ':' + segundos;
   } else {
      retorno = day + ' dias  ' + hora + ':' + minutes + ':' + segundos;
   }

   if (month !== '00') {
      if (month === '01') {
         retorno = month + ' mês e ' + retorno;
      } else {
         retorno = month + ' meses e ' + retorno;
      }
   }

   return retorno;
}
}
