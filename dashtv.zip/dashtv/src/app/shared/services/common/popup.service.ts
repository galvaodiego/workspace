import { Injectable, Output, EventEmitter } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Injectable({ providedIn: 'root' })
export class PopupService {

   items: any[] = [];
   subscriptions: any[] = [];

   @Output() itemPropertyChange: EventEmitter<any> = new EventEmitter();
   @Output() itemsChange: EventEmitter<any> = new EventEmitter();
   @Output() popupChangeState: EventEmitter<any> = new EventEmitter();

   constructor(
      protected _activatedRoute: ActivatedRoute,
      protected _router: Router
   ) {

   }

   setItems(components: any[]) {
      this.items = components;

      this.itemsChange.emit(components);
   }

   addItems(component: any, useData: boolean = false) {
      if (!useData) {
         Object.keys(component['__proto__']).forEach((item, index) => {
            if (item.search('__popup_items') !== -1) {
               this.setItems(component[component[item].items]);
            }
         });
      } else {
         this.setItems(component);
      }
   }

   show(component: string, options: Object = {}) {
      Object.assign(options, {
         operation: 'insert',
         component: component
      });

      if (options['id']) {
         Object.assign(options, {
            operation: 'update'
         });
      }

      this._router.navigate([this._router.url, options]);
   }

   hide(component: string) {
      this.popupChangeState.emit({ popup: component, visible: false });
   }

   togglePopup(popup: string, visible: boolean) {
      this.popupChangeState.emit({ popup: popup, visible: visible });
   }

   setItemProperty(component: string, options: Object = {}) {
      this.itemPropertyChange.emit({ component: component, options: options });
   }

}
