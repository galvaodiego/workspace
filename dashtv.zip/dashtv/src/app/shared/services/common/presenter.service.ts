import { Injectable, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({ providedIn: 'root' })
export class PresenterService {

   presenterContext: any;

   @Output() popupState: EventEmitter<any> = new EventEmitter();
   @Output() addBtnClicked: EventEmitter<boolean> = new EventEmitter();

   constructor(
      protected _router: Router
   ) { }

   getAction(context?: string, action?: string) {
      return this.presenterContext[action];
   }

   changePopupState(popup) {
      this.popupState.emit(popup);
   }

   actionFired() {
      this.addBtnClicked.emit(true);
   }

   getRouterUrl() {
      return this._router.url;
   }

}
