import { Injectable } from '@angular/core';
import { LocalStorageService } from 'ngx-webstorage';

import { Usuario } from '../models/usuario.model';
import { ClienteService } from './cliente.service';

@Injectable({ providedIn: 'root' })
export class UsuarioService {

    public _user: Usuario = Usuario.instance;

    constructor(
        private _storage: LocalStorageService,
        private clienteS: ClienteService
    ) { }

    /**
    * Inicia o objeto Usuario na aplicação.
    * Caso exista algum registro do usuário no storage, este método o retorna.
    * Caso contrário, o método formata um objeto para o usuário.
    */
    public init(): Promise<any> {
        return new Promise((resolve, reject) => {
            let data = this._storage.retrieve(this.clienteS.discover() + "-usuario");
            
            if (data == null) {
                this._user.usuario = "";
                this._user.url = "";
                this._user.ambiente = "";
                this._user.codGestao = null;
                this._user.token = "";
                this._user.isLogged = false;
                this._user.listaDashboards = [];
                this._user.selectedDashboard = null;
                this._user.listaModulos = [];
                this._user.selectedModulo = null;
                this._user.selectedDashDescricao = "";
                this._user.tvUsuarioId = null;
                this._user.showProgressBar = true;
                this._user.showMenuOpcoes = false;
                this._user.showIconOpcoes = true;
                this._user.showIconFiltro = false;
                this._user.showIconTemplates = false;
                this._user.showTemplates = false;
                this._user.showFiltroOpcoes = false;
                this._user.userType = null;
                this._user.timerTela = null;
                this._user.identificador = null;
                this._user.cliente = '';
                this._user.filiais = '';
                this._user.codPessoa = null;
                this._user.ultimoLogin = '';
                this._user.plataforma_tipo = null;
            } else {
                this._user.url = data.url;
                this._user.ambiente = data.ambiente;
                this._user.isLogged = data.isLogged;
                this._user.listaDashboards = data.listaDashboards;
                this._user.selectedDashboard = data.selectedDashboard;
                this._user.listaModulos = data.listaModulos;
                this._user.selectedModulo = data.selectedModulo;
                this._user.selectedDashDescricao = data.selectedDashDescricao;
                this._user.tvUsuarioId = data.tvUsuarioId;
                this._user.showProgressBar = data.showProgressBar;
                this._user.showMenuOpcoes = data.showMenuOpcoes;
                this._user.showIconOpcoes = data.showIconOpcoes;
                this._user.showIconFiltro = data.showIconFiltro;
                this._user.showIconTemplates = data.showIconTemplates;
                this._user.showFiltroOpcoes = data.showFiltroOpcoes;
                this._user.showTemplates = data.showTemplates;
                this._user.userType = data._userType;
                this._user.timerTela = data.timerTela;
                this._user.identificador = data.identificador;
                this._user.cliente = data.cliente;
                this._user.filiais = data.filiais;
                this._user.codPessoa = data.codPessoa;
                this._user.ultimoLogin = data.ultimoLogin;
                this._user.plataforma_tipo = data.plataforma_tipo;
                if (data.token != null) {
                    try {
                        let tokenData = JSON.parse(atob(data.token.split(".")[0])).data;
                        this._user.usuario = tokenData._username;
                        this._user.codGestao = tokenData.cod_gestao;
                        this._user.token = data.token;
                        this._user.isLogged = true;
                    } catch (error) {

                    }
                } else {
                    this._user.usuario = data.usuario;
                    this._user.senha = data.senha;
                    this._user.codGestao = data.codGestao;
                    this._user.token = data.token;
                    this.save();
                }
            }
            resolve(this._user);
        })
    }

    /**
    * Salva os dados do usuário do storage.
    */
    public save() {
        let data = {
            usuario: this._user.usuario,
            url: this._user.url,
            ambiente: this._user.ambiente,
            codGestao: this._user.codGestao,
            token: this._user.token,
            isLogged: this._user.isLogged,
            filiais: this._user.filiais,
            listaDashboards: this._user.listaDashboards,
            selectedDashboard: this._user.selectedDashboard,
            listaModulos: this._user.listaModulos,
            selectedModulo: this._user.selectedModulo,
            selectedDashDescricao: this._user.selectedDashDescricao,
            tvUsuarioId: this._user.tvUsuarioId,
            showProgressBar: this._user.showProgressBar,
            showMenuOpcoes: this._user.showMenuOpcoes,
            showIconOpcoes: this._user.showIconOpcoes,
            showIconFiltro: this._user.showIconFiltro,
            showFiltroOpcoes: this._user.showFiltroOpcoes,
            showIconTemplates: this._user.showIconTemplates,
            showTemplates: this._user.showTemplates,
            _userType: this._user.userType,
            timerTela: this._user.timerTela,
            identificador: this._user.identificador,
            cliente: this._user.cliente,
            codPessoa: this._user.codPessoa,
            ultimoLogin: this._user.ultimoLogin,
            plataforma_tipo: this._user.plataforma_tipo
        };
        this._storage.store(this.clienteS.discover() + "-usuario", data);
    }

}