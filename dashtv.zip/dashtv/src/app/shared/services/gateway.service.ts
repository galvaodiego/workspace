import { Injectable } from '@angular/core';
import { Headers, Http } from '@angular/http';
import { Router } from '@angular/router';

import { Usuario } from '../models/usuario.model';

import notify from 'devextreme/ui/notify';

@Injectable({ providedIn: 'root' })
export class GatewayService {

    private _user: Usuario = Usuario.instance;
    private _url: string;

    constructor(
        private _http: Http,
        private _router: Router
    ) { }

    public backendCall(module: string, operation: string, parameters?: any) {
        if (this._user.url == null || this._user.url == "") {
            this._user.url = location.protocol + "//" + location.host;
        }
        this._url = this._user.url + "_remote/gateway.php";

        let headers: Headers = new Headers();
        if (parameters == null) {
            parameters = {};
        }

        let requestData: any = {
            module: module,
            operation: operation,
            parameters: parameters
        };

        headers.append("Content-Type", "application/json");
        if (this._user.token) {
            headers.append("Authorization", "Bearer " + this._user.token);
        } else {
            headers.append("Token-Time-Hours", (180 * 24) + ""); // 180 dias
        }
        //if (this.user.isDebug) {
        headers.append("Debug", "1");
        //}
        headers.append("KMM-Platform", "Web");

        console.log('Requisição ao banco: ', requestData);

        return new Promise((resolvePai, rejectPai) => {
            this.send(this._url, requestData, headers).then(
                (data) => {
                    data = data.json();
                    if (data.result != null) {
                        resolvePai(data.result);
                    } else {
                        resolvePai(data);
                    }
                }
            ).catch(
                (dataError) => {
                    dataError = dataError.json();
                    console.log('dataError', dataError);

                    // Não autorizado - Quando o token é inválido ou expirado
                    if (dataError.code == 401) {
                        notify({
                            message: 'Autenticação expirada. Faça novamente o login.',
                            type: 'error',
                            displayTime: 200000,
                            closeOnClick: true,
                            width: () => window.innerWidth / 1.8
                        });
                        this._user.logout();
                    } else if (dataError.code == 403) {
                        notify({
                            message: dataError.message,
                            type: 'error',
                            displayTime: 200000,
                            closeOnClick: true,
                            width: () => window.innerWidth / 1.8
                        });
                        console.log('dataError', dataError);
                        this._user.logout();
                        this._router.navigate(['']);
                        rejectPai(dataError);
                    } else if (dataError.code == 404) {
                        notify({
                            message: 'Não Encontrado',
                            type: 'error',
                            displayTime: 200000,
                            closeOnClick: true,
                            width: () => window.innerWidth / 1.8
                        });
                        this._user.logout();
                    } else {
                        try {
                            // this.errorM = dataError.message;
                            notify({
                                message: dataError.message,
                                type: 'error',
                                displayTime: 200000,
                                closeOnClick: true,
                                width: () => window.innerWidth / 1.8
                            });
                            console.log('dataError', dataError);
                        } catch (er) {
                            if (this._user.isDebug) {
                                // this.errorM = JSON.stringify(dataError);
                                notify({
                                    message: JSON.stringify(dataError),
                                    type: 'error',
                                    displayTime: 200000,
                                    closeOnClick: true,
                                    width: () => window.innerWidth / 1.8
                                });
                            }
                        }
                        rejectPai(dataError); // Chama o reject do promise de retorno
                    }
                }
            );
        });
    }

    public send(url: string, requestData: any, headers: Headers): Promise<any> {
        return new Promise((resolve, reject) => {
            this._http.post(url, JSON.stringify(requestData), { headers: headers }).subscribe(
                data => resolve(data),
                err => reject(err));
        })

    }



}