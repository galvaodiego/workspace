import { Injectable } from '@angular/core';
import { LocalStorageService } from 'ngx-webstorage';

import { EstruturaOrganizacional } from '../models/organizacional.model';
import { ClienteService } from './cliente.service';

@Injectable({ providedIn: 'root' })
export class EstruturaOrganizacionalService {

   private _org: EstruturaOrganizacional = EstruturaOrganizacional.instance;

   constructor(
      private _storage: LocalStorageService,
      private _clienteS: ClienteService
   ) { }

   /**
   * Inicia o objeto Usuario na aplicação.
   * Caso exista algum registro do usuário no storage, este método o retorna.
   * Caso contrário, o método formata um objeto para o usuário.
   */
   public init(): Promise<any> {
      return new Promise((resolve, reject) => {
         const data = this._storage.retrieve(this._clienteS.discover() + '-organizacional');
         if (data == null) {
            this._org.base = '';
            this._org.usuario = {
               usuario: '',
               usuarioBiId: null
            };
            this._org.configOrgUsuario = [];
            this._org.configOrgUsuario.push({
               listConfigOrg: [],
               configOrgId: null,
               configOrg: '',
               modulo: '',
               moduloId: null,
               niveis: [],
               numModulo: '',
               dashs: []
            });
            this._org.niveis = {
               usuario: this._org.usuario,
               codNivelOrganizacional: '',
               nivel: null,
               organizacional: '',
               organizacionalId: null,
               tipoOrganizacionalId: null,
            };
            this._org.dashs = [];
            this._org.dashs.push({
               id: null,
               descricao: '',
               path: ''
            });
            this._org.permissoes = [];
            this._org.permissoes.push({
               ativo: false,
               codNivelOrganizacional: null,
               ordem: null,
               organizacional: '',
               organizacionalId: null,
               organizacionalIdCorp: null,
               organizacionalIdPai: null,
               tipoOrganizacional: '',
               tipoOrganizacionalId: null,
               usuario: this._org.usuario
            });
         } else {
            this._org.base = data.base;
            this._org.usuario = data.usuario;
            this._org.configOrgUsuario = data.configOrgUsuario;
            this._org.permissoes = data.permissoes;
            this._org.niveis = data.niveis;
            this._org.dashs = data.dashs;
         }
         this.save();
         resolve(this._org);
         return data;
      });
   }

   /**
    * Salva os dados da Estrutura Organizacional no storage.
    */
   public save() {

      const data = {
         base: this._org.base,
         usuario: this._org.usuario,
         configOrgUsuario: this._org.configOrgUsuario,
         permissoes: this._org.permissoes,
         niveis: this._org.niveis,
         dashs: this._org.dashs
      };
      this._storage.store(this._clienteS.discover() + '-organizacional', data);
   }

   /**
   * Limpa os dados da Estrutura Organizacional no storage.
   */
   public logout() {
      localStorage.clear();
   }


   /**
    * Objetivo::
    *  Resgatar o organizacional_id do Nivel Empresa
    */
   public getOrgEmpresa() {
      let organizacional_id: number;
      if (this._org.permissoes.length > 0) {
         organizacional_id = this._org.permissoes[0].organizacionalId;

         for (let i = 0; i < this._org.permissoes.length; i++) {
            const el = this._org.permissoes[i];
            if (el.codNivelOrganizacional.toUpperCase() !== this._clienteS.discover().toUpperCase()) {
               organizacional_id = el.organizacionalId;
            }
         }
      } else {
         organizacional_id = 175; // estava fixo no código..... (By NegoWill);
      }

      return organizacional_id;
   }

}
