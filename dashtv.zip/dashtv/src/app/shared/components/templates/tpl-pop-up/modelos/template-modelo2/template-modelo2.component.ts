import { Component, OnInit, Input } from '@angular/core';

@Component({
   selector: 'app-template-modelo2',
   templateUrl: './template-modelo2.component.html',
   styleUrls: ['./template-modelo2.component.scss']
})
export class TemplateModelo2Component implements OnInit {
   @Input() template: any;
   constructor() { }

   ngOnInit() {
   }

}
