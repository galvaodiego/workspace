import { Component, OnInit, Input } from '@angular/core';

@Component({
   selector: 'app-template-modelo1',
   templateUrl: './template-modelo1.component.html',
   styleUrls: ['./template-modelo1.component.scss']
})
export class TemplateModelo1Component implements OnInit {
   @Input() template: any;
   constructor() { }

   ngOnInit() {
   }

}
