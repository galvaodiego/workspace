import { Injectable } from '@angular/core';
import { DummyService } from './dummy.service';

@Injectable({
   providedIn: 'root'
})
export class TplPopUpService {

   constructor(
      private _dummy: DummyService
   ) { }

   getOpcoesFaturamento() {
      return [
         { tipo_info: 1, descricao: 'Faturamento por período', icone: 'fas fa-chart-line' },
         { tipo_info: 2, descricao: 'Faturamento por veículo', icone: 'fas fa-table' },
         { tipo_info: 3, descricao: 'Faturamento por destino', icone: 'fas fa-table' },
         { tipo_info: 4, descricao: 'Faturamento total', icone: 'kpi' },
         { tipo_info: 5, descricao: 'Faturamento por cliente', icone: 'fas fa-chart-pie' },
         { tipo_info: 6, descricao: 'Faturamento médio por emissão', icone: 'kpi' },
         { tipo_info: 7, descricao: 'Faturamento por mercadoria', icone: 'fas fa-chart-pie' },
         { tipo_info: 8, descricao: 'Faturamento por modalidade', icone: 'fas fa-chart-pie' },
         { tipo_info: 9, descricao: 'Faturamento por carroceria', icone: 'fas fa-chart-pie' },
         { tipo_info: 10, descricao: 'Faturamento total Previsto', icone: 'kpi' },
         { tipo_info: 11, descricao: 'Faturamento Top 10', icone: 'fas fa-chart-bar' },
         { tipo_info: 12, descricao: 'Faturamento por filial', icone: 'fas fa-chart-pie' },
         { tipo_info: 13, descricao: 'Faturamento por filial', icone: 'fas fa-table' },
         { tipo_info: 14, descricao: 'Faturamento por período', icone: 'fas fa-table' },
      ];
   }

   getOpcoesViagens() {
      return [
         { tipo_info: 1, descricao: 'Viagens por cliente', icone: 'fas fa-chart-pie' },
         { tipo_info: 2, descricao: 'Viagens por mercadoria', icone: 'fas fa-chart-pie' },
         { tipo_info: 3, descricao: 'Tonelagem por rota', icone: 'fas fa-table' },
         { tipo_info: 4, descricao: 'Viagens por destino', icone: 'fas fa-chart-bar' },
         { tipo_info: 5, descricao: 'Total de viagens', icone: 'kpi' },
         { tipo_info: 6, descricao: 'Total KM Vazio', icone: 'kpi' },
         { tipo_info: 7, descricao: 'Total tonelagem', icone: 'kpi' },
         { tipo_info: 8, descricao: 'Desbalanço de carga', icone: 'fas fa-chart-bar' },
         { tipo_info: 9, descricao: 'Total KM Carregado', icone: 'kpi' },
         { tipo_info: 10, descricao: 'Total KM Rodado', icone: 'kpi' },
         { tipo_info: 11, descricao: 'Desbalanço de carga', icone: 'fas fa-table' },
         { tipo_info: 12, descricao: 'Total Volume', icone: 'kpi' },
         { tipo_info: 13, descricao: 'Viagens por origem', icone: 'fas fa-chart-bar' },
         { tipo_info: 14, descricao: 'Viagens por origem', icone: 'fas fa-table' },
      ];
   }

   getOpcoesSolicitacoes() {
      return [
         { tipo_info: 1, descricao: 'Nº Solicitações Abertas', icone: 'kpi' },
         { tipo_info: 2, descricao: 'Nº Solicitações Canceladas', icone: 'kpi' },
         { tipo_info: 3, descricao: 'Total de Solicitações', icone: 'kpi' },
         { tipo_info: 4, descricao: 'Nº de Romaneios', icone: 'kpi' },
         { tipo_info: 5, descricao: 'Controle de Solicitações', icone: 'fas fa-chart-bar' },
         { tipo_info: 6, descricao: 'Aguardando emissão', icone: 'fas fa-chart-pie' },
         { tipo_info: 7, descricao: 'Solicitações abertas por operação', icone: 'fas fa-table' },
         { tipo_info: 8, descricao: 'Solicitações abertas', icone: 'fas fa-table' },
         { tipo_info: 9, descricao: 'Romaneios Pendentes de Emissões', icone: 'kpi' },
         { tipo_info: 10, descricao: 'Documentos Emitidos', icone: 'kpi' },
         { tipo_info: 11, descricao: 'Rom. não faturado por operação', icone: 'fas fa-table' },
         { tipo_info: 12, descricao: 'Rom. não faturado', icone: 'fas fa-table' },
         { tipo_info: 13, descricao: 'Emissões por usuário', icone: 'fas fa-table' },
         { tipo_info: 14, descricao: 'Emissões hora a hora', icone: 'fas fa-chart-bar' },
         { tipo_info: 15, descricao: 'Total de CTES emitidos', icone: 'kpi' },
         { tipo_info: 16, descricao: 'Total de CTES cancelados', icone: 'kpi' },
         { tipo_info: 17, descricao: 'CTES Emitidos por operação', icone: 'fas fa-chart-pie' },
         { tipo_info: 18, descricao: 'Lista de CTES cancelados', icone: 'fas fa-chart-pie' },
         { tipo_info: 19, descricao: 'Quantidade de emissões x CCG (Diário)', icone: 'fas fa-chart-bar' },
         { tipo_info: 20, descricao: 'Quantidade de emissões x CCG (Mensal)', icone: 'fas fa-chart-bar' },
         { tipo_info: 21, descricao: 'Rom. não faturado (Tipo documento)', icone: 'fas fa-table' },
      ];
   }

   getOpcoesAutomatizacao() {
      return [
         { tipo_info: 1, descricao: 'Total Emitido', icone: 'kpi' },
         { tipo_info: 2, descricao: 'Total Automatizado', icone: 'kpi' },
         { tipo_info: 3, descricao: '% Automatizado', icone: 'kpi' },
         { tipo_info: 4, descricao: 'Tempo entre emissão da NF e CT-E', icone: 'kpi' },
         { tipo_info: 5, descricao: 'Acompanhamento Mensal', icone: 'fas fa-table' },
         { tipo_info: 6, descricao: 'Integração de NF por Usuário', icone: 'fas fa-table' },
         { tipo_info: 7, descricao: 'Acompanhamento Diário', icone: 'fas fa-table' },
         { tipo_info: 8, descricao: 'Operações Automatizadas', icone: 'fas fa-table' },
      ];
   }

   getDefinicoesFaturamento(tipo) {
      const obj = {};
      switch (tipo) {
         case 1:
            Object.assign(obj, {
               tipo: 'linha-horizontal',
               datasource: this._dummy.getDataSource('charts'),
               tipo_legenda: 'valor',
               titulo: 'Faturamento Anual / Mensal / Semanal'
            });
            return obj;
            break;
         case 2:
            Object.assign(obj, {
               tipo: 'faturamento-por-veiculo',
               datasource: this._dummy.getDataSource('por_veiculo'),
               tipo_legenda: 'valor',
               titulo: 'Faturamento por veículo'
            });
            return obj;
            break;

         case 3:
            Object.assign(obj, {
               tipo: 'faturamento-por-destino',
               datasource: this._dummy.getDataSource('por_destino'),
               tipo_legenda: 'valor',
               titulo: 'Faturamento por destino'
            });
            return obj;
            break;
         case 4:
            Object.assign(obj, {
               tipo: 'box-titulo-valor',
               datasource: 1000000,
               tipo_legenda: 'numero',
               titulo: 'Faturamento total (Anual / Mensal / Semanal)'
            });
            return obj;
            break;
         case 5:
            Object.assign(obj, {
               tipo: 'pie-leg-right',
               datasource: this._dummy.getDataSource('charts'),
               tipo_legenda: 'valor',
               titulo: 'Faturamento por Cliente'
            });
            return obj;
            break;
         case 6:
            Object.assign(obj, {
               tipo: 'box-titulo-valor',
               datasource: 1000,
               tipo_legenda: 'valor',
               titulo: 'Faturamento médio por emissão'
            });
            return obj;
            break;
         case 7:
            Object.assign(obj, {
               tipo: 'pie-leg-right',
               datasource: this._dummy.getDataSource('charts'),
               tipo_legenda: 'valor',
               titulo: 'Faturamento por Mercadoria'
            });
            return obj;
            break;
         case 8:
            Object.assign(obj, {
               tipo: 'pie-leg-right',
               datasource: this._dummy.getDataSource('charts'),
               tipo_legenda: 'valor',
               titulo: 'Faturamento por Modalidade'
            });
            return obj;
            break;
         case 9:
            Object.assign(obj, {
               tipo: 'pie-leg-right',
               datasource: this._dummy.getDataSource('charts'),
               tipo_legenda: 'valor',
               titulo: 'Faturamento por Carroceria'
            });
            return obj;
            break;
         case 10:
            Object.assign(obj, {
               tipo: 'box-titulo-valor',
               af: null,
               vf: null,
               titulo: 'Faturamento total Previsto (Anual / Mensal / Semanal)',
               datasource: 999999999
            });
            return obj;
            break;
         case 11:
            Object.assign(obj, {
               tipo: 'barra-horizontal',
               af: null,
               vf: null,
               titulo: 'Faturamento Top 10',
               datasource: this._dummy.getDataSource('charts')
            });
            return obj;
            break;
         case 12:
            Object.assign(obj, {
               tipo: 'pie-leg-right',
               tipo_legenda: 'valor',
               titulo: 'Faturamento por Filial',
               datasource: this._dummy.getDataSource('charts')
            });
            return obj;
            break;
         case 14:
            Object.assign(obj, {
               tipo: 'faturamento-por-periodo-tbl',
               tipo_legenda: 'valor',
               titulo: 'Faturamento Anual / Mensal / Semanal',
               datasource: this._dummy.getDataSource('por_periodo_tbl')
            });
            return obj;
            break;
      }
   }

   getDefinicoesViagens(tipo) {
      const obj = {};
      switch (tipo) {
         case 1:
            Object.assign(obj, {
               tipo: 'pie-leg-right',
               datasource: this._dummy.getDataSource('charts'),
               tipo_legenda: 'numero',
               titulo: 'Viagens por cliente'
            });
            return obj;
            break;
         case 2:
            Object.assign(obj, {
               tipo: 'pie-leg-right',
               datasource: this._dummy.getDataSource('charts'),
               tipo_legenda: 'numero',
               titulo: 'Viagens por mercadoria'
            });
            return obj;
            break;

         case 3:
            Object.assign(obj, {
               tipo: 'tonelagem-por-rota',
               datasource: this._dummy.getDataSource('tonelagem_rota'),
               tipo_legenda: null,
               titulo: 'Tonelagem por rota'
            });
            return obj;
            break;
         case 4:
            Object.assign(obj, {
               tipo: 'barra-horizontal',
               datasource: this._dummy.getDataSource('charts'),
               tipo_legenda: 'numero',
               titulo: 'Viagens por destino'
            });
            return obj;
            break;
         case 5:
            Object.assign(obj, {
               tipo: 'box-titulo-numero',
               datasource: 100,
               tipo_legenda: null,
               titulo: 'Total Viagens'
            });
            return obj;
            break;
         case 6:
            Object.assign(obj, {
               tipo: 'box-titulo-numero',
               datasource: 1000,
               tipo_legenda: null,
               titulo: 'Total KM Vazio'
            });
            return obj;
            break;
         case 7:
            Object.assign(obj, {
               tipo: 'box-titulo-numero',
               datasource: 999999999,
               tipo_legenda: null,
               titulo: 'Total tonelagem'
            });
            return obj;
            break;
         case 8:
            Object.assign(obj, {
               tipo: 'desbalanco-carga',
               af: null,
               vf: null,
               titulo: 'Desbalanço de carga ',
               datasource: this._dummy.getDataSource('desbalanco'),
               tipo_legenda: null

            });
            return obj;
            break;
         case 9:
            Object.assign(obj, {
               tipo: 'box-titulo-numero',
               datasource: 999999999,
               tipo_legenda: null,
               titulo: 'Total KM Carregado'
            });
            return obj;
            break;
         case 10:
            Object.assign(obj, {
               tipo: 'box-titulo-numero',
               datasource: 999999999,
               tipo_legenda: null,
               titulo: 'Total KM Rodado'
            });
            return obj;
            break;
         case 11:
            Object.assign(obj, {
               tipo: 'desbalanco-carga-tbl',
               datasource: this._dummy.getDataSource('desbalanco_tbl'),
               tipo_legenda: null,
               titulo: 'Desbalanço de carga'
            });
            return obj;
            break;
         case 12:
            Object.assign(obj, {
               tipo: 'box-titulo-numero',
               datasource: 999999999,
               tipo_legenda: null,
               titulo: 'Total Volume'
            });
            return obj;
            break;
         case 13:
            Object.assign(obj, {
               tipo: 'barra-horizontal',
               datasource: this._dummy.getDataSource('charts'),
               tipo_legenda: 'numero',
               titulo: 'Viagens por origem'
            });
            return obj;
            break;
         case 14:
            Object.assign(obj, {
               tipo: 'viagens-por-origem',
               datasource: this._dummy.getDataSource('por_origem_tbl'),
               tipo_legenda: null,
               titulo: 'Viagens por origem'
            });
            return obj;
            break;
      }
   }

   getDefinicoesSolitacoes(tipo) {
      const obj = {};
      switch (tipo) {
         case 1:
            Object.assign(obj, {
               tipo: 'box-titulo-numero',
               datasource: 100,
               tipo_legenda: 'numero',
               titulo: 'Nº Solicitações Abertas'
            });
            return obj;
            break;
         case 2:
            Object.assign(obj, {
               tipo: 'box-titulo-numero',
               datasource: 100,
               tipo_legenda: 'numero',
               titulo: 'Nº Solicitações Canceladas'
            });
            return obj;
            break;

         case 3:
            Object.assign(obj, {
               tipo: 'box-titulo-numero',
               datasource: 100,
               tipo_legenda: 'numero',
               titulo: 'Total de Solicitações'
            });
            return obj;
            break;
         case 4:
            Object.assign(obj, {
               tipo: 'box-titulo-numero',
               datasource: 100,
               tipo_legenda: 'numero',
               titulo: 'Nº de Romaneios'
            });
            return obj;
            break;
         case 5:
            Object.assign(obj, {
               tipo: 'barra-vertical-dupla-variavel',
               datasource: this._dummy.getDataSource('charts'),
               tipo_legenda: 'numero',
               cores_series: ['#007bff', '#28a745'],
               titulo: 'Controle de Solicitações'
            });
            return obj;
            break;
         case 6:
            Object.assign(obj, {
               tipo: 'doughnut-leg-right',
               datasource: this._dummy.getDataSource('charts'),
               tipo_legenda: 'numero',
               cores_series: ['#28a745', '#dc3545'],
               titulo: 'Aguardando emissão'
            });
            return obj;
            break;
         case 7:
            Object.assign(obj, {
               tipo: 'abertas-operacao-tbl',
               af: null,
               vf: null,
               titulo: 'Solicitações abertas por operação',
               datasource: this._dummy.getDataSource('abertas-operacao-tbl'),
               tipo_legenda: null

            });
            return obj;
            break;
         case 8:
            Object.assign(obj, {
               tipo: 'solicitacoes-abertas-tbl',
               af: null,
               vf: null,
               titulo: 'Solicitações abertas',
               datasource: this._dummy.getDataSource('solicitacoes-abertas-tbl'),
               tipo_legenda: null
            });
            return obj;
            break;
         case 9:
            Object.assign(obj, {
               tipo: 'box-titulo-numero',
               datasource: 100,
               tipo_legenda: 'numero',
               titulo: 'Romaneios pend. de emissão'
            });
            return obj;
            break;
         case 10:
            Object.assign(obj, {
               tipo: 'box-titulo-numero',
               datasource: 100,
               tipo_legenda: 'numero',
               titulo: 'Documentos Emitidos'
            });
            return obj;
            break;
         case 11:
            Object.assign(obj, {
               tipo: 'rom-nao-fatu-ope-tbl',
               af: null,
               vf: null,
               titulo: 'Romaneios não faturados por operação',
               datasource: this._dummy.getDataSource('rom-nao-fatu-ope-tbl'),
               tipo_legenda: null
            });
            return obj;
            break;
         case 12:
            Object.assign(obj, {
               tipo: 'rom-nao-fatu-tbl',
               af: null,
               vf: null,
               titulo: 'Romaneios não faturados',
               datasource: this._dummy.getDataSource('rom-nao-fatu-tbl'),
               tipo_legenda: null
            });
            return obj;
            break;
         case 13:
            Object.assign(obj, {
               tipo: 'emiss-por-usuario-tbl',
               af: null,
               vf: null,
               titulo: 'Emissões por usuário',
               datasource: this._dummy.getDataSource('emiss-por-usuario-tbl'),
               tipo_legenda: null
            });
            return obj;
            break;
         case 14:
            Object.assign(obj, {
               tipo: 'barra-vertical',
               af: null,
               vf: null,
               tipo_legenda: 'numero',
               titulo: 'Emissões hora a hora',
               datasource: this._dummy.getDataSource('charts'),
            });
            return obj;
            break;
         case 15:
            Object.assign(obj, {
               tipo: 'box-titulo-numero',
               datasource: 100,
               tipo_legenda: 'numero',
               titulo: 'Total de CTES emitidos'
            });
            return obj;
            break;
         case 16:
            Object.assign(obj, {
               tipo: 'box-titulo-numero',
               datasource: 100,
               tipo_legenda: 'numero',
               titulo: 'Total de CTES cancelados'
            });
            return obj;
            break;
         case 17:
            Object.assign(obj, {
               tipo: 'pie-leg-right',
               af: null,
               vf: null,
               titulo: 'CTES emitidos por operação',
               datasource: this._dummy.getDataSource('charts'),
               tipo_legenda: null
            });
            return obj;
            break;
         case 18:
            Object.assign(obj, {
               tipo: 'pie-leg-right',
               af: null,
               vf: null,
               titulo: 'CTES cancelados',
               datasource: this._dummy.getDataSource('charts'),
               tipo_legenda: null
            });
            return obj;
            break;
         case 19:
            Object.assign(obj, {
               tipo: 'barra-horizontal',
               af: null,
               vf: null,
               tipo_legenda: 'numero',
               titulo: 'Quantidade de emissões X CCG (Diário)',
               datasource: this._dummy.getDataSource('charts'),
            });
            return obj;
            break;
         case 20:
            Object.assign(obj, {
               tipo: 'barra-horizontal',
               af: null,
               vf: null,
               tipo_legenda: 'numero',
               titulo: 'Quantidade de emissões X CCG (Mensal)',
               datasource: this._dummy.getDataSource('charts'),
            });
            return obj;
            break;
         case 21:
            Object.assign(obj, {
               tipo: 'rom-nao-fatu-td-tbl',
               af: null,
               vf: null,
               titulo: 'Romaneios não faturados (Tipo Documento)',
               datasource: this._dummy.getDataSource('rom-nao-fatu-tbl'),
               tipo_legenda: null
            });
            return obj;
            break;
      }
   }

   getDefinicoesAutomatizacao(tipo) {
      const obj = {};
      switch (tipo) {
         case 1:
            Object.assign(obj, {
               tipo: 'kpi-automatizacao-money',
               datasource: { faturamento: 10000, quantidade: 50 },
               tipo_legenda: 'numero',
               titulo: 'Total Emitido'
            });
            return obj;
            break;
         case 2:
            Object.assign(obj, {
               tipo: 'kpi-automatizacao-money',
               datasource: { faturamento: 10000, quantidade: 50 },
               tipo_legenda: 'numero',
               titulo: 'Total Automatizado'
            });
            return obj;
            break;

         case 3:
            Object.assign(obj, {
               tipo: 'kpi-automatizacao-percent',
               datasource: { porcentagem: 10, quantidade: 50 },
               tipo_legenda: 'numero',
               titulo: '% Automatizado'
            });
            return obj;
            break;
         case 4:
            Object.assign(obj, {
               tipo: 'kpi-automatizacao-regular',
               datasource: '1 min e 30s',
               tipo_legenda: 'numero',
               titulo: 'Tempo entre emissão da NF e CT-E'
            });
            return obj;
            break;
         case 5:
            Object.assign(obj, {
               tipo: 'acompanhamento-mensal-tbl',
               af: null,
               vf: null,
               tipo_legenda: null,
               datasource: this._dummy.getDataSource('acompanhamento-mensal-tbl'),
               titulo: 'Acompanhamento Mensal'
            });
            return obj;
            break;
         case 6:
            Object.assign(obj, {
               tipo: 'int-nf-usuario-tbl',
               af: null,
               vf: null,
               tipo_legenda: null,
               datasource: this._dummy.getDataSource('int-nf-usuario-tbl'),
               titulo: 'Integração de NF por Usuário'
            });
            return obj;
            break;
         case 7:
            Object.assign(obj, {
               tipo: 'acompanhamento-diario-tbl',
               af: null,
               vf: null,
               tipo_legenda: null,
               datasource: this._dummy.getDataSource('acompanhamento-diario-tbl'),
               titulo: 'Acompanhamento Diário'
            });
            return obj;
            break;
         case 8:
            Object.assign(obj, {
               tipo: 'operacoes-automatizadas-tbl',
               af: null,
               vf: null,
               tipo_legenda: null,
               datasource: this._dummy.getDataSource('operacoes-automatizadas-tbl'),
               titulo: 'Operações Automatizadas'
            });
            return obj;
            break;
      }
   }
}
