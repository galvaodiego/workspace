import { Component, OnInit, Input } from '@angular/core';

@Component({
   selector: 'app-template-modelo5',
   templateUrl: './template-modelo5.component.html',
   styleUrls: ['./template-modelo5.component.scss']
})
export class TemplateModelo5Component implements OnInit {
   @Input() template: any;

   constructor() { }

   ngOnInit() {
   }

}
