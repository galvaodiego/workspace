import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-template-modelo8',
  templateUrl: './template-modelo8.component.html',
  styleUrls: ['./template-modelo8.component.scss']
})
export class TemplateModelo8Component implements OnInit {
  @Input() template: any;
  constructor() { }

  ngOnInit() {
  }

}
