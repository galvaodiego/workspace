import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TemplateModelo7Component } from './template-modelo7.component';

describe('TemplateModelo7Component', () => {
  let component: TemplateModelo7Component;
  let fixture: ComponentFixture<TemplateModelo7Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TemplateModelo7Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TemplateModelo7Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
