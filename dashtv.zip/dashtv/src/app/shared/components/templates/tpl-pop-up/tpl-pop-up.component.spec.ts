import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TplPopUpComponent } from './tpl-pop-up.component';

describe('TplPopUpComponent', () => {
  let component: TplPopUpComponent;
  let fixture: ComponentFixture<TplPopUpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TplPopUpComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TplPopUpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
