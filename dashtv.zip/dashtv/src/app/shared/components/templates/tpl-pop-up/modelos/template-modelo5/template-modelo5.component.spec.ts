import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TemplateModelo5Component } from './template-modelo5.component';

describe('TemplateModelo5Component', () => {
  let component: TemplateModelo5Component;
  let fixture: ComponentFixture<TemplateModelo5Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TemplateModelo5Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TemplateModelo5Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
