import { Component, OnInit, Input } from '@angular/core';

@Component({
   selector: 'app-template-modelo6',
   templateUrl: './template-modelo6.component.html',
   styleUrls: ['./template-modelo6.component.scss']
})
export class TemplateModelo6Component implements OnInit {
   @Input() template: any;

   constructor() { }

   ngOnInit() {
   }

}
