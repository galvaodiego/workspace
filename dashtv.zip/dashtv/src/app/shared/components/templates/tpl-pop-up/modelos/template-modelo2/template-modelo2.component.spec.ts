import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TemplateModelo2Component } from './template-modelo2.component';

describe('TemplateModelo2Component', () => {
  let component: TemplateModelo2Component;
  let fixture: ComponentFixture<TemplateModelo2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TemplateModelo2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TemplateModelo2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
