import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TemplateModelo6Component } from './template-modelo6.component';

describe('TemplateModelo6Component', () => {
  let component: TemplateModelo6Component;
  let fixture: ComponentFixture<TemplateModelo6Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TemplateModelo6Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TemplateModelo6Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
