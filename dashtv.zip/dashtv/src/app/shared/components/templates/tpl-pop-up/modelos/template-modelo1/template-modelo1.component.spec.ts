import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TemplateModelo1Component } from './template-modelo1.component';

describe('TemplateModelo1Component', () => {
  let component: TemplateModelo1Component;
  let fixture: ComponentFixture<TemplateModelo1Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TemplateModelo1Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TemplateModelo1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
