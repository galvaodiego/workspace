import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TemplateModelo8Component } from './template-modelo8.component';

describe('TemplateModelo8Component', () => {
  let component: TemplateModelo8Component;
  let fixture: ComponentFixture<TemplateModelo8Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TemplateModelo8Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TemplateModelo8Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
