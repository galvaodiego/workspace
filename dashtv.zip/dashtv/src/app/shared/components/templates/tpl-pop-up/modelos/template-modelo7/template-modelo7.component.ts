import { Component, OnInit, Input } from '@angular/core';
import { SolicitacoesService } from 'src/app/modulos/logistica/services/solicitacoes.service';
import * as moment from 'moment';
@Component({
   selector: 'app-template-modelo7',
   templateUrl: './template-modelo7.component.html',
   styleUrls: ['./template-modelo7.component.scss']
})
export class TemplateModelo7Component implements OnInit {
   @Input() template: any;
   ultimaAtualizacao: string = null;
   constructor(
      private solicitacaoService: SolicitacoesService
   ) {
      if (this.solicitacaoService.ultimaAtualizacao) {
         this.ultimaAtualizacao = solicitacaoService.ultimaAtualizacao;
      } else {
         this.ultimaAtualizacao = moment().format();
      }
   }

   ngOnInit() {
   }

}
