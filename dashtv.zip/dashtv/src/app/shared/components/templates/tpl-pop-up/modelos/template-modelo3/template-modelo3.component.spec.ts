import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TemplateModelo3Component } from './template-modelo3.component';

describe('TemplateModelo3Component', () => {
  let component: TemplateModelo3Component;
  let fixture: ComponentFixture<TemplateModelo3Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TemplateModelo3Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TemplateModelo3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
