import { Component, OnInit, Input } from '@angular/core';

@Component({
   selector: 'app-template-modelo3',
   templateUrl: './template-modelo3.component.html',
   styleUrls: ['./template-modelo3.component.scss']
})
export class TemplateModelo3Component implements OnInit {
   @Input() template: any;
   constructor() { }

   ngOnInit() {
   }

}
