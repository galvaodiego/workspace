import { Injectable } from '@angular/core';
import * as moment from 'moment';
const now = moment();
const meses = [
   'Jan',
   'Fev',
   'Mar',
   'Abr',
   'Mai',
   'Jun',
   'Jul',
   'Ago',
   'Set',
   'Out',
   'Nov',
   'Dez',
];

const charts_datasource = [];
for (let index = 1; index < 11; index++) {
   charts_datasource.push({
      indicador: 'Indicador ' + index,
      valor: 100 * index,
      valor2: 200 * index,
   });
}

const charts_datasource_anual = [];
for (let index = 1; index < 13; index++) {
   charts_datasource_anual.push({
      indicador: meses[index - 1],
      valor: 1000 * index,
      meta: 900 * index
   });
}

const por_veiculo_datasource = [];
for (let index = 1; index < 11; index++) {
   por_veiculo_datasource.push({ '#': index, placa: 'Placa ' + index, modelo: 'Modelo ' + index, valor: 1000 * index });
}

const por_destino_datasource = [];
for (let index = 1; index < 11; index++) {
   por_destino_datasource.push({ '#': index, destino: 'Destino ' + index, valor: 1000 * index });
}

const por_filial = [];
for (let index = 1; index < 11; index++) {
   por_filial.push({ '#': index, filial: 'Filial ' + index, valor: 1000 * index });
}

const abertasOperacaoTbl_datasource = [];
for (let index = 1; index < 11; index++) {
   abertasOperacaoTbl_datasource.push({ qtde: index * 10, operacao: 'OPERAÇÃO ' + index });
}

const solicitacoesAbertasTbl_datasource = [];
for (let index = 1; index < 11; index++) {
   solicitacoesAbertasTbl_datasource.push(
      {
         SOLICITACAO_CARGA_ID: index * 1000,
         ORIGEM_MUNICIPIO_UF: 'SP',
         DESTINO_MUNICIPIO_UF: 'MG',
         OPERACAO: 'EXEMPLO ' + index,
         DATA_CARREGAMENTO_INICIO: moment(now).add(index, 'days')
      }
   );
}

const romNaoFatuOpeTbl_datasource = [];
for (let index = 1; index < 11; index++) {
   romNaoFatuOpeTbl_datasource.push({ qtde: index * 10, operacao: 'OPERAÇÃO ' + index });
}

const romNaoFatuTbl_datasource = [];
for (let index = 1; index < 11; index++) {
   romNaoFatuTbl_datasource.push(
      {
         NUM_ROMANEIO: 10000 + index,
         CLIENTE_MOTORISTA: 'EXEMPLO ' + index,
         ORIGEM_MUNICIPIO_UF: 'SP',
         DESTINO_MUNICIPIO_UF: 'SP',
         OPERACAO: 'EXEMPLO ' + index,
         DATA_TERMINO_CARGA: moment(now).add(index, 'days'),
         TEMPO_AGUARDANDO: 'EXEMPLO ' + index
      }
   );
}

const emissPorUsuario_datasource = [];
for (let index = 1; index < 11; index++) {
   emissPorUsuario_datasource.push(
      {
         qtde: index * 10,
         user_insert: 'USUARIO ' + index,
         ctes_emitido_dia: index + 10,
         ctes_cancelados_dia: index + 20,
         ctes_cancelados: index + 30,
         ctes_emitido_mes: index + 500,
         ctes_cancelados_mes: index + 100,
         acuracia_mes: index + 1000
      }
   );
}

const tonelagem_rota_datasource = [];
for (let index = 1; index < 11; index++) {
   tonelagem_rota_datasource.push({ rota: 'Rota ' + index, peso: 500 + index });
}


const desbalanco_datasource = {
   'unicos': ['MG', 'PR', 'SC', 'SP', 'RS'],
   'datasource': [
      {
         'origem': 'RS',
         'MG': 1,
         'PR': 5,
         'SP': 3,
         'SC': 5

      },
      {
         'origem': 'MG',
         'RS': 2,
         'PR': 5,
         'SP': 3,
         'SC': 5
      },
      {
         'origem': 'PR',
         'RS': 3,
         'MG': 6,
         'SP': 4,
         'SC': 1
      }
   ]
};

const desbalanco_datasource_tbl = [
   {
      'origem': 'MG',
      'destinos': [
         {
            'destino': 'RS',
            'viagens': 3
         },
         {
            'destino': 'PR',
            'viagens': 6
         },
         {
            'destino': 'SP',
            'viagens': 4
         },
         {
            'destino': 'SC',
            'viagens': 1
         }
      ]
   },
   {
      'origem': 'PR',
      'destinos': [
         {
            'destino': 'RS',
            'viagens': 3
         },
         {
            'destino': 'MG',
            'viagens': 6
         },
         {
            'destino': 'SP',
            'viagens': 4
         },
         {
            'destino': 'SC',
            'viagens': 1
         }
      ]
   },
   {
      'origem': 'RS',
      'destinos': [
         {
            'destino': 'PR',
            'viagens': 3
         },
         {
            'destino': 'MG',
            'viagens': 6
         },
         {
            'destino': 'SP',
            'viagens': 4
         },
         {
            'destino': 'SC',
            'viagens': 1
         }
      ]
   },
   {
      'origem': 'SC',
      'destinos': [
         {
            'destino': 'PR',
            'viagens': 3
         },
         {
            'destino': 'MG',
            'viagens': 6
         },
         {
            'destino': 'SP',
            'viagens': 4
         },
         {
            'destino': 'RS',
            'viagens': 1
         }
      ]
   },
];

const por_origem_datasource_tbl = [];
for (let index = 1; index < 11; index++) {
   por_origem_datasource_tbl.push({ origem: 'Origem ' + index, tonelagem: 10000 + index, viagens: 100 + index });
}

const por_periodo_datasource_tbl = [];
for (let index = 1; index < 31; index++) {
   por_periodo_datasource_tbl.push({
      data: moment(now).add(index, 'days').format('DD/MM/YYYY'),
      valor: 1000 * index,
      meta: 1500 * index
   });
}

const acompanhamento_mensal_tbl = [];
for (let index = 1; index < 10; index++) {
   acompanhamento_mensal_tbl.push({
      cliente: 'Cliente ' + index,
      faturamento: 1000 * index,
      fat_automatizado: 500 * index,
      operacoes: 10 * index,
      automatizadas: 8 * index
   });
}
const int_nf_usuario_tbl = [];
for (let index = 1; index < 10; index++) {
   int_nf_usuario_tbl.push({
      usuario: 'Usuario ' + index,
      quantidade: 10 * index
   });
}
const acompanhamento_diario_tbl = [];
for (let index = 1; index < 10; index++) {
   acompanhamento_diario_tbl.push({
      data: moment(now).add(index, 'days').format('DD/MM/YYYY'),
      total_cte: 100 * index,
      percent_automatizado: 0.10 * index,
      cte_automacao: 10 * index
   });
}
const operacoes_automatizadas_tbl = [];
for (let index = 1; index < 10; index++) {
   operacoes_automatizadas_tbl.push({
      cliente: 'Cliente ' + index,
      operacoes_auto: index
   });
}

@Injectable({
   providedIn: 'root'
})
export class DummyService {

   constructor() { }
   getDataSource(tipo) {
      switch (tipo) {
         case 'charts':
            return charts_datasource;
         case 'charts_anual':
            return charts_datasource_anual;
         case 'por_veiculo':
            return por_veiculo_datasource;
         case 'por_destino':
            return por_destino_datasource;
         case 'por_filial':
            return por_filial;
         case 'abertas-operacao-tbl':
            return abertasOperacaoTbl_datasource;
         case 'solicitacoes-abertas-tbl':
            return solicitacoesAbertasTbl_datasource;
         case 'rom-nao-fatu-ope-tbl':
            return romNaoFatuOpeTbl_datasource;
         case 'rom-nao-fatu-tbl':
            return romNaoFatuTbl_datasource;
         case 'emiss-por-usuario-tbl':
            return emissPorUsuario_datasource;
         case 'tonelagem_rota':
            return tonelagem_rota_datasource;
         case 'desbalanco':
            return desbalanco_datasource;
         case 'desbalanco_tbl':
            return desbalanco_datasource_tbl;
         case 'por_origem_tbl':
            return por_origem_datasource_tbl;
         case 'por_periodo_tbl':
            return por_periodo_datasource_tbl;
         case 'acompanhamento-mensal-tbl':
            return acompanhamento_mensal_tbl;
         case 'int-nf-usuario-tbl':
            return int_nf_usuario_tbl;
         case 'acompanhamento-diario-tbl':
            return acompanhamento_diario_tbl;
         case 'operacoes-automatizadas-tbl':
            return operacoes_automatizadas_tbl;

      }
   }
}
