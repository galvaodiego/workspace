import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TemplateModelo4Component } from './template-modelo4.component';

describe('TemplateModelo4Component', () => {
  let component: TemplateModelo4Component;
  let fixture: ComponentFixture<TemplateModelo4Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TemplateModelo4Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TemplateModelo4Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
