import { Component, OnInit, Output, EventEmitter, ViewChild } from '@angular/core';
import { DxPopupComponent } from 'devextreme-angular';
import { TplPopUpService } from './tpl-pop-up.service';
import { GatewayService } from 'src/app/shared/services/gateway.service';
import { NotificacaoService } from 'src/app/shared/services/common/notificacao.service';
import * as _ from 'underscore';
import { Router } from '@angular/router';
import { ClienteService } from 'src/app/shared/services/cliente.service';
import { TemplateService } from 'src/app/shared/services/template.service';


@Component({
   selector: 'app-tpl-pop-up',
   templateUrl: './tpl-pop-up.component.html',
   styleUrls: ['./tpl-pop-up.component.scss']
})
export class TplPopUpComponent implements OnInit {
   @Output() resposta = new EventEmitter();
   @ViewChild('popSlots', { static: true }) popSlots: DxPopupComponent;
   tipo: string;
   opcoes_slots: any;
   opcoes_templates: any = [
      { modelo_id: 1, descricao: 'Modelo 1' },
      { modelo_id: 2, descricao: 'Modelo 2' },
      { modelo_id: 3, descricao: 'Modelo 3' },
      { modelo_id: 4, descricao: 'Modelo 4' },
      { modelo_id: 5, descricao: 'Modelo 5' },
      { modelo_id: 6, descricao: 'Modelo 6' },
      { modelo_id: 7, descricao: 'Modelo 7' },
      { modelo_id: 8, descricao: 'Modelo 8' },
   ];
   modelo_id = 0;
   tipo_slot = 0;
   showPop = false;
   popTitle = 'Configuração de Área';
   slot_clicado = 0;
   dimensoes = {};
   form_modelo = {
      slots: [0, 0, 0, 0, 0, 0, 0, 0]
   };
   contentHeight: number;
   org: any;
   usuario: any;
   template: any;
   dash: any;
   dataModel: any = {
      modelo_id: 0,
      dash_id: 0,
      usuario_bi_id: 0,
      slots: []
   };
   dummy: any = {};

   constructor(
      private _popUpService: TplPopUpService,
      private _gateway: GatewayService,
      private _notificacao: NotificacaoService,
      private _clienteS: ClienteService,
      private _route: Router,
      private _templateService: TemplateService
   ) {
      switch (this._route.url) {
         case '/financeiro/faturamento':
            this.tipo = 'faturamento';
            this.opcoes_slots = this._popUpService.getOpcoesFaturamento();
            break;
         case '/logistica/viagens':
            this.tipo = 'viagens';
            this.opcoes_slots = this._popUpService.getOpcoesViagens();
            break;
         case '/logistica/solicitacoes':
         case '/logistica/central-de-carga':
            this.tipo = 'solicitacoes';
            this.opcoes_slots = this._popUpService.getOpcoesSolicitacoes();
            break;
         case '/logistica/automatizacao':
            this.tipo = 'automatizacao';
            this.opcoes_slots = this._popUpService.getOpcoesAutomatizacao();
            break;
         default:
            this.tipo = '';
            break;
      }

      this.opcoes_slots = _.sortBy(this.opcoes_slots, 'descricao');
   }

   ngOnInit() {
      this.org = JSON.parse(localStorage.getItem('kmm_bi-dash|' + this._clienteS.discover() + '-organizacional'));
      this.usuario = JSON.parse(localStorage.getItem('kmm_bi-dash|' + this._clienteS.discover() + '-usuario'));
      this.dash = this.usuario.listaDashboards.filter(element => {
         switch (this.tipo) {
            case 'faturamento':
               return element.path === 'financeiro/faturamento';
            case 'viagens':
               return element.path === 'logistica/viagens';
            case 'solicitacoes':
               return element.path === 'logistica/central-de-carga' || element.path === 'logistica/solicitacoes';
            case 'automatizacao':
               return element.path === 'logistica/automatizacao';
         }
      });
      const parametros = {
         usuario_bi_id: this.org.usuarioBiId ? this.org.usuarioBiId : this.org.usuario.usuarioBiId,
         dash_id: this.dash[0].dash_id
      };

      this._templateService.backendCall(parametros, 'post', 'get').then((res: any) => {
         if(res.dados && res.dados.length > 0){
            localStorage.setItem('template-' + this.tipo, JSON.stringify(res.dados[0]));
         }
         this.template = JSON.parse(localStorage.getItem('template-' + this.tipo));
         if (this.template) {
            if (this.template.modelo_id) {
               this.modelo_id = this.template.modelo_id;
            }
         }
      })
   }

   selectSlot(slot) {
      this.showPop = true;
      this.popTitle = 'Configuração: ÁREA ' + slot;
      this.slot_clicado = slot;
      this.tipo_slot = this.form_modelo.slots[this.slot_clicado - 1];
   }

   salvarSlot() {
      if (this.slot_clicado > 0) {
         if (this.valida_slot(this.slot_clicado, this.tipo_slot, this.modelo_id)) {
            this.form_modelo.slots[this.slot_clicado - 1] = this.tipo_slot;
            Object.assign(this.dataModel, {
               usuario_bi_id: this.org.usuario.usuarioBiId,
               modelo_id: this.modelo_id,
               slots: this.form_modelo.slots
            });
            this.tipo_slot = 0;

            localStorage.setItem('template-' + this.tipo, JSON.stringify(this.dataModel));
            this.setDummy(this.form_modelo.slots, this.tipo);
            this.popSlots.instance.hide();

         } else {
            this._notificacao.toast('Esta área não é compatível com este tipo de informação', 'error');
         }
      }

   }

   valida_slot(slot_clicado, tipo_slot, modelo_id) {
      const kpi = this.opcoes_slots.filter(e => {
         return e.icone === 'kpi';
      });
      const outros = this.opcoes_slots.filter(e => {
         return e.icone !== 'kpi';
      });
      const result_kpi = kpi.map(a => a.tipo_info);
      const result_outros = outros.map(a => a.tipo_info);

      let permitidos = [];
      switch (modelo_id) {
         case 1: // 4 e 6 KPI
            switch (slot_clicado) {
               case 1:
               case 2:
               case 3:
               case 5:
               case 7:
                  permitidos = result_outros;
                  break;

               case 4:
               case 6:
                  permitidos = result_kpi;
                  break;
            }

            break;
         case 2: //
            switch (slot_clicado) {
               case 1:
               case 5:
               case 6:
               case 7:
                  permitidos = result_outros;
                  break;

               case 2:
               case 3:
               case 4:
                  permitidos = result_kpi;
                  break;
            }
            break;
         case 3:
            switch (slot_clicado) {
               case 1:
               case 2:
               case 3:
               case 6:
                  permitidos = result_outros;
                  break;

               case 4:
               case 5:
                  permitidos = result_kpi;
                  break;
            }
            break;
         case 4:
            switch (slot_clicado) {
               case 1:
               case 2:
               case 3:
               case 4:
               case 7:
                  permitidos = result_outros;
                  break;

               case 5:
               case 6:
                  permitidos = result_kpi;
                  break;
            }
            break;
         case 5:
            switch (slot_clicado) {
               case 1:
               case 2:
               case 3:
               case 4:
                  permitidos = result_outros;
                  break;

               case 5:
               case 6:
               case 7:
                  permitidos = result_kpi;
                  break;
            }

            break;
         case 6:
            switch (slot_clicado) {
               case 1:
               case 5:
               case 6:
               case 7:
                  permitidos = result_outros;
                  break;

               case 2:
               case 3:
               case 4:
                  permitidos = result_kpi;
                  break;
            }
            break;
         case 7:
            switch (slot_clicado) {
               case 1:
               case 2:
               case 3:
               case 4:
                  permitidos = result_kpi;
                  break;

               case 5:
               case 6:
               case 7:
               case 8:
                  permitidos = result_outros;
                  break;
            }

            break;
         case 8:
            switch (slot_clicado) {
               case 1:
               case 2:
               case 3:
               case 4:
                  permitidos = result_kpi;
                  break;

               case 5:
               case 6:
               case 7:
               case 8:
                  permitidos = result_outros;
                  break;
            }

            break;
      }

      if (permitidos.indexOf(tipo_slot) !== -1) {
         return true;
      } else {
         return false;
      }
   }

   monta_form(modelo) {

      if (this.template) {
         if (modelo !== this.template.modelo_id) {
            this.form_modelo.slots = [0, 0, 0, 0, 0, 0, 0, 0];
            this.dataModel = {
               modelo_id: 0,
               usuario_bi_id: 0,
               slots: []
            };
            this.setDummy(this.form_modelo.slots, this.tipo);
         } else {
            this.dataModel = this.template;
            this.form_modelo.slots = this.template.slots;
            this.setDummy(this.template.slots, this.tipo);
         }
      } else {
         switch (modelo) {
            case 1:
               Object.assign(this.form_modelo, {
                  slots: [0, 0, 0, 0, 0, 0, 0, 0]
               });
               break;

            default:
               break;
         }

      }
   }

   setDummy(slots, tipo) {
      for (let index = 0; index < slots.length; index++) {
         if (slots[index] > 0) {
            switch (index) {
               case 0: // slot 1
                  Object.assign(this.dummy, {
                     slot_1: this.getDefinicoes(slots[index], tipo)
                  });
                  break;
               case 1: // slot 2
                  Object.assign(this.dummy, {
                     slot_2: this.getDefinicoes(slots[index], tipo)
                  });
                  break;
               case 2: // slot 3
                  Object.assign(this.dummy, {
                     slot_3: this.getDefinicoes(slots[index], tipo)
                  });
                  break;
               case 3: // slot 4
                  Object.assign(this.dummy, {
                     slot_4: this.getDefinicoes(slots[index], tipo)
                  });
                  break;
               case 4: // slot 5
                  Object.assign(this.dummy, {
                     slot_5: this.getDefinicoes(slots[index], tipo)
                  });
                  break;
               case 5: // slot 6
                  Object.assign(this.dummy, {
                     slot_6: this.getDefinicoes(slots[index], tipo)
                  });
                  break;
               case 6: // slot 7
                  Object.assign(this.dummy, {
                     slot_7: this.getDefinicoes(slots[index], tipo)
                  });
                  break;
               case 7: // slot 8
                  Object.assign(this.dummy, {
                     slot_8: this.getDefinicoes(slots[index], tipo)
                  });
                  break;
            }
         }

      }
   }

   getDefinicoes(slot, origem) {
      switch (origem) {
         case 'faturamento':
            return this._popUpService.getDefinicoesFaturamento(slot);
         case 'viagens':
            return this._popUpService.getDefinicoesViagens(slot);
         case 'solicitacoes':
            return this._popUpService.getDefinicoesSolitacoes(slot);
         case 'automatizacao':
            return this._popUpService.getDefinicoesAutomatizacao(slot);
      }
   }

   limpar() {
      if (confirm('Deseja limpar a configuração de templates?')) {
         this.form_modelo = {
            slots: [0, 0, 0, 0, 0, 0, 0, 0]
         };

         this.dataModel = {
            modelo_id: 0,
            dash_id: 0,
            usuario_bi_id: 0,
            slots: []
         };
         localStorage.removeItem('template-' + this.tipo);
         this._notificacao.toast('Dados limpos com sucesso!');
      }
   }

   salvar_deprecated() {
      if (this.dataModel.modelo_id > 0 && this.dataModel.slots.length > 0) {
         // salvar o dados da sessão no BD
         const parametros = {
            modelo_id: this.modelo_id,
            dash_id: this.dash[0].dash_id,
            usuario_bi_id: this.dataModel.usuario_bi_id,
            slots: JSON.stringify(this.dataModel.slots)
         };
         // console.log('salvar: parametros', parametros);

         this._gateway.backendCall('M4002', 'insTemplate', parametros).then((res: any) => {
            this.popSlots.instance.hide();
            this.resposta.emit({ mensagem: res.mensagem });
            this._notificacao.toast(res.mensagem);
         });
      } else {
         this._notificacao.toast('Não é permitido salvar templates vazios!', 'error');
      }
   }

   salvar() {
      if (this.dataModel.modelo_id > 0 && this.dataModel.slots.length > 0) {
         const clienteSelecionado = JSON.parse(localStorage.getItem('cliente-selecionado'));
         // salvar o dados da sessão no BD
         const parametros = {
            modelo_id: this.modelo_id,
            dash_id: this.dash[0].dash_id,
            usuario_bi_id: this.dataModel.usuario_bi_id,
            slots: this.dataModel.slots,
            dash: this.dash[0].descricao,
            usuario: this.org.usuario.usuario,
            cliente: clienteSelecionado.ref ? clienteSelecionado.ref : 'indefinido'
         };

         this._templateService.backendCall(parametros, 'post', 'save').then((res: any) => {
            this.popSlots.instance.hide();
            this.resposta.emit({ mensagem: res.message });
            this._notificacao.toast(res.message);
         })

      } else {
         this._notificacao.toast('Não é permitido salvar templates vazios!', 'error');
      }
   }

}
