import { Component, OnInit, Input } from '@angular/core';

@Component({
   selector: 'app-template-modelo4',
   templateUrl: './template-modelo4.component.html',
   styleUrls: ['./template-modelo4.component.scss']
})
export class TemplateModelo4Component implements OnInit {
   @Input() template: any;
   constructor() { }

   ngOnInit() {
   }

}
