import { OnInit, AfterViewInit, OnDestroy, Injector } from '@angular/core';
import { Subscription } from 'rxjs';

// import { MessageService } from '../../services/common/message.service';
import { CustomComponentService } from '../../services/common/custom-component.service';
import { FormService } from '../../services/common/form.service';
import { GridService } from '../../services/common/grid.service';
import { PresenterService } from '../../services/common/presenter.service';
import { PopupService } from '../../services/common/popup.service';
// import { MenuService } from '../../services/menu/menu.service';

/**
 * Componente extensível para parametrização do Presenter ou SubPresenter
 */
export class PresenterComponent implements OnInit, AfterViewInit, OnDestroy {

  onInit: Function;
  afterViewInit: Function;
  onDestroy: Function;

  subscriptions: Subscription[] = [];

  notifyAction: Subscription;

  _customComponentService: CustomComponentService;
  _formService: FormService;
  _gridService: GridService;
  // _messageService: MessageService;
  _popupService: PopupService;
  _presenterService: PresenterService;
  // _menuService: MenuService;

  ACAO = <any>{};

  /**
   *
   * @param _presenterContext Parametro responsável em caracterizar componente como Presenter(true|default) ou SubPresenter(false)
   */
  constructor(
    protected _injector: Injector,
    protected _presenterContext: boolean = true,
    public acoes: Array<string> = []
  ) {
    this._customComponentService = this._injector.get(CustomComponentService);
    this._formService = this._injector.get(FormService);
    this._gridService = this._injector.get(GridService);
    // this._messageService = this._injector.get(MessageService);
    this._popupService = this._injector.get(PopupService);
    this._presenterService = this._injector.get(PresenterService);
    // this._menuService = this._injector.get(MenuService);
  }

  ngOnInit() {
    if (!this['dataSource']) {
      // MessageService.error(' > Propriedade dataSource não encontrada!', this.constructor.name);
      // this._messageService.add('Propriedade dataSource não encontrada!', 'error', this.constructor.name);
    }

    if (this['_gridService']) {
      this['_gridService'].setCustomColumns(this);
    } else {
      // MessageService.error(' > _gridService não implementado!', this.constructor.name);
      // this._messageService.add('_gridService não implementado!', 'error', this.constructor.name);
    }

    if (this._presenterContext) {
      if (!this['_presenterService']) {
        // MessageService.error(' > _presenterService não implementado!', this.constructor.name);
        // this._messageService.add('_presenterService não implementado!', 'error', this.constructor.name);
      } else {
        this['_presenterService'].presenterContext = this;
      }
    }

    if (this.onInit) {
      try {
        this.onInit.call(this);
      } catch (ex) {
        // this._messageService.notify(ex, 'error', 'presenter2.component 74', ex, 5000);
      }
    }

    if (this['_popupService']) {
      this['_popupService'].addItems(this);
    } else {
      // MessageService.error(' > _popupService não implementado!', this.constructor.name);
      // this._messageService.add('_popupService não implementado!', 'error', this.constructor.name);
    }

    // this.acoes.forEach(a => {
    //   this.ACAO[a] = this._menuService.possuiAcao(a);
    // });
  }

  ngAfterViewInit() {
    try {
      if (this.afterViewInit) {
        this.afterViewInit.call(this);
      }

      if (this['wait_notification']) {
        this.notifyAction = this['_formService'].notifyComponent.subscribe(ev => {
          if (ev.sender === this['wait_notification'] && ev.receiver === this['contextName']) {
            this.subscribeActions();
          }
        });
      } else {
        this.subscribeActions();
      }
    } catch (ex) {
      // this._messageService.notify(ex, 'error', 'presenter2.component 102', ex, 5000);
    }
  }

  ngOnDestroy() {
    try {
      if (this.onDestroy) {
        this.onDestroy.call(this);
      }

      this.subscriptions.forEach((item, index) => {
        item.unsubscribe();
      });

      if (this['wait_notification']) {
        this.notifyAction.unsubscribe();
      }
    } catch (ex) {
      // this._messageService.notify(ex, 'error', 'presenter2.component 120', ex, 5000);
    }
  }

  protected subscribeActions() {
    try {
      Object.keys(this['__proto__']).forEach((item, index) => {
        if (item.search('__action_') !== -1) {
          if (this[this[item].service]) {
            this.subscriptions.push(
              this[this[item].service].getAction(
                this[item].context,
                this[item].action
              ).subscribe(data => {
                this[this[item].callback].call(this, data);
              })
            );
          } else {
            // MessageService.error(
            //   ` > Serviço ${this[item].service}.${this[item].action} não encontrado ou sem permissão para acessar esse item!`,
            //   this.constructor.name);
          }
        }
      });
    } catch (ex) {
      // this._messageService.notify(ex + ' - presenter2 subscriptions', 'error', 'presenter2.component 146', ex, 5000);
    }
  }

}
