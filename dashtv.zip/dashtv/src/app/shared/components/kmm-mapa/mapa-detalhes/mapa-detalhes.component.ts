import { Component, OnInit, Input } from '@angular/core';
import { GoogleMapsService } from '../mapa/maps-google.service';

@Component({
    selector: 'app-mapa-detalhes',
    templateUrl: './mapa-detalhes.component.html',
    styleUrls: ['./mapa-detalhes.component.scss']
})
export class MapaDetalhesComponent implements OnInit {

    @Input('dados') dados: any;

    constructor(
        public googleMaps: GoogleMapsService
    ) { }

    ngOnInit() { }


    public fechar(){
        this.googleMaps.showMarkerDetalhes = false;
    }

}
