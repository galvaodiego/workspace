import { GoogleMapsService } from './maps-google.service';
import { Component, OnInit } from '@angular/core';

import { NavigationService, GatewayService, Usuario } from 'src/app/shared';

// Plugins
import * as _ from 'underscore';
import 'moment/locale/pt-br';

@Component({
   selector: 'app-mapa',
   templateUrl: './mapa.component.html',
   styleUrls: ['./mapa.component.scss']
})
export class MapaComponent implements OnInit {

   public user: Usuario = Usuario.instance;

   constructor(
      private _gateway: GatewayService,
      public googleMaps: GoogleMapsService,
      public navigation: NavigationService
   ) { }

   ngOnInit() {
      this.googleMaps.initMap();
      this.getDadosMapa().then(
         (result) => {
            // Recebo o Estado Selecionado Atraves de um Evento para aplicar Zoom
            this.googleMaps.dispatcherZoom.subscribe((item: any) => this.googleMaps.zoomMapa(item));
         }
      );

   }



   /**
    * Resgata os Dados do Banco
    */
   public async getDadosMapa() {

      this.googleMaps.marcadores = [];
      this.googleMaps.mirrorMarcadores = [];

      try {

         const response: any = await this._gateway.backendCall('M4002', 'getDemanda');
         console.log('resultado getDemanda', response);

         this.navigation.loaderTela = false;

         this.googleMaps.indicadores[0] = response.mapaDiponibilidadeDemanda.indicadores_1;
         this.googleMaps.indicadores[1] = response.mapaDiponibilidadeDemanda.indicadores_2;
         this.googleMaps.indicadores[2] = response.mapaDiponibilidadeDemanda.canceladas;

         // Converto a string de Latitude e Longitude em Number
         for (let i = 0; i < response.mapaDiponibilidadeDemanda.location.length; i++) {
            const el = response.mapaDiponibilidadeDemanda.location[i];

            el.lat_raw = el.lat;
            el.lng_raw = el.lng;
            el.lng = Number.parseFloat(el.lng);
            el.lat = Number.parseFloat(el.lat);

            if (el.lat_raw !== '' && el.lng_raw !== '') {
               this.googleMaps.mirrorMarcadores.push(el);
            }

         }

         // Salvando os Estados que possuem Marcadores
         const tempArray = [];
         for (let i = 0; i < this.googleMaps.mirrorMarcadores.length; i++) {
            const el = this.googleMaps.mirrorMarcadores[i];

            let obj: any = {};
            obj = el.estado;
            tempArray.push(obj);
         }

         let estadosComMarkers: any = [];
         estadosComMarkers = _.uniq(tempArray);
         this.googleMaps.emiteEstadosComMarkers(estadosComMarkers);

         // Prepara o Array conforme Google Maps
         this.googleMaps.prepareArray(this.googleMaps.mirrorMarcadores);

      } catch (error) {
         console.log('Erro Demanda -> ', error);
      }


   }

}
