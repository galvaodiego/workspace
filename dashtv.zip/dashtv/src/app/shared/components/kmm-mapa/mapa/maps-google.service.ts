import { Injectable, EventEmitter } from '@angular/core';
import notify from 'devextreme/ui/notify';

import { Usuario, UsuarioService } from 'src/app/shared';

//Variaveis do Mapa 
declare let google: any;
declare let MarkerClusterer: any;
declare let OverlappingMarkerSpiderfier: any;

//Plugins
import * as _ from 'underscore';
import * as moment from 'moment';
import 'moment/locale/pt-br';

@Injectable({ providedIn: 'root' })
export class GoogleMapsService {

    //////////////////////////////
    //    VARIAVEIS DO MAPA
    /////////////////////////////

    public map: any; //Instancia do Mapa
    public instanceInfoWindow: any; // Instancia do Tooltip
    public instanceCircle: any; // Instancia do Circulo de Raio
    public instanceBounds: any; // Instancia de Centralização conforme Marcadores
    public instanceHeatMap: any = []; // Instancia do Mapa de Calor
    public instanceTrafficLayer: any; // Instancia de TrafficLayer
    public instanceMarkerCluster: any; // Instancia do Cluster de Markers
    public instanceOverlappingMarker: any; // Agrupamento de Markers próximos

    //////  CUSTOMIZAÇÕES  DO MAPA  //////
    public mapModoGray: any;  //Recebe os Styles do Mapa Cinza - Substitui Padrão
    public mapModoNight: any;  //Recebe os Styles do Mapa Noturno

    //////  OUTRAS VARIAVEIS  //////
    public user: Usuario = Usuario.instance;
    public filtrosDoMapa: any;  // Filtros do Componente
    public showMarkerDetalhes: any;  // Mostra os Detalhes 

    public indicadores: any = []; //Indicadores
    public marcadores: Array<any> = []; //Marcadores
    public mirrorMarcadores: Array<any> = []; //Marcadores - ESPELHO
    public googleMarcador: any = []; // Marcadores no Formato Google

    // Emissores de Evento
    public dispatcherEstados: EventEmitter<any> = new EventEmitter();
    public dispatcherMarker: EventEmitter<any> = new EventEmitter();
    public dispatcherZoom: EventEmitter<any> = new EventEmitter();
    public dispatcherRegiao: EventEmitter<any> = new EventEmitter();



    constructor(
        public userProvider: UsuarioService,
    ) { }


    /**
     *  Funcionamento:
     *    1-  Inicia o Mapa (InitMap)
     *    2-  Faz a Chamada pro Banco
     *    3-  Prepara o Array (prepareArray)
     *    4-  Adiciona os Markers (addMarkers)
     *    5- Verifica as Personalizações (verificaPersonalizacoes)
     * 
     */


    /**
     * Inicializa o Mapa
     *  Objetivo:: Iniciar o Mapa Vazio
     */
    public async initMap(): Promise<any> {
        const mapOptions = {
            zoom: 5.1,
            center: new google.maps.LatLng(-15.563089, -55.934619), // Cuiabá - MT
            mapTypeId: 'satellite', // Zoom 3D
            heading: 90,
            tilt: 45,
            gestureHandling: 'greedy',
            panControl: true,
            scaleControl: true,
            scrollwheel: true,
            draggable: true,
            overviewMapControl: true,
            fullscreenControl: false,
            fullscreenControlOptions: {
                position: google.maps.ControlPosition.LEFT_BOTTOM
            },
            streetViewControl: false,
            streetViewControlOptions: {
                position: google.maps.ControlPosition.LEFT_BOTTOM
            },
            zoomControl: false,
            zoomControlOptions: {
                style: google.maps.ZoomControlStyle.SMALL,
                position: google.maps.ControlPosition.LEFT_BOTTOM
            },
            mapTypeControl: false,
            mapTypeControlOptions: {
                style: google.maps.MapTypeControlStyle.DEFAULT,
                position: google.maps.ControlPosition.LEFT_BOTTOM
            }
        };

        //Renderiza o Mapa
        this.map = new google.maps.Map(document.getElementById('map'), mapOptions);

        //Instancia Plugin de Agrupamento de Markers no Mesmo lugar
        this.instanceOverlappingMarker = new OverlappingMarkerSpiderfier(this.map, {
            markersWontMove: true, markersWontHide: true, basicFormatEvents: true, ignoreMapClick: true, legWeight: 3, circleFootSeparation: 40
        });

        //Ativa Modo Cinza
        this.styleGrayMap();

        //Verifica se Existem Filtros no Storage
        this.verificaEstadoFiltros();

        //Ativa o Modo Noturno conforme Validações
        this.styleNightMap(1);
    }


    /**
	* Prepara Arrays para serem lidos pelo Maps
	* @param obj array para ser preparado
	*/
    public prepareArray(obj: any) {

        //Zera o Array para receber novamente os dados
        this.marcadores = [];

        //Monta o Array
        obj.forEach(
            (el: any) => {
                this.marcadores.push([el.lat, el.lng, el])
            }
        );

        //Adiciona os Markers
        this.addMarkers(this.map, this.marcadores);
    }


    /**
	 * Add Markers
     * @param map :: Meu Mapa
     * @param markers :: Array com Marcadores a serem criados
     */
    public addMarkers(map: any, markers: any) {

        this.instanceInfoWindow = new google.maps.InfoWindow();
        this.instanceBounds = new google.maps.LatLngBounds();

        // Remove os CLuster, se existir
        if (this.instanceMarkerCluster) {
            this.instanceMarkerCluster.clearMarkers();
        }

        if (this.filtrosDoMapa[0].showMarkerCluster == true) {

            // Remove os Marcadores Simples
            for (let i = 0; i < this.googleMarcador.length; i++) {
                this.googleMarcador[i].setMap(null);
            }

            this.googleMarcador = markers;

            //Cluster de Markers
            markers = markers.map(function (location, i) {
                return new google.maps.Marker({
                    position: { lat: markers[i][0], lng: markers[i][1] },
                    map: map,
                    icon: (markers[i][2].tipo_marcador == 1) ? new google.maps.MarkerImage("assets/icon/marker_doc.png") : new google.maps.MarkerImage("assets/icon/marker_truck.png"),
                    dados: markers[i][2]
                });
            });

            this.instanceMarkerCluster = new MarkerClusterer(map, markers, { imagePath: 'assets/images/maps/m' });

        } else {

            this.googleMarcador = markers;
            this.instanceOverlappingMarker.removeAllMarkers();
            for (let i = 0; i < this.googleMarcador.length; i++) {
                this.googleMarcador[i] = new google.maps.Marker({
                    position: { lat: this.googleMarcador[i][0], lng: this.googleMarcador[i][1] },
                    map: map,
                    icon: (this.googleMarcador[i][2].tipo_marcador == 1) ? new google.maps.MarkerImage("assets/icon/marker_doc.png") : new google.maps.MarkerImage("assets/icon/marker_truck.png"),
                    dados: this.googleMarcador[i][2]
                });


                // Raio em volta do Marker

                // if (this.googleMarcador[i].dados.tipo_marcador == 0) {
                //     //Cria Raio em volta da disponibilidade
                //     this.instanceCircle = new google.maps.Circle({
                //         strokeColor: '#0099ee',
                //         strokeOpacity: 0,
                //         strokeWeight: 0.5,
                //         fillColor: '#0099ee',
                //         fillOpacity: 0.25,
                //         map: map,
                //         center: { lat: this.googleMarcador[i].dados.lat, lng: this.googleMarcador[i].dados.lng },
                //         radius: 50000 //50KM
                //     });
                //     this.instanceCircle.setMap(map);
                // }


                //Agrupador de Posições no Mesmo local
                this.googleMarcador[i].addListener('spider_click', () => {
                    this.emiteMarkerSelecionado(this.googleMarcador[i].dados);
                    // Adiciona tooltip aqui - caso necessário
                    // iw.setContent('ID: ' + this.googleMarcador[i].dados.Id);
                    // iw.open(map, this.googleMarcador[i]);
                });
                this.instanceOverlappingMarker.addMarker(this.googleMarcador[i]);

                //Centralizador do Mapa
                this.instanceBounds.extend(this.googleMarcador[i].getPosition());
                this.map.fitBounds(this.instanceBounds);

            }
        }
        this.verificaPersonalizacoes();
    }

    /**
     * 
     * @param selecionado marker selecionado
     */
    public zoomMapa(selecionado?: any) {
        let posicao = { lat: selecionado[0], lng: selecionado[1] };
        this.map.setCenter(posicao);
        this.map.setZoom(selecionado[2]);
    }


    ////////////////////////////////////////////////////////////////
    ///                   CONTROLA OS EVENTOS                    ///
    ////////////////////////////////////////////////////////////////

    /**
     * Emite um Evento com os Estados que possuem Markers
     * @param EstadosUnicos Estados que possuem Markers
     *  Objetivo:
     *          Mostrar ao Usuário apenas os Estados que Possuem Markers nos Filtros
     */
    public emiteEstadosComMarkers(estados: any) {
        return this.dispatcherEstados.emit(estados);
    }

    /**
     * Emite um Evento com o Marker Selecionado
     * @param marker Marker Selecionado no Mapa
     *  Objetivo: 
     *          Quando houver click no Marcador emite um evento com as informaçoes dele
     */
    public emiteMarkerSelecionado(marker: any) {
        this.showMarkerDetalhes = true;
        return this.dispatcherMarker.emit(marker);
    }

    ////////////////////////////////////////////////////////////////
    ///           CONTROLA EXIBIÇÃO DAS CUSTOMIZAÇÕES            ///
    ////////////////////////////////////////////////////////////////

    /**
     * Controla a Exibição dos Agrupamentos
     */
    public manageCluster() {

        console.log('manageCluster', this.filtrosDoMapa[0].showMarkerCluster);


        if (this.filtrosDoMapa[0].showMarkerCluster) {
            this.filtrosDoMapa[0].showMarkerCluster = false;
            // this.addMarkers(this.map, this.marcadores);
            this.prepareArray(this.mirrorMarcadores);
            this.toast('Agrupamento Desativado! Mostrando Markers individualmente.');
        } else {
            console.log('sou falso, entao ativo ');

            this.filtrosDoMapa[0].showMarkerCluster = true;
            this.prepareArray(this.mirrorMarcadores);
            this.toast('Agrupamento Ativado! Mostrando Markers próximos agrupados');
        }
        this.setFilters(this.filtrosDoMapa);
    }


    /**
     * Controla Exibição do Mapa de Calor
     */
    public manageHeatMap() {
        if (this.filtrosDoMapa[0].showHeatMap) {
            if (typeof (this.instanceHeatMap) !== 'undefined') {
                this.filtrosDoMapa[0].showHeatMap = false;
                this.instanceHeatMap.setMap(null);
                this.prepareArray(this.mirrorMarcadores);
                this.toast('Mapa de calor Desativado!');
            }
        } else {
            this.filtrosDoMapa[0].showHeatMap = true;
            let heatmapData = [];
            this.marcadores.forEach(
                (el) => {

                    //Remove os Marcadores Simples e deixa apenas a marca de Calor
                    for (let i = 0; i < this.googleMarcador.length; i++) {
                        this.googleMarcador[i].setMap(null);
                    }

                    if (typeof (el.dados) == 'undefined') {
                        heatmapData.push(new google.maps.LatLng(el[2].lat, el[2].lng));
                    } else {
                        heatmapData.push(new google.maps.LatLng(el.dados.lat, el.dados.lng));
                    }
                }
            )
            this.instanceHeatMap = new google.maps.visualization.HeatmapLayer({ data: heatmapData });
            this.instanceHeatMap.set('radius', this.instanceHeatMap.get('radius') ? null : 80);
            this.instanceHeatMap.setMap(this.map);
            this.toast('Mapa de calor Ativado!');
        }

        this.setFilters(this.filtrosDoMapa)
    }


    /**
     * Controla a Exibição do Tráfego em Tempo Real
     */
    public manageTrafficLayer() {
        if (this.filtrosDoMapa[0].showTrafficLayer) {
            if (typeof (this.instanceTrafficLayer) !== 'undefined') {
                this.filtrosDoMapa[0].showTrafficLayer = false;
                this.instanceTrafficLayer.setMap(null);
                this.toast('Monitoramento de tráfego desativado!');
            }
        } else {
            this.filtrosDoMapa[0].showTrafficLayer = true;
            this.instanceTrafficLayer = new google.maps.TrafficLayer();
            this.instanceTrafficLayer.setMap(this.map);
            this.toast('Monitoramento de tráfego ativado!');
        }
        this.setFilters(this.filtrosDoMapa)
    }

    /**
     * Controla a Exibição do Modo Noturno
     */
    public manageModoNoturno() {
        if (this.filtrosDoMapa[0].showMapaNoturno) {
            this.filtrosDoMapa[0].showMapaNoturno = false;
            this.styleNightMap(3);
            this.toast('Modo Noturno desativado!');
        } else {
            this.filtrosDoMapa[0].showMapaNoturno = true;
            this.styleNightMap(2);
            this.toast('Modo Noturno ativado!');
        }
        this.setFilters(this.filtrosDoMapa);
    }

    /**
 	* Altera o Estilo do Mapa para Gray
	*/
    public styleGrayMap() {
        this.mapModoGray = new google.maps.StyledMapType([
            { stylers: [{ saturation: -100 }, { gamma: 1 }] },
            { elementType: 'labels.text.stroke', stylers: [{ visibility: 'off' }] },
            { featureType: 'poi.business', elementType: 'labels.text', stylers: [{ visibility: 'off' }] },
            { featureType: 'poi.business', elementType: 'labels.icon', stylers: [{ visibility: 'off' }] },
            { featureType: 'poi.place_of_worship', elementType: 'labels.text', stylers: [{ visibility: 'off' }] },
            { featureType: 'poi.place_of_worship', elementType: 'labels.icon', stylers: [{ visibility: 'off' }] },
            { featureType: 'road', elementType: 'geometry', stylers: [{ visibility: 'simplified' }] },
            { featureType: 'water', stylers: [{ visibility: 'on' }, { saturation: 50 }, { gamma: 0 }, { hue: '#50a5d1' }] },
            { featureType: 'administrative.neighborhood', elementType: 'labels.text.fill', stylers: [{ color: '#333333' }] },
            { featureType: 'road.local', elementType: 'labels.text', stylers: [{ 'weight': 0.5 }, { color: '#333333' }] },
            { featureType: 'transit.station', elementType: 'labels.icon', stylers: [{ 'gamma': 1 }, { saturation: 50 }] }
        ], { name: 'gray' });

        this.map.mapTypes.set('gray', this.mapModoGray);
        this.map.setMapTypeId('gray');
    }

    /**
     * Ativa o Modo Noturno
     * @param flag  1 = Ativa só se for de Noite | 2 = Ativa | 3 = Não Ativa ou Desativa
     */
    public styleNightMap(flag?: any) {
        this.mapModoNight = new google.maps.StyledMapType([
            { elementType: 'geometry', stylers: [{ color: '#242f3e' }] },
            { elementType: 'labels.text.stroke', stylers: [{ color: '#242f3e' }] },
            { elementType: 'labels.text.fill', stylers: [{ color: '#746855' }] },
            { featureType: 'administrative.locality', elementType: 'labels.text.fill', stylers: [{ color: '#d59563' }] },
            { featureType: 'poi', elementType: 'labels.text.fill', stylers: [{ color: '#d59563' }] },
            { featureType: 'poi.park', elementType: 'geometry', stylers: [{ color: '#263c3f' }] },
            { featureType: 'poi.park', elementType: 'labels.text.fill', stylers: [{ color: '#6b9a76' }] },
            { featureType: 'road', elementType: 'geometry', stylers: [{ color: '#38414e' }] },
            { featureType: 'road', elementType: 'geometry.stroke', stylers: [{ color: '#212a37' }] },
            { featureType: 'road', elementType: 'labels.text.fill', stylers: [{ color: '#9ca5b3' }] },
            { featureType: 'road.highway', elementType: 'geometry', stylers: [{ color: '#746855' }] },
            { featureType: 'road.highway', elementType: 'geometry.stroke', stylers: [{ color: '#1f2835' }] },
            { featureType: 'road.highway', elementType: 'labels.text.fill', stylers: [{ color: '#f3d19c' }] },
            { featureType: 'transit', elementType: 'geometry', stylers: [{ color: '#2f3948' }] },
            { featureType: 'transit.station', elementType: 'labels.text.fill', stylers: [{ color: '#d59563' }] },
            { featureType: 'water', elementType: 'geometry', stylers: [{ color: '#17263c' }] },
            { featureType: 'water', elementType: 'labels.text.fill', stylers: [{ color: '#515c6d' }] },
            { featureType: 'water', elementType: 'labels.text.stroke', stylers: [{ color: '#17263c' }] }
        ], { name: 'Noite' });

        if (flag == 1) {
            // Se mantem Neutro e ativa somente de Noite
            if ((moment().format('HH:MM') >= '07:00') && (moment().format('HH:MM') <= '18:00')) {
                this.filtrosDoMapa[0].showMapaNoturno = false;
            } else {
                this.filtrosDoMapa[0].showMapaNoturno = true;
                this.map.mapTypes.set('noite', this.mapModoNight);
                this.map.setMapTypeId('noite');
            }
        } else if (flag == 2) {
            //Ativa o Modo Noturno
            this.filtrosDoMapa[0].showMapaNoturno = true;
            this.map.mapTypes.set('noite', this.mapModoNight);
            this.map.setMapTypeId('noite');
        } else if (flag == 3) {
            //Não ativa o Modo 
            this.filtrosDoMapa[0].showMapaNoturno = false;
            this.styleGrayMap();
        }
        this.setFilters(this.filtrosDoMapa)
    }



    /**
     * Limpa os Filtros da Tela
     */
    public limpaFiltros() {
        this.filtrosDoMapa[0].showTrafficLayer = false;
        this.filtrosDoMapa[0].showHeatMap = false;
        this.filtrosDoMapa[0].showMapaNoturno = false;
        this.filtrosDoMapa[0].showMarkerCluster = false;

        if (typeof (this.instanceTrafficLayer) !== 'undefined') {
            this.filtrosDoMapa[0].showTrafficLayer = false;
            this.instanceTrafficLayer.setMap(null);
        }

        if (typeof (this.instanceHeatMap) !== 'undefined') {
            if (this.instanceHeatMap.lenght > 0) {
                this.instanceHeatMap.setMap(null);
                this.prepareArray(this.mirrorMarcadores);
            }
        }

        this.filtrosDoMapa[0].showMapaNoturno = false;
        this.styleNightMap(3);

    }


    /**
     * Verifica os Filtros da Tela e Ativa conforme necessidade
     */
    public verificaPersonalizacoes() {

        //Cluster
        if (this.filtrosDoMapa[0].showMarkerCluster) {
            this.filtrosDoMapa[0].showMarkerCluster = true;
            this.prepareArray(this.mirrorMarcadores);
            this.toast('Agrupamento Ativado! Mostrando Markers próximos agrupados');
        }

        //HeatMap


        if (this.filtrosDoMapa[0].showHeatMap) {
            if (typeof (this.instanceHeatMap) !== 'undefined') {
                this.filtrosDoMapa[0].showHeatMap = false;
                this.instanceHeatMap.setMap(null);
            }
            this.filtrosDoMapa[0].showHeatMap = true;
            let heatmapData = [];
            this.instanceHeatMap = [];
            console.log('oi1');

            this.marcadores.forEach(
                (el) => {

                    //Remove os Marcadores Simples e deixa apenas a marca de Calor
                    for (let i = 0; i < this.googleMarcador.length; i++) {
                        this.googleMarcador[i].setMap(null);
                    }

                    if (typeof (el.dados) == 'undefined') {
                        heatmapData.push(new google.maps.LatLng(el[2].lat, el[2].lng));
                    } else {
                        heatmapData.push(new google.maps.LatLng(el.dados.lat, el.dados.lng));
                    }
                }
            )
            this.instanceHeatMap = new google.maps.visualization.HeatmapLayer({ data: heatmapData });
            this.instanceHeatMap.set('radius', this.instanceHeatMap.get('radius') ? null : 80);
            this.instanceHeatMap.setMap(null);
            this.instanceHeatMap.setMap(this.map);
        }

        //Modo Noturno
        if (this.filtrosDoMapa[0].showMapaNoturno) {
            this.filtrosDoMapa[0].showMapaNoturno = true;
            this.map.mapTypes.set('noite', this.mapModoNight);
            this.map.setMapTypeId('noite');
        }

        //TrafficLayer
        if (this.filtrosDoMapa[0].showTrafficLayer) {
            this.filtrosDoMapa[0].showTrafficLayer = true;
            this.instanceTrafficLayer = new google.maps.TrafficLayer();
            this.instanceTrafficLayer.setMap(this.map);
        }
    }

    ////////////////////////////////////////////////////////////////
    ///                        FILTROS                           ///
    ////////////////////////////////////////////////////////////////

    /**
     * Verifica o Storage e Resgata os Filtros
    */
    public verificaEstadoFiltros() {
        let dashId = this.user.listaDashboards.findIndex(element => element.dash_id == this.user.selectedDashboard);

        if (typeof (this.user.listaDashboards[dashId].filters[0]) == 'undefined') {
            //Inicializa array, pra não causar erro
            this.user.listaDashboards[dashId].filters = [];
            //Cria array padrão
            this.filtrosDoMapa = [{
                "showMarkerCluster": false,
                "showMapaNoturno": false,
                "showTrafficLayer": false,
                "showHeatMap": false,
            }]
        } else {
            //Caso tenha dados no Storage resgata, se não cria um Padrão
            if (this.user.listaDashboards[dashId].filters[0]) {
                this.filtrosDoMapa = this.user.listaDashboards[dashId].filters;
            } else {
                this.filtrosDoMapa = [{
                    "showMarkerCluster": false,
                    "showMapaNoturno": false,
                    "showTrafficLayer": false,
                    "showHeatMap": false,
                }]
            }
        }
        this.setFilters(this.filtrosDoMapa);
    }


    /**
    *  Salva o filtro do painel na sessão.
    * @param {Array<any>} parameters - Parâmetros do filtro
    */
    public setFilters(parameters: any) {
        let dashId = this.user.listaDashboards.findIndex(element => element.dash_id == this.user.selectedDashboard)
        this.user.listaDashboards[dashId].filters = parameters;
        this.userProvider.save();
    }

    /**
    *  Resgata o filtro do painel da sessão.
    */
    public getFilters() {
        let dashId = this.user.listaDashboards.findIndex(element => element.dash_id == this.user.selectedDashboard)
        this.filtrosDoMapa[0] = this.user.listaDashboards[dashId].filters;
        let filters = this.user.listaDashboards[dashId].filters;
        this.verificaPersonalizacoes();
        return filters;
    }

    /**
    * Notificação ao Usuário 
    * @param msg :: Mensagem
    */
    public toast(msg, tempo?, cor?) {
        notify({ message: msg, type: cor ? cor : 'info', displayTime: tempo ? tempo : 3000, closeOnClick: true, width: function () { return window.innerWidth / 2.8; } });
    }
}