import { Component, OnInit, Input } from '@angular/core';

@Component({
    selector: 'lote-atributo',
    templateUrl: './atributo.component.html',
    styleUrls: ['./atributo.component.scss']
})
export class AtributoComponent implements OnInit {

    // @Input() ordem;
    @Input() toltip;
    @Input() sigla;
    @Input() valor;
    // @Input() selectedAttr;
    // @Input() limitecaracter
    // @Input() idAtr;
    // @Input() informe;

    constructor() { }

    ngOnInit() {
    }

}
