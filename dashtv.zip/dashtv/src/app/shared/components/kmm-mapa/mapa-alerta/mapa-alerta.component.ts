import { GoogleMapsService } from './maps-google.service';
import { Component, OnInit, Input, OnDestroy } from '@angular/core';

import { NavigationService, GatewayService, Usuario, ClienteService } from 'src/app/shared';
import io from 'socket.io-client';


// Plugins
import * as _ from 'underscore';
import 'moment/locale/pt-br';
import { environment } from 'src/environments/environment';


@Component({
   selector: 'app-mapa-alerta',
   templateUrl: './mapa-alerta.component.html',
   styleUrls: ['./mapa-alerta.component.scss']
})
export class MapaAlertaComponent implements OnInit, OnDestroy {
   @Input() locations: any;

   public user: Usuario = Usuario.instance;
   org: any;
   loadingMapVisible = true;
   // Config Socket
   socket_io: any;
   socket_rota = 'alerta';
   socket_metodo = 'getAlerta';
   socket_filtro: any;
   /***/
   constructor(
      private _gateway: GatewayService,
      public googleMaps: GoogleMapsService,
      public navigation: NavigationService,
      private _clienteS: ClienteService
   ) {
      this.org = JSON.parse(localStorage.getItem('kmm_bi-dash|' + this._clienteS.discover() + '-organizacional'));
      this.socket_io = io(environment.socket_end_point + '/' + this.socket_rota);
      this.socket_filtro = {
         base: (this._clienteS.clienteAtivo !== 'KMM' ? this._clienteS.clienteAtivo : environment.end_point_base_dev).toLowerCase(),
         mapa: 1
      };
   }

   ngOnInit() {
      this.googleMaps.initMap();
      this.getDadosMapa().then(() => {
         // Recebo o Estado Selecionado Atraves de um Evento para aplicar Zoom
         this.googleMaps.dispatcherZoom.subscribe((item: any) => this.googleMaps.zoomMapa(item));
         this.googleMaps.dispatcherOculta.subscribe((item: any) => this.googleMaps.ocultaMarkers(item));
      });
   }
   ngOnDestroy() {
      this.socket_io.disconnect();
   }

   /**
    * Resgata os Dados do Banco
    */

   public async getDadosMapa() {

      this.googleMaps.marcadores = [];
      this.googleMaps.mirrorMarcadores = [];

      try {
         this.socket_io.emit(this.socket_metodo, this.socket_filtro);
         this.socket_io.on(this.socket_rota, (data) => {

            // let key, keys = Object.keys(data.mapa);
            // let n = keys.length;
            // const newobj = {};
            // while (n--) {
            //   key = keys[n];
            //   newobj[key.toLowerCase()] = data.mapa[key];
            // }

            console.log('chegou o load do mapa', data.mapa);

            for (let i = 0; i < data.mapa.length; i++) {
               const el = data.mapa[i];

               el.lat_raw = el.LAT;
               el.lng_raw = el.LNG;
               el.lng = Number.parseFloat(el.LNG);
               el.lat = Number.parseFloat(el.LAT);

               if (el.lat_raw !== '' && el.lng_raw !== '') {
                  this.googleMaps.mirrorMarcadores.push(el);
               }

            }

            // Salvando os Estados que possuem Marcadores
            const tempArray = [];
            for (let i = 0; i < this.googleMaps.mirrorMarcadores.length; i++) {
               const el = this.googleMaps.mirrorMarcadores[i];

               let obj: any = {};
               if (el.ESTADO !== null) {
                  obj = el.ESTADO;
                  tempArray.push(obj);
               }
            }

            let estadosComMarkers: any = [];
            estadosComMarkers = _.uniq(tempArray);
            this.googleMaps.emiteEstadosComMarkers(estadosComMarkers);

            // Salvando os Segmentos que possuem Marcadores
            const tempArray2 = [];
            for (let i = 0; i < this.googleMaps.mirrorMarcadores.length; i++) {
               const el = this.googleMaps.mirrorMarcadores[i];

               let obj: any = {};
               if (el.SEGMENTO !== null) {
                  obj = el.SEGMENTO;
                  tempArray2.push(obj);
               }
            }

            let segmentosComMarkers: any = [];
            segmentosComMarkers = _.uniq(tempArray2);
            // console.log('segmentosComMarkers', segmentosComMarkers);

            this.googleMaps.emiteSegmentosComMarkers(segmentosComMarkers);

            // Prepara o Array conforme Google Maps
            this.googleMaps.prepareArray(this.googleMaps.mirrorMarcadores);

            this.loadingMapVisible = false;
            this.navigation.loaderTela = false;

         });
         // const parametros = {
         //    usuario_bi_id: this.org.usuario.usuarioBiId
         // };
         // const response: any = await this._gateway.backendCall('M4002', 'getAlertasDash', parametros);
         // console.log('resultado getAlertasDash', response);

         // this.navigation.loaderTela = false;

         // this.googleMaps.indicadores[0] = response.dash_alertas.indicadores_al_abertos; // indicadores rodapé.
         // this.googleMaps.indicadores[7] = response.dash_alertas.ind_status;
         // this.googleMaps.indicadores[8] = response.dash_alertas.plano_viagem;


         // REDIRECIONADO PARA O COMPONENTE INDICADORES-TIPO-GRAFICO
         /*
         this.googleMaps.indicadores[1] = response.dash_alertas.grafico_al_ab_fechado;
         this.googleMaps.indicadores[2] = response.dash_alertas.grafico_operador;
         this.googleMaps.indicadores[3] = response.dash_alertas.grafico_grupo;
         this.googleMaps.indicadores[4] = response.dash_alertas.grafico_horas;
         this.googleMaps.indicadores[5] = response.dash_alertas.tempo_medio;
         this.googleMaps.indicadores[6] = response.dash_alertas.nivel_servico.valor;
         */

         // Converto a string de Latitude e Longitude em Number
         // for (let i = 0; i < this.locations.length; i++) {
         //    const el = this.locations.location[i];

         //    el.lat_raw = el.lat;
         //    el.lng_raw = el.lng;
         //    el.lng = Number.parseFloat(el.lng);
         //    el.lat = Number.parseFloat(el.lat);

         //    if (el.lat_raw !== '' && el.lng_raw !== '') {
         //       this.googleMaps.mirrorMarcadores.push(el);
         //    }

         // }

         // Salvando os Estados que possuem Marcadores
         // const tempArray = [];
         // for (let i = 0; i < this.googleMaps.mirrorMarcadores.length; i++) {
         //    const el = this.googleMaps.mirrorMarcadores[i];

         //    let obj: any = {};
         //    obj = el.estado;
         //    tempArray.push(obj);
         // }

         // let estadosComMarkers: any = [];
         // estadosComMarkers = _.uniq(tempArray);
         // this.googleMaps.emiteEstadosComMarkers(estadosComMarkers);

         // Salvando os Segmentos que possuem Marcadores
         // const tempArray2 = [];
         // for (let i = 0; i < this.googleMaps.mirrorMarcadores.length; i++) {
         //    const el = this.googleMaps.mirrorMarcadores[i];

         //    let obj: any = {};
         //    obj = el.segmento;
         //    tempArray2.push(obj);
         // }

         // let segmentosComMarkers: any = [];
         // segmentosComMarkers = _.uniq(tempArray2);
         // this.googleMaps.emiteSegmentosComMarkers(segmentosComMarkers);

         // Prepara o Array conforme Google Maps
         // this.googleMaps.prepareArray(this.googleMaps.mirrorMarcadores);

      } catch (error) {
         this.loadingMapVisible = false;
         this.navigation.loaderTela = false;
         console.log('Erro Demanda -> ', error);
      }


   }

}
