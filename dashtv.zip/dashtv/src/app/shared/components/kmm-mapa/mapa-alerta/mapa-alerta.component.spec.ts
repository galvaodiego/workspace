import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MapaAlertaComponent } from './mapa-alerta.component';

describe('MapaAlertaComponent', () => {
  let component: MapaAlertaComponent;
  let fixture: ComponentFixture<MapaAlertaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MapaAlertaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MapaAlertaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
