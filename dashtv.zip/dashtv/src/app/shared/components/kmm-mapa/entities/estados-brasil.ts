/** Classe criada para representar os Estados Brasileiros */
export class Estados {
    id: number
    sigla: string;
    descricao: string;
    lat: number;
    lng: number;
    zoom: number;
    regiao: string;
}
