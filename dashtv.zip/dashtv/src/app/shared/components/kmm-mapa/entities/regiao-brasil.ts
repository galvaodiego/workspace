/** Classe criada para representar as Regiões Brasileiras */
export class Regiao {
    id: number
    sigla: string;
    descricao: string;
    lat: number;
    lng: number;
    zoom: number;
}
