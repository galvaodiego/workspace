import { Injectable } from '@angular/core';

import { Estados } from './estados-brasil';
import { Regiao } from './regiao-brasil';
import { Segmento } from './segmentos';

//Estados Brasileiros com a Lat e Long da Cidade que fica no Centro do Estado
let estados: Estados[] = [
    { id: 1, sigla: 'AC', descricao: 'Acre', lat: -8.77, lng: -70.55, zoom: 8, regiao: 'N' },
    { id: 2, sigla: 'AL', descricao: 'Alagoas', lat: -9.71, lng: -35.73, zoom: 9, regiao: 'NE' },
    { id: 3, sigla: 'AP', descricao: 'Amapá', lat: 1.41, lng: -51.77, zoom: 8, regiao: 'N' },
    { id: 4, sigla: 'AM', descricao: 'Amazonas', lat: -3.07, lng: -61.66, zoom: 6, regiao: 'N' },
    { id: 5, sigla: 'BA', descricao: 'Bahia', lat: -12.96, lng: -38.51, zoom: 8, regiao: 'NE' },
    { id: 6, sigla: 'CE', descricao: 'Ceará', lat: -3.71, lng: -38.54, zoom: 8, regiao: 'NE' },
    { id: 7, sigla: 'DF', descricao: 'Distrito Federal', lat: -15.83, lng: -47.86, zoom: 10, regiao: 'CO' },
    { id: 8, sigla: 'ES', descricao: 'Espírito Santo', lat: -19.19, lng: -40.34, zoom: 8, regiao: 'SE' },
    { id: 9, sigla: 'GO', descricao: 'Goiás', lat: -16.64, lng: -49.31, zoom: 7, regiao: 'CO' },
    { id: 10, sigla: 'MA', descricao: 'Maranhão', lat: -2.55, lng: -44.30, zoom: 6, regiao: 'NE' },
    { id: 11, sigla: 'MT', descricao: 'Mato Grosso', lat: -12.64, lng: -55.42, zoom: 8, regiao: 'CO' },
    { id: 12, sigla: 'MS', descricao: 'Mato Grosso do Sul', lat: -20.51, lng: -54.54, zoom: 8, regiao: 'CO' },
    { id: 13, sigla: 'MG', descricao: 'Minas Gerais', lat: -18.10, lng: -44.38, zoom: 8, regiao: 'SE' },
    { id: 14, sigla: 'PA', descricao: 'Pará', lat: -5.53, lng: -52.29, zoom: 8, regiao: 'N' },
    { id: 15, sigla: 'PB', descricao: 'Paraíba', lat: -7.06, lng: -35.55, zoom: 8, regiao: 'NE' },
    { id: 16, sigla: 'PR', descricao: 'Paraná', lat: -24.32, lng: -50.61, zoom: 8, regiao: 'S' },
    { id: 17, sigla: 'PE', descricao: 'Pernambuco', lat: -8.28, lng: -35.07, zoom: 8, regiao: 'NE' },
    { id: 18, sigla: 'PI', descricao: 'Piauí', lat: -8.28, lng: -43.68, zoom: 8, regiao: 'NE' },
    { id: 19, sigla: 'RJ', descricao: 'Rio de Janeiro', lat: -22.84, lng: -43.15, zoom: 8, regiao: 'SE' },
    { id: 20, sigla: 'RN', descricao: 'Rio Grande do Norte', lat: -5.22, lng: -36.52, zoom: 8, regiao: 'NE' },
    { id: 21, sigla: 'RS', descricao: 'Rio Grande do Sul', lat: -30.01, lng: -51.22, zoom: 8, regiao: 'S' },
    { id: 22, sigla: 'RO', descricao: 'Rondônia', lat: -11.22, lng: -62.80, zoom: 8, regiao: 'N' },
    { id: 23, sigla: 'RR', descricao: 'Roraima', lat: 1.89, lng: -61.22, zoom: 8, regiao: 'N' },
    { id: 24, sigla: 'SC', descricao: 'Santa Catarina', lat: -27.33, lng: -49.44, zoom: 8, regiao: 'S' },
    { id: 25, sigla: 'SP', descricao: 'São Paulo', lat: -23.55, lng: -46.64, zoom: 8, regiao: 'SE' },
    { id: 26, sigla: 'SE', descricao: 'Sergipe', lat: -10.90, lng: -37.07, zoom: 8, regiao: 'NE' },
    { id: 27, sigla: 'TO', descricao: 'Tocantins', lat: -10.25, lng: -48.25, zoom: 8, regiao: 'N' },
    { id: 28, sigla: 'AR', descricao: 'Argentina', lat: -34.603722, lng: -58.381592, zoom: 8, regiao: 'S' },
]
let regiao: Regiao[] = [
    { id: 1, sigla: 'N', descricao: 'Norte', lat: -3.1292, lng: -60.0214, zoom: 6 },
    { id: 2, sigla: 'NE', descricao: 'Nordeste', lat: -5.7947, lng: -35.2414, zoom: 6 },
    { id: 3, sigla: 'CO', descricao: 'Centro-Oeste', lat: -15.7797, lng: -47.9306, zoom: 6 },
    { id: 4, sigla: 'SE', descricao: 'Sudeste', lat: -23.55, lng: -46.6333, zoom: 6 },
    { id: 5, sigla: 'S', descricao: 'Sul', lat: -25.4333, lng: -49.2667, zoom: 6 },
]

let segmentos: Segmento[] = [
    { id: 1, sigla: 'BE', descricao: 'Bens', nome: 'BENS'},
    { id: 3, sigla: 'HM', descricao: 'High Maltose', nome: 'HM'},
    { id: 5, sigla: 'ME', descricao: 'Mercosul', nome: 'MERCOSUL'},
    { id: 6, sigla: 'PA', descricao: 'Papel e Celulose', nome: 'PAPEL'}
]


@Injectable()
export class DadosRegiaoEstado {

    getRegioes(): Regiao[] {
        return regiao;
    }
    getEstados(): Estados[] {
        return estados;
    }
    getSegmentos(): Segmento[] {
        return segmentos;
    }
}
