/** Classe criada para representar os Segmentos */
export class Segmento {
   id: number;
   sigla: string;
   descricao: string;
   nome: string;
}
