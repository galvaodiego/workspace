import { Component, OnInit } from '@angular/core';
import { NavigationService, ClienteService } from 'src/app/shared';

@Component({
    selector: 'loader',
    templateUrl: './loader.component.html',
    styleUrls: ['./loader.component.scss']
})
export class LoaderComponent implements OnInit {

    constructor(
        public navigation: NavigationService,
        public clienteS: ClienteService,
    ) { }

    ngOnInit() {}

}
