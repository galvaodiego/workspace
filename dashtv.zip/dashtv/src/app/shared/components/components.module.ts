import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

import {
   DxTemplateModule,
   DxPopupModule,
   DxDataGridModule,
   DxTooltipModule,
   DxChartModule,
   DxPieChartModule,
   DxSelectBoxModule,
   DxFormModule,
   DxLoadPanelModule
} from 'devextreme-angular';

import { CountdownModule } from 'ngx-countdown';

import { LoaderComponent } from './loader/loader.component';
import { NavbarComponent } from './navbar/navbar.component';
import { ProgressBarComponent } from './progress-bar/progress-bar.component';

import { MapaComponent } from './kmm-mapa/mapa/mapa.component';
import { AtributoComponent } from './kmm-mapa/atributo/atributo.component';
import { DadosRegiaoEstado } from './kmm-mapa/entities';
import { MapaDetalhesComponent } from './kmm-mapa/mapa-detalhes/mapa-detalhes.component';
import { DebuggerComponent } from './debugger/debugger.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { GridComponent } from './grid/grid.component';
import { MapaAlertaComponent } from './kmm-mapa/mapa-alerta/mapa-alerta.component';
import { NavbarPainelComponent } from './navbar_painel/navbar_painel.component';
import { ElementoGraficoComponent } from './elemento-grafico/elemento-grafico.component';

import { TplPopUpComponent } from './templates/tpl-pop-up/tpl-pop-up.component';
import { TemplateModelo1Component } from './templates/tpl-pop-up/modelos/template-modelo1/template-modelo1.component';
import { TemplateModelo2Component } from './templates/tpl-pop-up/modelos/template-modelo2/template-modelo2.component';
import { TemplateModelo3Component } from './templates/tpl-pop-up/modelos/template-modelo3/template-modelo3.component';
import { TemplateModelo4Component } from './templates/tpl-pop-up/modelos/template-modelo4/template-modelo4.component';
import { TemplateModelo5Component } from './templates/tpl-pop-up/modelos/template-modelo5/template-modelo5.component';
import { TemplateModelo6Component } from './templates/tpl-pop-up/modelos/template-modelo6/template-modelo6.component';
import { TemplateModelo7Component } from './templates/tpl-pop-up/modelos/template-modelo7/template-modelo7.component';
import { NoDataFoundComponent } from './no-data-found/no-data-found.component';
import { TemplateModelo8Component } from './templates/tpl-pop-up/modelos/template-modelo8/template-modelo8.component';


@NgModule({
   imports: [
      CommonModule,
      FormsModule,
      ReactiveFormsModule,
      DxPopupModule,
      DxTemplateModule,
      DxDataGridModule,
      DxTooltipModule,
      DxChartModule,
      DxPieChartModule,
      DxSelectBoxModule,
      DxFormModule,
      DxLoadPanelModule,
      CountdownModule,
   ],
   declarations: [
      DebuggerComponent,
      NavbarComponent,
      NavbarPainelComponent,
      LoaderComponent,
      ProgressBarComponent,
      MapaComponent,
      MapaAlertaComponent,
      AtributoComponent,
      MapaDetalhesComponent,
      NotFoundComponent,
      GridComponent,
      ElementoGraficoComponent,
      TplPopUpComponent,
      TemplateModelo1Component,
      TemplateModelo2Component,
      TemplateModelo3Component,
      TemplateModelo4Component,
      TemplateModelo5Component,
      TemplateModelo6Component,
      TemplateModelo7Component,
      TemplateModelo8Component,
      NoDataFoundComponent,
      TemplateModelo8Component

   ],
   exports: [
      DebuggerComponent,
      NavbarComponent,
      NavbarPainelComponent,
      LoaderComponent,
      ProgressBarComponent,
      MapaComponent,
      MapaAlertaComponent,
      AtributoComponent,
      MapaDetalhesComponent,
      NotFoundComponent,
      GridComponent,
      ElementoGraficoComponent,
      TplPopUpComponent,
      TemplateModelo1Component,
      TemplateModelo2Component,
      TemplateModelo3Component,
      TemplateModelo4Component,
      TemplateModelo5Component,
      TemplateModelo6Component,
      TemplateModelo7Component,
      TemplateModelo8Component,
   ],
   providers: [DadosRegiaoEstado]
})
export class ComponentsModule { }
