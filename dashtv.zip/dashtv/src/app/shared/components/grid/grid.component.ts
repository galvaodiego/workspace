import { Component, OnInit, ViewChild, Input, ChangeDetectorRef, AfterViewInit, OnDestroy } from '@angular/core';

import { DxDataGridComponent } from 'devextreme-angular';
import DataGrid from 'devextreme/ui/data_grid';
import { GatewayService } from '../../services/gateway.service';
import notify from 'devextreme/ui/notify';
import { Usuario, ClienteService } from 'src/app/shared';


@Component({
   selector: 'app-grid',
   templateUrl: './grid.component.html',
   styleUrls: ['./grid.component.scss']
})
export class GridComponent implements OnInit, AfterViewInit, OnDestroy {
   public user: Usuario = Usuario.instance;
   @ViewChild('dxDataGrid', { read: DxDataGridComponent, static: true }) dxDataGrid: DxDataGridComponent;
   @ViewChild(DxDataGridComponent, { static: true }) dataGrid: DxDataGridComponent;

   @Input() dataSource: any;
   @Input() masterDetail: any;


   private _toolbar: any;

   constructor(
      protected _cd: ChangeDetectorRef,
      protected _gateway: GatewayService,
      private _clienteS: ClienteService

   ) { }

   saveState() {
      const json = localStorage.getItem(this.dataSource.contextName);
      this.saveModelo(json);
      notify({
         message: 'Modelo salvo com sucesso!',
         type: 'success',
         displayTime: 3000,
         closeOnClick: true,
         width: function () {
            return window.innerWidth / 2.8;
         }
      });


   }

   ngOnInit() {

   }

   ngAfterViewInit() {


      setTimeout(() => {
         //Instancia o Grid na Tela
         // this.optionsMounted();

         //Carrega os Dados no Grid
         this.loadSource();

         //Detecta as Mudanças no Componente
         this._cd.detectChanges();

      }, 1);


   }

   ngOnDestroy() { }

   /**
    * Instancia as Opções no Grid
    */
   public optionsMounted() {
      let op = this.dataSource.options;
      DataGrid.defaultOptions({
         device: { deviceType: 'desktop' },
         options: {
            keyExpr: op.keyExpr ? op.keyExpr : '',
            height: op.height ? op.height : '',
            width: op.width ? op.width : '',
            allowColumnResizing: op.allowColumnResizing ? op.allowColumnResizing : true,
            allowColumnReordering: op.allowColumnReordering ? op.allowColumnReordering : true,
            columnAutoWidth: op.columnAutoWidth ? op.columnAutoWidth : true,
            columnChooser: { enabled: true },
            export: {
               allowExportSelectedData: op.allowExportSelectedData ? op.allowExportSelectedData : false,
               enabled: op.exportEnable ? op.exportEnable : false,
               fileName: this.dataSource.contextName ? this.dataSource.contextName : '',
            },
            filterRow: { visible: op.filterRow ? op.filterRow : false },
            filterSyncEnabled: op.filterSyncEnabled ? op.filterSyncEnabled : true,
            groupPanel: { visible: op.groupPanel ? op.groupPanel : false },
            grouping: { autoExpandAll: op.grouping ? op.grouping : true },
            headerFilter: { allowSearch: true, visible: op.headerFilter ? op.headerFilter : true },
            pager: {
               allowedPageSizes: op.allowedPageSizes ? op.allowedPageSizes : [5, 10, 20, 50],
               showInfo: op.showInfo ? op.showInfo : false,
               showPageSizeSelector: op.showPageSizeSelector ? op.showPageSizeSelector : false
            },
            scrolling: {
               scrollByContent: op.scrollByContent ? op.scrollByContent : true,
               scrollByThumb: op.scrollByThumb ? op.scrollByThumb : true,
               showScrollbar: op.showScrollbar ? op.showScrollbar : 'always',
               useNative: op.useNative ? op.useNative : false
            },
            selection: { mode: op.selection ? op.selection : false },
            showRowLines: op.showRowLines ? op.showRowLines : true,
            editing: {
               allowUpdating: false,
               allowAdding: false,
               allowDeleting: false,
               mode: 'row',
               useIcons: true
            },
            wordWrapEnabled: op.wordWrapEnabled ? op.wordWrapEnabled : true
         }
      });

   }


   /**
    * Carrega os dados no Grid
    * @param changeState 
    */
   loadSource(changeState: boolean = true) {
      if (this.dataSource.contextName) {
         this.dxDataGrid.columns = this.dataSource.columns;
         this.dxDataGrid.instance.option('dataSource', this.dataSource.arrayResult);
         this.getModelo();
      }
   }

   /**
   * Função Para Alterar o Estilo da Tabela
   * @param e Evento recebido pelo componente
   */
   public onCellPrepared(e: any) {


      //Pinta as Linhas de Cabeçalho
      if (e.rowType == 'header') {
         e.cellElement.style.paddingTop = '5px';
         e.cellElement.style.paddingBottom = '5px';
         // e.cellElement.style.lineHeight = '18px';
         e.cellElement.style.fontSize = '1rem';
      } else {
         e.cellElement.style.fontSize = '1rem';
         e.cellElement.style.fontWeight = '700';
         e.cellElement.style.paddingTop = '7px';
         e.cellElement.style.paddingBottom = '7px';
      }

      /////////////////////////////////
      //           REGRAS           ///
      /////////////////////////////////
      if (typeof (e.data) !== 'undefined') {

         //Grids de CARGA e DESCARGA
         if (e.data.tempo_min < 0) {
            this.dxDataGrid.rowAlternationEnabled = false;
            e.cellElement.bgColor = '#be322e';
            e.cellElement.style.color = '#ffffff';
         }
         //Grid Em Carga
         if (e.data.em_carga == 1) {
            this.dxDataGrid.rowAlternationEnabled = false;
            e.cellElement.bgColor = '#be322e';
            e.cellElement.style.color = '#ffffff';
         }
      }


      // GRIDS TRANSIT TIME
      if (this.dataSource.contextName == 'TransitTimeGrid') {
         this.dxDataGrid.rowAlternationEnabled = false;
         if (typeof (e.key) !== 'undefined') {
            if (e.key.nac_no_prazo_rota == null || typeof (e.key.nac_no_prazo_rota) == 'undefined') {

               //Regra para quem não usa configura o TT no KMM 
               if (e.key.executado_horas == 1) {
                  e.cellElement.bgColor = '#be322e';
                  e.cellElement.style.color = '#ffffff';
               }
            } else {
               if (e.key.tempo_atraso < 0) {
                  e.cellElement.bgColor = '#be322e';
                  e.cellElement.style.color = '#ffffff';
               }
            }
         }
      }




   }

   /**
    * Prepara Botões da Toolbar
    * @param e evento do componente
    */
   onToolbarPreparing = (e: any) => {
      const toolbaropems = e.toolbarOptions.opems;
      const toolbarItems = e.toolbarOptions.items;
      const obj = this;
      toolbarItems.push({
         widget: 'dxButton',
         options: {
            hint: 'Salvar modelo',
            icon: 'save', onClick: function () {
               obj.saveState();
            }
         },
         location: 'after'
      });

      let opems: any;

      if (typeof (toolbaropems) !== 'undefined') {
         toolbaropems.forEach(function (opem) {
            if (opem.name === 'searchPanel') {
               opem.location = 'after';
            }
         });
      }

      const defaultopems = [
         {
            location: 'after',
            widget: 'dxButton',
            options: {
               icon: 'refresh',
               hint: 'Atualizar',
               elementAttr: {
                  id: 'atualizar'
               },
               // onClick: () => this._gridService.callRefresh()
            }
         }
      ];


      //Se tiver uma Toolbar Custom vinda do Input usa ela
      //   se não usa a Padrão criada acima
      if (this.toolbar) {
         opems = defaultopems.concat(this.toolbar);
      } else {
         opems = defaultopems;
      }

      if (typeof (toolbaropems) !== 'undefined') {
         opems.forEach(opem => {
            toolbaropems.push(opem);
         });
      }
   }


   @Input()
   set toolbar(toolbar: any) {
      this._toolbar = toolbar;
   }

   get toolbar(): any {
      return this._toolbar;
   }

   async saveModelo(json) {
      const org = JSON.parse(localStorage.getItem('kmm_bi-dash|' + this._clienteS.discover() + '-organizacional'));
      try {
         const parametros = {
            grid_ref: this.dataSource.contextName,
            usuario: org.usuario.usuario,
            json_colunas: json
         };

         const response: any = await this._gateway.backendCall('M4002', 'cadModeloGrid', parametros);
         return response;

      } catch (error) {
         console.log(error);
      }

   }

   async getModelo() {
      const org = JSON.parse(localStorage.getItem('kmm_bi-dash|' + this._clienteS.discover() + '-organizacional'));
      try {
         const parametros = {
            grid_ref: this.dataSource.contextName,
            usuario: org.usuario.usuario,
         };

         const response: any = await this._gateway.backendCall('M4002', 'getModeloGrid', parametros);
         // console.log('[PARAMETROS]', parametros, '[RETORNO]', response);

         if (response.modelo_grid) {
            this.dxDataGrid.instance.state(JSON.parse(response.modelo_grid[0].json_colunas));
         }

      } catch (error) {
         console.log(error);
      }

   }

}
