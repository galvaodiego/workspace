import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { confirm } from 'devextreme/ui/dialog';

import { environment } from 'src/environments/environment';
import { Usuario, UsuarioService, NavigationService, EstruturaOrganizacional } from 'src/app/shared';
import { ClienteService } from '../../services/cliente.service';

@Component({
    selector: 'app-navbar-painel',
    templateUrl: './navbar_painel.component.html',
    styleUrls: ['./navbar_painel.component.scss'],
    host: { '(window:keydown)': 'hotkeys($event)' }
})
export class NavbarPainelComponent implements OnInit {

    public user: Usuario = Usuario.instance;
    public org: EstruturaOrganizacional = EstruturaOrganizacional.instance;

    public showLogout: boolean = false;
    public showUser: boolean = false;

    public base: any = [];
    public version: string

    public itemHover: any

    /////////////////////////////////////////////////
    // Controle de Atalhos do Teclado 
    /////////////////////////////////////////////////
    hotkeys(event: any) {
        //F2 Altera o Estado do Menu de Opções
        if (event.keyCode == 113) {
            this.showMenuOptions();
        }
        //F4 Sai do Sistema
        if (event.keyCode == 115) {
            this.logout();
        }
        //F7 Altera o Estado da ProgressBar
        if (event.keyCode == 118) {
            this.showProgressBar();
        }
        //F8 Retrocede um Dash
        if (event.keyCode == 119) {
            this.navigation.previous();
        }
        //F9  Avança um Dash
        if (event.keyCode == 120) {
            this.navigation.next();
        }
        //F10  Inicia Timer da Tela
        if (event.keyCode == 121) {
            this.navigation.InitTela();
        }

    }

    constructor(
        private _userProvider: UsuarioService,
        private _router: Router,
        public clienteS: ClienteService,
        public navigation: NavigationService
    ) {
        this.version = environment.version;

        if (this.org.base !== '' && typeof (this.org.base) != 'undefined') {
            let temp = this.org.base.split('.');
            this.base = temp[0]
        } else {
            this.base = this.user.ambiente
        }
    }

    ngOnInit() { }

    public teste() {
        this._router.navigate(['logistica/trafego-ocorrencia'])
    }

    public hoverOption(item: any) {
        this.itemHover = item;
    }

    public leaveTooltip() {
        this.itemHover = -1;
    }

    /**
    * Mostra a ProgressBar de Timer nas Telas
    */
    public showProgressBar() {
        this.user.showProgressBar = !this.user.showProgressBar;
        this._userProvider.save();
    }

    /**
     * ALtera o estado do Menu de Opções
     */
    public showMenuOptions() {
        this.user.showMenuOpcoes = !this.user.showMenuOpcoes;
        this._userProvider.save();
    }


    /**
    * Sair do Sistema
    */
    public logout() {
        const result = confirm(`Você tem certeza que deseja encerrar a sessão?`, 'Sair');
        result.then((dialogResult) => {
            if (dialogResult) {
                this.user = null;
                localStorage.clear();
                window.location.reload();
            }
        });
    }

}
