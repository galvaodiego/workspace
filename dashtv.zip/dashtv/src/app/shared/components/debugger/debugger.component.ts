import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Component, OnInit, Input } from '@angular/core';
import { Usuario, UsuarioService } from 'src/app/shared';

import notify from 'devextreme/ui/notify';

@Component({
    selector: 'app-debugger',
    templateUrl: './debugger.component.html',
    styleUrls: ['./debugger.component.scss']
})
export class DebuggerComponent implements OnInit {

    public user: Usuario = Usuario.instance
    @Input() opcaoSelecionada: number;

    public formUrl: FormGroup;


    constructor(
        public userProv: UsuarioService
    ) {
        this.formUrl = new FormGroup({
            novaUrl: new FormControl('', Validators.required)
        });
    }

    ngOnInit() {

        console.log('menu Debug', this.opcaoSelecionada);

    }



    /**
     * Efetua a Troca de URL
     */
    public trocaUrl() {
        this.user.url = this.verificaUrl(this.formUrl.get('novaUrl').value);
        this.userProv.save();
        notify('Url Alterada! ', 'success', 3000)
    }

    /**
    * Verifica e converte a url para um valor válido. 
    * @param url Url digitada
    */
    public verificaUrl(url: string) {
        if (!url.startsWith("http")) {
            url = "http://" + url;
        }
        if (!this.isURL(url)) {
            notify('Url Inválida! ', 'danger', 3000)
        }
        return url;
    }

    /**
    * Valida se a URL é válida
    * @param str string que contém a URL
    */
    isURL(str: string): boolean {
        var urlRegex = '^(?!mailto:)(?:(?:http|https|ftp)://)(?:\\S+(?::\\S*)?@)?(?:(?:(?:[1-9]\\d?|1\\d\\d|2[01]\\d|22[0-3])(?:\\.(?:1?\\d{1,2}|2[0-4]\\d|25[0-5])){2}(?:\\.(?:[0-9]\\d?|1\\d\\d|2[0-4]\\d|25[0-4]))|(?:(?:[a-z\\u00a1-\\uffff0-9]+-?)*[a-z\\u00a1-\\uffff0-9]+)(?:\\.(?:[a-z\\u00a1-\\uffff0-9]+-?)*[a-z\\u00a1-\\uffff0-9]+)*(?:\\.(?:[a-z\\u00a1-\\uffff]{2,})))|localhost)(?::\\d{2,5})?(?:(/|\\?|#)[^\\s]*)?$';
        var url = new RegExp(urlRegex, 'i');
        return str.length < 2083 && url.test(str);
    }

}
