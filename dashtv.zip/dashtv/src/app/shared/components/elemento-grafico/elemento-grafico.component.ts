import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { DxDataGridComponent, DxPieChartComponent, DxChartComponent } from 'devextreme-angular';
import { ActivatedRoute } from '@angular/router';

@Component({
   selector: 'app-elemento-grafico',
   templateUrl: './elemento-grafico.component.html',
   styleUrls: ['./elemento-grafico.component.scss']
})
export class ElementoGraficoComponent implements OnInit {
   @ViewChild('tabela', { static: false }) tabela: DxDataGridComponent;
   @ViewChild('pie', { static: false }) pie: DxPieChartComponent;
   @ViewChild('chartMeta', { static: false }) chartMeta: DxChartComponent;

   @Input() tipo: string;
   @Input() titulo: string;
   @Input() datasource: any;
   @Input() height: number;
   @Input() width: number;
   @Input() af: string; // argumentField
   @Input() vf: string; // valueField
   @Input() vf2: string; // valueField 2
   @Input() pageSize: number; // paginação de tabelas
   @Input() tipo_legenda: string; // define a forma que deve ser exibido a legenda.
   @Input() cores_series: Array<any> = []; // cores para series dos charts.

   index_tabela = 0;
   porVeiculos = 'Placa';
   config_pie = {
      grafico_pizza_legenda: true,
      grafico_pizza_label: false
   };

   linhaHorizontalMeta = true;
   constructor(
      private route: ActivatedRoute
   ) { }

   ngOnInit() {
      this.route.data.subscribe(rota => {
         if (rota.dashboard) {
            switch (rota.dashboard) {
               case 'faturamento':
                  const fatTipoFatVeiculo = localStorage.getItem('faturamento-tipoFatVeiculo');
                  if (fatTipoFatVeiculo) {
                     this.porVeiculos = fatTipoFatVeiculo;
                  }
                  const faturamentoConfigPie = JSON.parse(localStorage.getItem('faturamentoConfigPie'));
                  if (faturamentoConfigPie) {
                     this.config_pie = faturamentoConfigPie;
                  }
                  break;
               case 'viagens':
                  const viagensConfigPie = JSON.parse(localStorage.getItem('viagensConfigPie'));
                  if (viagensConfigPie) {
                     this.config_pie = viagensConfigPie;
                  }
                  break;
            }
         }

      });

      // const obj = {
      //    tipo: this.tipo,
      //    titulo: this.titulo,
      //    datasource: this.datasource,
      //    height: this.height,
      //    width: this.width,
      //    af: this.af,
      //    vf: this.vf,
      //    pageSize: this.pageSize,
      //    tipo_legenda: this.tipo_legenda,
      // };
      // console.log('DEBUG:', obj);
      setInterval(() => {
         this.trocaPagina();
      }, 10000);
   }

   customizeTextLabel(arg) {
      return arg.argumentText + ': ' + arg.valueText + ' (' + arg.percentText + ')';
   }
   customizeLabel = (arg: any) => {
      return {
         customizeText(e: any) {
            if (arg.series.tag) {
               switch (arg.series.tag) {
                  case 'numero':
                     return e.value;
                     break;
                  case 'valor':
                     return 'R$ ' + e.valueText;
                     break;
               }
            } else {
               return 'R$ ' + e.valueText;
            }
         }
      };
   }

   customizeLegend = (arg: any) => {
      let valor = 0;
      this.datasource.forEach(element => {
         if (element.cliente === arg.pointName) {
            valor = element.valor;
         }

         if (element.carroceria === arg.pointName) {
            valor = element.valor;
         }

         if (element.modalidade === arg.pointName) {
            valor = element.valor;
         }

         if (element.mercadoria === arg.pointName) {
            valor = element.valor;
         }

         if (element.filial === arg.pointName) {
            valor = element.valor;
         }

         if (element.descricao === arg.pointName) {
            valor = element.valor;
         }

         if (element.operacao === arg.pointName) {
            valor = element.qtde;
         }

         if (element.cancelado_por === arg.pointName) {
            valor = element.qtde;
         }
      });

      return arg.pointName + ' ( ' + this.thousands_separators(valor.toFixed()) + ' )';
   }

   thousands_separators(num) {
      const num_parts = num.toString().split('.');
      num_parts[0] = num_parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, '.');
      return num_parts.join('.');
   }

   trocaPagina() {
      // tabela
      if (this.tabela) {
         const total_pd = this.tabela.instance.pageCount();
         if (total_pd > 1) {
            if (this.index_tabela === total_pd - 1) {
               this.index_tabela = 0;
            } else {
               this.index_tabela++;
            }
            this.tabela.instance.pageIndex(this.index_tabela);
         }
      }
   }

   toggleLabel() {
      const flag = !this.pie.instance.option('series[0].label.visible');
      this.pie.instance.option('series[0].label.visible', flag);
   }

   toggleLegend() {
      const flag = !this.pie.instance.option('legend.visible');
      this.pie.instance.option('legend.visible', flag);
   }

   toggleMeta() {
      const flag = !this.chartMeta.instance.option('series[0].label.visible');
      console.log('toggleMeta', flag);

      this.chartMeta.instance.option('series[0].label.visible', flag);
   }

   toggleRealizado() {
      const flag = !this.chartMeta.instance.option('series[1].label.visible');
      console.log('toggleRealizado', flag);
      this.chartMeta.instance.option('series[1].label.visible', flag);
   }

   public onCellPreparedDesba(e: any) {
      if (e.rowType === 'header') {
         e.cellElement.style.paddingTop = '5px';
         e.cellElement.style.paddingBottom = '5px';
      }

      if (typeof (e.data) !== 'undefined') {
         e.cellElement.style.paddingTop = '5px';
         e.cellElement.style.paddingBottom = '5px';
      }

   }

   public onCellPreparedemissPorUsuario(e: any) {
      if (e.rowType === 'header') {
         e.cellElement.style.paddingTop = '5px';
         e.cellElement.style.paddingBottom = '5px';
      }

      if (typeof (e.data) !== 'undefined') {
         e.cellElement.style.paddingTop = '20px';
         e.cellElement.style.paddingBottom = '20px';
         e.cellElement.style.fontSize = '40px';
         e.cellElement.style.color = '#007bff';
      }
   }

   public gridContainerRomNaoFaturado(e: any) {
      if (e.data) {
         if (e.data.ALERT_SEM_DOC === 1) {
            e.cellElement.style.color = '#ffffff';
            e.cellElement.style.backgroundColor = '#dc3545';
         }
      }
   }

   public onCellPreparedPorPeriodo(e: any) {
      if (e.rowType === 'header') {
         e.cellElement.style.paddingTop = '5px';
         e.cellElement.style.paddingBottom = '5px';
      }

      if (typeof (e.data) !== 'undefined') {
         e.cellElement.style.paddingTop = '5px';
         e.cellElement.style.paddingBottom = '5px';
         e.cellElement.style.color = '#007bff';
         e.cellElement.style.fontSize = '35px';

      }
   }
   public onCellPreparedRegular(e: any) {
      if (e.rowType === 'header') {
         e.cellElement.style.paddingTop = '5px';
         e.cellElement.style.paddingBottom = '5px';
      }

      if (typeof (e.data) !== 'undefined') {
         e.cellElement.style.paddingTop = '5px';
         e.cellElement.style.paddingBottom = '5px';
         e.cellElement.style.color = '#666';
      }
   }

}
