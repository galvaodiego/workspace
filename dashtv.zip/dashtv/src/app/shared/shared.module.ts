import { RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ComponentsModule } from './components/components.module';
import { MinuteSecondsPipe } from './pipes/minute-seconds.pipe';
import { MaterialModule } from './material/material.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

@NgModule({
   imports: [
      CommonModule,
      ComponentsModule,
      RouterModule,
      MaterialModule,
      ReactiveFormsModule,
      FormsModule
   ],
   exports: [
      ComponentsModule,
      MinuteSecondsPipe,
      MaterialModule,
      ReactiveFormsModule,
      FormsModule
   ],
   declarations: [MinuteSecondsPipe]
})
export class SharedModule { }
