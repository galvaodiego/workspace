import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const MANUTENCAO_ROUTES: Routes = [
    {
        path: '',
        loadChildren: 'src/app/modulos/manutencao/presenters/presenters.module#PresentersModule',
    }
];

export const ManutencaoRouting: ModuleWithProviders = RouterModule.forChild(MANUTENCAO_ROUTES);