import { ModuleWithProviders } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { GuardaRotas } from 'src/app/shared';
import { PreventivaComponent } from './preventiva/preventiva.component';
import { GestaoComponent } from './gestao/gestao.component';
import { OficinaComponent } from './oficina/oficina.component';
import { ExecucaoComponent } from './execucao/execucao.component';

// Componentes
const modulo = 'manutencao';
const PRESENTERS_ROUTES: Routes = [
   {
      path: 'manutencao-preventiva',
      component: PreventivaComponent,
      canActivate: [GuardaRotas],
      data: { modulo }
   },
   {
      path: 'manutencao-gestao',
      component: GestaoComponent,
      canActivate: [GuardaRotas],
      data: { modulo }
   },
   {
      path: 'painel-oficina',
      component: OficinaComponent,
      canActivate: [GuardaRotas],
      data: { modulo, versao: 1 }
   },
   {
      path: 'painel-oficinav2',
      component: OficinaComponent,
      canActivate: [GuardaRotas],
      data: { modulo, versao: 2 }
   },
   {
      path: 'execucao',
      component: ExecucaoComponent,
      canActivate: [GuardaRotas],
      data: { modulo }
   },
];

export const PresentersRouting: ModuleWithProviders = RouterModule.forChild(PRESENTERS_ROUTES);

