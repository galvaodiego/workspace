import { Component } from '@angular/core';
import { Usuario, ClienteService, EstruturaOrganizacional } from 'src/app/shared';

@Component({
    selector: 'app-gestao',
    templateUrl: './gestao.component.html',
    styleUrls: ['./gestao.component.scss']
})
export class GestaoComponent {

    public user: Usuario = Usuario.instance;
    public org: EstruturaOrganizacional = EstruturaOrganizacional.instance;

    public flag: number;

    constructor(
        public clienteS: ClienteService
    ) {
        
    }


}
