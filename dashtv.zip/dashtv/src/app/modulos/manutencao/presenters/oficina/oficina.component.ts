import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { Usuario } from 'src/app/shared/models/usuario.model';
import { NavigationService, GatewayService, ClienteService } from 'src/app/shared';

// Plugins
import * as moment from 'moment';
import 'moment/locale/pt-br';
import * as _ from 'underscore';
import { DxMultiViewComponent, DxDataGridComponent } from 'devextreme-angular';
import SetInterval from 'set-interval';
import { ActivatedRoute } from '@angular/router';
import io from 'socket.io-client';
import { environment } from 'src/environments/environment';


@Component({
   selector: 'app-oficina',
   templateUrl: './oficina.component.html',
   styleUrls: ['./oficina.component.scss']
})
export class OficinaComponent implements OnInit, OnDestroy {
   @ViewChild('multiview', { static: false }) multiview: DxMultiViewComponent;
   @ViewChild('gridMecanicos', { static: false }) gridMecanicos: DxDataGridComponent;

   // Config Socket
   socket_io: any;
   socket_rota = 'box';
   socket_metodo = 'getBox';
   socket_filtro: any;
   /***/

   user: Usuario = Usuario.instance;

   public abreModal = true;
   public listaAgrupamentos: Array<any> = [];
   public agrupamentosSelecionados: Array<any> = [];
   public parameterListCardsBoxes: Array<any> = [];
   public listaBoxes: Array<any> = [];

   // responsavel atualizar tela
   public timer = 0;
   public trocaTela: any;

   public boxOsLength = 0;

   public nowHour: string;
   public nowToday: string;
   public tempo_medio: any = [];
   public ordensServico: any = [];
   public mecanicos: any = [];
   public boxes: any = [];
   public indicadores: any = [];
   public usuario: any;
   public selecionados = [];

   public startBox = 0;
   public finalBox = 4;
   public startTable1 = 0;
   public finalTable1 = 4;
   public startTable2 = 4;
   public finalTable2 = 8;
   public executingOrders = 0;
   public waitingOrders = 0;
   public finalizedOrders = 0;
   public interval: any;
   public conjuntoBox: any;
   public boxAtual: any;
   public parameterList: Array<any> = [];

   /**
    * TABS CONTROL
    */
   public tabs: any = [];
   public tables: any = [];


   /** --------------------------------- */
   public selectedItens = [];
   views: Array<any>;
   porPagina: number;
   pages = 0;
   index_mecanico = 0;


   constructor(
      public navigation: NavigationService,
      private _gateway: GatewayService,
      private _clienteS: ClienteService,
      private route: ActivatedRoute
   ) {
      this.socket_io = io(environment.socket_end_point + '/' + this.socket_rota);
      this.socket_filtro = {
         base: (this._clienteS.clienteAtivo !== 'KMM' ? this._clienteS.clienteAtivo : environment.end_point_base_dev).toLowerCase(),
         token: this.user.token
      };

      const clienteSelecionado = JSON.parse(localStorage.getItem('cliente-selecionado'));
      if (clienteSelecionado) {
         Object.assign(this.socket_filtro, {
            url: clienteSelecionado.url
         });
      }
      moment.locale('pt-br');
      this.navigation.loaderTela = true;
      this.navigation.hideTimeBar = false;
      // this.navigation.timer_troca_tela = 30000000; // importante para funcionar corretamente a troca de tela
      this.navigation.timer_troca_tela = 300000; // importante para funcionar corretamente a troca de tela

      this.user.showIconOpcoes = false;
      this.user.showIconFiltro = false;
      this.user.showFiltroOpcoes = false;
      this.user.showIconTemplates = false;
      this.user.showTemplates = false;

      if (this.getFilters(this.user.selectedDashboard).length == 0) {
         this.parameterList = [
            {
               tipo: 'CARD_BOXES',
               values: []
            },
         ];
         this.setFilters(this.user.selectedDashboard, this.parameterList);
         this.abreModal = true;
      } else {
         this.parameterList = this.getFilters(this.user.selectedDashboard);
      }
   }

   ngOnInit() {
      this.getData().then(() => {
         this.navigation.trocaDash();
         const config = JSON.parse(localStorage.getItem('oficina-config'));
         if (config) {
            this.abreModal = false;
            this.selectedItens = config.selectedItens;
            this.updateListBoxes(this.selectedItens);

         }
         SetInterval.start(() => {
            this.trocaPagina();
         }, 5000, 'intervalo_tabelas');
      });

   }

   ngOnDestroy(): void {
      SetInterval.clear('intervalo_tabelas');
      SetInterval.clear('trocaView');
      this.socket_io.disconnect();
   }

   async getData() {
      // console.log('versao:', this.route.snapshot.data['versao'])

      this.manageDateHour();
      this.switchTabs();

      try {

         switch (this.route.snapshot.data['versao']) {
            case 1:
               const org = JSON.parse(localStorage.getItem('kmm_bi-dash|' + this._clienteS.discover() + '-organizacional'));
               const usuario = JSON.parse(localStorage.getItem('kmm_bi-dash|' + this._clienteS.discover() + '-usuario'));
               const parametros = {
                  'username': usuario.usuario
               };
               const result: any = await this._gateway.backendCall('M4002', 'getOficinaBoxes', parametros);
               console.log('response:', result);
               this.navigation.loaderTela = false;
               this.boxes = result.oficina.boxes;
               this.ordensServico = result.oficina.ordem_servico;
               this.mecanicos = result.oficina.mecanicos_disponiveis;
               this.indicadores = result.oficina.os_indicadores;
               this.preparacaoDados();
               break;

            case 2:
               this.socket_io.emit(this.socket_metodo, this.socket_filtro);
               this.socket_io.on(this.socket_rota, (response) => {
                  console.log('filtro:', this.socket_filtro);
                  console.log('resposta socket:', response);
                  this.navigation.loaderTela = false;
                  this.boxes = response.oficina.boxes;
                  this.ordensServico = response.oficina.ordem_servico;
                  this.mecanicos = response.oficina.mecanicos_disponiveis;
                  this.indicadores = response.oficina.os_indicadores;
                  this.preparacaoDados();
               });
               break;

         }
      } catch (error) {
         console.log(error);
      }



   }

   preparacaoDados() {
      this.boxOsLength = 1;
      this.indicadores.forEach(indicator => {
         if (indicator.situacao === 'EXECUTANDO') {
            this.executingOrders = indicator.quantidade;

         } else if (indicator.situacao === 'AGUARDANDO') {
            this.waitingOrders = indicator.quantidade;

         } else if (indicator.situacao === 'ENCERRADAS') {
            this.finalizedOrders = indicator.quantidade;

         }
      });

      // this.boxes.forEach(
      //    (el) => {
      //       el.countOs = el.os.length;
      //    }
      // );
      // this.parameterList = this.getFilters(this.user.selectedDashboard);
      this.listaBoxes = [];

      setTimeout(is => {
         this.parameterList[0].values.forEach(
            element => {
               this.boxes.findIndex(box => {
                  if (box.box_id == element) {
                     this.listaBoxes.push(box);
                  }
               });
            }
         );
      }, 100);

      /**
       * PREPARA LISTA PARA OS FILTROS
       */
      this.listaAgrupamentos = [];

      const tempArray = [];
      this.boxes.forEach(element => {
         let obj: any = {};
         obj = element;
         tempArray.push(obj);
      });

      let listaBoxes: Array<any> = [];
      listaBoxes = _.uniq(tempArray);

      listaBoxes.forEach(element => {
         const obj: any = {};
         obj.agrupamento_id = element.box_id;
         obj.agrupamento = element.descricao;
         obj.checked = false;
         this.listaAgrupamentos.push(obj);
      });

      this.listaAgrupamentos.forEach(
         (element) => {
            if (this.parameterList[0].values.findIndex(el => element.agrupamento_id == el) != -1) {
               element.checked = true;
               // this.selectedItens.push(element.agrupamento_id);
            }
         }
      );

      this.feedTabs();
   }

   public updateListBoxes(e) {
      this.agrupamentosSelecionados = e;
      this.parameterList[0].values = this.agrupamentosSelecionados;
      this.listaBoxes = [];
      setTimeout(is => {
         this.parameterList[0].values.forEach(
            element => {
               this.boxes.findIndex(box => {
                  if (box.box_id == element) {
                     this.listaBoxes.push(box);
                  }
               });
            }
         );
         this.multiView();
      }, 100);

      this.setFilters(this.user.selectedDashboard, this.parameterList);

   }

   multiView() {
      this.views = [];
      this.pages = Math.ceil(this.listaBoxes.length / 5);
      for (let index = 0; index < this.pages; index++) {
         this.views.push(this.paginate(this.listaBoxes, 5, index + 1));
      }

      // controla a troca de paginas
      SetInterval.start(() => {
         this.trocaView(this.pages);
      }, 10000, 'trocaView');

   }

   paginate(array, page_size, page_number) {
      --page_number; // because pages logically start with 1, but technically with 0
      return array.slice(page_number * page_size, (page_number + 1) * page_size);
   }

   trocaView(paginas) {
      if (this.multiview) {
         if (this.multiview.selectedIndex === paginas - 1) {
            this.multiview.selectedIndex = 0;
         } else {
            this.multiview.selectedIndex = this.multiview.selectedIndex + 1;
         }
      }
   }

   public moveToFilterString(e) {
      const config = {
         selectedItens: this.selectedItens
      };
      localStorage.setItem('oficina-config', JSON.stringify(config));
      this.updateListBoxes(this.selectedItens);
   }

   public limpaSelecionados() {
      localStorage.removeItem('oficina-config');
      this.selectedItens = [];
      // this.selecionados = [];
      this.agrupamentosSelecionados = [];
      this.parameterList = [
         {
            tipo: 'CARD_BOXES',
            values: []
         },
      ];

      this.setFilters(this.user.selectedDashboard, this.parameterList);
      this.getData();
   }

   /**
    * FUNÇÃO QUE SETA OS VALORES DE DATA E HORA NO MOMENTO DE SUA CHAMADA
    */
   private manageDateHour() {
      this.nowHour = moment().format('HH:mm');
      this.nowToday = moment().format('DD') + ' DE ' + moment().format('MMMM').toUpperCase();
   }

   /**
   *  Salva o filtro do painel na sessão.
   * @param {number} numDash - Número do dash que contém o filtro
   * @param {Array<any>} parameters - Parâmetros do filtro
   */

   public setFilters(numDash: number, parameters: Array<any>) {
      this.user.listaDashboards[this.user.listaDashboards.findIndex(element => element.dash_id == numDash)].filters = parameters;
      // this.usuarioProvider.save();
   }

   /**
    *  Resgata o filtro do painel da sessão.
    * @param {number} numDash - Número do dash que contém o filtro
    */
   public getFilters(numDash: number) {
      const filters = this.user.listaDashboards[this.user.listaDashboards.findIndex(element => element.dash_id == numDash)].filters;

      if (filters.length > 0) {
         this.abreModal = false;
         this.parameterList = [
            {
               tipo: 'CARD_BOXES',
               values: [filters[0].values]
            }
         ];
      }
      return filters;
   }

   public feedTabs() {
      this.tabs = [];

      let countMax = 4, count = 0, countFix = 4, countTable = 0, countTabs = 1;

      do {
         const ordensTemp = [];
         this.tables.push(
            {
               items: []
            }
         );

         for (count; count < countMax; count++) {
            ordensTemp.push(this.ordensServico[count]);
         }

         this.tables[countTable].items = ordensTemp;

         countMax += countFix;
         countTable++;

         if (countMax > this.ordensServico.length) {
            countMax -= countFix;
            countMax += (this.ordensServico.length - countMax);
         }

      } while (count < this.ordensServico.length);



      for (let i = 0; i < this.ordensServico.length / 4 / 2; i++) {
         this.tabs.push(
            {
               tabId: countTabs,
               tabName: 'tab' + countTabs,
               active: false
            }
         );
         countTabs++;
      }

      this.tabs[0].active = true;
   }

   private manageTabs(tabId: number) {
      for (let i = 0; i < this.tabs.length; i++) {
         if (tabId === this.tabs[i].tabId) {
            this.tabs[i].active = true;
         } else {
            this.tabs[i].active = false;
         }
      }
   }

   /**
   * REALIZA A ALTERNÂNCIA ENTRE AS TABS
   */
   private switchTabs() {
      let i = 0;
      this.interval = setInterval(
         tabs => {
            i++;

            if (i > this.tabs.length) {
               i = 1;
               this.startTable1 = 0;
               this.finalTable1 = 4;
               this.startTable2 = 4;
               this.finalTable2 = 8;
            }
            if (i >= 2) {
               this.startTable1 += 8;
               this.finalTable1 += 8;
               this.startTable2 += 8;
               this.finalTable2 += 8;
            }
            this.manageTabs(i);
         }, 30000);
   }


   public onCellPrepared(e: any) {
      if (e.rowType === 'header') {
         e.cellElement.style.display = 'none';
      }

      if (typeof (e.data) !== 'undefined') {
         e.cellElement.style.paddingTop = '5px';
         e.cellElement.style.paddingBottom = '5px';
         e.cellElement.style.color = '#ffffff';
         e.cellElement.style.backgroundColor = '#2f395c';
         e.cellElement.style.fontWeight = 'bold';
         e.cellElement.style.fontSize = '0.9rem';
      }

   }

   trocaPagina() {
      // gridMecanicos
      if (this.gridMecanicos) {
         const total_pd = this.gridMecanicos.instance.pageCount();
         if (total_pd > 1) {
            if (this.index_mecanico === total_pd - 1) {
               this.index_mecanico = 0;
            } else {
               this.index_mecanico++;
            }
            this.gridMecanicos.instance.pageIndex(this.index_mecanico);
         }
      }


   }

}
