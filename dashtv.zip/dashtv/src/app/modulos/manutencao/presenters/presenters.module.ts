import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PresentersRouting } from './presenters.routing';
import { FeaturesModule } from '../features/features.module';

import { ComponentsModule } from 'src/app/shared/components/components.module';
import { DxTagBoxModule, DxResponsiveBoxModule, DxPopupModule, DxScrollViewModule, DxMultiViewModule, DxDataGridModule, DxChartModule, DxBarGaugeModule } from 'devextreme-angular';
// Componentes
import { PreventivaComponent } from './preventiva/preventiva.component';
import { GestaoComponent } from './gestao/gestao.component';
import { OficinaComponent } from './oficina/oficina.component';
import { ExecucaoComponent } from './execucao/execucao.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ExecKpiComponent } from './execucao/exec-kpi/exec-kpi.component';
import { BarHorComponent } from './execucao/bar-hor/bar-hor.component';


@NgModule({
   imports: [
      CommonModule,
      ComponentsModule,
      FormsModule, ReactiveFormsModule,
      DxTagBoxModule,
      DxPopupModule,
      DxResponsiveBoxModule,
      DxScrollViewModule,
      DxMultiViewModule,
      DxDataGridModule,
      PresentersRouting,
      FeaturesModule,
      DxChartModule,
      DxBarGaugeModule,
   ],
   declarations: [
      PreventivaComponent,
      GestaoComponent,
      OficinaComponent,
      ExecucaoComponent,
      ExecKpiComponent,
      BarHorComponent

   ],
})
export class PresentersModule { }
