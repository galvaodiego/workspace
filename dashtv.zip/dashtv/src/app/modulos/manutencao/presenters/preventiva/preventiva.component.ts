import { Component } from '@angular/core';
import { Usuario, ClienteService, EstruturaOrganizacional } from 'src/app/shared';

@Component({
    selector: 'app-preventiva',
    templateUrl: './preventiva.component.html',
    styleUrls: ['./preventiva.component.scss']
})
export class PreventivaComponent {

    public user: Usuario = Usuario.instance;
    public org: EstruturaOrganizacional = EstruturaOrganizacional.instance;

    public flag: number;

    constructor(
        public clienteS: ClienteService
    ) {
        
    }


}
