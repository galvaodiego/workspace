import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BarHorComponent } from './bar-hor.component';

describe('BarHorComponent', () => {
  let component: BarHorComponent;
  let fixture: ComponentFixture<BarHorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BarHorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BarHorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
