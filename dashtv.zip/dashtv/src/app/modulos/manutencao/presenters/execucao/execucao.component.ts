import { Component, OnInit, OnDestroy, ChangeDetectorRef, AfterContentChecked, ViewChild, AfterViewChecked } from '@angular/core';
import SetInterval from 'set-interval';
import { Usuario, NavigationService, GatewayService, ClienteService } from 'src/app/shared';
import { DummyExecucaoService } from './dummy-execucao.service';
import { DxBarGaugeComponent, DxDataGridComponent, DxPopupComponent } from 'devextreme-angular';
import { getPalette } from 'devextreme/viz/palette';
import * as _ from 'underscore';
import { UtilitarioService } from 'src/app/shared/services/common/utilitario.service';
import io from 'socket.io-client';
import { environment } from 'src/environments/environment';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';


@Component({
   selector: 'app-execucao',
   templateUrl: './execucao.component.html',
   styleUrls: ['./execucao.component.scss']
})
export class ExecucaoComponent implements OnInit, OnDestroy, AfterViewChecked {
   @ViewChild('barGauge', { static: false }) barGauge: DxBarGaugeComponent;
   @ViewChild('tabela', { static: false }) tabela: DxDataGridComponent;
   @ViewChild('tabela2', { static: false }) tabela2: DxDataGridComponent;
   @ViewChild('popFiltro', { static: false }) popFiltro: DxPopupComponent;


   public user: Usuario = Usuario.instance;
   index_tabela = 0;
   index_tabela2 = 0;
   dataTableTAPP = [];
   dataTableTAPM = [];
   dataTableQOPP = [];
   chartQOAPM = [];
   chartOAPT = {
      valores: [],
      legendas: []
   };
   chartTAPP = [];
   // Config Socket
   socket_io: any;
   socket_rota = 'manutencao';
   socket_metodo = 'getManutencao';
   socket_filtro: any;
   /***/

   indicadores = {
      disponibilidade: 0,
      qtde_itens_os_aberta: 0,
      qtde_os_aberta: 0,
      qtde_veiculo_os_aberta: 0
   };

   legendasTAPP = [];

   filtroOptions = {
      ccg: []
   };

   filtroForm: FormGroup;

   kpi;
   bar = {
      os_placa: [],
      os_marca_carreta: [],
      os_marca_cavalo: []
   };
   constructor(
      public navigation: NavigationService,
      private _gateway: GatewayService,
      private dummy: DummyExecucaoService,
      public utilitario: UtilitarioService,
      private _clienteS: ClienteService,
      private _formBuilder: FormBuilder,
      private cdRef: ChangeDetectorRef
   ) {
      this.navigation.loaderTela = false;
      this.navigation.hideTimeBar = false;
      this.user.showIconOpcoes = false;
      this.user.showIconFiltro = true;
      this.user.showFiltroOpcoes = false;
      this.user.showIconTemplates = false;
      this.user.showTemplates = false;

      this.socket_io = io(environment.socket_end_point + '/' + this.socket_rota);
      this.socket_filtro = {
         base: (this._clienteS.clienteAtivo !== 'KMM' ? this._clienteS.clienteAtivo : environment.end_point_base_dev).toLowerCase(),
      };

      this.filtroForm = this._formBuilder.group({
         ccg: new FormControl({ value: null })
      });

   }

   ngOnInit() {
      this.getData();
   }

   ngAfterViewChecked() {
      this.cdRef.detectChanges();
   }

   ngOnDestroy() {
      SetInterval.clear('trocaTela');
   }
   async getData() {
      try {
         this.navigation.loaderTela = true;
         const ls = JSON.parse(localStorage.getItem('exec-manut-filtro'));
         if (ls) {
            if (ls.ccg) {
               this.filtroForm.get('ccg').setValue(ls.ccg);
               Object.assign(this.socket_filtro, {
                  ccg: ls.ccg
               });
            }
         }

         this.socket_io.emit(this.socket_metodo, this.socket_filtro);
         this.socket_io.on(this.socket_rota, (data) => {
            console.log('filtro enviado', this.socket_filtro);
            console.log('data', data);
            this.filtroOptions.ccg = data.lista_ccg;
            this.indicadores = data.indicadores;

            this.dataTableTAPP = [...data.tempo_aberto_placa.dados];
            this.legendasTAPP = data.tempo_aberto_placa.legenda;

            // this.dataTableTAPM = this.dummy.getTAPM();
            this.dataTableQOPP = data.qtde_os_placa;
            this.chartTAPP = data.qtde_os_placa_grafico.reverse();
            this.chartQOAPM = data.qtde_os_marca.reverse();
            this.chartOAPT = data.qtde_os_tipo;

            this.kpi = data.kpi;
            Object.assign(this.bar, {
               os_placa: data.os_placa,
               os_marca_carreta: data.os_marca_carreta.reverse(),
               os_marca_cavalo: data.os_marca_cavalo.reverse()
            });
            this.navigation.loaderTela = false;
            // const g = this.dummy.getOSAPT();
            // this.getLeg(g);
            this.navigation.trocaDash();
            setInterval(() => {
               this.trocaPagina();
            }, 15000);
         });
      } catch (error) {
         console.log(error);
      }
   }

   public onCellPrepared(e: any) {
      if (e.rowType === 'header') {
         e.cellElement.style.paddingTop = '5px';
         e.cellElement.style.paddingBottom = '5px';
      }

      if (typeof (e.data) !== 'undefined') {
         e.cellElement.style.paddingTop = '5px';
         e.cellElement.style.paddingBottom = '5px';
      }
   }

   getLeg(dados) {
      const palette = getPalette('Material');
      dados.forEach((element, i) => {
         this.chartOAPT.valores.push(element.valor);
         this.chartOAPT.legendas.push({ nome: element.chave, cor: palette.simpleSet[i] });
      });
   }

   customizePointMultiple = (arg: any) => {
      let cor = '';
      if (arg.data.tipo === 1) {
         cor = '#87A079';
      } else if (arg.data.tipo === 2) {
         cor = '#F09000';
      } else if (arg.data.tipo === 3) {
         cor = '#731212';
      } else {
         cor = '#666666';
      }
      return { color: cor };
   }

   customizeLabel = (arg: any) => {
      const obj = this;
      return {
         customizeText(e: any) {
            return obj.utilitario.convertTime(e.value);
         }
      };
   }

   trocaPagina() {
      // tabela
      if (this.tabela) {
         const total_pd = this.tabela.instance.pageCount();
         if (total_pd > 1) {
            if (this.index_tabela === total_pd - 1) {
               this.index_tabela = 0;
            } else {
               this.index_tabela++;
            }
            this.tabela.instance.pageIndex(this.index_tabela);
         }
      }
      if (this.tabela2) {
         const total_pd = this.tabela2.instance.pageCount();
         if (total_pd > 1) {
            if (this.index_tabela2 === total_pd - 1) {
               this.index_tabela2 = 0;
            } else {
               this.index_tabela2++;
            }
            this.tabela2.instance.pageIndex(this.index_tabela2);
         }
      }
   }

   aplicar() {
      const filtro = this.filtroForm.value;
      if (filtro.ccg) {
         Object.assign(this.socket_filtro, {
            ccg: filtro.ccg
         });
      }
      localStorage.setItem('exec-manut-filtro', JSON.stringify(this.socket_filtro));
      this.popFiltro.instance.hide();
      this.navigation.loaderTela = true;
      this.socket_io.emit(this.socket_metodo, this.socket_filtro);
   }

   limpar() {
      localStorage.removeItem('exec-manut-filtro');
      delete this.socket_filtro.ccg;
      this.resetForm();
      this.popFiltro.instance.hide();
      this.navigation.loaderTela = true;
      this.socket_io.emit(this.socket_metodo, this.socket_filtro);
   }

   resetForm() {
      this.filtroForm = this._formBuilder.group({
         ccg: new FormControl({ value: null })
      });
   }

}
