import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-exec-kpi',
  templateUrl: './exec-kpi.component.html',
  styleUrls: ['./exec-kpi.component.scss']
})
export class ExecKpiComponent implements OnInit {
  @Input() tituloCard;
  @Input() total;
  @Input() interna;
  @Input() externa;
  constructor() { }

  ngOnInit() {
  }

}
