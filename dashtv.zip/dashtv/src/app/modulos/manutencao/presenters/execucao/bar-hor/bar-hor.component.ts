import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-bar-hor',
  templateUrl: './bar-hor.component.html',
  styleUrls: ['./bar-hor.component.scss']
})
export class BarHorComponent implements OnInit {
  @Input() datasource;
  @Input() name;
  @Input() height = 250;
  @Input() rotated = false;
  constructor() { }

  ngOnInit() {
  }

}
