import { Injectable } from '@angular/core';
import * as _ from 'underscore';
import { UtilitarioService } from 'src/app/shared/services/common/utilitario.service';


@Injectable({
   providedIn: 'root'
})
export class DummyExecucaoService {

   constructor(public utilitario: UtilitarioService) { }

   getTAPP() {
      const array = [];
      for (let index = 0; index < 10; index++) {
         array.push({ placa: 'ABC-00' + index, tempo: '00:00:00' });
      }
      return array;
   }
   getTAPM() {
      const array = [];
      for (let index = 0; index < 100; index++) {
         array.push({ mecanico: 'MECANICO ' + index, tempo: '00:00:00' });
      }
      return array;
   }
   getQOPP() {
      const array = [];
      for (let index = 0; index < 100; index++) {
         array.push({ placa: 'ABC-00 ' + index * 2, quantidade: _.random(0, 100) });
      }
      return array;
   }
   getQOAPM() {
      let array = [];
      for (let index = 0; index < 10; index++) {
         array.push({ chave: 'MARCA ' + index * 2, valor: _.random(0, 100) });
      }
      array = _.sortBy(array, 'valor');
      return array;
   }

   getOSAPT() {
      let array = [];
      for (let index = 0; index < 5; index++) {
         array.push({ chave: 'TIPO ' + index, valor: _.random(0, 100) });
      }
      array = _.sortBy(array, 'valor').reverse();
      return array;
   }

   getTAPPChart() {
      let array = [];
      for (let index = 0; index < 10; index++) {
         const v = _.random(3600, 172800);
         array.push({ chave: 'ABC00- ' + index, valor: v, label: this.utilitario.convertTime(v) });
      }
      array = _.sortBy(array, 'valor');
      return array;
   }
}
