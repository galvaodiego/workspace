import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ManutencaoRouting } from './manutencao.routing';

@NgModule({
    imports: [
        CommonModule,
        ManutencaoRouting
    ]
})
export class ManutencaoModule { }