import { Component, OnInit, OnDestroy } from '@angular/core';

import { Usuario, NavigationService, UsuarioService, GatewayService, EstruturaOrganizacional } from 'src/app/shared';
import SetInterval from 'set-interval';

@Component({
   selector: 'app-manutencao-preventiva',
   templateUrl: './manutencao-preventiva.component.html',
   styleUrls: ['./manutencao-preventiva.component.scss']
})
export class ManutencaoPreventivaComponent implements OnInit, OnDestroy {

   public user: Usuario = Usuario.instance;
   public preventivas: Array<any> = [];
   public parameterList: Array<any> = [];
   public listaAgrupamentos: Array<any> = [];
   public agrupamentosSelecionados: Array<any> = [];
   public datax: Array<any> = [];
   public data: Array<any> = [];
   public tableList: Array<any> = [];
   public showList = false;

   constructor(

      public logisticaProvider: GatewayService,
      public navigation: NavigationService,
      public usuarioProvider: UsuarioService
   ) {
      this.navigation.loaderTela = true;
      this.navigation.timer_troca_tela = 60000; // importante para funcionar corretamente a troca de tela

      this.user.showIconOpcoes = false;
      this.user.showIconFiltro = false;
      this.user.showFiltroOpcoes = false;
      this.user.showIconTemplates = false;
      this.user.showTemplates = false;
      this.user.showIconOpcoes = false;

      if (this.getFilters(this.user.selectedDashboard).length == 0) {
         this.parameterList = [
            {
               tipo: 'CAVALO MECÂNICO',
               values: false
            },
            {
               tipo: 'SEMI REBOQUE',
               values: false
            }
         ];
         this.setFilters(this.user.selectedDashboard, this.parameterList);
      } else {
         this.parameterList = this.getFilters(this.user.selectedDashboard);
         this.agrupamentosSelecionados = this.parameterList.filter(
            (data) => {
               return (data.tipo == 'CAVALO MECÂNICO' || data.tipo == 'SEMI REBOQUE') && (data.values == true);
            }
         ).map(
            el => {
               return el['tipo'];
            }
         );

      }
   }

   ngOnInit() {
      this.getData().then(() => { this.navigation.trocaDash(); });
   }

   ngOnDestroy() {
      SetInterval.clear('trocaTela');
   }

   /**
   * Resgata os dados da Base
   * @returns {Promise<any>} - retorna a chamada do backendCall.
   */
   public async getData(): Promise<any> {

      const parametrosBd = {
         'organizacional_id': 0
      };

      try {
         const response: any = await this.logisticaProvider.backendCall('M4002', 'getVeiculoPreventiva', parametrosBd);


         this.navigation.loaderTela = false;
         this.listaAgrupamentos = [];
         this.preventivas = response.preventivas;
         this.preventivas.forEach(element => {
            const obj: any = {};
            obj.agrupamento_id = element.agrupamento_id;
            obj.agrupamento = element.agrupamento;
            obj.checked = false;
            this.listaAgrupamentos.push(obj);
            this.datax.push(element.veiculo_preventiva);
         });
         console.log('---------------', this.datax);
      } catch (error) {
         console.log('erro no Preventivas -> ', error);
      }
   }



   /*
   * FILTROS
  */
   public updateListCavalo(e) {
      this.parameterList[0].values = e.target.checked;

      if (this.agrupamentosSelecionados.find(element => element === 'CAVALO MECÂNICO')) {
         this.agrupamentosSelecionados.splice(this.agrupamentosSelecionados.findIndex(element => element === 'CAVALO MECÂNICO'), 1);
      } else {
         this.agrupamentosSelecionados.push('CAVALO MECÂNICO');
      }
      this.setFilters(this.user.selectedDashboard, this.parameterList);
   }

   public updateListSider(e) {
      this.parameterList[1].values = e.target.checked;

      if (this.agrupamentosSelecionados.find(element => element === 'SEMI REBOQUE')) {
         this.agrupamentosSelecionados.splice(this.agrupamentosSelecionados.findIndex(element => element === 'SEMI REBOQUE'), 1);
      } else {
         this.agrupamentosSelecionados.push('SEMI REBOQUE');
      }
      this.setFilters(this.user.selectedDashboard, this.parameterList);
   }

	/**
	  *  Salva o filtro do painel na sessão.
	  * @param {number} numDash - Número do dash que contém o filtro
	  * @param {Array<any>} parameters - Parâmetros do filtro
	  */

   public setFilters(numDash: number, parameters: Array<any>) {
      this.user.listaDashboards[this.user.listaDashboards.findIndex(element => element.dash_id == numDash)].filters = parameters;
      this.usuarioProvider.save();
   }


	/**
	  *  Resgata o filtro do painel da sessão.
	  * @param {number} numDash - Número do dash que contém o filtro
	  */
   public getFilters(numDash: number) {
      const filters = this.user.listaDashboards[this.user.listaDashboards.findIndex(element => element.dash_id == numDash)].filters;

      if (filters.length > 0) {
         this.parameterList = [
            {
               tipo: 'CAVALO MECÂNICO',
               values: filters[0].values
            },
            {
               tipo: 'SEMI REBOQUE',
               values: filters[1].values
            },
         ];
      }
      return filters;
   }

   public setIcon(agrupamentoId: number) {
      let classe = '';
      switch (agrupamentoId) {
         case 3:
            classe = 'fa fa-car circle-size';
            break;
         case 1:
            classe = 'bg-cavalo';
            break;
         case 2:
            classe = 'bg-bau';
            break;
         case 7:
            classe = 'bg-sider';
            break;
         default:
      }
      return classe;
   }

   public countTables(data: string) {
      let numTables: number;
      return numTables = data.split('/').length;
   }

   public explainTables(data: string) {
      this.tableList = data.split('/');
   }

   public showTableList(data: string) {
      this.explainTables(data);
      this.showList = !this.showList;
   }


}
