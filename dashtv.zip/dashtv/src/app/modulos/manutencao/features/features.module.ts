import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ComponentsModule } from 'src/app/shared/components/components.module';
import { DxResponsiveBoxModule, DxTagBoxModule, DxPopupModule, DxChartModule, DxLoadIndicatorModule, DxLinearGaugeModule, DxDataGridModule, DxCircularGaugeModule } from 'devextreme-angular';


//Componentes
import { ManutencaoPreventivaComponent } from './manutencao-preventiva/manutencao-preventiva.component';
import { LogisticaPreventivasPipe } from '../pipes/logistica-preventivas.pipe';
import { ManutencaoPreventivasCardComponent } from './manutencao-preventivas-card/manutencao-preventivas-card.component';
import { ManutencaoGestaoComponent } from './manutencao-gestao/manutencao-gestao.component';
@NgModule({
    imports: [
        CommonModule,
        ComponentsModule,
        DxTagBoxModule,
        DxPopupModule,
        DxResponsiveBoxModule,
        DxChartModule,
        DxPopupModule,
        DxLoadIndicatorModule,
        DxLinearGaugeModule,
        DxDataGridModule,
        DxCircularGaugeModule
    
    ],
    declarations: [
        ManutencaoPreventivaComponent,
        LogisticaPreventivasPipe,
        ManutencaoPreventivasCardComponent,
        ManutencaoGestaoComponent
        
    ],
    exports: [
        ManutencaoPreventivaComponent,
        LogisticaPreventivasPipe,
        ManutencaoPreventivasCardComponent,
        ManutencaoGestaoComponent
    ]
})
export class FeaturesModule { }

