import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManutencaoGestaoComponent } from './manutencao-gestao.component';

describe('ManutencaoGestaoComponent', () => {
  let component: ManutencaoGestaoComponent;
  let fixture: ComponentFixture<ManutencaoGestaoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManutencaoGestaoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManutencaoGestaoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
