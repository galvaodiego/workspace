import { Component, OnInit, OnDestroy } from '@angular/core';
import SetInterval from 'set-interval';
// KMM
// import { NavigationService, Usuario, UsuarioProvider, GatewayService } from '../../../core/helpers';
import { Usuario, NavigationService, UsuarioService, GatewayService, EstruturaOrganizacional } from 'src/app/shared';
import { getPalette } from 'devextreme/viz/palette';

@Component({
   selector: 'app-manutencao-gestao',
   templateUrl: './manutencao-gestao.component.html',
   styleUrls: ['./manutencao-gestao.component.scss']
})
export class ManutencaoGestaoComponent implements OnInit, OnDestroy {

   public user: Usuario = Usuario.instance;

   public dataHoje = '';
   public mesAtual = '';

   public tempoMedio = '';

   public indicadores: any = {};
   public dataServicos: any = [];
   public listaVeiculosManutencao: any = [];
   public listaTopCustos: any = [];

   constructor(
      private _gateway: GatewayService,
      private usuarioProvider: UsuarioService,
      public navigation: NavigationService
   ) {

      this.navigation.timer = 0;
      this.navigation.loaderTela = true;
      this.navigation.timer_troca_tela = 60000; // importante para funcionar corretamente a troca de tela
      this.user.showIconOpcoes = false;
      this.user.showIconFiltro = true;
      this.user.showFiltroOpcoes = false;
      this.user.showIconTemplates = true;
      this.user.showTemplates = false;

   }

   ngOnInit() {

      this.getData().then(() => { this.navigation.trocaDash(); });
      this.getDatas();
      // this.getData().then(
      //    (result) => {
      //       this.navigation.controlTela(20);
      //       this.navigation.trocaTela = setInterval(() => {
      //          if (this.user.listaDashboards.length == 1) {
      //             this.getData().then(
      //                () => {
      //                   this.navigation.timer = 0;
      //                }
      //             );
      //          } else {
      //             clearInterval(this.navigation.trocaTela);
      //          }
      //       }, this.user.timerTela ? this.user.timerTela : 60000);
      //       console.log(this.indicadores);

      //    }
      // );
      // console.log('xablau <---- rodrigo que fez');

   }

   ngOnDestroy(): void {
      SetInterval.clear('trocaTela');
      SetInterval.clear('intervalo_tabelas');
   }

   /**
    * Resgata as Data de Hoje
    */
   async getDatas() {
      const response: any = await this._gateway.backendCall('M4002', 'getDataFormat');
      this.dataHoje = response.Datas[0].valor;
      this.mesAtual = response.Datas[1].valor;
   }


   public async getData(): Promise<any> {
      return this._gateway.backendCall('M4002', 'getManutencao').then(
         (result: any) => {
            console.log('res', result);
            this.navigation.loaderTela = false;

            this.indicadores = result.manutencao[0].indicadores[0];
            this.listaVeiculosManutencao = result.manutencao[0].em_manutencao;
            this.dataServicos = result.manutencao[0].grafico;
            this.listaTopCustos = result.manutencao[0].top_custo;

            this.calcTempoMedio(this.indicadores.media_atd);

         });
   }

   getColorBG(valor: number) {
      let color = '';
      if (valor > 0 && valor <= 30) {
         color = '#CB6161';
      } else if (valor > 30.01 && valor <= 50) {
         color = '#F0D472';
      } else if (valor > 50.01 && valor <= 100) {
         color = '#9CCF8A';
      } else {
         color = '#666666';
      }
      return color;
   }

   customizePointMultiple = (arg: any) => {
      const tipo = 'Soft';

      const palette = getPalette(tipo);
      const index = arg.index % (palette.simpleSet.length - 1);
      return { color: palette.simpleSet[index] };
   }




   public calcTempoMedio(tempo) {
      let hours, minutes, seconds;

      hours = Math.floor((tempo % (60 * 60 * 24)) / (60 * 60));
      minutes = Math.floor((tempo % (60 * 60)) / (60));
      seconds = Math.floor((tempo % 60));

      if (hours > 0) {
         this.tempoMedio = hours + 'h ' + minutes + 'm ' + seconds + 's';
      } else {
         this.tempoMedio = minutes + 'm ' + seconds + 's ';
      }
   }


   /**
  * Função Para Alterar o Estilo da Tabela
  * @param e Evento recebido pelo componente
  */
   public onCellPrepared(e: any) {
      e.cellElement.style.fontSize = '1.2em';
      e.cellElement.style.fontWeight = '700';

      // Pinta as Linhas de Cabeçalho e Filtros
      if (e.rowType == 'header') {
         e.cellElement.style.paddingTop = '3px';
         e.cellElement.style.paddingBottom = '3px';
         e.cellElement.style.lineHeight = '18px';
         e.cellElement.style.textAlign = 'center';
      } else {
         e.cellElement.style.padding = '3px';
      }

      if (typeof (e.key) !== 'undefined') {
         if (e.key.atraso == 1) {
            e.cellElement.bgColor = '#be322e';
            e.cellElement.style.color = '#ffffff';
         }
      }

   }

}
