import { Component, OnInit, Input } from '@angular/core';

@Component({
    selector: 'card-preventiva',
    templateUrl: './manutencao-preventivas-card.component.html',
    styleUrls: ['./manutencao-preventivas-card.component.scss']
})
export class ManutencaoPreventivasCardComponent implements OnInit {

    @Input() data: any = {};
    @Input() agrupamentoId: number;

    public showList = false;
    public tableList: Array<any> = [];

    constructor() {
        
    }

    ngOnInit() {
    }


    /**
     * Faz o split e retorna o número de tabelas associadas
     * @param {string} data - string que contém tabelas
     */

    public countTables(data: string) {
        let numTables: number;
        return numTables = data.split("/").length;
    }

    /**
     *
     * @param {string} data - string que contém tabelas
     */
    public explainTables(data: string) {
        this.tableList = data.split("/");
    }

    public showTableList(data: string) {
        this.explainTables(data);
        this.showList = !this.showList;
    }

    public setIcon(agrupamentoId: number) {
        let classe: string = '';
        switch (agrupamentoId) {
            case 3:
                classe = 'fa fa-car circle-size';
                break;
            case 1:
                classe = 'bg-cavalo';
                break;
            case 2:
                classe = 'bg-bau';
                break;
            case 7:
                classe = "bg-sider";
                break;
            default:
        }
        return classe;
    }

}
