import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManutencaoPreventivasCardComponent } from './manutencao-preventivas-card.component';

describe('ManutencaoPreventivasCardComponent', () => {
  let component: ManutencaoPreventivasCardComponent;
  let fixture: ComponentFixture<ManutencaoPreventivasCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManutencaoPreventivasCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManutencaoPreventivasCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
