import { Component, OnInit, OnDestroy } from '@angular/core';

import { Usuario, NavigationService, UsuarioService, GatewayService, EstruturaOrganizacional } from 'src/app/shared';
import SetInterval from 'set-interval';

@Component({
   selector: 'app-jornada-quatro-tempos',
   templateUrl: './jornada-quatro-tempos.component.html',
   styleUrls: ['./jornada-quatro-tempos.component.scss']
})
export class JornadaQuatroTemposComponent implements OnInit, OnDestroy {

   public user: Usuario = Usuario.instance;
   private _org: EstruturaOrganizacional = EstruturaOrganizacional.instance;

   public listaMirror: any = [];
   public listaMirrorMirror: any = [];
   public arrayPassagem: any = [];

   public listaOne: any = [];
   public listaTwo: any = [];
   public listaThree: any = [];
   public listaFour: any = [];

   public grupos: any;
   public meusGrupos: any;

   public intervaloSoma: any;
   public parameterList: any = [];

   constructor(
      private _gateway: GatewayService,
      public navigation: NavigationService,
      public userProvider: UsuarioService
   ) {
      this.navigation.timer = 0;
      this.navigation.timer_troca_tela = 60000; // importante para funcionar corretamente a troca de tela

      this.user.showIconOpcoes = true;
      this.user.showIconFiltro = false;
      this.user.showFiltroOpcoes = false;
      this.user.showIconTemplates = false;
      this.user.showTemplates = false;
      this.user.showMenuOpcoes = false;
   }

   ngOnInit() {
      this.getData().then(() => { this.navigation.trocaDash(); });
   }

   ngOnDestroy() {
      SetInterval.clear('trocaTela');
      SetInterval.clear('intervaloSoma');
   }

   /**
    * Resgata os dados
    */
   async getData() {

      const parametrosBd = {
         'organizacional_id': this._org.permissoes[0].organizacionalId
      };

      try {
         const response: any = await this._gateway.backendCall('M4002', 'getJornada', parametrosBd);
         console.log('response 4 tempos', response);
         
         this.navigation.loaderTela = false;
         this.grupos = response.jornada[0].grupos;
         this.listaMirrorMirror = response.jornada[0].motoristas;
         this.listaMirror = response.jornada[0].motoristas;

         // Chama a funcção de Grupos para verificar se possui grupo Selecionado
         this.getFilters(this.user.selectedDashboard);
         this.selecionaGrupos();
         this.aplicaFiltro();

         // Chama a Função de Distribuição dos Arrays
         this.setTimeList();

         console.log(this.listaOne);


      } catch (error) {
         console.log('erro no Jornada -> ', error);
      }

   }

   public setTimeList() {
      let hours, minutes, seconds;

      // Atualiza a contagem a cada segundo
      SetInterval.start(() => {
         this.listaOne = [];
         this.listaTwo = [];
         this.listaThree = [];
         this.listaFour = [];

         this.arrayPassagem.forEach(
            (el) => {

               // Critério para contagem continua
               if (el.em_viagem == 1) {
                  el.segundos = (Number.parseFloat(el.segundos) + 1);
               } else if (el.em_viagem == 0) {
                  el.segundos = Number.parseFloat(el.segundos);
               }

               hours = Math.floor((el.segundos % (60 * 60 * 24)) / (60 * 60));
               minutes = Math.floor((el.segundos % (60 * 60)) / (60));
               seconds = Math.floor((el.segundos % 60));

               if (hours > 0) {
                  el.contagem = hours + 'h ' + minutes + 'm ' + seconds + 's';
               } else {
                  el.contagem = minutes + 'm ' + seconds + 's ';
               }

               if (el.segundos > 0 && el.segundos <= 28800) {
                  this.listaOne.push(el);
               } else if (el.segundos > 28801 && el.segundos <= 36000) {

                  if (el.segundos >= 34200) { el.estrapolando = 1; } else { el.estrapolando = 0; }

                  this.listaTwo.push(el);

               } else if (el.segundos > 36001 && el.segundos <= 43200) {

                  if (el.segundos >= 41400) { el.estrapolando = 1; } else { el.estrapolando = 0; }

                  this.listaThree.push(el);

               } else if (el.segundos > 43201) {

                  this.listaFour.push(el);
               }
            }
         );
      }, 1000, 'intervaloSoma');
   }


   /**
    * Converte os Segundos em HH:MM
    * @param valor tempo em Segundos
    */
   public convertTime(valor) {
      let hours, minutes, seconds;

      hours = Math.floor((valor % (60 * 60 * 24)) / (60 * 60));
      minutes = Math.floor((valor % (60 * 60)) / (60));
      seconds = Math.floor((valor % 60));

      if (hours > 0) {
         return hours + 'h ' + minutes + 'm ' + seconds + 's';
      } else {
         return minutes + 'm ' + seconds + 's ';
      }

   }


   public aplicaFiltro(e?) {
      if (typeof (e) != 'undefined') {
         if (e.name == 'selectedItems') {
            if (e.value.length !== 0) {
               this.meusGrupos = [];
               e.value.forEach(
                  (el) => {
                     this.meusGrupos.push(el.grupo);
                  }
               );
               this.arrayPassagem = [];
               this.listaMirror.filter(
                  (el) => {
                     this.meusGrupos.forEach(
                        (it) => {
                           if (el.grupo == it) {
                              this.arrayPassagem.push(el);
                           }
                        }
                     );
                  }
               );
               this.setFilters(this.user.selectedDashboard, this.meusGrupos);
            } else if (e.value.length == 0) {
               this.meusGrupos = [];
               this.arrayPassagem = [];
               this.arrayPassagem = this.listaMirror;
               this.setFilters(this.user.selectedDashboard, this.meusGrupos);
            }
         }
      } else {
         if (this.meusGrupos.length > 0) {
            this.arrayPassagem = [];
            this.listaMirror.filter(
               (el) => {
                  this.meusGrupos.forEach(
                     (it) => {
                        if (el.grupo == it) {
                           this.arrayPassagem.push(el);
                        }
                     }
                  );
               }
            );
         } else {
            this.meusGrupos = [];
            this.arrayPassagem = [];
            this.arrayPassagem = this.listaMirror;
            this.setFilters(this.user.selectedDashboard, this.meusGrupos);
         }
      }
   }



   /**
    *  Seleciona os Grupos para a Consulta
    */
   public selecionaGrupos(e?) {

      if (typeof (e) != 'undefined') {
         // Atribui para mostrar no TagBox
         if (this.meusGrupos.length > 0) {
            e.component._options.value = this.meusGrupos;
         }

         if (e.component._options.value.length == 0) {
            this.meusGrupos = [];
            this.arrayPassagem = [];
            this.arrayPassagem = this.listaMirror;
            this.setFilters(this.user.selectedDashboard, this.meusGrupos);
         } else {
            this.arrayPassagem = [];
            this.listaMirror.filter(
               (el) => {
                  this.meusGrupos.forEach(
                     (it) => {
                        if (el.grupo == it) {
                           this.arrayPassagem.push(el);
                        }
                     }
                  );
               }
            );
            this.setFilters(this.user.selectedDashboard, this.meusGrupos);
         }
      } else {
         this.listaMirror.filter(
            (el) => {
               this.meusGrupos.forEach(
                  (it) => {
                     if (el.grupo == it) {
                        this.arrayPassagem.push(el);
                     }
                  }
               );
            }
         );
         this.setFilters(this.user.selectedDashboard, this.meusGrupos);
      }
   }

   /**
   * Seta o Icone
   * @param item macro desejada
   */
   setIcon(item) {
      let macro = '';
      switch (item) {
         case 1:
            macro = 'assets/images/macros/pernoite.svg';
            break;
         case 5:
            macro = 'assets/images/macros/carga.svg';
            break;
         case 4:
            macro = 'assets/images/macros/descanso.png';
            break;
         case 3:
            macro = 'assets/images/macros/refeicao.svg';
            break;
         case 2:
            macro = 'assets/images/macros/finalizada.svg';
            break;
         case 6:
            macro = 'assets/images/macros/descarga.svg';
            break;
         case 7:
            macro = 'assets/images/macros/viagem.svg';
            break;
         default:
            macro = 'assets/images/logo-bbm.png';
            break;
      }
      return macro;
   }


   /**
   * Contagem de Motorista por Card
   * @param item array de dados
   */
   public countItens(item) {
      return item.length;
   }

   /**
   * Percentual de Motoristas do Card pelo Total
   * @param item array de dados
   */
   public countPercentItens(item) {
      const sum = item.length / this.arrayPassagem.length * 100;
      return sum.toFixed(0);
   }

   /*
   * xs: phones
   * sm: tablets
   * md: medium desktops
   * lg: larger desktops
   */
   public screen(width) {
      return (width < 320) ? 'xs' :
         (width < 768) ? 'sm' :
            (width < 1200) ? 'md' :
               'lg';
   }


   /**
    *  Salva o filtro do painel na sessão.
    * @param {number} id - Id do dash que contém o filtro
    * @param {Array<any>} parameters - Parâmetros do filtro
    */

   public setFilters(id: number, parameters: Array<any>) {
      this.user.listaDashboards[this.user.listaDashboards.findIndex(element => element.dash_id == id)].filters = parameters;
      this.userProvider.save();
   }

	/**
	 *  Resgata o filtro do painel da sessão.
	 * @param {number} id - ID do dash que contém o filtro
	 */
   public getFilters(id: number) {
      const filters = this.user.listaDashboards[this.user.listaDashboards.findIndex(element => element.dash_id == id)].filters;
      this.meusGrupos = filters;
      return filters;
   }

}
