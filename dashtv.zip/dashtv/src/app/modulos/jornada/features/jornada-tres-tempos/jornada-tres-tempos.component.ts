import { Component, OnInit, OnDestroy, ViewChild, Input } from '@angular/core';

import { Usuario, NavigationService, UsuarioService, GatewayService, ClienteService } from 'src/app/shared';
import SetInterval from 'set-interval';
import { DxTagBoxComponent } from 'devextreme-angular';
import io from 'socket.io-client';
import { environment } from 'src/environments/environment';
@Component({
   selector: 'app-jornada-tres-tempos',
   templateUrl: './jornada-tres-tempos.component.html',
   styleUrls: ['./jornada-tres-tempos.component.scss']
})
export class JornadaTresTemposComponent implements OnInit, OnDestroy {
   @ViewChild('dxTagBoxPlaca', { static: false }) dxTagBoxPlaca: DxTagBoxComponent;
   @ViewChild('dxTagBoxGrupo', { static: false }) dxTagBoxGrupo: DxTagBoxComponent;
   @ViewChild('dxTagBoxStatus', { static: false }) dxTagBoxStatus: DxTagBoxComponent;

   public user: Usuario = Usuario.instance;

   public listaMirror: any = [];
   public listaMirrorMirror: any = [];

   public arrayPassagem: any = [];

   public listaOne: any = [];
   public listaTwo: any = [];
   public listaThree: any = [];

   public grupos: any;
   public meusGrupos: any;

   public placas: any;
   public minhasPlacas: any;

   public status: any = [];
   public meusStatus: any;

   public intervaloSoma: any;
   public parameterList: any = [];

   public estadoTela;
   public estadosTela: any = [];

   public listaStatus = [];

   // Config Socket
   socket_io: any;
   socket_rota = 'jornada';
   socket_metodo = 'getJornada';
   socket_metodoV2 = 'getJornada_v2';
   socket_filtro: any;
   /***/

   @Input() versao = 1;

   constructor(
      public navigation: NavigationService,
      public userProvider: UsuarioService,
      private _gateway: GatewayService,
      public _clienteS: ClienteService
   ) {
      this.navigation.timer = 0;
      this.navigation.loaderTela = true;
      this.navigation.timer_troca_tela = 60000; // importante para funcionar corretamente a troca de tela

      this.user.showIconOpcoes = false;
      this.user.showIconFiltro = true;
      this.user.showFiltroOpcoes = false;
      this.user.showIconTemplates = false;
      this.user.showTemplates = false;
      this.estadosTela = ['CONTINUA', 'DIÁRIO', 'PARADO'];
      this.socket_io = io(environment.socket_end_point + '/' + this.socket_rota);
      this.socket_filtro = {
         base: (this._clienteS.clienteAtivo !== 'KMM' ? this._clienteS.clienteAtivo : environment.end_point_base_dev).toLowerCase(),
         token: this.user.token
      };

      const clienteSelecionado = JSON.parse(localStorage.getItem('cliente-selecionado'));
      if (clienteSelecionado) {
         Object.assign(this.socket_filtro, {
            url: clienteSelecionado.url
         });
      }

   }

   ngOnInit() {
      if (this.getFilters(this.user.selectedDashboard).length > 0) {
         this.estadoTela = this.getFilters(this.user.selectedDashboard)[0].tela;
         this.meusGrupos = this.getFilters(this.user.selectedDashboard)[1].grupo;
         this.minhasPlacas = this.getFilters(this.user.selectedDashboard)[2].placa;
         this.meusStatus = this.getFilters(this.user.selectedDashboard)[3].status;
         // console.log('filtrado', this.meusGrupos, this.minhasPlacas);
      } else {
         this.estadoTela = this.estadosTela[0];
         this.meusGrupos = [];
         this.minhasPlacas = [];
         this.meusStatus = [];
      }
      this.getData().then(() => { this.navigation.trocaDash(); });
   }

   ngOnDestroy() {
      SetInterval.clear('trocaTela');
      SetInterval.clear('intervaloSoma');
   }

   /**
    * Resgata os dados
    */
   public async getData() {

      const parametrosBd = {
         'organizacional_id': 0
      };

      try {
         if(this.versao === 2 ){
            this.socket_io.emit(this.socket_metodoV2, this.socket_filtro);
         }else{
            this.socket_io.emit(this.socket_metodo, this.socket_filtro);
         }
         this.socket_io.on(this.socket_rota, (response) => {
            console.log('filtro:', this.socket_filtro);
            console.log('resposta:', response);
            // console.log('users', this.user.listaDashboards);
            // const response: any = await this._gateway.backendCall('M4002', 'getJornada', parametrosBd);
            // console.log(response);

            this.navigation.loaderTela = false;
            this.grupos = response.jornada[0].grupos;
            this.placas = response.jornada[0].placas;

            this.listaStatus = response.jornada[0].status;
            this.listaStatus.forEach(element => {
               this.status.push({ status: element.macro, desc: element.chave });
            });
            this.listaMirrorMirror = response.jornada[0].motoristas;
            this.listaMirror = response.jornada[0].motoristas;

            // Chama a funcção de Grupos para verificar se possui grupo Selecionado
            this.getFilters(this.user.selectedDashboard);
            this.selecionaGrupos();
            this.selecionaPlacas();
            this.selecionaStatus();
            this.aplicaFiltro();

            // Chama a Função de Distribuição dos Arrays
            SetInterval.clear('intervaloSoma');
            this.setTimeList();
         });


      } catch (error) {
         console.log('erro no Jornada -> ', error);
      }
   }

   public setTimeList() {
      let hours, minutes, seconds, temp, temp2, temp3;

      SetInterval.start(() => {
         this.listaOne = [];
         this.listaTwo = [];
         this.listaThree = [];
         temp = [];
         temp2 = [];
         temp3 = [];

         this.arrayPassagem.forEach(
            (el: any) => {
               // console.log('---', el);

               //////////////////
               // TROCA DE TELA
               /////////////////

               /**
                * Tela Continua
                */
               if (this.estadoTela == 'CONTINUA' && (el.macro === 7 || el.macro === 8 || el.macro === 9) && el.tempo_continuo != 0) {
                  el.tempo_continuo = (Number.parseFloat(el.tempo_continuo) + 1);

                  // Conversão do Tempo
                  hours = Math.floor((el.tempo_continuo % (60 * 60 * 24)) / (60 * 60));
                  minutes = Math.floor((el.tempo_continuo % (60 * 60)) / (60));
                  seconds = Math.floor((el.tempo_continuo % 60));

                  if (hours > 0) {
                     el.contagem = hours + 'h ' + minutes + 'm ' + seconds + 's';
                  } else {
                     el.contagem = minutes + 'm ' + seconds + 's ';
                  }

                  // if (this._clienteS.clienteAtivo === 'panorama') {
                  //    el.inicio = el.inicio_continuo;
                  // }
                  // Distribui nos Arrays
                  if (el.tempo_continuo > 0 && el.tempo_continuo <= 18000) {

                     temp.push(el);
                     this.listaOne = temp.sort((a, b) => {
                        return (a.tempo_continuo < b.tempo_continuo ? 1 : (a.tempo_continuo > b.tempo_continuo) ? -1 : 0);
                     });

                  } else if (el.tempo_continuo > 18001 && el.tempo_continuo <= 19800) {

                     if (el.tempo_continuo >= 18840) {
                        el.estrapolando = 1;
                     } else {
                        el.estrapolando = 0;
                     }

                     temp2.push(el);
                     this.listaTwo = temp2.sort((a, b) => {
                        return (a.tempo_continuo < b.tempo_continuo ? 1 : (a.tempo_continuo > b.tempo_continuo) ? -1 : 0);
                     });

                     // this.listaTwo.push(el);
                  } else if (el.tempo_continuo >= 19800) {

                     temp3.push(el);
                     this.listaThree = temp3.sort((a, b) => {
                        return (a.tempo_continuo < b.tempo_continuo ? 1 : (a.tempo_continuo > b.tempo_continuo) ? -1 : 0);
                     });

                     // this.listaThree.push(el);
                  }


                  /**
                   * Tela Diária
                   */
               } else if (this.estadoTela == 'DIÁRIO' && el.segundos != 0) {
                  if (el.macro == 1 || el.macro == 2 || el.macro == 3 || el.macro == 4 || el.macro == 5 || el.macro == 6) {
                     el.segundos = Number.parseFloat(el.segundos);
                  } else {
                     el.segundos = (Number.parseFloat(el.segundos) + 1);
                  }

                  // Conversão do Tempo
                  hours = Math.floor((el.segundos % (60 * 60 * 24)) / (60 * 60));
                  minutes = Math.floor((el.segundos % (60 * 60)) / (60));
                  seconds = Math.floor((el.segundos % 60));

                  if (hours > 0) {
                     el.contagem = hours + 'h ' + minutes + 'm ' + seconds + 's';
                  } else {
                     el.contagem = minutes + 'm ' + seconds + 's ';
                  }

                  // Distribui nos Arrays
                  if (el.segundos > 0 && el.segundos <= 28800) {

                     temp.push(el);
                     this.listaOne = temp.sort((a, b) => {
                        return (a.segundos < b.segundos ? 1 : (a.segundos > b.segundos) ? -1 : 0);
                     });

                     // this.listaOne.push(el)
                  } else if (el.segundos > 28801 && el.segundos <= 39600) {

                     if (el.segundos >= 38520) {
                        el.estrapolando = 1;
                     } else {
                        el.estrapolando = 0;
                     }

                     temp2.push(el);
                     this.listaTwo = temp2.sort((a, b) => {
                        return (a.segundos < b.segundos ? 1 : (a.segundos > b.segundos) ? -1 : 0);
                     });

                     // this.listaTwo.push(el)
                  } else if (el.segundos >= 39601) {

                     temp3.push(el);
                     this.listaThree = temp3.sort((a, b) => {
                        return (a.segundos < b.segundos ? 1 : (a.segundos > b.segundos) ? -1 : 0);
                     });

                     // this.listaThree.push(el)
                  }


                  /**
                   * Tela Parada
                   */
               } else if (this.estadoTela == 'PARADO' && (el.macro === 3 || el.macro === 4) && el.tempo_parado != 0) {

                  el.tempo_parado = (Number.parseFloat(el.tempo_parado) + 1);

                  // Conversão do Tempo
                  hours = Math.floor((el.tempo_parado % (60 * 60 * 24)) / (60 * 60));
                  minutes = Math.floor((el.tempo_parado % (60 * 60)) / (60));
                  seconds = Math.floor((el.tempo_parado % 60));

                  if (hours > 0) {
                     el.contagem = hours + 'h ' + minutes + 'm ' + seconds + 's';
                  } else {
                     el.contagem = minutes + 'm ' + seconds + 's ';
                  }

                  // if (this._clienteS.clienteAtivo === 'panorama') {
                  //    el.inicio = el.inicio_parado;
                  // }

                  // Distribui nos Arrays
                  if (el.tempo_parado > 0 && el.tempo_parado <= 1080) {
                     temp.push(el);
                     this.listaOne = temp.sort((a, b) => {
                        return (a.tempo_parado < b.tempo_parado ? 1 : (a.tempo_parado > b.tempo_parado) ? -1 : 0);
                     });

                     // this.listaOne.push(el)
                  } else if (el.tempo_parado > 1081 && el.tempo_parado <= 3960) {

                     if (el.tempo_parado >= 3060) {
                        el.estrapolando = 1;
                     } else {
                        el.estrapolando = 0;
                     }

                     temp2.push(el);
                     this.listaTwo = temp2.sort((a, b) => {
                        return (a.tempo_parado < b.tempo_parado ? 1 : (a.tempo_parado > b.tempo_parado) ? -1 : 0);
                     });

                     // this.listaTwo.push(el)
                  } else if (el.tempo_parado >= 3961) {

                     temp3.push(el);
                     this.listaThree = temp3.sort((a, b) => {
                        return (a.tempo_parado < b.tempo_parado ? 1 : (a.tempo_parado > b.tempo_parado) ? -1 : 0);
                     });

                     // this.listaThree.push(el)
                  }

               }
            }
         );
      }, 1000, 'intervaloSoma');
   }

   /**
    * Converte os Segundos em HH:MM
    * @param valor tempo em Segundos
    */
   public convertTime(valor) {
      let hours, minutes, seconds;

      hours = Math.floor((valor % (60 * 60 * 24)) / (60 * 60));
      minutes = Math.floor((valor % (60 * 60)) / (60));
      seconds = Math.floor((valor % 60));

      if (hours > 0) {
         return hours + 'h ' + minutes + 'm ' + seconds + 's';
      } else {
         return minutes + 'm ' + seconds + 's ';
      }
   }

   public aplicaFiltro(e?) {

      if (typeof (e) != 'undefined') {
         if (e.name == 'selectedItems') {
            if (e.value.length !== 0) {
               if (e.value[0].grupo) {
                  this.meusGrupos = [];
                  this.dxTagBoxPlaca.instance.reset();
                  this.dxTagBoxStatus.instance.reset();
               } else if (e.value[0].placa) {
                  this.minhasPlacas = [];
                  this.dxTagBoxGrupo.instance.reset();
                  this.dxTagBoxStatus.instance.reset();
               } else if (e.value[0].status) {
                  this.meusStatus = [];
                  this.dxTagBoxPlaca.instance.reset();
                  this.dxTagBoxGrupo.instance.reset();
               }

               e.value.forEach((el) => {
                  this.meusGrupos.push(el.grupo);
                  this.minhasPlacas.push(el.placa);
                  this.meusStatus.push(el.status);
               });


               // console.log('debug', this.meusStatus, e);

               this.arrayPassagem = [];
               this.listaMirror.filter((el) => {
                  this.meusGrupos.forEach((it) => {
                     if (el.grupo === it) {
                        this.arrayPassagem.push(el);
                     }
                  });

                  this.minhasPlacas.forEach((it) => {
                     if (el.placa === it) {
                        this.arrayPassagem.push(el);
                     }
                  });

                  this.meusStatus.forEach((it) => {
                     if (el.macro === it) {
                        this.arrayPassagem.push(el);
                     }
                  });
               });
               this.setFilters(this.user.selectedDashboard, this.meusGrupos);
               this.setFilters(this.user.selectedDashboard, this.minhasPlacas);
               this.setFilters(this.user.selectedDashboard, this.meusStatus);
            } else if (e.value.length === 0) {
               this.meusGrupos = [];
               this.minhasPlacas = [];
               this.meusStatus = [];
               this.arrayPassagem = [];
               this.arrayPassagem = this.listaMirror;
               this.setFilters(this.user.selectedDashboard, this.meusGrupos);
               this.setFilters(this.user.selectedDashboard, this.minhasPlacas);
               this.setFilters(this.user.selectedDashboard, this.meusStatus);
            }
         }
      } else {
         this.arrayPassagem = [];
         if (this.meusGrupos.length > 0) {
            // this.arrayPassagem = [];
            this.listaMirror.filter((el) => {
               this.meusGrupos.forEach((it) => {
                  if (el.grupo === it) {
                     this.arrayPassagem.push(el);
                  }
               });
            });
         } else if (this.minhasPlacas.length > 0) {
            // this.arrayPassagem = [];
            this.listaMirror.filter((el) => {
               this.minhasPlacas.forEach((it) => {
                  if (el.placa === it) {
                     this.arrayPassagem.push(el);
                  }
               });
            });
         } else if (this.meusStatus.length > 0) {
            // this.arrayPassagem = [];
            this.listaMirror.filter((el) => {
               this.meusStatus.forEach((it) => {
                  if (el.status === it) {
                     this.arrayPassagem.push(el);
                  }
               });
            });
         } else {
            this.meusGrupos = [];
            this.minhasPlacas = [];
            this.meusStatus = [];
            this.arrayPassagem = [];
            this.arrayPassagem = this.listaMirror;
            this.setFilters(this.user.selectedDashboard, this.meusGrupos);
            this.setFilters(this.user.selectedDashboard, this.minhasPlacas);

         }
      }
   }

   /**
    *  Seleciona os Grupos para a Consulta
    */
   public selecionaGrupos(e?) {
      if (typeof (e) != 'undefined') {
         // Atribui para mostrar no TagBox
         if (this.meusGrupos.length > 0) {
            e.component._options.value = this.meusGrupos;
         }
         if (e.component._options.value.length == 0) {
            this.meusGrupos = [];
            this.arrayPassagem = [];
            this.arrayPassagem = this.listaMirror;
            this.setFilters(this.user.selectedDashboard, this.meusGrupos);
         } else {
            this.arrayPassagem = [];
            this.listaMirror.filter((el) => {
               this.meusGrupos.forEach((it) => {
                  if (el.grupo == it) {
                     this.arrayPassagem.push(el);
                  }
               });
            });
            this.setFilters(this.user.selectedDashboard, this.meusGrupos);
         }
      } else {
         this.listaMirror.filter((el) => {
            this.meusGrupos.forEach((it) => {
               if (el.grupo == it) {
                  this.arrayPassagem.push(el);
               }
            });
         });
         this.setFilters(this.user.selectedDashboard, this.meusGrupos);
      }


   }

   public selecionaStatus(e?) {
      if (typeof (e) != 'undefined') {
         // Atribui para mostrar no TagBox
         if (this.meusStatus.length > 0) {
            e.component._options.value = this.meusStatus;
         }
         if (e.component._options.value.length == 0) {
            this.meusStatus = [];
            this.arrayPassagem = [];
            this.arrayPassagem = this.listaMirror;
            this.setFilters(this.user.selectedDashboard, this.meusStatus);
         } else {
            this.arrayPassagem = [];
            this.listaMirror.filter((el) => {
               this.meusStatus.forEach((it) => {
                  if (el.status == it) {
                     this.arrayPassagem.push(el);
                  }
               });
            });
            this.setFilters(this.user.selectedDashboard, this.meusStatus);
         }
      } else {
         this.listaMirror.filter((el) => {
            this.meusStatus.forEach((it) => {
               if (el.status == it) {
                  this.arrayPassagem.push(el);
               }
            });
         });
         this.setFilters(this.user.selectedDashboard, this.meusStatus);
      }


   }

   /**
    *  Seleciona as Placas para a Consulta
    */
   public selecionaPlacas(e?) {
      if (typeof (e) != 'undefined') {
         // Atribui para mostrar no TagBox
         if (this.minhasPlacas.length > 0) {
            e.component._options.value = this.minhasPlacas;
         }
         if (e.component._options.value.length == 0) {
            this.minhasPlacas = [];
            this.arrayPassagem = [];
            this.arrayPassagem = this.listaMirror;
            this.setFilters(this.user.selectedDashboard, this.minhasPlacas);
         } else {
            this.arrayPassagem = [];
            this.listaMirror.filter((el) => {
               this.minhasPlacas.forEach((it) => {
                  if (el.placa == it) {
                     this.arrayPassagem.push(el);
                  }
               });
            });
            this.setFilters(this.user.selectedDashboard, this.minhasPlacas);
         }
      } else {
         this.listaMirror.filter((el) => {
            this.minhasPlacas.forEach((it) => {
               if (el.placa == it) {
                  this.arrayPassagem.push(el);
               }
            });
         });
         this.setFilters(this.user.selectedDashboard, this.minhasPlacas);
      }



   }

   /**
   * Seta o Icone
   * @param item macro desejada
   */
   setIcon(item) {
      let macro = '';
      switch (item) {
         case 1:
            macro = 'assets/images/macros/pernoite.svg';
            break;
         case 5:
            macro = 'assets/images/macros/carga.svg';
            break;
         case 4:
            macro = 'assets/images/macros/descanso.png';
            break;
         case 3:
            macro = 'assets/images/macros/refeicao.svg';
            break;
         case 2:
            macro = 'assets/images/macros/finalizada.svg';
            break;
         case 6:
            macro = 'assets/images/macros/descarga.svg';
            break;
         case 7:
            macro = 'assets/images/macros/viagem.svg';
            break;
         case 8:
            macro = 'assets/images/macros/vazio.png';
            break;
         case 9:
            macro = 'assets/images/macros/destinado.png';
            break;
         case 10:
            macro = 'assets/images/macros/descarga_parcial.svg';
            break;
         default:
            macro = 'assets/images/logo-bbm.png';
            break;
      }
      return macro;
   }

   /**
   * Contagem de Motorista por Card
   * @param item array de dados
   */
   public countItens(item) {
      return item.length;
   }

   /**
   * Percentual de Motoristas do Card pelo Total
   * @param item array de dados
   */
   public countPercentItens(item) {
      const sum = item.length / this.arrayPassagem.length * 100;
      return sum.toFixed(0);
   }

   /*
   * xs: phones
   * sm: tablets
   * md: medium desktops
   * lg: larger desktops
   */
   public screen(width) {
      return (width < 320) ? 'xs' :
         (width < 768) ? 'sm' :
            (width < 1200) ? 'md' :
               'lg';
   }

   ////////////////////////////////////////
   //               FILTROS              //
   ////////////////////////////////////////

   /**
    *  Salva o filtro do painel na sessão.
    * @param {number} id - Id do dash que contém o filtro
    * @param {Array<any>} parameters - Parâmetros do filtro
    */

   public setFilters(id: number, parameters) {
      const param = [
         {
            'tela': this.estadoTela
         },
         {
            'grupo': this.meusGrupos
         },
         {
            'placa': this.minhasPlacas
         },
         {
            'status': this.meusStatus
         },
      ];
      this.user.listaDashboards[this.user.listaDashboards.findIndex(element => element.dash_id == id)].filters = param;
      this.userProvider.save();
   }

   /**
	 *  Resgata o filtro do painel da sessão.
	 * @param {number} id - ID do dash que contém o filtro
	 */
   public getFilters(id: number) {
      const filters = this.user.listaDashboards[this.user.listaDashboards.findIndex(element => element.dash_id == id)].filters;
      return filters;
   }

   /**
     * Troca a Tela
     * @param e
     */
   public trocaTela(e) {
      this.estadoTela = e.value;
      this.setFilters(this.user.selectedDashboard, this.estadoTela);
   }

   public exibeTitulos(item?) {
      switch (this.estadoTela) {
         case 'CONTINUA':
            if (item == 'verde') {
               return 'ATÉ 5h';
            } else if (item == 'amarelo') {
               return 'DE 5h A 5h30';
            } else if (item == 'vermelho') {
               return 'ACIMA DE 5h30';
            }
            break;
         case 'DIÁRIO':
            if (item == 'verde') {
               return '8h';
            } else if (item == 'amarelo') {
               return '11h';
            } else if (item == 'vermelho') {
               return '+ 11h';
            }
            break;
         case 'PARADO':
            if (item == 'verde') {
               return 'ATÉ 30m';
            } else if (item == 'amarelo') {
               return 'DE 30m A 1h10';
            } else if (item == 'vermelho') {
               return 'ACIMA DE 1h10';
            }
            break;
         default:
            break;
      }

   }


}
