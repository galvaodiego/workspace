import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ComponentsModule } from 'src/app/shared/components/components.module';
import { DxResponsiveBoxModule, DxTagBoxModule, DxPopupModule, DxSelectBoxModule } from 'devextreme-angular';

// Componentes
import { JornadaTresTemposComponent } from './jornada-tres-tempos/jornada-tres-tempos.component';
import { JornadaQuatroTemposComponent } from './jornada-quatro-tempos/jornada-quatro-tempos.component';
import { JornadaQuatroTemposHomologComponent } from './jornada-quatro-tempos-homolog/jornada-quatro-tempos-homolog.component';


@NgModule({
    imports: [
        CommonModule,
        CommonModule,
        ComponentsModule,
        DxTagBoxModule,
        DxPopupModule,
        DxResponsiveBoxModule,
        DxSelectBoxModule
    ],
    declarations: [
        JornadaTresTemposComponent,
        JornadaQuatroTemposComponent,
        JornadaQuatroTemposHomologComponent,
    ],
    exports: [
        JornadaTresTemposComponent,
        JornadaQuatroTemposComponent,
        JornadaQuatroTemposHomologComponent,
    ]
})
export class FeaturesModule { }
