import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { JornadaRouting } from './jornada.routing';

@NgModule({
    imports: [
        CommonModule,
        JornadaRouting
    ]
})
export class JornadaModule { }