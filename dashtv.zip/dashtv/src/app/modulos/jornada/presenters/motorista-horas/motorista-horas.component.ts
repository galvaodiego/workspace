import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Usuario, ClienteService, EstruturaOrganizacional } from 'src/app/shared';

@Component({
   selector: 'app-jornada-motorista-horas',
   templateUrl: './motorista-horas.component.html',
   styleUrls: ['./motorista-horas.component.scss']
})
export class MotoristaHorasComponent {

   public user: Usuario = Usuario.instance;
   public org: EstruturaOrganizacional = EstruturaOrganizacional.instance;

   public flag: number;
   public versao = 1;

   constructor(
      public clienteS: ClienteService,
      private route: ActivatedRoute
   ) {
      this.setNivel();
   }

   public setNivel() {
      this.versao = this.route.snapshot.data['versao'];
      if (this.clienteS.discover() === 'BBM' && this.org.usuario.usuario.toUpperCase() === 'DASH.HOMOLOG') {
         this.flag = 1;
      } else if (this.clienteS.discover() === 'BBM') {
         this.flag = 2;
      } else {
         this.flag = 3;
      }
   }

}
