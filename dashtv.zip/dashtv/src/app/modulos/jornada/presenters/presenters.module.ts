import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PresentersRouting } from './presenters.routing';
import { FeaturesModule } from '../features/features.module';

import { ComponentsModule } from 'src/app/shared/components/components.module';
import { DxTagBoxModule, DxResponsiveBoxModule, DxPopupModule } from 'devextreme-angular';

//Componentes
import { MotoristaHorasComponent } from './motorista-horas/motorista-horas.component';

@NgModule({
    imports: [
        CommonModule,
        ComponentsModule,
        DxTagBoxModule,
        DxPopupModule,
        DxResponsiveBoxModule,
        PresentersRouting,
        FeaturesModule
    ],
    declarations: [
        MotoristaHorasComponent
    ],
})
export class PresentersModule { }
