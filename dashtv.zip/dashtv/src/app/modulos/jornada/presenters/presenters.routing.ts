import { ModuleWithProviders } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { GuardaRotas } from 'src/app/shared';

// Componentes
import { MotoristaHorasComponent } from './motorista-horas/motorista-horas.component';
const modulo = 'jornada';
const PRESENTERS_ROUTES: Routes = [
   {
      path: 'motorista-horas',
      component: MotoristaHorasComponent,
      canActivate: [GuardaRotas],
      data: { modulo, versao: 1 }
   },
   {
      path: 'motorista-horas_v2',
      component: MotoristaHorasComponent,
      canActivate: [GuardaRotas],
      data: { modulo, versao: 2 }
   },
];

export const PresentersRouting: ModuleWithProviders = RouterModule.forChild(PRESENTERS_ROUTES);
