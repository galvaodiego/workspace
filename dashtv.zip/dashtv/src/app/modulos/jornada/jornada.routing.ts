import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const JORNADA_ROUTES: Routes = [
    {
        path: '',
        loadChildren: 'src/app/modulos/jornada/presenters/presenters.module#PresentersModule',
    }
];

export const JornadaRouting: ModuleWithProviders = RouterModule.forChild(JORNADA_ROUTES);