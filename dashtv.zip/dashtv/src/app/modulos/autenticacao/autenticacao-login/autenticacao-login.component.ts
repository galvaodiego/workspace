import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

import { environment } from 'src/environments/environment';

import notify from 'devextreme/ui/notify';
import * as moment from 'moment';

import {
   Usuario,
   UsuarioService,
   EstruturaOrganizacional,
   EstruturaOrganizacionalService,
   Permissao,
   ConfigOrgUsuario,
   Nivel,
   Dash,
   GatewayService,
   ClienteService,
   NavigationService,
} from 'src/app/shared';
import { LocalStorageService } from 'ngx-webstorage';
import { NotificacaoService } from 'src/app/shared/services/common/notificacao.service';

@Component({
   // tslint:disable-next-line: component-selector
   selector: 'autenticacao-login',
   templateUrl: './autenticacao-login.component.html',
   styleUrls: ['./autenticacao-login.component.scss']
})
export class AutenticacaoLoginComponent implements OnInit {

   public user: Usuario = Usuario.instance;
   private _org: EstruturaOrganizacional = EstruturaOrganizacional.instance;

   public form: FormGroup;
   public version: string;

   public opcoesDebug: any = [];
   public popupDebugger = false;
   public menuDebugSelecionado: number;
   mensagem = false;

   data = [
      { 'tipo': 1, 'descricao': 'Dashboard' },
      { 'tipo': 2, 'descricao': 'Gerencial' },
   ];

   showPass = false;

   constructor(
      private _formBuilder: FormBuilder,
      private _router: Router,
      private _gateway: GatewayService,
      private _userProvider: UsuarioService,
      public clienteS: ClienteService,
      private _orgProvider: EstruturaOrganizacionalService,
      private _navigation: NavigationService,
      private _notificacao: NotificacaoService,

   ) {

      this.form = this._formBuilder.group({
         'usuario': ['', Validators.required],
         'senha': ['', Validators.required],
         'plataforma_tipo': [1],
      });

      this.version = environment.version;
      this._userProvider.save();

      // Opções de Menu, no Modo Debug
      this.initDebug();

   }

   ngOnInit() { }

   ///////////////////////////////////////////////////////////
   //                      DEBUGGER                        //
   ///////////////////////////////////////////////////////////

   /**
    * Inicializa as Opções de Debug do Dash
    */
   public initDebug() {
      this.opcoesDebug = [
         { id: 2, text: 'Alterar URL de Conexão' }
      ];
   }

   /**
    * Capta a Função de Clique no Menud e Debug
    * @param e evento do Menu de Contexto
    */
   public selecionouMenuDebug(e) {
      this.popupDebugger = true;
      if (!e.itemData.items) {
         this.menuDebugSelecionado = e.itemData.id;
      }
   }

   ///////////////////////////////////////////////////////////
   //                       LOGIN                           //
   ///////////////////////////////////////////////////////////


   /**
   * Recebe os Dados do Formulário e chama a função de Login
   */
   public doLogin() {
      const login = this.form.get('usuario').value;
      if (login.indexOf('@') === -1) {
         this._notificacao.toast('Formato correto de seu usuário: Ex: nome.usuario@seudominio.com.br', 'error');
         return false;
      } else {
         const acesso = login.split('@');
         const cliente = this.clienteS.validaCliente(acesso[1]);
         if (!cliente) {
            this._notificacao.toast('Nenhum cliente encontrado com este domínio', 'error');
         } else {
            // encontrou cliente
            this.setCliente(cliente);
            this.user.usuario = acesso[0];
            this._userProvider.save();
            this.user.codGestao = null;
            this.user.filiais = null;
            this.user.token = null;
            this.user.senha = this.form.get('senha').value;
            this.user.plataforma_tipo = this.form.get('plataforma_tipo').value;
            this.requestLogin();
            console.log('Url de Conexão', this.user.url);
         }

      }



      // if (this.user.url === '' || this.user.url == null) {
      //    this.user.url = this.clienteS.setUrlCliente();
      // }

      // this.user.usuario = this.form.get('usuario').value;
      // this._userProvider.save();
      // this.user.codGestao = null;
      // this.user.filiais = null;
      // this.user.token = null;
      // this.user.senha = this.form.get('senha').value;
      // this.user.plataforma_tipo = this.form.get('plataforma_tipo').value;
      // this.requestLogin();
      // console.log('Url de Conexão', this.user.url);
   }

   /**
   * LOGIN SEM ESCOLHA DE GESTÃO | Função que realiza o Login e traz os Dados do Usuário
   */
   async requestLogin() {
      const tempGestoes: any = [];

      const parametrosBd = {
         username: this.user.usuario,
         password: this.user.senha,
         cod_gestao: this.user.codGestao,
         filiais: this.user.filiais,
         plataforma_tipo: this.user.plataforma_tipo
      };

      // Chama o Backend
      try {
         const response: any = await this._gateway.backendCall('LOGON', 'LOGON', parametrosBd);
         if (response.token != null && response.token.length) {
            this.user.token = response.token;
            this.user.ambiente = response.ambiente;
            this.user.ultimoLogin = moment().format();
            this._userProvider.save();
            // Resgata as Permissoes do Usuario
            this.getPermissoes();

         } else if (response.gestoes !== null && response.gestoes.length > 0) {

            // Coleta o COD_PESSOA de todas as Gestões
            //  O Menor COD_PESSOA, é o da Gestão Principal;
            for (let i = 0; i < response.gestoes.length; i++) {
               const el = response.gestoes[i];
               tempGestoes.push(el.cod_pessoa);
            }

            for (let i = 0; i < response.gestoes.length; i++) {
               const el = response.gestoes[i];
               if (el.cod_pessoa === Math.min.apply(null, tempGestoes)) {
                  this.user.codGestao = el.cod_gestao;
                  this.user.codPessoa = el.cod_pessoa;
                  this.user.cliente = el.cliente;
                  this.user.usuario = el.usuario;
                  this.user.identificador = el.identificador;
                  this.user.filiais = el.filiais.map(el => el['cod_pessoa']).join(',');
                  this._userProvider.save();
                  this.requestLogin();
               }
            }
         } else if (response.gestoes.length === 0) {
            notify({
               message: 'Usuário Sem Gestão',
               type: 'error',
               displayTime: 100000,
               closeOnClick: true,
               width: () => window.innerWidth / 1.8
            });
         }

      } catch (error) {
         console.log('Erro Login -> ', error);
         return;
      }
   }

   ///////////////////////////////////////////////////////////
   //               PERMISSOES DO USUÁRIO                   //
   ///////////////////////////////////////////////////////////

   /**
   * Retorna do Banco as Permissões do Usuário Logado, para acesso aos módulos
   */
   public async getPermissoes(): Promise<any> {
      let plataforma = '';
      switch (this.user.plataforma_tipo) {
         case 1:
            plataforma = 'DASH';
            break;
         case 2:
            plataforma = 'GERENCIAL';
            break;
         default:
            plataforma = 'APP';
            break;
      }
      const parametrosBd = {
         usuario_bi: this.user.usuario,
         plataforma: plataforma
      };

      this.user.listaDashboards = [];
      this._userProvider.save();

      try {
         const response: any = await this._gateway.backendCall('1811-APPGESTOR', 'getUsuarioPermissoes', parametrosBd);
         this.prepara(response);

         let flag = true;
         let msg = '';
         if (this.user.plataforma_tipo == 2) {
            flag = false;
            msg = 'Este usuário não possui módulos gerenciais!';
            response.permissoes.forEach(element => {
               if (element.config_org_usuario.length > 0) {
                  flag = true;
               }
            });
         } else if (this.user.plataforma_tipo == 1 && this.user.listaDashboards.length === 0) {
            console.log('plataforma_tipo:', this.user.plataforma_tipo, 'listaDashboards:', this.user.listaDashboards.length);

            flag = false;
            msg = 'Não existe DASHBOARD cadastrado para este usuário';
         }

         if (!flag) {
            this.user.isLogged = false;
            this._notificacao.toast(msg, 'error');
            this.limpaStorage();
         } else {
            this.user.isLogged = true;

            switch (this.user.plataforma_tipo) {
               case 1:
                  if (this.user.listaDashboards.length > 0) {
                     this._router.navigate([this.user.listaDashboards[0].path]);
                  } else {
                     console.log('Erro: listaDashboards vazio', this.user.listaDashboards);
                  }
                  break;
               case 2:
                  this._router.navigate(['gerencial/painel']);
                  break;
            }
         }
      } catch (error) {
         console.log('Erro Permissoes -> ', error);
      }
   }

   prepara(response) {
      console.log(response);

      if (response.permissoes[0].usuario_grupo_negociador && response.permissoes[0].usuario_grupo_negociador.length > 0) {
         localStorage.setItem(this.clienteS.discover() + '-grupo_negociador', JSON.stringify(response.permissoes[0].usuario_grupo_negociador))
      } else {
         localStorage.removeItem(this.clienteS.discover() + '-grupo_negociador');
      }

      // Base Acessada
      this._org.base = response.permissoes[0].base ? response.permissoes[0].base : '';

      // Usuario
      this._org.usuario.usuario = response.permissoes[0].usuario;
      this._org.usuario.usuarioBiId = response.permissoes[0].usuario_bi_id;

      // Permissoes do Usuario
      this._org.permissoes = [];
      for (let i = 0; i < response.permissoes[0].permissoes_usuario.length; i++) {
         const element = response.permissoes[0].permissoes_usuario[i];
         const obj: Permissao = new Permissao();
         obj.ativo = element.ativo;
         obj.codNivelOrganizacional = element.cod_nivel_organizacional;
         obj.ordem = element.ordem;
         obj.organizacional = element.organizacional;
         obj.organizacionalId = element.organizacional_id;
         obj.organizacionalIdCorp = element.organizacional_id_corp;
         obj.organizacionalIdPai = element.organizacional_id_pai;
         obj.tipoOrganizacional = element.tipo_organizacional;
         obj.tipoOrganizacionalId = element.tipo_organizacional_id;
         obj.usuario = this._org.usuario;
         this._org.permissoes.push(obj);
      }

      // Configuracao organizacional do Usuario
      this._org.configOrgUsuario = [];
      for (let i = 0; i < response.permissoes[0].config_org_usuario.length; i++) {
         const element = response.permissoes[0].config_org_usuario[i];
         const obj: ConfigOrgUsuario = new ConfigOrgUsuario();
         obj.listConfigOrg = element.config_organizacional;
         obj.configOrgId = element.configuracao_org_id;
         obj.configOrg = element.configuracao_organizacional;
         obj.modulo = element.modulo;
         obj.moduloId = element.modulo_id;
         obj.niveis = this.toNiveis(element.niveis);
         obj.dashs = this.toDashs(element.permissao_dash);
         obj.numModulo = element.num_modulo;
         this._org.configOrgUsuario.push(obj);
      }

      this._orgProvider.save();
   }

   /**
   * Modela o resultado de Niveis para o AccessConfig
   * @param list :: Niveis
   */
   public toNiveis(list: any) {

      if (!Array.isArray(list)) {
         return new Array<Nivel>();
      }

      if (list.length > 0) {
         list.forEach(
            (item) => {
               this._org.niveis.usuario = this._org.usuario;
               this._org.niveis.codNivelOrganizacional = item.cod_nivel_organizacional;
               this._org.niveis.nivel = item.nivel;
               this._org.niveis.organizacional = item.organizacional;
               this._org.niveis.organizacionalId = item.organizacionalId;
               this._org.niveis.tipoOrganizacionalId = item.tipoOrganizacionalId;
            }
         );
      }
      return list;
   }

   /**
   * Modela o resultado de Dashs para o AccessConfig
   * @param list :: Dashs
   */
   public toDashs(list: any) {

      if (!Array.isArray(list)) {
         return new Array<Dash>();
      }

      if (list.length > 0) {
         list.forEach(
            (item) => {
               const obj: any = {};
               obj.dash_id = item.dash_id;
               obj.descricao = item.descricao;
               obj.path = item.path;
               obj.filters = [];
               this.user.listaDashboards.push(obj);
            }
         );

         this.user.selectedDashboard = this.user.listaDashboards[0].dash_id;
         this._userProvider.save();
      }
      return list;
   }

   limpaStorage() {
      localStorage.removeItem('kmm_bi-dash|' + this.clienteS.discover() + '-usuario');
      localStorage.removeItem('kmm_bi-dash|' + this.clienteS.discover() + '-organizacional');
   }


   setCliente(cliente) {
      localStorage.setItem('cliente-selecionado', JSON.stringify(cliente));
      this.user.cliente = cliente.nome;
      this.user.ref = cliente.ref;
      this.user.url = cliente.url;
      this._userProvider.save();
   }


}
