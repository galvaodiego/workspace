import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule, FormBuilder } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import {MatIconModule} from '@angular/material/icon'

// PLUGINS
import { DxPopupModule, DxContextMenuModule, DxButtonModule, DxFormModule, DxSelectBoxModule } from 'devextreme-angular';

// MODULOS
import { ComponentsModule } from 'src/app/shared/components/components.module';

// PAGINAS
import { AutenticacaoLoginComponent } from './autenticacao-login/autenticacao-login.component';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        DxPopupModule,
        DxContextMenuModule,
        ComponentsModule,
        DxButtonModule,
        DxFormModule,
        DxSelectBoxModule,
        MatInputModule,
        MatIconModule
    ],
    declarations: [
        AutenticacaoLoginComponent,
    ],
    exports: [
        RouterModule,
        AutenticacaoLoginComponent
    ],
    providers: [FormBuilder]

})
export class AutenticacaoModule { }