import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SuprimentosRouting } from './suprimentos.routing';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    SuprimentosRouting,
  ]
})
export class SuprimentosModule { }
