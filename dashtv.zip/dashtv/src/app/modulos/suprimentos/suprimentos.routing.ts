import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const SUPRIMENTOS_ROUTES: Routes = [
   {
      path: '',
      loadChildren: 'src/app/modulos/suprimentos/presenters/presenters.module#PresentersModule',
   }
];

export const SuprimentosRouting: ModuleWithProviders = RouterModule.forChild(SUPRIMENTOS_ROUTES);
