import { ModuleWithProviders } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { GuardaRotas } from 'src/app/shared';
import { LancamentosAbastecimentoComponent } from './lancamentos-abastecimento/lancamentos-abastecimento.component';
const modulo = 'suprimentos';
const PRESENTERS_ROUTES: Routes = [
   {
      path: 'lancamentos-abastecimento',
      canActivate: [GuardaRotas],
      component: LancamentosAbastecimentoComponent,
      data: { modulo }
   },
];

export const PresentersRouting: ModuleWithProviders = RouterModule.forChild(PRESENTERS_ROUTES);
