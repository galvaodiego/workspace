import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PresentersRouting } from './presenters.routing';
import { LancamentosAbastecimentoComponent } from './lancamentos-abastecimento/lancamentos-abastecimento.component';
import { DxChartModule, DxDataGridModule, DxLoadPanelModule, DxPieChartModule } from 'devextreme-angular';
import { GoogleChartsModule } from 'angular-google-charts';



@NgModule({
  declarations: [LancamentosAbastecimentoComponent],
  imports: [
    CommonModule,
    PresentersRouting,
    DxChartModule,
    DxDataGridModule,
    DxLoadPanelModule,
    DxPieChartModule,
    GoogleChartsModule.forRoot(),
  ]
})
export class PresentersModule { }
