import { Injectable } from '@angular/core';

@Injectable({
   providedIn: 'root'
})
export class DummyAbastecimentoService {

   constructor() { }
   getData() {
      return {
         'graficos': {
            'automatizacao_ultimos_dias': [
               {
                  'chave': '15/02/2020',
                  'valor': 25
               },
               {
                  'chave': '16/02/2020',
                  'valor': 75
               },
               {
                  'chave': '17/02/2020',
                  'valor': 95
               },
               {
                  'chave': '18/02/2020',
                  'valor': 100
               },
               {
                  'chave': '19/02/2020',
                  'valor': 10
               }
            ],
            'quantidade_tm_lancamento': [
               { 'chave': '> 1 Hora', 'valor': 50 },
               { 'chave': '> 30 Min', 'valor': 10 },
               { 'chave': '> 10 Min', 'valor': 5 },
               { 'chave': '< 10 Min', 'valor': 25 }
            ],
            'nf_registro': [
               { 'chave': 'Com Registro', 'valor': 45 },
               { 'chave': 'Sem Registro', 'valor': 55 }
            ]
         },
         'indicadores': {
            'tm_integracao_nf_dia': 3600,
            'tm_integracao_nf_mes': 3600,
            'tm_lancamento_cupom_dia': 3600,
            'tm_lancamento_cupom_mes': 3600
         },
         'listas': {
            'veiculos_3k': [
               { placa: 'ABCD-0000', quantidade: 100 },
               { placa: 'ABCD-0000', quantidade: 100 },
               { placa: 'ABCD-0000', quantidade: 100 },
               { placa: 'ABCD-0000', quantidade: 100 },
               { placa: 'ABCD-0000', quantidade: 100 },
               { placa: 'ABCD-0000', quantidade: 100 },
               { placa: 'ABCD-0000', quantidade: 100 },
               { placa: 'ABCD-0000', quantidade: 100 },
               { placa: 'ABCD-0000', quantidade: 100 },
               { placa: 'ABCD-0000', quantidade: 100 },
            ],
            'veiculos_4d': [
               { placa: 'ABCD-0000', quantidade: 100 },
               { placa: 'ABCD-0000', quantidade: 100 },
               { placa: 'ABCD-0000', quantidade: 100 },
               { placa: 'ABCD-0000', quantidade: 100 },
               { placa: 'ABCD-0000', quantidade: 100 },
               { placa: 'ABCD-0000', quantidade: 100 },
               { placa: 'ABCD-0000', quantidade: 100 },
               { placa: 'ABCD-0000', quantidade: 100 },
               { placa: 'ABCD-0000', quantidade: 100 },
               { placa: 'ABCD-0000', quantidade: 100 },
            ]
         }
      };
   }
}

export class Datasource {
   graficos: {
      automatizacao_ultimos_dias: Array<any>,
      quantidade_tm_lancamento: Array<any>,
      nf_registro: Array<any>
   };
   indicadores: {
      tempo_medio: [
         {
            tm_integracao_nf_dia: number,
            tm_integracao_nf_mes: number,
            tm_lancamento_cupom_dia: number,
            tm_lancamento_cupom_mes: number
         }
      ]
   };
   listas: {
      veiculos_3k: Array<any>,
      veiculos_4d: Array<any>,
      nf_sem_reg: Array<any>
   };
}
