import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import SetInterval from 'set-interval';
import { Usuario, NavigationService, GatewayService } from 'src/app/shared';
import { DummyAbastecimentoService, Datasource } from './dummy-abastecimento.service';
import { getPalette } from 'devextreme/viz/palette';
import { UtilitarioService } from 'src/app/shared/services/common/utilitario.service';
import { DxDataGridComponent } from 'devextreme-angular';


@Component({
   selector: 'app-lancamentos-abastecimento',
   templateUrl: './lancamentos-abastecimento.component.html',
   styleUrls: ['./lancamentos-abastecimento.component.scss'],
   providers: [Datasource]
})
export class LancamentosAbastecimentoComponent implements OnInit, OnDestroy {
   @ViewChild('t1', { static: false }) t1: DxDataGridComponent;
   @ViewChild('t2', { static: false }) t2: DxDataGridComponent;
   @ViewChild('t3', { static: false }) t3: DxDataGridComponent;

   public user: Usuario = Usuario.instance;
   pie3d: Pie3D = {
      chartType: '',
      containerId: '',
      dataTable: [],
      options: []
   };

   tempoMedio: TempoMedio = {
      integracao_nf_dia: '00:00:00',
      integracao_nf_mes: '00:00:00',
      lancamento_cupom_dia: '00:00:00',
      lancamento_cupom_mes: '00:00:00'
   };
   loadingVisible = true;



   // controle das tabelas
   index_t1 = 0;
   index_t2 = 0;
   index_t3 = 0;

   constructor(
      public navigation: NavigationService,
      private _gateway: GatewayService,
      private _dummy: DummyAbastecimentoService,
      public datasource: Datasource,
      public utilitario: UtilitarioService
   ) {
      this.navigation.loaderTela = false;
      this.navigation.hideTimeBar = false;
      this.user.showIconOpcoes = false;
      this.user.showIconFiltro = false;
      this.user.showFiltroOpcoes = false;
      this.user.showIconTemplates = false;
      this.user.showTemplates = false;
   }

   ngOnInit() {
      this.getData();
   }

   ngOnDestroy() {
      SetInterval.clear('trocaTela');
   }
   async getData() {
      try {
         const response: any = await this._gateway.backendCall('M4002', 'getAbastecimento');
         console.log('response:', response);

         if (response.result) {
            this.loadingVisible = false;
            // this.datasource = this._dummy.getData();
            this.datasource = response.result;

            if (this.datasource.graficos) {
               const graficos = this.datasource.graficos;
               if (graficos.quantidade_tm_lancamento.length > 0) {
                  graficos.quantidade_tm_lancamento.reverse();
               }

               // const dt = [['Chave', 'Valor']];
               // if (graficos.nf_registro.length > 0) {
               //    graficos.nf_registro.forEach(element => {
               //       const aux = [];
               //       aux.push(element.chave);
               //       aux.push(element.valor);
               //       dt.push(aux);
               //    });


               //    Object.assign(this.pie3d, {
               //       chartType: 'PieChart',
               //       dataTable: dt,
               //       options: {
               //          is3D: true,
               //          colors: ['#871111', '#cccccc'],
               //       },
               //       containerId: 'pizza3d'
               //    });
               // }

            }

            if (this.datasource.indicadores) {
               const indicadores = this.datasource.indicadores.tempo_medio[0];
               if (indicadores.tm_integracao_nf_dia) {
                  this.tempoMedio.integracao_nf_dia = this.utilitario.convertTime(indicadores.tm_integracao_nf_dia);
               }

               if (indicadores.tm_integracao_nf_mes) {
                  this.tempoMedio.integracao_nf_mes = this.utilitario.convertTime(indicadores.tm_integracao_nf_mes);
               }

               if (indicadores.tm_lancamento_cupom_dia) {
                  this.tempoMedio.lancamento_cupom_dia = this.utilitario.convertTime(indicadores.tm_lancamento_cupom_dia);
               }

               if (indicadores.tm_lancamento_cupom_mes) {
                  this.tempoMedio.lancamento_cupom_mes = this.utilitario.convertTime(indicadores.tm_lancamento_cupom_mes);
               }
            }

            if (this.datasource.listas) {
               const listas = this.datasource.listas;
            }

         }
         setInterval(() => {
            this.trocaPagina();
         }, 15000);
         this.navigation.trocaDash();
      } catch (error) {
         this.loadingVisible = false;

         console.log(error);
      }
   }
   trocaPagina() {
      // tabela
      if (this.t1) {
         const total_pd = this.t1.instance.pageCount();
         if (total_pd > 1) {
            if (this.index_t1 === total_pd - 1) {
               this.index_t1 = 0;
            } else {
               this.index_t1++;
            }
            this.t1.instance.pageIndex(this.index_t1);
         }
      }
      if (this.t2) {
         const total_pd = this.t2.instance.pageCount();
         if (total_pd > 1) {
            if (this.index_t2 === total_pd - 1) {
               this.index_t2 = 0;
            } else {
               this.index_t2++;
            }
            this.t2.instance.pageIndex(this.index_t2);
         }
      }
      if (this.t3) {
         const total_pd = this.t3.instance.pageCount();
         if (total_pd > 1) {
            if (this.index_t3 === total_pd - 1) {
               this.index_t3 = 0;
            } else {
               this.index_t3++;
            }
            this.t3.instance.pageIndex(this.index_t3);
         }
      }
   }
   customizePointMultiple = (arg: any) => {
      const tipo = 'Soft';

      const palette = getPalette(tipo);
      const index = arg.index % (palette.simpleSet.length - 1);
      return { color: palette.simpleSet[index] };
   }

   customizeLabel = (arg: any) => {
      const obj = this;
      return {
         customizeText(e: any) {
            return obj.utilitario.convertTime(e.value);
         }
      };
   }
   customizeLabelPerc = (arg: any) => {
      return {
         customizeText(e: any) {
            return e.value + '%';
         }
      };
   }

   customizeTextLabel(arg) {
      // return arg.argumentText + ': ' + arg.valueText + ' (' + arg.percentText + ')';
      return arg.percentText;
   }

   onCellPrepared(e: any) {
      if (e.rowType === 'header') {
         e.cellElement.style.paddingTop = '5px';
         e.cellElement.style.paddingBottom = '5px';
         e.cellElement.style.fontWeight = 'bolder';
      }

      if (typeof (e.data) !== 'undefined') {
         e.cellElement.style.paddingTop = '8px';
         e.cellElement.style.paddingBottom = '8px';

      }
   }

   gerarPDF(arg: any) {
      try {
         if (arg.data.num_nota_id) {
            this._gateway.backendCall('M4002', 'getImpressaoNFe', { num_nota_id: arg.data.num_nota_id }).then((response: any) => {
               // console.log('sucesso', response);
               if (response) {
                  const pdf = response.doc;
                  const linkSource = `data:application/pdf;base64,${pdf}`;
                  const downloadLink = document.createElement('a');
                  const fileName = 'nota_' + arg.data.num_nota_id + '.pdf';
                  downloadLink.href = linkSource;
                  downloadLink.download = fileName;
                  downloadLink.target = '_blank';
                  downloadLink.click();
               }
            });
         } else {
            console.log('ERROR num_nota_id', arg.data.num_nota_id);
         }

      } catch (error) {
         console.log('ERROR', error);

      }



   }
}


export class Pie3D {
   chartType: string;
   dataTable: Array<any>;
   options: object;
   containerId: string;
}

export class TempoMedio {
   integracao_nf_dia: string;
   integracao_nf_mes: string;
   lancamento_cupom_dia: string;
   lancamento_cupom_mes: string;
}
