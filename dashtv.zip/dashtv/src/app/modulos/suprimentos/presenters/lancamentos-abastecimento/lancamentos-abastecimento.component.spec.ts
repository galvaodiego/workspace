import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LancamentosAbastecimentoComponent } from './lancamentos-abastecimento.component';

describe('LancamentosAbastecimentoComponent', () => {
  let component: LancamentosAbastecimentoComponent;
  let fixture: ComponentFixture<LancamentosAbastecimentoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LancamentosAbastecimentoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LancamentosAbastecimentoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
