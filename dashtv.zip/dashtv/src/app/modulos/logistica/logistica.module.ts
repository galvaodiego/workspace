import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LogisticaRouting } from './logistica.routing';

@NgModule({
    imports: [
        CommonModule,
        LogisticaRouting
    ]
})
export class LogisticaModule { }