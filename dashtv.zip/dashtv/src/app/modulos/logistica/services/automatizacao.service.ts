import { Injectable } from '@angular/core';
import * as moment from 'moment';


@Injectable({
  providedIn: 'root'
})
export class AutomatizacaoService {

  constructor() { }
  getDefinicoes(tipo, matriz) {
    const obj = {};
    switch (tipo) {
       case 1:
          Object.assign(obj, {
             tipo: 'kpi-automatizacao-money',
             datasource: matriz.indicadores.total_emitido,
             tipo_legenda: 'numero',
             titulo: 'Total Emitido'
          });
          return obj;
          break;
       case 2:
          Object.assign(obj, {
             tipo: 'kpi-automatizacao-money',
             datasource: matriz.indicadores.total_automatizado,
             tipo_legenda: 'numero',
             titulo: 'Total Automatizado'
          });
          return obj;
          break;

       case 3:
          Object.assign(obj, {
             tipo: 'kpi-automatizacao-percent',
             datasource: matriz.indicadores.percent_automatizado,
             tipo_legenda: 'numero',
             titulo: '% Automatizado'
          });
          return obj;
          break;
       case 4:
          Object.assign(obj, {
             tipo: 'kpi-automatizacao-regular',
             datasource: matriz.indicadores.tempo_emissao,
             tipo_legenda: 'numero',
             titulo: 'Tempo entre emissão da NF e CT-E'
          });
          return obj;
          break;
       case 5:
          Object.assign(obj, {
            tipo: 'acompanhamento-mensal-tbl',
            af: null,
            vf: null,
            tipo_legenda: null,
            datasource: matriz.listas.acompanhamento_mensal,
            titulo: 'Acompanhamento Mensal'
          });
          return obj;
          break;
       case 6:
          Object.assign(obj, {
            tipo: 'int-nf-usuario-tbl',
            af: null,
            vf: null,
            tipo_legenda: null,
            datasource: matriz.listas.integracao_por_usuario,
            titulo: 'Integração de NF por Usuário'
          });
          return obj;
          break;
       case 7:
          Object.assign(obj, {
            tipo: 'acompanhamento-diario-tbl',
            af: null,
            vf: null,
            tipo_legenda: null,
            datasource: matriz.listas.acompanhamento_diario,
            titulo: 'Acompanhamento Diário'

          });
          return obj;
          break;
       case 8:
          Object.assign(obj, {
            tipo: 'operacoes-automatizadas-tbl',
            af: null,
            vf: null,
            tipo_legenda: null,
            datasource: matriz.listas.operacoes_automatizadas,
            titulo: 'Operações Automatizadas'
          });
          return obj;
          break;
    }
 }
}
