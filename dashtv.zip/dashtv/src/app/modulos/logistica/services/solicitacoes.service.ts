import { Injectable } from '@angular/core';
import * as _ from 'underscore';
import * as moment from 'moment';

@Injectable({
   providedIn: 'root'
})
export class SolicitacoesService {
   ultimaAtualizacao: string;
   constructor() { }

   getDefinicoes(tipo, visualizacao, matriz) {
      const obj = {};
      switch (tipo) {
         case 1:
            Object.assign(obj, {
               tipo: 'box-titulo-numero',
               datasource: matriz.sol_aberta,
               tipo_legenda: 'numero',
               titulo: 'Nº Solicitações Abertas'
            });
            return obj;
            break;
         case 2:
            Object.assign(obj, {
               tipo: 'box-titulo-numero',
               datasource: matriz.sol_cancelada,
               tipo_legenda: 'numero',
               titulo: 'Nº Solicitações Canceladas'
            });
            return obj;
            break;

         case 3:
            Object.assign(obj, {
               tipo: 'box-titulo-numero',
               datasource: matriz.sol_total,
               tipo_legenda: 'numero',
               titulo: 'Total de Solicitações'
            });
            return obj;
            break;
         case 4:
            Object.assign(obj, {
               tipo: 'box-titulo-numero',
               datasource: matriz.rom_qtde,
               tipo_legenda: 'numero',
               titulo: 'Nº de Romaneios'
            });
            return obj;
            break;
         case 5:
            Object.assign(obj, {
               tipo: 'barra-vertical-dupla-variavel',
               datasource: matriz.dataSolicitacoes,
               af: 'descricao',
               vf: 'agendada',
               vf2: 'atendida',
               tipo_legenda: null,
               cores_series: ['#007bff', '#28a745'],
               titulo: 'Controle de Solicitações: ' + moment().format('DD/MM/YYYY')
            });
            return obj;
            break;
         case 6:
            Object.assign(obj, {
               tipo: 'doughnut-leg-right',
               datasource: matriz.dataEmissoes.filter(e => {
                  return e.valor > 0;
               }),
               af: 'descricao',
               vf: 'valor',
               tipo_legenda: 'numero',
               cores_series: ['#28a745', '#dc3545'],
               titulo: 'Aguardando emissão: ' + moment().format('DD/MM/YYYY')
            });
            return obj;
            break;
         case 7:
            Object.assign(obj, {
               tipo: 'abertas-operacao-tbl',
               af: null,
               vf: null,
               titulo: 'Solicitações Abertas por operação',
               datasource: matriz.lista_sol_aberta_op,
               tipo_legenda: null

            });
            return obj;
            break;
         case 8:
            Object.assign(obj, {
               tipo: 'solicitacoes-abertas-tbl',
               af: null,
               vf: null,
               titulo: 'Solicitações Abertas',
               datasource: matriz.lista_sol_aberta,
               tipo_legenda: null
            });
            return obj;
            break;
         case 9:
            Object.assign(obj, {
               tipo: 'box-titulo-numero',
               datasource: matriz.rom_pendente,
               tipo_legenda: 'numero',
               titulo: 'Romaneios Pend. de Emissões'
            });
            return obj;
            break;
         case 10:
            Object.assign(obj, {
               tipo: 'box-titulo-numero',
               datasource: matriz.doc_emitido,
               tipo_legenda: 'numero',
               titulo: 'Documentos Emitidos'
            });
            return obj;
            break;
         case 11:
            Object.assign(obj, {
               tipo: 'rom-nao-fatu-ope-tbl',
               af: null,
               vf: null,
               titulo: 'Romaneio não faturado por operação',
               datasource: matriz.lista_rom_fat_op,
               tipo_legenda: null
            });
            return obj;
            break;
         case 12:
            Object.assign(obj, {
               tipo: 'rom-nao-fatu-tbl',
               af: null,
               vf: null,
               titulo: 'Romaneio não faturado',
               datasource: matriz.lista_rom_fat2,
               tipo_legenda: null
            });
            return obj;
            break;
         case 13:
            Object.assign(obj, {
               tipo: 'emiss-por-usuario-tbl',
               af: null,
               vf: null,
               titulo: 'Emissões por usuário',
               datasource: matriz.lista_qtde_doc_usuario,
               tipo_legenda: null
            });
            return obj;
            break;
         case 14:
            Object.assign(obj, {
               tipo: 'barra-vertical',
               af: 'descricao',
               vf: 'valor',
               tipo_legenda: 'numero',
               titulo: 'Emissões hora a hora',
               datasource: matriz.dataCtes,
            });
            return obj;
            break;
         case 15:
            Object.assign(obj, {
               tipo: 'box-titulo-numero',
               datasource: matriz.ctes_emitidos,
               tipo_legenda: 'numero',
               titulo: 'Total de CTES emitidos'
            });
            return obj;
            break;
         case 16:
            Object.assign(obj, {
               tipo: 'box-titulo-numero',
               datasource: matriz.ctes_cancelado,
               tipo_legenda: 'numero',
               titulo: 'Total de CTES cancelados'
            });
            return obj;
            break;
         case 17:
            Object.assign(obj, {
               tipo: 'pie-leg-right',
               af: 'operacao',
               vf: 'qtde',
               titulo: 'CTES emitidos por operação',
               datasource: matriz.ctes_operacao.filter(e => {
                  return e.qtde > 0;
               }),
               tipo_legenda: 'numero'
            });
            return obj;
            break;
         case 18:
            Object.assign(obj, {
               tipo: 'pie-leg-right',
               af: 'cancelado_por',
               vf: 'qtde',
               titulo: 'Lista de CTES cancelados',
               datasource: matriz.lista_ctes_cancelados,
               tipo_legenda: 'numero'
            });
            return obj;
            break;
         case 19:
            Object.assign(obj, {
               tipo: 'barra-horizontal',
               af: 'chave',
               vf: 'valor',
               titulo: 'Quantidade de emissões X CCG (Diário)',
               datasource: matriz.lista_ccg_diario.reverse(),
               tipo_legenda: 'numero'
            });
            return obj;
            break;
         case 20:
            Object.assign(obj, {
               tipo: 'barra-horizontal',
               af: 'chave',
               vf: 'valor',
               titulo: 'Quantidade de emissões X CCG (Mensal)',
               datasource: matriz.lista_ccg_mensal.reverse(),
               tipo_legenda: 'numero'
            });
            return obj;
            break;
         case 21:
            Object.assign(obj, {
               tipo: 'rom-nao-fatu-td-tbl',
               af: null,
               vf: null,
               titulo: 'Romaneio não faturado (Tipo Documento)',
               datasource: matriz.lista_rom_fat,
               tipo_legenda: null
            });
            return obj;
            break;
      }
   }

   transforma(visualizacao) {
      switch (visualizacao) {
         case 'Mensal':
            return 'Mensais';
            break;
         case 'Semanal':
            return 'Semanais';
            break;
         case 'Anual':
            return 'Anuais';
            break;
      }
   }
}
