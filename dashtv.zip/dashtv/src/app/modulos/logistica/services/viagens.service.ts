import { Injectable } from '@angular/core';
import * as _ from 'underscore';

@Injectable({
   providedIn: 'root'
})
export class ViagensService {

   constructor() { }

   getDefinicoes(tipo, visualizacao, matriz) {
      const obj = {};
      switch (tipo) {
         case 1:
            Object.assign(obj, {
               tipo: 'pie-leg-right',
               af: 'cliente',
               vf: 'valor',
               titulo: 'Viagens ' + this.transforma(visualizacao) + ' por Cliente',
               datasource: this.getByCliente(matriz.viagemCiente),
               tipo_legenda: 'numero'
            });

            return obj;

            break;
         case 2:
            Object.assign(obj, {
               tipo: 'pie-leg-right',
               af: 'mercadoria',
               vf: 'valor',
               titulo: 'Viagens ' + this.transforma(visualizacao) + ' por Mercadoria',
               datasource: this.getByMercadoria(matriz.viagemMercadoria),
               tipo_legenda: 'numero'

            });
            return obj;
            break;

         case 3:
            Object.assign(obj, {
               tipo: 'tonelagem-por-rota',
               af: null,
               vf: null,
               titulo: 'Tonelagem ' + visualizacao + ' por Rota',
               datasource: this.getByRota(matriz.viagemRota),
               tipo_legenda: null

            });
            return obj;
            break;
         case 4:
            Object.assign(obj, {
               tipo: 'barra-horizontal',
               af: 'destino',
               vf: 'valor',
               titulo: 'Viagens ' + this.transforma(visualizacao) + ' por Destino',
               datasource: this.getByDestino(matriz.viagemDestino),
               tipo_legenda: 'numero'

            });
            return obj;
            break;
         case 5:
            Object.assign(obj, {
               tipo: 'box-titulo-numero',
               af: null,
               vf: null,
               titulo: 'Total Viagens (' + visualizacao + ')',
               datasource: (matriz.totalizadores.length > 0 ? matriz.totalizadores[0].viagens.toFixed(0) : 0),
               tipo_legenda: null

            });
            return obj;
            break;
         case 6:
            Object.assign(obj, {
               tipo: 'box-titulo-numero',
               af: null,
               vf: null,
               titulo: 'Total KM Vazio (' + visualizacao + ')',
               datasource: (matriz.totalizadores.length > 0 ? matriz.totalizadores[0].km_vazio.toFixed(0) : 0),
               tipo_legenda: null

            });
            return obj;
            break;
         case 7:
            Object.assign(obj, {
               tipo: 'box-titulo-numero',
               af: null,
               vf: null,
               titulo: 'Total Tonelagem (' + visualizacao + ')',
               datasource: (matriz.totalizadores.length > 0 ? matriz.totalizadores[0].tonelagem.toFixed(0) : 0),
               tipo_legenda: null

            });
            return obj;
            break;
         case 8:
            Object.assign(obj, {
               tipo: 'desbalanco-carga',
               af: null,
               vf: null,
               titulo: 'Desbalanço de carga ' + visualizacao,
               datasource: this.getByOrigemDestino(matriz.origemDestino),
               tipo_legenda: null
            });
            return obj;
            break;
         case 9:
            Object.assign(obj, {
               tipo: 'box-titulo-numero',
               af: null,
               vf: null,
               titulo: 'Total KM Carregado (' + visualizacao + ')',
               datasource: (matriz.totalizadores.length > 0 ? matriz.totalizadores[0].km_carregado.toFixed(0) : 0),
               tipo_legenda: null

            });
            return obj;
            break;
         case 10:
            Object.assign(obj, {
               tipo: 'box-titulo-numero',
               af: null,
               vf: null,
               titulo: 'Total KM Rodado (' + visualizacao + ')',
               datasource: (matriz.totalizadores.length > 0 ? matriz.totalizadores[0].km_total.toFixed(0) : 0),
               tipo_legenda: null

            });
            return obj;
            break;
         case 11:
            Object.assign(obj, {
               tipo: 'desbalanco-carga-tbl',
               af: null,
               vf: null,
               titulo: 'Desbalanço de carga ' + visualizacao,
               datasource: this.getByOrigemDestinoTbl(matriz.origemDestino),
               tipo_legenda: null

            });
            return obj;
            break;
         case 12:
            Object.assign(obj, {
               tipo: 'box-titulo-numero',
               af: null,
               vf: null,
               titulo: 'Total Volume(' + visualizacao + ')',
               datasource: (matriz.totalizadores.length > 0 ? matriz.totalizadores[0].volume.toFixed(0) : 0),
               tipo_legenda: null
            });
            return obj;
            break;
         case 13:
            Object.assign(obj, {
               tipo: 'barra-horizontal',
               af: 'origem',
               vf: 'valor',
               titulo: 'Viagens ' + this.transforma(visualizacao) + ' por Origem',
               datasource: this.getByOrigem(matriz.viagemOrigem),
               tipo_legenda: 'numero'
            });
            return obj;
            break;
         case 14:
            Object.assign(obj, {
               tipo: 'viagens-por-origem',
               datasource: matriz.viagemOrigem,
               tipo_legenda: 'numero',
               titulo: 'Viagens ' + this.transforma(visualizacao) + ' por origem'
            });
            return obj;
            break;
      }
   }

   transforma(visualizacao) {
      switch (visualizacao) {
         case 'Mensal':
            return 'Mensais';
            break;
         case 'Semanal':
            return 'Semanais';
            break;
         case 'Anual':
            return 'Anuais';
            break;
      }
   }

   getByCliente(matriz) {
      let lista = [];
      matriz.reduce(function (res, value) {
         if (!res[value.cliente]) {
            res[value.cliente] = { cliente: value.cliente, valor: 0 };
            lista.push(res[value.cliente]);
         }
         res[value.cliente].valor += value.viagens;
         return res;
      }, {});

      lista = _.sortBy(lista, 'valor').reverse();

      let top10 = [];
      if (lista.length > 10) {
         let novoSaldo = 0;
         lista.forEach((element, i) => {
            if (i > 9) {
               novoSaldo += element.valor;
            } else {
               top10.push({ cliente: element.cliente, valor: element.valor }); // setar o campo utilizado em "valor"
            }
         });

         if (novoSaldo > 0) {
            top10.push({ cliente: 'OUTROS', valor: novoSaldo }); // setar o campo utilizado em "valor"
         }
      } else {
         top10 = lista;
      }

      return top10;
   }

   getByMercadoria(matriz) {
      let lista = [];
      matriz.reduce(function (res, value) {
         if (!res[value.mercadoria]) {
            res[value.mercadoria] = { mercadoria: value.mercadoria, valor: 0 };
            lista.push(res[value.mercadoria]);
         }
         res[value.mercadoria].valor += value.viagens;
         return res;
      }, {});

      lista = _.sortBy(lista, 'valor').reverse();

      let top10 = [];
      if (lista.length > 10) {
         let novoSaldo = 0;
         lista.forEach((element, i) => {
            if (i > 9) {
               novoSaldo += element.valor;
            } else {
               top10.push({ mercadoria: element.mercadoria, valor: element.valor }); // setar o campo utilizado em "valor"
            }
         });

         if (novoSaldo > 0) {
            top10.push({ mercadoria: 'OUTROS', valor: novoSaldo }); // setar o campo utilizado em "valor"
         }
      } else {
         top10 = lista;
      }

      return top10;
   }

   getByDestino(matriz) {
      let lista = [];
      matriz.reduce(function (res, value) {
         if (!res[value.destino]) {
            res[value.destino] = { destino: value.destino, valor: 0 };
            lista.push(res[value.destino]);
         }
         res[value.destino].valor += value.viagens;
         return res;
      }, {});

      lista = _.sortBy(lista, 'valor').reverse();

      let top10 = [];
      if (lista.length > 10) {
         let novoSaldo = 0;
         lista.forEach((element, i) => {
            if (i > 9) {
               novoSaldo += element.valor;
            } else {
               top10.push({ destino: element.destino, valor: element.valor });
            }
         });

         if (novoSaldo > 0) {
            top10.push({ destino: 'OUTROS', valor: novoSaldo });
         }
      } else {
         top10 = lista;
      }

      return top10.reverse();
   }

   getByRota(matriz) {
      let lista = [];
      matriz.reduce(function (res, value) {
         if (!res[value.rota]) {
            res[value.rota] = { rota: value.rota, peso: 0 };
            lista.push(res[value.rota]);
         }
         res[value.rota].peso += value.tonelagem;
         return res;
      }, {});

      lista = _.sortBy(lista, 'peso').reverse();
      return lista;
   }

   getByOrigemDestino(matriz) {
      matriz = _.filter(matriz, function (num) {
         return num.origem !== 'SEM UF ORIGEM';
      });
      const destinos_unicos = _.uniq(matriz, false, 'destino');
      const du = [];
      destinos_unicos.forEach(element => {
         du.push(element.destino);
      });

      const lista = [];
      const obj = _.groupBy(matriz, 'origem');
      Object.keys(obj).forEach(function (item) {
         const destinoOBJ = _.groupBy(obj[item], 'destino');
         lista.push({ origem: item, destinos: destinoOBJ });
      });

      let lista2 = [];
      lista.forEach(element => {
         const o = {};
         Object.assign(o, { origem: element.origem });
         Object.keys(element.destinos).forEach(function (destino) {
            Object.assign(o, { [destino]: element.destinos[destino][0].viagens });
         });
         lista2.push(o);
      });
      lista2 = _.sortBy(lista2, 'origem');
      const retorno = { datasource: lista2, unicos: du };
      return retorno;
   }

   getByOrigemDestinoTbl(matriz) {
      matriz = _.filter(matriz, function (num) {
         return num.origem !== 'SEM UF ORIGEM';
      });

      let lista_auxiliar = [];
      const obj = _.groupBy(matriz, 'origem');
      Object.keys(obj).forEach(function (item) {
         const destinoOBJ = _.groupBy(obj[item], 'destino');
         lista_auxiliar.push({ origem: item, destinos: destinoOBJ });
      });
      lista_auxiliar = _.sortBy(lista_auxiliar, 'origem');

      const lista = [];
      lista_auxiliar.forEach(element => {
         const o = {};
         Object.assign(o, { origem: element.origem });
         const array = [];
         Object.keys(element.destinos).forEach(function (destino) {
            array.push({ destino: destino, viagens: element.destinos[destino][0].viagens });
            Object.assign(o, { destinos: array });
         });
         lista.push(o);
      });

      return lista;
   }

   getByOrigem(matriz) {
      let lista = [];
      matriz.reduce(function (res, value) {
         if (!res[value.origem]) {
            res[value.origem] = { origem: value.origem, valor: 0 };
            lista.push(res[value.origem]);
         }
         res[value.origem].valor += value.viagens;
         return res;
      }, {});

      lista = _.sortBy(lista, 'valor').reverse();

      let top10 = [];
      if (lista.length > 10) {
         let novoSaldo = 0;
         lista.forEach((element, i) => {
            if (i > 9) {
               novoSaldo += element.valor;
            } else {
               top10.push({ origem: element.origem, valor: element.valor });
            }
         });

         if (novoSaldo > 0) {
            top10.push({ origem: 'OUTROS', valor: novoSaldo });
         }
      } else {
         top10 = lista;
      }

      return top10.reverse();
   }
}
