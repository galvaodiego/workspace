import { Component, OnInit, Input } from '@angular/core';

@Component({
   selector: 'app-preventivas-card-box',
   templateUrl: './preventivas-card-box.component.html',
   styleUrls: ['./preventivas-card-box.component.scss']
})
export class PreventivasCardBoxComponent implements OnInit {
   @Input() veiculo: any;
   @Input() tipo: number; // 1 - CAVALO MECANICO, 2 - SEMI REBOQUE

   showList = false;
   tableList: Array<any> = [];
   constructor() { }

   ngOnInit() {
   }

   public countTables(data: string) {
      let numTables: number;
      return numTables = data.split('/').length;
   }

   public explainTables(data: string) {
      this.tableList = data.split('/');
   }

   public showTableList(data: string) {
      console.log('clicou', data);
      this.explainTables(data);
      this.showList = !this.showList;
   }

}
