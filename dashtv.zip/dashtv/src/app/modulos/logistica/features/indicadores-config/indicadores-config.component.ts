import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Usuario, NavigationService, GatewayService, UsuarioService, ClienteService } from 'src/app/shared';
import notify from 'devextreme/ui/notify';
import * as _ from 'underscore';

@Component({
   selector: 'app-indicadores-config',
   templateUrl: './indicadores-config.component.html',
   styleUrls: ['./indicadores-config.component.scss']
})
export class IndicadoresConfigComponent implements OnInit {
   @Output() respostaCadastro = new EventEmitter();

   datasource: Array<any>;
   indicadores: Array<any>;
   ordem_options: Array<any>;
   org: any;
   showColors: boolean;
   dadosCores: any;
   formColor: any;

   constructor(
      private _gateway: GatewayService,
      private _clienteS: ClienteService
   ) {
      this.ordem_options = [1, 2, 3, 4, 5, 6];
      this.org = JSON.parse(localStorage.getItem('kmm_bi-dash|' + this._clienteS.discover() + '-organizacional'));
      this.datasource = [];
      this.showColors = false;
      this.formColor = {
         resolvido: '#05d605',
         nao_resolvido: '#de1010',
         barras: '#003A70',
         range_1: '#CE2029',
         range_2: '#FFD700',
         range_3: '#228B22'
      };
   }

   ngOnInit() {
      this.getData();
      this._clienteS.discover();
      console.log('this.org', this.org, this._clienteS.discover());
   }

   ins(e) {
      
      
      Object.assign(e.data, {
         usuario_bi_id: this.org.usuario.usuarioBiId,
         largura: 350
      });
      this._gateway.backendCall('M4002', 'insConfigAlerta', e.data).then((res: any) => {
         let tipo = 'success';
         if (res.mensagem === 'Já existe registro com este tipo de indicador para este usuário') {
            tipo = 'error';
         }

         this.toast(res.mensagem, tipo);
         this.atualiza(res.mensagem);
         this.getData();
      });
   }

   alt(e) {
      const obj = Object.assign({}, e.oldData, e.newData);
      Object.assign(e, {
         data: obj
      });

      Object.assign(e.data, {
         config_alerta_logistica_id: e.key
      });

      this._gateway.backendCall('M4002', 'altConfigAlerta', e.data).then((res: any) => {
         this.toast(res.mensagem);
         this.atualiza(res.mensagem);
      });

   }

   del(e) {
      this._gateway.backendCall('M4002', 'delConfigAlerta', e.data).then((res: any) => {
         this.toast(res.mensagem);
         this.atualiza(res.mensagem);
      });
   }

   getData() {
      try {
         this._gateway.backendCall('M4002', 'getConfigAlertas').then((res: any) => {
            console.log('getConfigAlertas:', res, res.config.length);
            this.datasource = res.config;
            this._gateway.backendCall('M4002', 'getIndicadores').then((resp: any) => {
               console.log('getIndicadores:', resp);
               this.indicadores = resp.indicadores;
            });
         });
      } catch (error) {
         console.log(error);
      }
   }

   toast(msg, cor?, tempo?) {
      notify({
         message: msg,
         type: cor ? cor : 'success',
         displayTime: tempo ? tempo : 3000,
         closeOnClick: true,
         width: function () {
            return window.innerWidth / 2.8;
         }
      });
   }

   atualiza(mensagem) {
      this.respostaCadastro.emit({ mensagem: mensagem });
   }

   showInfo(data) {
      this.dadosCores = data;
      const obj = _.findWhere(this.datasource, { config_alerta_logistica_id: data.key });
      // console.log('aqui', obj);
      if (obj) {
         switch (obj.indicador) {
            case 1:
               if (obj.opcoes !== '') {
                  const opcoesJson = JSON.parse(obj.opcoes);
                  if (opcoesJson.cores && opcoesJson.cores.resolvido && opcoesJson.cores.nao_resolvido) {
                     Object.assign(this.formColor, {
                        resolvido: opcoesJson.cores.resolvido,
                        nao_resolvido: opcoesJson.cores.nao_resolvido,
                     });
                  }
               }
               break;
            case 3:
            case 4:
            case 6:
               if (obj.opcoes !== '') {
                  const opcoesJson = JSON.parse(obj.opcoes);
                  if (opcoesJson.cores && opcoesJson.cores.barras) {
                     Object.assign(this.formColor, {
                        barras: opcoesJson.cores.barras
                     });
                  }
               }
               break;

            case 5:
               if (obj.opcoes !== '') {
                  const opcoesJson = JSON.parse(obj.opcoes);
                  if (opcoesJson.cores && opcoesJson.cores.range_1 && opcoesJson.cores.range_2 && opcoesJson.cores.range_3) {
                     Object.assign(this.formColor, {
                        range_1: opcoesJson.cores.range_1,
                        range_2: opcoesJson.cores.range_2,
                        range_3: opcoesJson.cores.range_3,
                     });
                  }
               }
               break;


         }
      }
      this.showColors = true;
   }

   salvaCores(dados) {
      const obj = {};
      switch (dados.data.indicador) {
         case 1:
            Object.assign(obj, {
               cores: {
                  resolvido: this.formColor.resolvido,
                  nao_resolvido: this.formColor.nao_resolvido
               }
            });
            break;
         case 3:
         case 4:
         case 6:
            Object.assign(obj, {
               cores: {
                  barras: this.formColor.barras,
               }
            });
            break;
         case 5:
            Object.assign(obj, {
               cores: {
                  range_1: this.formColor.range_1,
                  range_2: this.formColor.range_2,
                  range_3: this.formColor.range_3
               }
            });
            break;
      }

      const parametros = {
         config_alerta_logistica_id: dados.key,
         opcoes: JSON.stringify(obj)
      };

      this._gateway.backendCall('M4002', 'altConfigAlertaOpcoes', parametros).then((res: any) => {
         this.getData();
         this.toast(res.mensagem);
         this.atualiza(res.mensagem);
      });
   }

}
