import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CoreModule } from '../@core/@core.module';
import { ComponentsModule } from 'src/app/shared/components/components.module';
import { DxDataGridModule, DxPieChartModule, DxChartModule, DxPopupModule, DxMapModule, DxDateBoxModule, DxLinearGaugeModule, DxCircularGaugeModule, DxLoadPanelModule, DxColorBoxModule, DxFormModule, DxButtonModule } from 'devextreme-angular';

// Services
import { DadosRegiaoEstado } from 'src/app/shared/components/kmm-mapa/entities';

//Componentes
import { LogisticaIndicadoresCargaDescargaComponent } from './logistica-indicadores-carga-descarga/logistica-indicadores-carga-descarga.component';
import { LogisticaSolicitacoesResumoComponent } from './logistica-solicitacoes-resumo/logistica-solicitacoes-resumo.component';

//Micro Componentes
import { MapaView } from './mapa.view';
import { DestinadoGrid } from './grids/destinado.grid';
import { CteGrid } from './grids/cte.grid';
import { EmCargaGrid } from './grids/em_carga.grid';
import { NfEsperaGrid } from './grids/nf_espera.grid';
import { NotasAtendidasGrid } from './grids/notas_atendidas.grid';
import { ParqueamentoGrid } from './grids/parqueamento.grid';
import { PrevisaoDescargaGrid } from './grids/previsao_descarga.grid';
import { TempoDescargaGrid } from './grids/tempo_descarga.grid';
import { TransitTimeGrid } from './grids/transit_time.grid';
import { ViewsModule } from './grids/views/views.module';
import { IndicadoresConfigComponent } from './indicadores-config/indicadores-config.component';
import { IndicadoresTipoGraficoComponent } from './indicadores-tipo-grafico/indicadores-tipo-grafico.component';
import { PreventivasCardBoxComponent } from './preventivas-card-box/preventivas-card-box.component';

@NgModule({
    imports: [
        CommonModule,
        ComponentsModule,
        CoreModule,
        ViewsModule,
        DxDataGridModule,
        DxChartModule,
        DxPieChartModule,
        DxPopupModule,
        DxMapModule,
        DxDateBoxModule,
        DxLinearGaugeModule,
        DxCircularGaugeModule,
        DxLoadPanelModule,
        DxColorBoxModule,
        DxFormModule,
        DxButtonModule
    ],
    declarations: [
        MapaView,
        DestinadoGrid,
        CteGrid,
        EmCargaGrid,
        NfEsperaGrid,
        NotasAtendidasGrid,
        ParqueamentoGrid,
        PrevisaoDescargaGrid,
        TempoDescargaGrid,
        TransitTimeGrid,
        LogisticaIndicadoresCargaDescargaComponent,
        LogisticaSolicitacoesResumoComponent,
        IndicadoresConfigComponent,
        IndicadoresTipoGraficoComponent,
        PreventivasCardBoxComponent,
    ],
    exports: [
        ViewsModule,
        MapaView,
        DestinadoGrid,
        CteGrid,
        EmCargaGrid,
        NfEsperaGrid,
        NotasAtendidasGrid,
        ParqueamentoGrid,
        PrevisaoDescargaGrid,
        TempoDescargaGrid,
        TransitTimeGrid,
        LogisticaIndicadoresCargaDescargaComponent,
        LogisticaSolicitacoesResumoComponent,
        IndicadoresConfigComponent,
        IndicadoresTipoGraficoComponent,
        PreventivasCardBoxComponent
    ],
    providers: [DadosRegiaoEstado],

})
export class FeaturesModule { }
