import { Component, Input, AfterViewInit } from '@angular/core';
import { environment } from 'src/environments/environment';

@Component({
    selector: 'app-feature-logistica-trafego-ocorrencia-mapa',
    template: `
    <dx-map #map id="mapArea" [zoom]="10" height="100%" width="100%" [key]="apiKey" [provider]="'google'" [type]="'roadmap'"
	 [controls]="false" [markers]="marcadores"></dx-map>
    `
})
export class MapaView implements AfterViewInit {

    @Input('dados') dados: any;

    // Markers Personalizados do Mapa
    public marcadores: Array<any> = [];
    // Markers Personalizados do Mapa - ESPELHO PARA A BUSCA
    public mirrorMarcadores: Array<any> = [];
    // Chave de Acesso
    public apiKey = environment.mapa_key_google;

    ngAfterViewInit() {

        // Cópia dos Marcadores Originais
        this.mirrorMarcadores = this.dados;

        // Prepara o Array conforme Google Maps
        this.initMap(this.mirrorMarcadores);
    }

    /**
    * Inicializa o Mapa Atribuindo valor ao @var this.marcadores
    * @param obj array para ser preparado
    */
    public initMap(obj) {
        // Zera o Array para receber os dados
        this.marcadores = [];
        if (obj.length > 0) {
            obj.forEach(
                (el) => {
                    this.marcadores.push({
                        location: [el.lat, el.lng],
                        data: el,
                        // iconSrc: "assets/icon/map-markers/" + el.status.toLowerCase() + ".png",
                        iconSrc: 'assets/icon/marker_truck.png',
                        onClick: (args) => { }
                    });
                }
            );
        }
    }
}
