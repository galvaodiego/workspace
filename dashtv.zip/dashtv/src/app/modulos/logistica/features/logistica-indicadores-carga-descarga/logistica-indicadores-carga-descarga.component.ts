import { Component, OnInit, Input } from '@angular/core';
import { ClienteService } from 'src/app/shared';

@Component({
    selector: 'logistica-indicadores-carga-descarga',
    templateUrl: './logistica-indicadores-carga-descarga.component.html',
    styles: ["i { font-size: 3.8em !important; }.number { font-family: 'Russo One', sans-serif; font-size: 2em; margin-bottom: 0; }"],
})
export class LogisticaIndicadoresCargaDescargaComponent implements OnInit {

    @Input() formato: string;
    @Input() data: any;

    constructor(public clienteS: ClienteService) { }

    ngOnInit() {
        setTimeout(() => {
        }, 5000);
    }

}
