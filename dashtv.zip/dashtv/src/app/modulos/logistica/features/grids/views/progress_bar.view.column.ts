import { Component, OnInit, AfterViewInit } from '@angular/core';

@Component({
    template:
        `<div *dxTemplate="let row of 'transitTime'">
            {{ row.frota ? row.frota : 'Teste' }}
            <p>  Teste </p>
        </div>
        `
})

export class TransitTimeProgressViewColumn implements OnInit, AfterViewInit {

    constructor() {
        console.log('1');

    }

    ngOnInit() {
        console.log('2');
    }

    ngAfterViewInit() {
        console.log('3');
    }
}
