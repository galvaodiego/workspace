import { Component, Input, ViewChild, AfterViewInit, OnDestroy, OnInit, Injector } from '@angular/core';

import { GridComponent } from 'src/app/shared/components/grid/grid.component';
import { GridColumn } from 'src/app/shared/';

import { GridColumn2 } from 'src/app/shared/decorators/grid.decorator';

import { TransitTimeProgressViewColumn } from './views/progress_bar.view.column';
import { TransitTimeJanelaViewColumn } from './views/transitTimeJanela.view.column';
import { PresenterComponent } from 'src/app/shared/components/presenter/presenter.component';

@Component({
    selector: 'app-feature-logistica-transit-time-grid',
    template: `
        <div class="card">
            <div class="body pd-table">
                <app-grid #TransitTimeGrid [dataSource]="dataSourceForGrid"></app-grid>
            </div>
        </div>
    `
})
export class TransitTimeGrid extends PresenterComponent implements OnInit, OnDestroy {

    @ViewChild('TransitTimeGrid', { static: true }) TransitTimeGrid: GridComponent;

    @Input('dados') dados: any;


    @GridColumn2('gridTT', 'Template', TransitTimeProgressViewColumn, { visible: true, cellTemplate: 'transitTime' })
    options

    dataSourceForGrid: any = {};

    columns = [
        GridColumn.Text({ dataField: 'placa_tracao', caption: 'Placa', alignment: 'center', width: 120 }),
        GridColumn.Text({ dataField: 'frota', caption: 'Frota', alignment: 'center', width: 120 }),
        GridColumn.Text({ dataField: 'num_romaneio', caption: 'Romaneio', alignment: 'center', width: 120 }),
        GridColumn.Text({ dataField: 'origem', caption: 'Origem', alignment: 'center', width: 180 }),
        GridColumn.Text({ dataField: 'destino', caption: 'Destino', alignment: 'center', width: 180 }),
        GridColumn.Text({ dataField: 'nac_previsao_chegada', caption: 'Previsão de Chegada', alignment: 'center', width: 200 }),
        GridColumn.Text({ dataField: 'previsao_inicio_carga_descarga', caption: 'Prev. Inicio Descarga', alignment: 'center', width: 180 }),
        // GridColumn.Template({
        //     dataField: 'nac_percentual_executado',
        //     caption: 'Transit Time',
        //     cellTemplate: 'transitTime',
        //     template: 'transitTime',
        //     component: TransitTimeProgressViewColumn,
        //     calculateCellValue: function (data) {
        //         return
        //     }
        // }),
        // Cumpriu Janela Carga
        GridColumn.Text({
            dataField: 'janela_carga', caption: 'Janela Carga', width: 30, visible: false,
            calculateCellValue: function (data) {
                let html: string;
                if (data.janela_carga == 1) {
                    html = '<i class="fas fa-check-circle fa-2x u-color-success"></i> ';
                } else if (data.janela_carga == 0) {
                    html = '<i class="fas fa-times-circle fa-2x u-color-danger"></i> ';
                }
                return html;
            }
        }),

        // Transit Time Janela
        GridColumn.Template({
            dataField: 'transit_time',
            caption: 'Transit Time Janela',
            cellTemplate: 'transitTimeJan',
            component: TransitTimeJanelaViewColumn
        }),
    ];


    constructor(
        protected _injector: Injector,
    ) {
        super(_injector, true, ['RECINTO_INSERIR_CARGA_CLIENTE']);
    }

    ngAfterViewInit() {
        this.dataSourceForGrid = {
            contextName: 'TransitTimeGrid',
            arrayResult: this.dados,
            columns: this.columns,
            options: {
                "columnChooser": false
            }
        };
    }
}