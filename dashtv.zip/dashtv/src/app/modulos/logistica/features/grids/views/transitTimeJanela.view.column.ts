import { Component, OnInit, AfterViewInit } from '@angular/core';

@Component({
    selector: 'app-transit-time-janela-view-column',
    template:
        `<div *dxTemplate="let row of 'transitTimeJan'">
            {{ row.frota ? row.frota : 'Teste' }}
            olz
        </div>
        `
})

export class TransitTimeJanelaViewColumn implements OnInit, AfterViewInit {

    constructor() {
        console.log('ooooii');
        
    }
    
    ngOnInit() { 
        console.log('ooooii1');
    }
    
    ngAfterViewInit() { 
        console.log('ooooii2');
        
    }
}
