import { Component, Input, AfterViewInit } from '@angular/core';
import { GridColumn } from 'src/app/shared/';

@Component({
    selector: 'app-feature-logistica-parqueamento-grid',
    template: `
        <div class="card">
            <div class="header">
                <h2 class="u-text-bold">Lista de Parqueados</h2>
            </div>
            <div class="body pd-table">
                <app-grid #parqueamentoGrid [dataSource]="dataSourceForGrid"></app-grid>
            </div>
        </div>
    `
})
export class ParqueamentoGrid implements AfterViewInit {

    @Input('dados') dados: any;

    dataSourceForGrid: any = {};

    columns = [
        GridColumn.Text({ dataField: 'placa', caption: 'Placa', alignment: 'center' }),
        GridColumn.Text({ dataField: 'operacao', caption: 'Operação', alignment: 'center' }),
        GridColumn.Text({ dataField: 'tempo', caption: 'Tempo', alignment: 'center' }),
        GridColumn.Text({ dataField: 'referencia', caption: 'Referência', alignment: 'center' }),
        GridColumn.Text({ dataField: 'status', caption: 'Status', alignment: 'center' }),
    ];

    ngAfterViewInit() {
        this.dataSourceForGrid = {
            contextName: 'parqueamentoGrid',
            arrayResult: this.dados,
            columns: this.columns,
            options: {}
        };
    }

}