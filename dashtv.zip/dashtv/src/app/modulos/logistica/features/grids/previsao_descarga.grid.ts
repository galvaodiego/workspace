import { Component, Input, AfterViewInit } from '@angular/core';

import { GridColumn } from 'src/app/shared/';

@Component({
    selector: 'app-feature-logistica-previsao-descarga-grid',
    template: `
        <div class="card">
            <div class="header">
                <h2 class="u-text-bold">Previsão de Descarga</h2>
            </div>
            <div class="body pd-table card-absolut">
                <app-grid [dataSource]="dataSourceForGrid"></app-grid>
            </div>
        </div>
    `
})
export class PrevisaoDescargaGrid implements AfterViewInit {

    @Input('dados') dados: any;

    dataSourceForGrid: any = {};

    columns = [
        GridColumn.Text({ dataField: 'frota', caption: 'Frota', alignment: 'center' }),
        GridColumn.Text({ dataField: 'placa_tracao', caption: 'Placa', alignment: 'center' }),
        GridColumn.Text({ dataField: 'num_romaneio', caption: 'Romaneio', alignment: 'center' }),
        GridColumn.Text({ dataField: 'origem', caption: 'Origem', alignment: 'center' }),
        GridColumn.Text({ dataField: 'destino', caption: 'Destino', alignment: 'center' }),
        GridColumn.Text({ dataField: 'previsao_carregado', caption: 'Previsão', alignment: 'center' }),
        GridColumn.Text({ dataField: 'identificador', caption: 'CNPJ', alignment: 'center', visible: false }),
        GridColumn.Text({ dataField: 'grupo_negociador', caption: 'Grupo Negoc.', alignment: 'center', visible: false }),
        GridColumn.Text({ dataField: 'cliente', caption: 'Cliente', alignment: 'center', visible: false }),
        GridColumn.Text({ dataField: 'origem', caption: 'Origem', alignment: 'center', visible: false }),
        GridColumn.Text({ dataField: 'destino', caption: 'Destino', alignment: 'center', visible: false }),
        GridColumn.Text({ dataField: 'tempo_min', caption: 'Tempo Min', alignment: 'center', visible: false }),
    ];

    ngAfterViewInit() {
        this.dataSourceForGrid = {
            contextName: 'previsaoDescargaGrid',
            arrayResult: this.dados,
            columns: this.columns,
            options: {
                "columnChooser": true
            }
        };
    }

}