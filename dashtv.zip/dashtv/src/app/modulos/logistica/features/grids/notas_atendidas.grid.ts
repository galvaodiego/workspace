import { Component, Input, ViewChild, AfterViewInit } from '@angular/core';

import { GridComponent } from 'src/app/shared/components/grid/grid.component';
import { GridColumn } from 'src/app/shared/';

import * as moment from 'moment';
import 'moment/locale/pt-br';

@Component({
    selector: 'app-feature-logistica-notas-atendidas-grid',
    template: `
        <div class="card">
            <div class="header">
            <h2 class="u-text-bold"> <strong>Quadro de resumo</strong> – Núm. de notas atendidas em {{ dataHoje ? dataHoje : '' }} </h2>
            </div>
            <div class="body pd-table card-absolut">
                <app-grid #NotasAtendidasGrid [dataSource]="dataSourceForGrid"></app-grid>
            </div>
        </div>
    `
})
export class NotasAtendidasGrid implements AfterViewInit {

    @ViewChild('NotasAtendidasGrid', { static: true }) NotasAtendidasGrid: GridComponent;

    @Input('dados') dados: any;

    public dataHoje: string = '';

    dataSourceForGrid: any = {};

    columns = [
        GridColumn.Text({ dataField: 'descricao', caption: 'Segmento', alignment: 'center' }),
        GridColumn.Text({ dataField: 'qtde_nf', caption: 'Quantidade', alignment: 'center' }),
    ];

    ngAfterViewInit() {
        this.dataHoje = moment().format('DD/MM/YYYY');
        this.dataSourceForGrid = {
            contextName: 'NotasAtendidasGrid',
            arrayResult: this.dados,
            columns: this.columns,
            options: {
                "columnChooser": true
            }
        };
    }

}