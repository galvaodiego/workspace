import { Component, Input, ViewChild, AfterViewInit } from '@angular/core';

import { GridComponent } from 'src/app/shared/components/grid/grid.component';
import { GridColumn } from 'src/app/shared/';

@Component({
    selector: 'app-feature-logistica-em-carga-grid',
    template: `
        <div class="card">
            <div class="header">
                <h2 class="u-text-bold">Em Carga</h2>
            </div>
            <div class="body pd-table card-absolut">
                <app-grid #emCargaGrid [dataSource]="dataSourceForGrid"></app-grid>
            </div>
        </div>
    `
})
export class EmCargaGrid implements AfterViewInit {

    @ViewChild('emCargaGrid', { static: true }) emCargaGrid: GridComponent;

    @Input('dados') dados: any;

    dataSourceForGrid: any = {};

    columns = [
        GridColumn.Text({ dataField: 'frota', caption: 'Frota', alignment: 'center' }),
        GridColumn.Text({ dataField: 'num_romaneio', caption: 'Romaneio', alignment: 'center' }),
        GridColumn.Text({ dataField: 'tempo_carga', caption: 'Tempo em Carga', alignment: 'center' }),
        GridColumn.Text({ dataField: 'previsao_termino', caption: 'Previsão de término de carga', alignment: 'center' }),
        GridColumn.Boolean({ dataField: 'carga_atraso', caption: 'Atraso', alignment: 'center', visible: false }),
    ];

    ngAfterViewInit() {
        this.dataSourceForGrid = {
            contextName: 'emCargaGrid',
            arrayResult: this.dados,
            columns: this.columns,
            options: {
                "columnChooser": true
            }
        };
    }

}