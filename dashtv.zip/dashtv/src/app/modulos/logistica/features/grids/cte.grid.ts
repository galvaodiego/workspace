import { Component, Input, ViewChild, AfterViewInit } from '@angular/core';

import { GridComponent } from 'src/app/shared/components/grid/grid.component';
import { GridColumn } from 'src/app/shared/';

@Component({
    selector: 'app-feature-logistica-cte-grid',
    template: `
    <div class="card">
         <div class="header">
            <h2 class="u-text-bold ">Aguardando Emissão</h2>
         </div>
         <div class="body pd-table card-absolut">
            <app-grid #cteGrid [dataSource]="dataSourceForGrid"></app-grid>
        </div>
    </div>
    `
})
export class CteGrid implements AfterViewInit {

    @ViewChild('cteGrid', { static: true }) cteGrid: GridComponent;

    @Input('dados') dados: any;

    dataSourceForGrid: any = {};

    columns = [
        GridColumn.Text({ dataField: 'frota', caption: 'Frota', alignment: 'center' }),
        GridColumn.Text({ dataField: 'placa_tracao', caption: 'Placa Tração', alignment: 'center' }),
        GridColumn.Text({ dataField: 'data_termino_carga', caption: 'Término de carga', alignment: 'center' }),
        GridColumn.Text({ dataField: 'previsao_chegada_grade', caption: 'Previsão de chegada', alignment: 'center' }),
        GridColumn.Text({ dataField: 'tempo_espera', caption: 'Tempo espera', alignment: 'center' }),
        GridColumn.Text({ dataField: 'identificador', caption: 'CNPJ', alignment: 'center', visible: false }),
        GridColumn.Text({ dataField: 'num_romaneio', caption: 'Romaneio', alignment: 'center', visible: false }),
        GridColumn.Text({ dataField: 'cliente', caption: 'Cliente', alignment: 'center', visible: false }),
        GridColumn.Text({ dataField: 'origem', caption: 'Origem', alignment: 'center', visible: false }),
        GridColumn.Text({ dataField: 'destino', caption: 'Destino', alignment: 'center', visible: false }),
        GridColumn.Text({ dataField: 'tempo_min', caption: 'Tempo Min', alignment: 'center', visible: false })
    ];

    ngAfterViewInit() {
        this.dataSourceForGrid = {
            contextName: 'cteGrid',
            arrayResult: this.dados,
            columns: this.columns,
            options: {
                "columnChooser": true
            }
        };
    }

}