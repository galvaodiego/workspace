import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DxTemplateModule } from 'devextreme-angular';

import { TransitTimeProgressViewColumn } from './progress_bar.view.column';
import { TransitTimeJanelaViewColumn } from './transitTimeJanela.view.column';

@NgModule({
    imports: [
        CommonModule,
        DxTemplateModule,
    ],
    declarations: [
        TransitTimeProgressViewColumn,
        TransitTimeJanelaViewColumn,
    ],
    exports: [
        TransitTimeProgressViewColumn,
        TransitTimeJanelaViewColumn,
    ],
    entryComponents: [
        TransitTimeProgressViewColumn,
        TransitTimeJanelaViewColumn,
    ]
})
export class ViewsModule { }
