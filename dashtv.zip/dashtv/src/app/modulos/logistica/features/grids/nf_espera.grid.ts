import { Component, Input, ViewChild, AfterViewInit } from '@angular/core';

import { GridComponent } from 'src/app/shared/components/grid/grid.component';
import { GridColumn } from 'src/app/shared/';

@Component({
    selector: 'app-feature-logistica-nf-espera-grid',
    template: `
        <div class="card">
            <div class="header">
            <h2 class="u-text-bold"> <strong>Lista</strong> – Notas fiscais em espera </h2>
            </div>
            <div class="body pd-table card-absolut">
                <app-grid #NfEsperaGrid [dataSource]="dataSourceForGrid"></app-grid>
            </div>
        </div>
    `
})
export class NfEsperaGrid implements AfterViewInit {

    @ViewChild('NfEsperaGrid', { static: true }) NfEsperaGrid: GridComponent;

    @Input('dados') dados: any;

    dataSourceForGrid: any = {};

    columns = [
        GridColumn.Text({ dataField: 'num_nf', caption: 'Número NF', alignment: 'center' }),
        GridColumn.Text({ dataField: 'data_emissao', caption: 'Data emissão', alignment: 'center' }),
        GridColumn.Text({ dataField: 'destinatario', caption: 'Destinatário', alignment: 'center' }),
        GridColumn.Text({ dataField: 'produto', caption: 'Produto', alignment: 'center' }),
        GridColumn.Text({ dataField: 'valor', caption: 'Valor', alignment: 'center' }),
    ];

    ngAfterViewInit() {
        this.dataSourceForGrid = {
            contextName: 'NfEsperaGrid',
            arrayResult: this.dados,
            columns: this.columns,
            options: {
                "columnChooser": true
            }
        };
    }

}