import { Component, OnInit, Input, ViewChild, AfterViewInit, AfterContentInit, OnChanges, SimpleChanges } from '@angular/core';
import { GatewayService, ClienteService, NavigationService, Usuario } from 'src/app/shared';
import * as _ from 'underscore';

@Component({
   selector: 'app-indicadores-tipo-grafico',
   templateUrl: './indicadores-tipo-grafico.component.html',
   styleUrls: ['./indicadores-tipo-grafico.component.scss']
})
export class IndicadoresTipoGraficoComponent implements OnInit, OnChanges {
   @ViewChild('pieChartAlertas', { static: false }) pieChartAlertas: any;
   @Input() dadosComponente: any;
   public user: Usuario = Usuario.instance;

   showLoad = false;
   atendimento: any;
   grafico_operador: any;
   grafico_grupo: any;
   grafico_grupo_seg: any;
   tempo_medio: any;
   nivel_servico: any;
   opcoes: any;
   org: any;

   resolvido = '#05d605';
   nao_resolvido = '#d41515';

   constructor(
      public _gateway: GatewayService,
      private _clienteS: ClienteService,
      public navigation: NavigationService,

   ) {
      this.atendimento = {};
      this.grafico_operador = {};
      this.grafico_grupo = {};
      this.grafico_grupo_seg = {};
      this.tempo_medio = {};
      this.nivel_servico = {};
      this.org = JSON.parse(localStorage.getItem('kmm_bi-dash|' + this._clienteS.discover() + '-organizacional'));
   }

   ngOnInit() {
      // console.log('datasource', this.datasource);
      // this.getDados().then(() => {});
   }



   ngOnChanges(changes: SimpleChanges): void {
      console.log('changes', changes);

      if (changes.dadosComponente) {
         // this.showLoad = true;
         // this.atendimento = changes.dadosComponente.currentValue.datasource.alertas;
         console.log('atendimento ficou = ', changes.dadosComponente.currentValue.datasource.alertas);

         // this.tempo_medio = dash_alertas.periodo[0].tempo_medio;
         // this.grafico_operador = res.dash_alertas.grafico_operador;
         // this.grafico_grupo_seg = res.dash_alertas.grafico_grupo_seg;
         // this.grafico_grupo = res.dash_alertas.grafico_grupo;
         // this.nivel_servico = res.dash_alertas.nivel_servico;
         // changes.dadosComponente.currentValue.itens.map((item) => {
         //    if (item.opcoes != '') {
         //       item.opcoes = JSON.parse(item.opcoes);
         //    }
         // });
         // const obj = _.findWhere(changes.dadosComponente.currentValue.itens, { indicador: 1 });
         // if (obj) {
         //    if (obj.opcoes !== '') {
         //       if (obj.opcoes.cores && obj.opcoes.cores.resolvido && obj.opcoes.cores.nao_resolvido) {
         //          this.resolvido = obj.opcoes.cores.resolvido;
         //          this.nao_resolvido = obj.opcoes.cores.nao_resolvido;
         //       }
         //    }
         // }
         // this.showLoad = false;
      }
   }


   // async getDados() {
   //    try {
   //       const parametros = {
   //          usuario_bi_id: this.org.usuario.usuarioBiId
   //       };
   //       const res: any = await this._gateway.backendCall('M4002', 'getAlertasDash', parametros);
   //       console.log('response:', res);
   //       this.showLoad = true;
   //       this.atendimento = res.dash_alertas.grafico_al_ab_fechado;
   //       this.tempo_medio = res.dash_alertas.tempo_medio;
   //       this.grafico_operador = res.dash_alertas.grafico_operador;
   //       this.grafico_grupo_seg = res.dash_alertas.grafico_grupo_seg;
   //       this.grafico_grupo = res.dash_alertas.grafico_grupo;
   //       this.nivel_servico = res.dash_alertas.nivel_servico;
   //       this.itens.map((item) => {
   //          if (item.opcoes != '') {
   //             item.opcoes = JSON.parse(item.opcoes);
   //          }
   //       });
   //       const obj = _.findWhere(this.itens, { indicador: 1 });
   //       if (obj) {
   //          if (obj.opcoes !== '') {
   //             if (obj.opcoes.cores && obj.opcoes.cores.resolvido && obj.opcoes.cores.nao_resolvido) {
   //                this.resolvido = obj.opcoes.cores.resolvido;
   //                this.nao_resolvido = obj.opcoes.cores.nao_resolvido;
   //             }
   //          }
   //       }
   //       this.showLoad = false;

   //       // this.navigation.loaderTela = false;

   //    } catch (error) {
   //       console.log(error);
   //    }
   // }

   customizePointGrafico = (pointInfo: any) => {
      if (pointInfo.argument === 'Viagens agendadas') {
         return { color: '#45b854' };
      } else if (pointInfo.argument === 'Solicitação sem Agendamento') {
         return { color: '#fd9a18' };
      } else if (pointInfo.argument === 'Canceladas') {
         return { color: '#ed1c24' };
      } else if (pointInfo.argument === 'Resolvido') {
         return { color: this.resolvido };
      } else if (pointInfo.argument === 'Não Resolvido') {
         return { color: this.nao_resolvido };
      }
   }

   customizeLegend = (arg: any) => {
      if (this.pieChartAlertas) {
         let valor = 0;
         this.pieChartAlertas.dataSource.forEach(element => {
            if (element.tipo === arg.pointName) {
               valor = element.total;
            }
         });

         return arg.pointName + '(' + valor + ')';
      }
   }

   customizeLabelGrafico(arg: any) {
      return arg.percentText;
   }

   getOpcoes(itens) {
      console.log('itens', itens);

      if (itens) {
         itens.forEach(element => {
            if (element.opcoes != '') {
               Object.assign(this.opcoes, {
                  indicador: element.indicador,
                  dados: element.opcoes
               });
            }
         });


      }
   }

   getColor(itens) {
      console.log('entrou no getColor');

      // let color = '';
      // switch (indicador) {
      //    case 1:
      //       const obj = _.findWhere(this.itens, { indicador: 1 });
      //       console.log('encontrou:', obj);

      //       break;

      // }

   }

}
