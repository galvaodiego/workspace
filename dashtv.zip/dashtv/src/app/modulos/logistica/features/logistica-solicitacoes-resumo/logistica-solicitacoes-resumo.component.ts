import { Component, OnInit } from '@angular/core';

import { GatewayService } from 'src/app/shared';
import { formatDate } from 'devextreme/localization';

@Component({
    selector: 'app-logistica-solicitacoes-resumo',
    templateUrl: './logistica-solicitacoes-resumo.component.html',
    styleUrls: ['./logistica-solicitacoes-resumo.component.scss']
})
export class LogisticaSolicitacoesResumoComponent implements OnInit {

    public tabMotivo: string;
    public mensagemErro: string;
    public showConteudo: boolean = false;
    public solicCancCliente: any = [];
    public solicCancMes: any = [];
    public solicDestino: any = [];
    public solicOperacao: any = [];
    public solicOrigem: any = [];
    public solicResumo: any = [];
    public solicModalidade: any = [];
    public dataInicial: Date = new Date();
    public dataFinal: Date = new Date();

    constructor(
        private _gateway: GatewayService
    ) { }

    ngOnInit() {
        this.tabMotivo = 'motivo';
        this.getDados();
    }

 

    async getDados() {
        let date = new Date();
        let firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
        let lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0);

        this.dataInicial = firstDay;
        this.dataFinal = lastDay;
        
        let param = {
            data_inicial: formatDate(firstDay,'dd/MM/yyyy'),
            data_final: formatDate(lastDay,'dd/MM/yyyy'),
        }
        try {
            const response: any = await this._gateway.backendCall('M4002', 'getSolicPeriodo', param);
            this.showConteudo = true;
            this.solicResumo = response.solicitacoes.solic_resumo;
            this.solicModalidade = response.solicitacoes.modalidade_resumo; 
            this.solicCancCliente = response.solicitacoes.solic_canc_cliente;
            this.solicCancMes = response.solicitacoes.solic_canc_mes;
            this.solicOperacao = response.solicitacoes.solic_operacoes;
            this.solicOrigem = response.solicitacoes.solic_origem.slice(0, 9).reverse();
            this.solicDestino = response.solicitacoes.solic_destino.slice(0, 9).reverse();
            console.log('response', response);
        } catch (error) {
            this.mensagemErro = error.detail.message;
            console.log('errou', error);
        }
    }


    customizePointGrafico(pointInfo: any) {
        if (pointInfo.argument == 'Agendadas') {
            return { color: '#45b854' }
        } else if (pointInfo.argument == 'Não Atendidas') {
            return { color: '#fd9a18' }
        } else if (pointInfo.argument == 'Canceladas') {
            return { color: '#ed1c24' }
        }
    };

    customizeLabelGrafico(arg: any) {
        return arg.value + ' (' + arg.percentText + ')';
    }

    async filtroData(){
        let param = {
            data_inicial: formatDate(this.dataInicial,'dd/MM/yyyy'),
            data_final: formatDate(this.dataFinal,'dd/MM/yyyy')
        }
        try {
            const response: any = await this._gateway.backendCall('M4002', 'getSolicPeriodo', param);
            this.showConteudo = true;
            this.solicResumo = response.solicitacoes.solic_resumo;
            this.solicModalidade = response.solicitacoes.modalidade_resumo; 
            this.solicCancCliente = response.solicitacoes.solic_canc_cliente;
            this.solicCancMes = response.solicitacoes.solic_canc_mes;
            this.solicOperacao = response.solicitacoes.solic_operacoes;
            this.solicOrigem = response.solicitacoes.solic_origem.slice(0, 9).reverse();
            this.solicDestino = response.solicitacoes.solic_destino.slice(0, 9).reverse();
            console.log('response', response);

            
        } catch (error) {
            this.mensagemErro = error.detail.message;
            console.log('errou', error);
        }

    }

}
