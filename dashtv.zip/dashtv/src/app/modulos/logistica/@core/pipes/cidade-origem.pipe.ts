import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'logisticaCidadeOrigemPipe',
    pure: false
})
export class CidadeOrigemPipe implements PipeTransform {

    transform(items: any[], field: string, value: string): any[] {
        if (!items)
            return [];
        else if (value.length == 0)
            return items;
        else
            return items.filter(it => value.includes(it.origem));
    }

}
