import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

//Componentes
import { CidadeDestinoComponent } from './filtros/cidade-destino/cidade-destino.component';
import { CidadeOrigemComponent } from './filtros/cidade-origem/cidade-origem.component';
import { ClienteComponent } from './filtros/cliente/cliente.component';

//Pipes
import { CidadeDestinoPipe } from './pipes/cidade-destino.pipe';
import { CidadeOrigemPipe } from './pipes/cidade-origem.pipe';
import { ClientePipe } from './pipes/cliente.pipe';

@NgModule({
    imports: [
        CommonModule
    ],
    declarations: [
        //Filtros Pipe
        CidadeDestinoComponent,
        CidadeOrigemComponent,
        ClienteComponent,

        //Pipes
        CidadeDestinoPipe,
        CidadeOrigemPipe,
        ClientePipe,
    ],
    exports: [
        //Filtros Pipe
        CidadeDestinoComponent,
        CidadeOrigemComponent,
        ClienteComponent,

        //Pipes
        CidadeDestinoPipe,
        CidadeOrigemPipe,
        ClientePipe,
    ],
})
export class CoreModule { }
