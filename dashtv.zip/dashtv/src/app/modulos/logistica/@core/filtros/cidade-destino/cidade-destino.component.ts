import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
    selector: 'logistica-filtro-cidade-destino',
    templateUrl: './cidade-destino.component.html',
    styleUrls: ['./cidade-destino.component.scss']
})
export class CidadeDestinoComponent implements OnInit {

    @Input() lista: Array<any> = [];
    @Output() selected = new EventEmitter();
    private _selecionados = [];

    public clickPipe = new EventEmitter();

    public busca: string = '';

    constructor() { }

    ngOnInit() {
    }

    /**
     *  Getters e setters
     */
    public get selecionados(): Array<any> {
        return this._selecionados;
    }

    public set selecionados(value: Array<any>) {
        this._selecionados = value;
    }

    /**
     *  Adiciona ou remove elementos do array de ids
     *
     *  @param {any} e - recebe o valor do input do html
     *  @param {any} item - recebe o item operado
     */

    public moveToFilterString(e, item: any) {
        if (e.target.checked) {
            this.selecionados.push(item.agrupamento_id);
        } else {
            this.selecionados.splice(this.selecionados.findIndex(el => el == item.agrupamento_id), 1);
        }
        this.selected.emit(this.selecionados);
    }

    public setFilterList(e) {
        let index = this.selecionados.findIndex(el => el === e.target.id);
        if (index != -1) {
            this.selecionados.splice(index, 1);
        } else {
            this.selecionados.push(e.target.id);
        }
        this.selected.emit(this.selecionados);
    }

}
