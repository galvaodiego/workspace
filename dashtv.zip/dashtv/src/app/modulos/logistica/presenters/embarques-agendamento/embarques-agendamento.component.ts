import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { NavigationService, GatewayService, Usuario } from 'src/app/shared';

import SetInterval from 'set-interval';
import { DxDataGridComponent } from 'devextreme-angular';

@Component({
   selector: 'app-embarques-agendamento',
   templateUrl: './embarques-agendamento.component.html',
   styleUrls: ['./embarques-agendamento.component.scss']
})
export class EmbarquesAgendamentoComponent implements OnInit, OnDestroy {
   @ViewChild('gridEmbarques', { static: false }) gridEmbarques: DxDataGridComponent;
   public user: Usuario = Usuario.instance;
   listaCargas = [];
   tabela_index = 0;

   constructor(
      public navigation: NavigationService,
      private _gateway: GatewayService,
   ) {
      this.navigation.loaderTela = true;
      this.navigation.hideTimeBar = false;
      this.navigation.timer_troca_tela = 120000; // importante para funcionar corretamente a troca de tela

      this.user.showIconOpcoes = false;
      this.user.showIconFiltro = false;
      this.user.showFiltroOpcoes = false;
      this.user.showIconTemplates = false;
      this.user.showTemplates = false;
   }

   ngOnInit() {
      SetInterval.start(() => { this.trocaPagina(); }, 10000, 'intervalo_tabelas');
      this.getData().then(() => { this.navigation.trocaDash(); });
   }

   ngOnDestroy() {
      SetInterval.clear('trocaTela');
      SetInterval.clear('intervalo_tabelas');
   }

   async getData() {
      try {
         const response: any = await this._gateway.backendCall('M4002', 'getEmbarquesEstimados');
         console.log('response:', response);
         this.listaCargas = response.operacional.tabela[0].lista;
         this.navigation.loaderTela = false;
      } catch (error) {
         console.log(error);
      }
   }

   onCellPrepared(e) {
      e.cellElement.style.fontSize = '0.8em';
      e.cellElement.style.fontWeight = '700';
      e.cellElement.style.color = '#354052;';
   }

   trocaPagina() {
      if (this.gridEmbarques) {
         const total_pd = this.gridEmbarques.instance.pageCount();
         if (total_pd > 1) {
            if (this.tabela_index === total_pd - 1) {
               this.tabela_index = 0;
            } else {
               this.tabela_index++;
            }
            this.gridEmbarques.instance.pageIndex(this.tabela_index);
         }
      }
   }

}
