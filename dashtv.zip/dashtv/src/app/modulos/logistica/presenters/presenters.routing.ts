import { ModuleWithProviders } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { GuardaRotas } from 'src/app/shared';

// Componentes
import { CargaComponent } from './carga/carga.component';
import { ControleSolicitacoesComponent } from './controle-solicitacoes/controle-solicitacoes.component';
import { DemandaDisponibilidadeComponent } from './demanda-disponibilidade/demanda-disponibilidade.component';
import { DescargaComponent } from './descarga/descarga.component';
import { MetasComponent } from './metas/metas.component';
import { ParqueamentoComponent } from './parqueamento/parqueamento.component';
import { TempoEmissaoComponent } from './tempo-emissao/tempo-emissao.component';
import { TrafegoOcorrenciasComponent } from './trafego-ocorrencias/trafego-ocorrencias.component';
import { TransitTimeComponent } from './transit-time/transit-time.component';
import { TransitTimeV2Component } from './transit-time_v2/transit-time.component';
import { ViagensComponent } from './viagens/viagens.component';
import { DocumentacaoComponent } from './documentacao/documentacao.component';
import { AlertaIndicadoresComponent } from './alerta-indicadores/alerta-indicadores.component';
import { ProdutividadeComponent } from './produtividade/produtividade.component';
import { VelocidadeComponent } from './velocidade/velocidade.component';
import { PerformanceEmpresaComponent } from './performance-empresa/performance-empresa.component';
import { KpiDescargaComponent } from './kpi-descarga/kpi-descarga.component';
import { PreventivasComponent } from './preventivas/preventivas.component';
import { ControleTrafegoComponent } from './controle-trafego/controle-trafego.component';
import { EmbarquesAgendamentoComponent } from './embarques-agendamento/embarques-agendamento.component';
import { OcorrenciasComponent } from './ocorrencias/ocorrencias.component';
import { SolicitacoesComponent } from './solicitacoes/solicitacoes.component';
import { SolicitacoesPendentesComponent } from './solicitacoes-pendentes/solicitacoes-pendentes.component';
import { AcompanhamentoLogisticoComponent } from './acompanhamento-logistico/acompanhamento-logistico.component';
import { AcompanhamentoDescargaComponent } from './acompanhamento-descarga/acompanhamento-descarga.component';
import { DisponibilidadeMotoristasComponent } from './disponibilidade-motoristas/disponibilidade-motoristas.component';
import { FluxoLogisticoComponent } from './fluxo-logistico/fluxo-logistico.component';
import { RastreamentoColetaComponent } from './rastreamento-coleta/rastreamento-coleta.component';
import { AcompanhamentoOcorrenciasComponent } from './acompanhamento-ocorrencias/acompanhamento-ocorrencias.component';
import { NivelServicoComponent } from './nivel-servico/nivel-servico.component';
import { AutomatizacaoComponent } from './automatizacao/automatizacao.component';
import { Cargav2Component } from './cargav2/cargav2.component';
import { Descargav2Component } from './descargav2/descargav2.component';
const modulo = 'logistica';
const PRESENTERS_ROUTES: Routes = [
   {
      path: 'carga',
      canActivate: [GuardaRotas],
      component: CargaComponent,
      data: { modulo }
   },
   {
      path: 'cargav2',
      canActivate: [GuardaRotas],
      component: Cargav2Component,
      data: { modulo }
   },
   {
      path: 'controle-solicitacoes',
      canActivate: [GuardaRotas],
      component: ControleSolicitacoesComponent,
      data: { modulo }
   },
   {
      path: 'demanda',
      canActivate: [GuardaRotas],
      component: DemandaDisponibilidadeComponent,
      data: { modulo }
   },
   {
      path: 'alerta',
      canActivate: [GuardaRotas],
      component: AlertaIndicadoresComponent,
      data: { modulo }
   },
   {
      path: 'descarga',
      canActivate: [GuardaRotas],
      component: DescargaComponent,
      data: { modulo }
   },
   {
      path: 'descargav2',
      canActivate: [GuardaRotas],
      component: Descargav2Component,
      data: { modulo }
   },
   {
      path: 'metas',
      canActivate: [GuardaRotas],
      component: MetasComponent,
      data: { modulo }
   },
   {
      path: 'parqueamento',
      canActivate: [GuardaRotas],
      component: ParqueamentoComponent,
      data: { modulo }
   },
   {
      path: 'documentacao',
      canActivate: [GuardaRotas],
      component: DocumentacaoComponent,
      data: { modulo }
   },
   {
      path: 'trafego-ocorrencia',
      canActivate: [GuardaRotas],
      component: TrafegoOcorrenciasComponent,
      data: { modulo }
   },
   {
      path: 'tempo-emissao',
      canActivate: [GuardaRotas],
      component: TempoEmissaoComponent,
      data: { modulo }
   },
   {
      path: 'transit-time',
      canActivate: [GuardaRotas],
      component: TransitTimeComponent,
      data: { modulo }
   },
   {
      path: 'transit-timev2',
      canActivate: [GuardaRotas],
      component: TransitTimeV2Component,
      data: { modulo }
   },
   {
      path: 'viagens',
      canActivate: [GuardaRotas],
      component: ViagensComponent,
      data: {
         dashboard: 'viagens',
         modulo,
         versao: 1

      }
   },
   {
      path: 'viagens_v2',
      canActivate: [GuardaRotas],
      component: ViagensComponent,
      data: {
         dashboard: 'viagens',
         modulo,
         versao: 2
      }
   },
   {
      path: 'produtividade',
      canActivate: [GuardaRotas],
      component: ProdutividadeComponent,
      data: {
         tipo: 1,
         modulo
      }
   },
   {
      path: 'produtividade-empresa',
      canActivate: [GuardaRotas],
      component: ProdutividadeComponent,
      data: {
         tipo: 2,
         modulo
      }
   },
   {
      path: 'produtividade-periodo',
      canActivate: [GuardaRotas],
      component: ProdutividadeComponent,
      data: {
         tipo: 3,
         modulo
      }
   },
   {
      path: 'velocidade',
      canActivate: [GuardaRotas],
      component: VelocidadeComponent,
      data: { modulo }
   },
   {
      path: 'performance-empresa',
      canActivate: [GuardaRotas],
      component: PerformanceEmpresaComponent,
      data: { modulo }
   },
   {
      path: 'kpi-descarga',
      canActivate: [GuardaRotas],
      component: KpiDescargaComponent,
      data: { modulo }
   },
   {
      path: 'preventivas',
      canActivate: [GuardaRotas],
      component: PreventivasComponent,
      data: {
         modulo,
         versao: 1
      }
   },
   {
      path: 'preventivas_v2',
      canActivate: [GuardaRotas],
      component: PreventivasComponent,
      data: {
         modulo,
         versao: 2
      }
   },
   {
      path: 'controle-trafego',
      canActivate: [GuardaRotas],
      component: ControleTrafegoComponent,
      data: { modulo }
   },
   {
      path: 'embarques-agendamentos',
      canActivate: [GuardaRotas],
      component: EmbarquesAgendamentoComponent,
      data: { modulo }
   },
   {
      path: 'ocorrencias',
      canActivate: [GuardaRotas],
      component: OcorrenciasComponent,
      data: { modulo }
   },
   {
      path: 'solicitacoes',
      canActivate: [GuardaRotas],
      component: SolicitacoesComponent,
      data: { modulo }
   },
   {
      path: 'central-de-carga', // foi alterado o nome do antigo dash de solicitações
      canActivate: [GuardaRotas],
      component: SolicitacoesComponent,
      data: { modulo }
   },
   {
      path: 'solicitacoes-pendentes',
      canActivate: [GuardaRotas],
      component: SolicitacoesPendentesComponent,
      data: { modulo }
   },
   {
      path: 'acompanhamento-logistico',
      canActivate: [GuardaRotas],
      component: AcompanhamentoLogisticoComponent,
      data: { modulo }
   },
   {
      path: 'acompanhamento-descarga',
      canActivate: [GuardaRotas],
      component: AcompanhamentoDescargaComponent,
      data: { modulo }
   },
   {
      path: 'disponibilidade-motoristas',
      canActivate: [GuardaRotas],
      component: DisponibilidadeMotoristasComponent,
      data: { modulo }
   },
   {
      path: 'fluxo-logistico',
      canActivate: [GuardaRotas],
      component: FluxoLogisticoComponent,
      data: { modulo }
   },
   {
      path: 'rastreamento-coleta',
      canActivate: [GuardaRotas],
      component: RastreamentoColetaComponent,
      data: { modulo }
   },
   {
      path: 'acompanhamento-ocorrencias',
      canActivate: [GuardaRotas],
      component: AcompanhamentoOcorrenciasComponent,
      data: { modulo }
   },
   {
      path: 'nivel-servico',
      canActivate: [GuardaRotas],
      component: NivelServicoComponent,
      data: { modulo }
   },
   {
      path: 'automatizacao',
      canActivate: [GuardaRotas],
      component: AutomatizacaoComponent,
      data: { modulo }
   },
];

export const PresentersRouting: ModuleWithProviders = RouterModule.forChild(PRESENTERS_ROUTES);
