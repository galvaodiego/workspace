import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { Usuario, NavigationService, GatewayService } from 'src/app/shared';
import { DxDataGridComponent } from 'devextreme-angular';
import SetInterval from 'set-interval';

@Component({
   selector: 'app-kpi-descarga',
   templateUrl: './kpi-descarga.component.html',
   styleUrls: ['./kpi-descarga.component.scss']
})
export class KpiDescargaComponent implements OnInit, OnDestroy {
   @ViewChild('tabela', { static: false }) tabela: DxDataGridComponent;
   @ViewChild('tabela2', { static: false }) tabela2: DxDataGridComponent;
   public user: Usuario = Usuario.instance;
   atrasados: Array<any>;
   regular: Array<any>;
   porCoordenador: Array<any>;
   indicadores = {};
   tabela_index = 0;
   tabela2_index = 0;
   corAtraso = '#db0404';
   inter_tabelas: any;
   constructor(
      public navigation: NavigationService,
      private _gateway: GatewayService,
   ) {
      this.navigation.loaderTela = true;
      this.navigation.hideTimeBar = false;
      this.navigation.timer_troca_tela = 60000; // importante para funcionar corretamente a troca de tela

      this.user.showIconOpcoes = false;
      this.user.showIconFiltro = false;
      this.user.showFiltroOpcoes = false;
      this.user.showIconTemplates = false;
      this.user.showTemplates = false;
   }

   ngOnInit() {
      SetInterval.start(() => { this.trocaPagina(); }, 5000, 'intervalo_tabelas');
      this.getData().then(() => { this.navigation.trocaDash(); });
   }

   ngOnDestroy() {
      SetInterval.clear('trocaTela');
      SetInterval.clear('intervalo_tabelas');
   }

   async getData() {
      try {
         const response: any = await this._gateway.backendCall('M4002', 'getKpiDescarga');
         console.log('response:', response);
         this.atrasados = response.descarga.lista.filter(v => {
            return v.flag === 1;
         });
         this.regular = response.descarga.lista.filter(v => {
            return v.flag === 0;
         });
         this.indicadores = response.descarga.indicadores[0];
         this.porCoordenador = response.descarga.agendamento_x_coordenador;
         this.navigation.loaderTela = false;
      } catch (error) {
         console.log(error);
      }
   }

   atraso(e: any) {
      if (e.rowType === 'header') {
         e.cellElement.style.paddingTop = '5px';
         e.cellElement.style.paddingBottom = '5px';
         e.cellElement.style.fontSize = '1rem';
      }

      if (typeof (e.data) !== 'undefined') {
         e.cellElement.style.color = this.corAtraso;
         e.cellElement.style.fontWeight = 'bold';
         e.cellElement.style.fontSize = '24px';

      }

   }

   s_atraso(e: any) {
      if (e.rowType === 'header') {
         e.cellElement.style.paddingTop = '5px';
         e.cellElement.style.paddingBottom = '5px';
         e.cellElement.style.fontSize = '1rem';
      }

      if (typeof (e.data) !== 'undefined') {
         e.cellElement.style.fontSize = '24px';
      }

   }

   trocaPagina() {
      if (this.tabela) {
         const total_pd = this.tabela.instance.pageCount();
         if (total_pd > 1) {
            if (this.tabela_index === total_pd - 1) {
               this.tabela_index = 0;
            } else {
               this.tabela_index++;
            }
            this.tabela.instance.pageIndex(this.tabela_index);
         }
      }

      if (this.tabela2) {
         const total_pd = this.tabela2.instance.pageCount();
         if (total_pd > 1) {
            if (this.tabela2_index === total_pd - 1) {
               this.tabela2_index = 0;
            } else {
               this.tabela2_index++;
            }
            this.tabela2.instance.pageIndex(this.tabela2_index);
         }
      }

   }
}
