import { Component, OnInit, OnDestroy } from '@angular/core';
import io from 'socket.io-client';
import { environment } from 'src/environments/environment';
import { Usuario, NavigationService, ClienteService } from 'src/app/shared';
import { NotificacaoService } from 'src/app/shared/services/common/notificacao.service';
import SetInterval from 'set-interval';
import * as _ from 'underscore';
import 'moment/locale/pt-br';
@Component({
   selector: 'app-acompanhamento-logistico',
   templateUrl: './acompanhamento-logistico.component.html',
   styleUrls: ['./acompanhamento-logistico.component.scss']
})
export class AcompanhamentoLogisticoComponent implements OnInit, OnDestroy {
   public user: Usuario = Usuario.instance;
   // Config Socket
   socket_io: any;
   socket_rota = 'meta';
   socket_metodo = 'getMeta';
   socket_filtro: any;
   /***/
   visualizacao: any;
   loadingVisible = false;
   default = 'faturamento';
   vf = 'TOTAL_DOCUMENTO';
   tipo = 'FATURAMENTO (R$)';

   // dados
   datasource: any = [];
   dstipoFrete: any = [];
   dsFatFilial: any = [];
   dsFatCliente: any = [];
   dsFatGrupo: any = [];


   data_base = '';
   meta_faturamento = 50;
   meta_tonelagem = 50;
   kpi = {
      faturamento: 0,
      tonelagem: 0,
      freteMedio: 0
   };
   // dados-fim


   showLabel = false;
   showLegend = true;

   constructor(
      public navigation: NavigationService,
      private _clienteS: ClienteService,
   ) {
      this.navigation.loaderTela = true;
      this.navigation.hideTimeBar = false;
      this.navigation.timer_troca_tela = 120000; // importante para funcionar corretamente a troca de tela

      this.user.showIconOpcoes = false;
      this.user.showIconFiltro = false;
      this.user.showFiltroOpcoes = false;
      this.user.showIconTemplates = false;
      this.user.showTemplates = false;

      this.visualizacao = 'Mensal';

      this.socket_io = io(environment.socket_end_point + '/' + this.socket_rota);
      this.socket_filtro = {
         base: (this._clienteS.clienteAtivo !== 'KMM' ? this._clienteS.clienteAtivo : environment.end_point_base_dev).toLowerCase(),
         periodo: this.visualizacao.toLowerCase()
      };


      const origem = JSON.parse(localStorage.getItem('acomp-logistico-origem'));
      if (origem) {
         this.default = origem.default;
         this.vf = origem.vf;
         this.tipo = origem.tipo;
      }

      SetInterval.start(() => {
         let o = this.default;
         if (o === 'faturamento') {
            o = 'tonelagem';
         } else {
            o = 'faturamento';
         }

         this.setOrigem(o);
         this.alterna();
      }, 15000, 'trocaOrigem');
   }

   ngOnInit() {
      this.socket().then(() => {
         this.navigation.trocaDash();
         this.navigation.loaderTela = false;
      });
   }

   ngOnDestroy(): void {
      this.socket_io.disconnect();
      SetInterval.clear('trocaTela');
      SetInterval.clear('trocaOrigem');
   }

   async socket() {
      try {
         this.loadingVisible = true;
         this.socket_io.emit(this.socket_metodo, this.socket_filtro);
         this.socket_io.on(this.socket_rota, (data) => {
            console.log('data', data, this.socket_filtro);
            data.realizado_mensal.map(e => {
               e.TOTAL_PESO = e.TOTAL_PESO / 1000;
               e.DIM_META = e.DIM_META.substring(0, e.DIM_META.length - 5);
            });

            data.realizado_mensal = _.sortBy(data.realizado_mensal, 'DATA_BASE');

            this.datasource = data.realizado_mensal;
            this.meta_faturamento = data.meta_faturamento.valor;
            this.meta_tonelagem = data.meta_tonelagem.valor;
            this.data_base = data.totalizador.data_base;
            this.kpi.faturamento = data.totalizador.total_faturamento;
            this.kpi.tonelagem = data.totalizador.total_ton;
            this.kpi.freteMedio = data.totalizador.media_frete_dia;
            this.dsFatCliente = data.fat_cliente;
            this.dsFatFilial = data.fat_filial;
            this.dstipoFrete = data.fat_frete;
            this.dsFatGrupo = data.fat_grupo;
            this.loadingVisible = false;
         });
      } catch (error) {
         console.log('error => ', error);
      }
   }

   setOrigem(origem) {
      if (origem === 'tonelagem') {
         this.vf = 'TOTAL_PESO';
         this.tipo = 'TONELAGEM (TON)';
         this.default = 'tonelagem';
      } else {
         this.vf = 'TOTAL_DOCUMENTO';
         this.tipo = 'FATURAMENTO (R$)';
         this.default = 'faturamento';
      }

      const obj = {
         default: this.default, vf: this.vf, tipo: this.tipo
      };

      localStorage.setItem('acomp-logistico-origem', JSON.stringify(obj));
   }




   customizeTextLabel(arg) {
      return 'R$ ' + arg.valueText + ' (' + arg.percentText + ')';
   }

   customizeLegend1 = (arg: any) => {
      const o = this.dsFatFilial.filter(e => {
         return e.filial === arg.pointName;
      });
      return o[0].filial + ': R$ ' + o[0].total.toLocaleString('pt-BR');
   }

   customizeLegend2 = (arg: any) => {
      const o = this.dstipoFrete.filter(e => {
         return e.tipo_frete === arg.pointName;
      });
      return o[0].tipo_frete + ': R$ ' + o[0].total.toLocaleString('pt-BR');
   }

   thousands_separators(num) {
      const num_parts = num.toString().split('.');
      num_parts[0] = num_parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, '.');
      return num_parts.join('.');
   }


   alterna() {
      this.showLabel = !this.showLabel;
      this.showLegend = !this.showLegend;
   }


   public onCellPrepared(e: any) {
      if (e.rowType === 'header') {
         e.cellElement.style.paddingTop = '5px';
         e.cellElement.style.paddingBottom = '5px';
         e.cellElement.style.fontSize = '1rem';
      }

      if (typeof (e.data) !== 'undefined') {
         e.cellElement.style.paddingTop = '5px';
         e.cellElement.style.paddingBottom = '5px';
         e.cellElement.style.fontSize = '1rem';
      }

   }




}
