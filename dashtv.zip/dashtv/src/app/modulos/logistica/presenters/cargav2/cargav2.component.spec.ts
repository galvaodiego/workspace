import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Cargav2Component } from './cargav2.component';

describe('Cargav2Component', () => {
  let component: Cargav2Component;
  let fixture: ComponentFixture<Cargav2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Cargav2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Cargav2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
