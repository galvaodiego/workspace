import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { Usuario, NavigationService, EstruturaOrganizacionalService, GatewayService } from 'src/app/shared';
import notify from 'devextreme/ui/notify';
import { DxDataGridComponent } from 'devextreme-angular';
import SetInterval from 'set-interval';


@Component({
   selector: 'app-velocidade',
   templateUrl: './velocidade.component.html',
   styleUrls: ['./velocidade.component.scss']
})
export class VelocidadeComponent implements OnInit, OnDestroy {
   @ViewChild('gridOutros', { static: false }) gridOutros: DxDataGridComponent;
   @ViewChild('gridViagem', { static: false }) gridViagem: DxDataGridComponent;
   @ViewChild('gridAlerta', { static: false }) gridAlerta: DxDataGridComponent;

   public user: Usuario = Usuario.instance;
   datasource: any;
   percent_outros: number;
   percent_em_viagem: number;
   percent_em_viagem_alerta: number;

   index_outros: number;
   index_viagem: number;
   index_alerta: number;

   constructor(
      public navigation: NavigationService,
      public orgS: EstruturaOrganizacionalService,
      private _gateway: GatewayService,
   ) {
      this.navigation.loaderTela = true;
      this.navigation.hideTimeBar = false;
      this.navigation.timer_troca_tela = 30000; // importante para funcionar corretamente a troca de tela

      this.user.showIconOpcoes = false;
      this.datasource = {
         em_viagem: [],
         em_viagem_alerta: [],
         outros: []
      };
      this.index_outros = 0;
      this.index_viagem = 0;
      this.index_alerta = 0;

   }

   ngOnInit() {
      SetInterval.start(() => {
         this.trocaPagina();
      }, 5000, 'intervalo_tabelas');

      this.getData().then(() => { this.navigation.trocaDash(); });
   }

   ngOnDestroy(): void {
      SetInterval.clear('trocaTela');
      SetInterval.clear('intervalo_tabelas');
   }


   trocaPagina() {
      // GridOutros
      const total_outros = this.gridOutros.instance.pageCount();
      if (total_outros > 1) {
         if (this.index_outros == total_outros - 1) {
            this.index_outros = 0;
         } else {
            this.index_outros++;
         }
         this.gridOutros.instance.pageIndex(this.index_outros);
         // console.log('Outros...', total_outros, this.index_outros);
      }


      // GridViagem
      const total_viagem = this.gridViagem.instance.pageCount();
      if (total_viagem > 1) {
         if (this.index_viagem == total_viagem - 1) {
            this.index_viagem = 0;
         } else {
            this.index_viagem++;
         }
         this.gridViagem.instance.pageIndex(this.index_viagem);
         // console.log('Viagem...', total_viagem, this.index_viagem);
      }

      // GridAlerta
      const total_alerta = this.gridAlerta.instance.pageCount();
      if (total_alerta > 1) {
         if (this.index_alerta == total_alerta - 1) {
            this.index_alerta = 0;
         } else {
            this.index_alerta++;
         }
         this.gridAlerta.instance.pageIndex(this.index_alerta);
         // console.log('Alerta...', total_alerta, this.index_viagem);
      }

   }

   async getData() {
      try {
         const response: any = await this._gateway.backendCall('M4002', 'getVelocidadeDash');
         console.log('response:', response);
         this.datasource = response.alerta_velocidade;

         const total = this.datasource.outros.length + this.datasource.em_viagem.length + this.datasource.em_viagem_alerta.length;
         this.percent_outros = this.datasource.outros.length * 100 / total;
         this.percent_em_viagem = this.datasource.em_viagem.length * 100 / total;
         this.percent_em_viagem_alerta = this.datasource.em_viagem_alerta.length * 100 / total;

         this.navigation.loaderTela = false;
      } catch (error) {
         console.log(error);
      }
   }

   getImage(id) {
      let path = '';
      switch (id) {
         case 1: // Vazio
            path = 'status-icon fas fa-truck vazio';
            break;
         case 2: // Destinado
            path = 'status-icon fas fa-road destinado';
            break;
         case 3: // Carga
            path = 'status-icon fas fa-truck-loading carga';
            break;
         case 4: // Em viagem
            path = 'status-icon fas fa-truck-moving em-viagem';
            break;
         case 5: // Descarga
            path = 'status-icon fas fa-truck-loading descarga';
            break;
      }

      return path;
   }

   calculateCellValue(rowData) {
      // console.log('rowdata', rowData);
      return '<span class="nome_motorista">' + rowData.motorista + '</span><br><span class="referencia">' + rowData.referencia + '</span>';
      // ...
      // let column = this as any;
      // return column.defaultCalculateCellValue(rowData);

   }

}
