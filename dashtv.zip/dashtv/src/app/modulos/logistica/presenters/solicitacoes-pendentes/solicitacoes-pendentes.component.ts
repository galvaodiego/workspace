import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { Usuario, NavigationService, GatewayService } from 'src/app/shared';
import { DxDataGridComponent } from 'devextreme-angular';

import SetInterval from 'set-interval';


@Component({
   selector: 'app-solicitacoes-pendentes',
   templateUrl: './solicitacoes-pendentes.component.html',
   styleUrls: ['./solicitacoes-pendentes.component.scss']
})
export class SolicitacoesPendentesComponent implements OnInit, OnDestroy {
   @ViewChild('tabela', { static: false }) tabela: DxDataGridComponent;
   public user: Usuario = Usuario.instance;
   index_tabela = 0;
   loadingVisible = false;
   datasource = [];

   constructor(
      public navigation: NavigationService,
      private _gateway: GatewayService
   ) {
      this.navigation.loaderTela = true;
      this.navigation.hideTimeBar = false;
      this.navigation.timer_troca_tela = 90000; // importante para funcionar corretamente a troca de tela

      this.user.showIconOpcoes = false;
      this.user.showIconFiltro = false;
      this.user.showFiltroOpcoes = false;
      this.user.showIconTemplates = false;
      this.user.showTemplates = false;

   }

   ngOnInit() {
      this.getData().then(() => { this.navigation.trocaDash(); });

      SetInterval.start(() => {
         this.trocaPagina();
      }, 10000, 'intervalo_tabelas');

   }

   ngOnDestroy(): void {
      SetInterval.clear('trocaTela');
      SetInterval.clear('intervalo_tabelas');
   }

   async getData() {
      try {
         this.loadingVisible = true;
         const response: any = await this._gateway.backendCall('M4002', 'getSolicitacoes');
         console.log('response:', response);
         this.datasource = response.Solicitacoes;
         this.loadingVisible = false;
         this.navigation.loaderTela = false;
      } catch (error) {
         console.log(error);
      }
   }

   onCellPrepared(e) {
      if (e.rowType === 'header') {
         e.cellElement.style.paddingTop = '5px';
         e.cellElement.style.paddingBottom = '5px';
         e.cellElement.style.fontSize = '1rem';
         e.cellElement.style.fontWeight = 'bold';

      }

      if (typeof (e.data) !== 'undefined') {
         if (e.data.flag === 1) {
            e.cellElement.style.color = 'red';
            e.cellElement.style.fontWeight = 'bold';
         }
      }
   }

   trocaPagina() {
      // tabela
      if (this.tabela) {
         const total_pd = this.tabela.instance.pageCount();
         if (total_pd > 1) {
            if (this.index_tabela === total_pd - 1) {
               this.index_tabela = 0;
            } else {
               this.index_tabela++;
            }
            this.tabela.instance.pageIndex(this.index_tabela);
         }
      }


   }

}
