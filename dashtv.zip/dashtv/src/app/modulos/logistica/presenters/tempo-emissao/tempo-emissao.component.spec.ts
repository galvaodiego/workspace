import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TempoEmissaoComponent } from './tempo-emissao.component';

describe('TempoEmissaoComponent', () => {
  let component: TempoEmissaoComponent;
  let fixture: ComponentFixture<TempoEmissaoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TempoEmissaoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TempoEmissaoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
