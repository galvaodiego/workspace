import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';

import { DxSelectBoxComponent } from 'devextreme-angular';

import { Usuario, NavigationService, UsuarioService, GatewayService } from 'src/app/shared';
import SetInterval from 'set-interval';

@Component({
   selector: 'app-tempo-emissao',
   templateUrl: './tempo-emissao.component.html',
   styleUrls: ['./tempo-emissao.component.scss']
})
export class TempoEmissaoComponent implements OnInit, OnDestroy {

   @ViewChild("selectBox", { static: false }) selectBox: DxSelectBoxComponent

   public user: Usuario = Usuario.instance;

   public listaUnidadesMirror: Array<any> = [];
   public listaUnidades: Array<any> = [];
   public listaEmpresa: Array<any> = [];

   public interval: any;

   //Tabs Control
   public tabs: any = [];
   public cards: any = [];
   public initialCard: number = 0;
   public finalCard: number = 6;

   public visoes: any = [];

   public selectTipo: string;
   public selectUnidade: string;

   constructor(
      public navigation: NavigationService,
      private _gateway: GatewayService,
      public userProvider: UsuarioService,
   ) {
      this.user.showIconOpcoes = true;
      this.navigation.loaderTela = true;
      this.navigation.timer_troca_tela = 120000; // importante para funcionar corretamente a troca de tela

      this.visoes = [
         {
            "visao": "unidade",
            "descricao": "Visão Por Unidade"
         },
         {
            "visao": "empresa",
            "descricao": "Visão Geral Empresa"
         }
      ]
      if (this.getFilters(this.user.selectedDashboard).length > 0) {
         this.getFilters(this.user.selectedDashboard);
      } else {
         let parameter = [{
            "tipo": "",
            "unidade": ""
         }]
         this.setFilters(this.user.selectedDashboard, parameter);
      }
   }

   ngOnInit() {
      this.getEmpresa().then(() => { this.navigation.trocaDash(); });
      this.switchTabs();
   }

   ngOnDestroy() {
      SetInterval.clear('trocaTela');
      clearInterval(this.interval);
   }

   /**
    * Resgata os Dados da Empresa
    */
   async getEmpresa() {
      try {
         this.getUnidades();
         const response: any = await this._gateway.backendCall('M4002', 'getTempoEmpresa');
         this.listaEmpresa = response.location;
      } catch (error) {
         console.log(error)
      }
   }

   /**
    * Resgata os Dados por Unidade
    */
   public async getUnidades(tipo?): Promise<any> {
      let item = '';

      if (typeof (this.selectBox) != 'undefined') {
         item = this.selectBox.value;
      }

      let parametrosBd = { visao: item.toUpperCase() }

      try {
         const response: any = await this._gateway.backendCall('M4002', 'getLotesUnidades');
         this.listaUnidadesMirror = response.location;
         this.navigation.loaderTela = false;
         this.feedTabs();
      } catch (error) {
         console.log(error)
      }

   }

   public customizeText(arg: any) {
      return arg.valueText + " h";
   }


   /**
    * Seleciona o Tipo de Visualização
    * @param item tipo :: ontem, hoje, 48 horas 
    */
   public selecionaTipo(item: string) {
      this.selectTipo = item;
      this.feedTabs();
   }

   /**
    * Seleciona o Tipo de Visualização
    * @param item tipo :: ontem, hoje, 48 horas 
    */
   public selecionaUnidade(item: string) {
      this.selectUnidade = item;
      this.feedTabs();
   }


   /**
    * Limpa Os filtros e Retorna os Dados Originais 
    */
   public limpaFiltros() {
      this.selectTipo = '';
      this.selectUnidade = '';
      this.feedTabs();
   }


   /////////////////////////////////////////////
   //             TABS DINAMICAS              //
   /////////////////////////////////////////////

   /***
    * FUNÇÃO QUE ALIMENTA AS TABS DINÂMICAMENTE
    */
   public feedTabs() {
      this.tabs = [];
      this.listaUnidades = [];

      ////////////
      // FILTROS
      ///////////
      if (this.selectTipo == '' && this.selectUnidade == '') {
         this.listaUnidades = this.listaUnidadesMirror;
      } else if (this.selectTipo == '' && this.selectUnidade != '') {
         this.listaUnidades = this.listaUnidadesMirror.filter((el) => { return el.unidade.toLowerCase() == this.selectUnidade.toLowerCase() });
      } else if (this.selectTipo != '' && this.selectUnidade == '') {
         this.listaUnidades = this.listaUnidadesMirror.filter((el) => { return el.tipo.toLowerCase() == this.selectTipo.toLowerCase() });
      } else {
         this.listaUnidades = this.listaUnidadesMirror.filter((el) => { return el.unidade.toLowerCase() == this.selectUnidade.toLowerCase() && el.tipo.toLowerCase() == this.selectTipo.toLowerCase() });
      }

      let parameter = [{
         "tipo": this.selectTipo,
         "unidade": this.selectUnidade
      }]
      this.setFilters(this.user.selectedDashboard, parameter);


      let countTabs = 1;
      for (let i = 0; i < this.listaUnidades.length / 6; i++) {
         this.tabs.push(
            {
               tabId: countTabs,
               tabName: 'tab[' + countTabs + ']',
               active: false
            }
         );
         countTabs++;
      }
      this.tabs[0].active = true;

   }

	/**
 	* FUNÇÃO QUE CONTROLA O FUNCIONAMENTO DAS TABS DE CORDENADORES
	* @param tabId 
	*/
   private manageTabs(tabId: number) {
      for (let i = 0; i < this.tabs.length; i++) {
         if (tabId === this.tabs[i].tabId) {
            this.tabs[i].active = true;
         } else {
            this.tabs[i].active = false;
         }
      }
   }

	/**
 	* REALIZA A ALTERNÂNCIA ENTRE AS TABS
	*/
   private switchTabs() {
      let i = 0;
      this.interval = setInterval(
         tabs => {
            i++;
            if (i > this.tabs.length) {
               i = 1;
               this.initialCard = 0;
               this.finalCard = 6;
            }
            if (i >= 2) {
               this.initialCard += 6;
               this.finalCard += 6;
            }
            this.manageTabs(i);
         }, 30000);
   }

   /**
    *  Salva o filtro do painel na sessão.
    * @param {number} id - Id do dash que contém o filtro
    * @param {Array<any>} parameters - Parâmetros do filtro
    */

   public setFilters(id: number, parameters: Array<any>) {
      this.user.listaDashboards[this.user.listaDashboards.findIndex(element => element.dash_id == id)].filters = parameters;
      this.userProvider.save();
   }

	/**
	 *  Resgata o filtro do painel da sessão.
	 * @param {number} id - ID do dash que contém o filtro
	 */
   public getFilters(id: number) {
      let filters = this.user.listaDashboards[this.user.listaDashboards.findIndex(element => element.dash_id == id)].filters;
      if (filters.length > 0) {
         this.selectTipo = filters[0].tipo;
         this.selectUnidade = filters[0].unidade
      }
      return filters;
   }


}
