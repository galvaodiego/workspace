import { Component, OnInit, OnDestroy } from '@angular/core';
import { NavigationService, GatewayService } from 'src/app/shared';

@Component({
    selector: 'app-trafego-ocorrencias',
    templateUrl: './trafego-ocorrencias.component.html',
    styleUrls: ['./trafego-ocorrencias.component.scss']
})
export class TrafegoOcorrenciasComponent implements OnInit, OnDestroy {

    public listaMarcadores: any = [];
    public listaOcorrencia: any = [];
    public ocorrenciaOperador: any = [];
    public ocorrenciaOperacao: any = [];

    constructor(
        public navigation: NavigationService,
        private _gateway: GatewayService
    ) { }

    ngOnInit() {
        this.listaMarcadores = [
            {
                lat: -25.5076462,
                lng: -49.3326878
            }
        ];

        this.ocorrenciaOperacao = [
            {
                "descricao": "BENS PR",
                "valor": 5
            },
            {
                "descricao": "H MALTOSE",
                "valor": 4
            },
            {
                "descricao": "GERAL",
                "valor": 4
            },
            {
                "descricao": "CAULIM",
                "valor": 2
            },
            {
                "descricao": "DURATEX SP",
                "valor": 1
            },
        ];

        this.ocorrenciaOperador = [
            {
                "descricao": "Marcos Almeida",
                "valor": 4
            },
            {
                "descricao": "José Antônio",
                "valor": 2
            },
            {
                "descricao": "Vilmar Cezar",
                "valor": 2
            },
            {
                "descricao": "Fernando Aurélio",
                "valor": 1
            },
            {
                "descricao": "Daniel Ferreira",
                "valor": 1
            },
        ];

        this.listaOcorrencia = [
            {
                "descricao": "Por Operador",
                "valor": 30,
            },
            {
                "descricao": "Por Operação",
                "valor": 4,
            }
        ]
    }

    ngOnDestroy() { }


    /**
     * Resgata os Dados
     */
    async getDados() {
        try {
            const response: any = await this._gateway.backendCall('M4002', 'getTrafegoOcorrencia');
            console.log(response)
        } catch (error) {
            console.log(error)
        }
    }

    /**
     * Customiza o Valor do Label
     * @param arg argumentos do Evento
     */
    customizeLabel(arg: any) {
        return arg.valueText + " (" + arg.percentText + ")";
    }

    customizePoint(pointInfo: any) {
        console.log('point', pointInfo);
        if (pointInfo.argument == 'Por Operador') {
            return { color: '#589fd7' }
        } else if (pointInfo.argument == 'Por Operação') {
            return { color: '#f37d37' }
        }
    };

}
