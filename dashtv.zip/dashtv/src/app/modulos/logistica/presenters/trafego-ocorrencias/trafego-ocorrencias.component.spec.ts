import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TrafegoOcorrenciasComponent } from './trafego-ocorrencias.component';

describe('TrafegoOcorrenciasComponent', () => {
  let component: TrafegoOcorrenciasComponent;
  let fixture: ComponentFixture<TrafegoOcorrenciasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TrafegoOcorrenciasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TrafegoOcorrenciasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
