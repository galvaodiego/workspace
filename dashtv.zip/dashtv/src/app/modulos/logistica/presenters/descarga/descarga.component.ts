import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { NavigationService, Usuario, UsuarioService, GatewayService, EstruturaOrganizacionalService, ClienteService } from 'src/app/shared';

import io from 'socket.io-client';
import { environment } from 'src/environments/environment';

// Plugins
import * as _ from 'underscore';
import { DxDataGridComponent, DxPopupComponent } from 'devextreme-angular';
import notify from 'devextreme/ui/notify';
import SetInterval from 'set-interval';



@Component({
   selector: 'app-feature-logistica-descarga',
   templateUrl: './descarga.component.html',
   styleUrls: ['./descarga.component.scss']
})
export class DescargaComponent implements OnInit, OnDestroy {
   @ViewChild('previsaoDescargaGrid', { static: false }) previsaoDescargaGrid: DxDataGridComponent;
   @ViewChild('tempoDescargaGrid', { static: false }) tempoDescargaGrid: DxDataGridComponent;
   @ViewChild('popFiltro', { static: false }) popFiltro: DxPopupComponent;


   public user: Usuario = Usuario.instance;

   public tipoData: string;
   public listaTempoDescarga: Array<any> = [];
   public listaPrevisaoDescarga: Array<any> = [];

   public indicador: any = {
      viajando: 0,
      previsto: 0,
      atrasado: 0,
      descarga: 0
   };


   index_pd: number;
   index_td: number;

   tolerancia = 5;
   tipo_tolerancia_opcoes = ['Minutos', 'Horas'];
   tipo_tolerancia = 'Horas';
   base_calculo = this.tolerancia;
   tempo = 300;
   fonte_grid = 14;
   controle_tempo_tela: number;
   controle_tempo_tabela: number;
   org: any;
   // Config Socket
   socket_io: any;
   socket_rota = 'descarga';
   socket_metodo = 'getDescarga';
   socket_filtro: any;
   /***/
   constructor(
      public navigation: NavigationService,
      public UsuarioService: UsuarioService,
      public orgS: EstruturaOrganizacionalService,
      private _gateway: GatewayService,
      public clienteS: ClienteService
   ) {
      this.navigation.loaderTela = true;
      this.navigation.timer_troca_tela = 30000; // importante para funcionar corretamente a troca de tela
      this.controle_tempo_tela = this.navigation.timer_troca_tela / 1000;
      this.controle_tempo_tabela = 5;

      this.user.showIconOpcoes = false;
      this.user.showIconFiltro = true;
      this.user.showFiltroOpcoes = false;
      this.user.showIconTemplates = false;
      this.user.showTemplates = false;
      this.tipoData = 'DESCARGA';
      this.index_pd = this.index_td = 0;

      this.socket_io = io(environment.socket_end_point + '/' + this.socket_rota);
      this.socket_filtro = {
         base: (this.clienteS.clienteAtivo !== 'KMM' ? this.clienteS.clienteAtivo : environment.end_point_base_dev).toLowerCase(),
         token: this.user.token
      };

      const clienteSelecionado = JSON.parse(localStorage.getItem('cliente-selecionado'));
      if (clienteSelecionado) {
         Object.assign(this.socket_filtro, {
            url: clienteSelecionado.url
         });
      }
   }

   ngOnInit() {
      const config = JSON.parse(localStorage.getItem('descarga-configuracao'));
      if (config) {
         if (config.tolerancia) {
            this.tipo_tolerancia = config.tolerancia.tipo_tolerancia;
            this.tolerancia = config.tolerancia.valor;
         }

         if (config.font_grid) {
            this.fonte_grid = Number(config.font_grid);
         }

         if (config.tempos.troca_tela) {
            this.controle_tempo_tela = config.tempos.troca_tela;
            this.navigation.timer_troca_tela = this.controle_tempo_tela * 1000;
         }

         if (config.tempos.troca_tabela) {
            this.controle_tempo_tabela = config.tempos.troca_tabela;
         }
      }
      // const tolerancia = JSON.parse(localStorage.getItem('descarga-tolerancia'));
      // if (tolerancia) {
      //    this.tipo_tolerancia = tolerancia.tipo_tolerancia;
      //    this.tolerancia = tolerancia.valor;
      // }

      // const fontGrid = localStorage.getItem('descarga-fontGrid');
      // if (fontGrid) {
      //    this.fonte_grid = Number(fontGrid);
      // }


      this.getModelo('previsaoDescargaGrid');
      this.getModelo('tempoDescargaGrid');
      SetInterval.start(() => {
         this.trocaPagina();
      }, this.controle_tempo_tabela * 1000, 'intervalo_tabelas');

      this.getData().then(() => { this.navigation.trocaDash(); });

   }

   ngOnDestroy() {
      SetInterval.clear('trocaTela');
      SetInterval.clear('intervalo_tabelas');
   }


   async getData() {
      this.org = JSON.parse(localStorage.getItem('kmm_bi-dash|' + this.clienteS.discover() + '-organizacional'));
      try {
         // const parametrosBd = { organizacional_id: this.orgS.getOrgEmpresa(), usuario: this.org.usuario };
         // const response: any = await this._gateway.backendCall('M4002', 'getDescarga', parametrosBd);
         // console.log('res', response, 'parametros', parametrosBd);

         this.socket_io.emit(this.socket_metodo, this.socket_filtro);
         this.socket_io.on(this.socket_rota, (response) => {
            console.log('filtro:', this.socket_filtro);
            console.log('resposta:', response);
            this.navigation.loaderTela = false;
            this.listaPrevisaoDescarga = response.teladescarga.descargaViagem;
            this.listaTempoDescarga = response.teladescarga.descargaAguardando;

            // INDICADORES
            this.indicador.viajando = this.listaPrevisaoDescarga.length;
            this.indicador.atrasado = this.listaPrevisaoDescarga.reduce(
               (prev, curr) => {
                  return (curr.tempo_min < 0 ? prev + 1 : prev + 0);
               }, 0
            );
            this.indicador.previsto = this.listaPrevisaoDescarga.reduce(
               (prev, curr) => {
                  return (curr.tempo_min > 0 ? prev + 1 : prev + 0);
               }, 0
            );
            this.indicador.descarga = this.listaTempoDescarga.length;
         });

      } catch (error) {
         console.log(error);
      }

   }

   aplicar = () => {
      this.base_calculo = this.tolerancia;
      if (this.tipo_tolerancia === 'Horas') {
         this.base_calculo = this.base_calculo * 60;
      }
      const config = {
         tolerancia: {
            tipo_tolerancia: this.tipo_tolerancia,
            valor: this.tolerancia,
            base_calculo: this.base_calculo
         },
         font_grid: this.fonte_grid,
         tempos: {
            troca_tela: this.controle_tempo_tela,
            troca_tabela: this.controle_tempo_tabela
         }
      };

      localStorage.setItem('descarga-configuracao', JSON.stringify(config));

      location.reload();

   }

   validaAtraso(valor) {
      const tempo_atraso = Math.floor(valor * 1440); // transforma dias em minutos.
      const config = JSON.parse(localStorage.getItem('descarga-configuracao'));

      if (config) {
         if (config.tolerancia) {
            this.tempo = config.tolerancia.base_calculo;
         }

         if (tempo_atraso > this.tempo) {
            return true;
         } else {
            return false;
         }

      }

   }

   public onCellPrepared(e: any) {
      if (e.rowType === 'header') {
         e.cellElement.style.paddingTop = '5px';
         e.cellElement.style.paddingBottom = '5px';
         e.cellElement.style.fontSize = '1rem';
      }

      if (typeof (e.data) !== 'undefined') {
         if (typeof (e.data.tempo_atraso) !== 'undefined') {
            // if (e.data.tempo_min < 0) {
            if (this.validaAtraso(e.data.tempo_atraso)) {
               e.cellElement.style.color = '#fd0e06';
               e.cellElement.style.fontWeight = 'bold';
               e.cellElement.style.fontSize = (this.fonte_grid + 2) + 'px';
            }

         }
         e.cellElement.style.fontSize = this.fonte_grid + 'px';
      }

   }

   public onCellPrepared2(e: any) {
      if (e.rowType === 'header') {
         e.cellElement.style.paddingTop = '5px';
         e.cellElement.style.paddingBottom = '5px';
         e.cellElement.style.fontSize = '1rem';
      }

      if (typeof (e.data) !== 'undefined') {
         if (e.data.tempo_min < 0) {
            e.cellElement.style.color = '#fd0e06';
            e.cellElement.style.fontWeight = 'bold';
            e.cellElement.style.fontSize = (this.fonte_grid + 2) + 'px';
         } else {
            e.cellElement.style.fontSize = this.fonte_grid + 'px';
         }

      }

   }

   onToolbarPreparing = (e: any) => {
      const toolbaropems = e.toolbarOptions.opems;
      const toolbarItems = e.toolbarOptions.items;
      const obj = this;
      toolbarItems.push({
         widget: 'dxButton',
         options: {
            hint: 'Salvar modelo',
            icon: 'save', onClick: function () {
               obj.saveState(e.element.id);
            }
         },
         location: 'after'
      });

   }

   saveState(contextName) {
      const json = localStorage.getItem(contextName);
      this.saveModelo(json, contextName);
      notify({
         message: 'Modelo salvo com sucesso!',
         type: 'success',
         displayTime: 3000,
         closeOnClick: true,
         width: function () {
            return window.innerWidth / 2.8;
         }
      });


   }
   async saveModelo(json, contextName) {
      const org = JSON.parse(localStorage.getItem('kmm_bi-dash|' + this.clienteS.discover() + '-organizacional'));
      try {
         const parametros = {
            grid_ref: contextName,
            usuario: org.usuario.usuario,
            json_colunas: json
         };

         const response_get: any = await this._gateway.backendCall('M4002', 'getModeloGrid', parametros);
         let operation = 'insModeloGrid';
         if (response_get.modelo_grid.length > 0) {
            console.log('entrou no get', response_get);

            Object.assign(parametros, {
               modelo_grid_id: response_get.modelo_grid[0].modelo_grid_id
            });
            operation = 'altModeloGrid';
         }

         const response: any = await this._gateway.backendCall('M4002', operation, parametros);
         return response;

      } catch (error) {
         console.log(error);
      }

   }

   async getModelo(contextName) {
      const org = JSON.parse(localStorage.getItem('kmm_bi-dash|' + this.clienteS.discover() + '-organizacional'));
      try {
         const parametros = {
            grid_ref: contextName,
            usuario: org.usuario.usuario,
         };

         const response: any = await this._gateway.backendCall('M4002', 'getModeloGrid', parametros);

         if (response.modelo_grid) {
            switch (contextName) {
               case 'previsaoDescargaGrid':
                  if (this.previsaoDescargaGrid) {
                     this.previsaoDescargaGrid.instance.state(JSON.parse(response.modelo_grid[0].json_colunas));
                  }

                  break;
               case 'tempoDescargaGrid':
                  if (this.tempoDescargaGrid) {
                     this.tempoDescargaGrid.instance.state(JSON.parse(response.modelo_grid[0].json_colunas));
                  }
                  break;
            }
         }

      } catch (error) {
         console.log(error);
      }

   }

   trocaPagina() {
      // previsaoDescargaGrid
      if (this.previsaoDescargaGrid) {
         const total_pd = this.previsaoDescargaGrid.instance.pageCount();
         if (total_pd > 1) {
            if (this.index_pd === total_pd - 1) {
               this.index_pd = 0;
            } else {
               this.index_pd++;
            }
            this.previsaoDescargaGrid.instance.pageIndex(this.index_pd);
         }
      }


      // tempoDescargaGrid
      if (this.tempoDescargaGrid) {
         const total_td = this.tempoDescargaGrid.instance.pageCount();
         if (total_td > 1) {
            if (this.index_td === total_td - 1) {
               this.index_td = 0;
            } else {
               this.index_td++;
            }
            this.tempoDescargaGrid.instance.pageIndex(this.index_td);
         }
      }

   }
}
