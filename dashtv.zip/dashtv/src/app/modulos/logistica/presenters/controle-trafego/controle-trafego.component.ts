import { Component, OnInit, ViewChild } from '@angular/core';
import { Usuario, NavigationService, GatewayService } from 'src/app/shared';
import { DxMultiViewComponent } from 'devextreme-angular';
//Plugins
import * as moment from 'moment';
import SetInterval from 'set-interval';

@Component({
   selector: 'app-controle-trafego',
   templateUrl: './controle-trafego.component.html',
   styleUrls: ['./controle-trafego.component.scss']
})
export class ControleTrafegoComponent implements OnInit {
   @ViewChild('multiview', { static: false }) multiview: DxMultiViewComponent;
   public user: Usuario = Usuario.instance;
   dataset = [];
   dataChart = [];
   views: Array<any>;
   constructor(
      public navigation: NavigationService,
      private _gateway: GatewayService,
   ) {
      this.navigation.loaderTela = true;
      this.navigation.hideTimeBar = false;
      this.navigation.timer_troca_tela = 60000; // importante para funcionar corretamente a troca de tela

      this.user.showIconOpcoes = false;
      this.user.showIconFiltro = false;
      this.user.showFiltroOpcoes = false;
      this.user.showIconTemplates = false;
      this.user.showTemplates = false;
   }

   ngOnInit() {
      this.getData().then(() => { this.navigation.trocaDash(); });
   }

   async getData() {
      try {
         this.views = [];
         const index = 0;
         const response: any = await this._gateway.backendCall('M4002', 'getCarretaUFGrupo');
         console.log('response:', response);
         this.dataset = response.carretaGrupo;
         // tslint:disable-next-line: no-shadowed-variable
         this.dataset.forEach((element_pai, index) => {
            this.dataChart = [];
            this.dataset[index].ufCarretaGrupo.forEach(element => {
               const obj: any = {};
               obj.estado = element.estado;
               element.graficoEmissaoCte.forEach(
                  (status) => {
                     obj[status.status_carreta_slug] = status['quantidade'];
                  }
               );
               this.dataChart.push(obj);
            });
            this.views.push({
               index: index,
               grupoCarretas: this.dataset[index].grupo_carreta,
               qtdeCarretas: this.dataset[index].quantidade_carreta,
               sysdate: moment().format('DD/MM/YYYY HH:mm'),
               dataChart: this.dataChart
            });
         });

         // controla a troca de paginas
         SetInterval.start(() => {
            this.trocaView(this.views.length);
         }, 10000, 'trocaView');

         this.navigation.loaderTela = false;
      } catch (error) {
         console.log(error);
      }
   }

   trocaView(paginas) {
      if (this.multiview.selectedIndex === paginas - 1) {
         this.multiview.selectedIndex = 0;
      } else {
         this.multiview.selectedIndex = this.multiview.selectedIndex + 1;
      }
   }

}
