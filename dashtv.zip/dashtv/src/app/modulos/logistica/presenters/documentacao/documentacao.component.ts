import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import SetInterval from 'set-interval';
import { Usuario, NavigationService, UsuarioService, GatewayService, EstruturaOrganizacional } from 'src/app/shared';
import { DxDataGridComponent } from 'devextreme-angular';

@Component({
   selector: 'app-logistica-documentacao',
   templateUrl: './documentacao.component.html',
   styleUrls: ['./documentacao.component.scss']
})

export class DocumentacaoComponent implements OnInit, OnDestroy {
   @ViewChild('gridDocVeic', { static: false }) gridDocVeic: DxDataGridComponent;
   public user: Usuario = Usuario.instance;
   public listaDocVeic: Array<string> = [];
   index_grid = 0;

   constructor(
      public logisticaProvider: GatewayService,
      public navigation: NavigationService,
   ) {
      this.navigation.loaderTela = true;
      this.navigation.timer_troca_tela = 60000; // importante para funcionar corretamente a troca de tela
      this.user.showIconOpcoes = false;
   }

   ngOnInit() {
      this.getData().then(() => { this.navigation.trocaDash(); });
      SetInterval.start(() => {
         this.trocaPagina();
      }, 10000, 'intervalo_tabelas');
   }

   ngOnDestroy() {
      SetInterval.clear('trocaTela');
      SetInterval.clear('intervalo_tabelas');
   }


   /** 
   * Resgata os dados da Base
   * @returns {Promise<any>} - retorna a chamada do backendCall.
   */
   public async getData(): Promise<any> {
      return this.logisticaProvider.backendCall('M4002', 'getVeicDocVencimento', {
         cod_modalidade: "TUDO",
         tipo_documentacao: "TUDO"
      }).then(
         (result: any) => {
            console.log('res', result);
            this.navigation.loaderTela = false;
            this.listaDocVeic = result.docVeiculos.documentos;
         })
   }


   /**
  * Função Para Alterar o Estilo da Tabela
  * @param e Evento recebido pelo componente
  */
   public onCellPrepared(e) {
      e.cellElement.style.fontSize = '1rem';
      e.cellElement.style.fontWeight = '700';

      //Pinta as Linhas de Cabeçalho e Filtros
      if (e.rowType == 'header') {
         e.cellElement.style.paddingTop = '3px';
         e.cellElement.style.paddingBottom = '3px';
         e.cellElement.style.lineHeight = '18px';
      } else if (e.rowType == 'filter') {
         // e.cellElement.bgColor = '#e2e2e2';
         // e.cellElement.style.color = '#000000';
      } else {
         e.cellElement.style.padding = '7px';
      }

      if (typeof (e.key) !== 'undefined') {
         if (e.key.vencido === 'VENCIDO' && e.column.caption == 'Dias') {
            e.cellElement.style.color = '#be322e';
         }
      }
   }

   trocaPagina() {
      // gridDocVeic
      if (this.gridDocVeic) {
         const total_pd = this.gridDocVeic.instance.pageCount();
         if (total_pd > 1) {
            if (this.index_grid === total_pd - 1) {
               this.index_grid = 0;
            } else {
               this.index_grid++;
            }
            this.gridDocVeic.instance.pageIndex(this.index_grid);
         }
      }

   }
}
