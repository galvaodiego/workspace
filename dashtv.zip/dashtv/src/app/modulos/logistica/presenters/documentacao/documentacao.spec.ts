import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LogisticaDocumentacaoVeiculoComponent } from './logistica-documentacao-veiculo.component';

describe('LogisticaDocumentacaoVeiculoComponent', () => {
  let component: LogisticaDocumentacaoVeiculoComponent;
  let fixture: ComponentFixture<LogisticaDocumentacaoVeiculoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LogisticaDocumentacaoVeiculoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LogisticaDocumentacaoVeiculoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
