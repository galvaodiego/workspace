import { Component, OnInit, Input } from '@angular/core';
import { getPalette } from 'devextreme/viz/palette';
import { UtilitarioService } from 'src/app/shared/services/common/utilitario.service';

@Component({
   selector: 'app-comp-fluxo',
   templateUrl: './comp-fluxo.component.html',
   styleUrls: ['./comp-fluxo.component.scss']
})
export class CompFluxoComponent implements OnInit {
   @Input() datasource: any;
   constructor(
      public utilitario: UtilitarioService
   ) { }

   ngOnInit() {
   }

   onCelPrepared(e: any) {

      if (e.rowType === 'header') {
         e.cellElement.style.paddingTop = '5px';
         e.cellElement.style.paddingBottom = '5px';
         e.cellElement.style.display = 'none';

      }

      if (typeof (e.data) !== 'undefined') {
         e.cellElement.style.paddingTop = '5px';
         e.cellElement.style.paddingBottom = '5px';
         e.cellElement.style.fontSize = '30px';
         e.cellElement.style.border = '0';
         e.cellElement.style.color = '#666666';

      }
   }
   onCelPreparedTipo2(e: any) {

      if (e.rowType === 'header') {
         e.cellElement.style.paddingTop = '5px';
         e.cellElement.style.paddingBottom = '5px';
         // e.cellElement.style.display = 'none';

      }

      if (typeof (e.data) !== 'undefined') {
         e.cellElement.style.paddingTop = '8px';
         e.cellElement.style.paddingBottom = '8px';
         // e.cellElement.style.fontSize = '30px';
         e.cellElement.style.border = '0';
         e.cellElement.style.color = '#666666';

      }
   }

   customizeTextLabel(e: any) {
      return e.percentText;
   }


   customizeLabel = (arg: any) => {
      const obj = this;
      return {
         customizeText(e: any) {
            return obj.utilitario.convertTime(e.value);
         }
      };
   }

   customizeLabelPercent = (arg: any) => {
      return {
         customizeText(e: any) {
            return e.value + '%';
         }
      };
   }

   customizePointMultiple = (arg: any) => {
      let tipo = 'Soft';
      if (arg.seriesName === 'CCG') {
         tipo = 'Bright';
      }
      const palette = getPalette(tipo);
      const index = arg.index % (palette.simpleSet.length - 1);
      return { color: palette.simpleSet[index] };
   }

}
