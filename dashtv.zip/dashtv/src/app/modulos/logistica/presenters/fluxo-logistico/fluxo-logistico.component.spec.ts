import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FluxoLogisticoComponent } from './fluxo-logistico.component';

describe('FluxoLogisticoComponent', () => {
  let component: FluxoLogisticoComponent;
  let fixture: ComponentFixture<FluxoLogisticoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FluxoLogisticoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FluxoLogisticoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
