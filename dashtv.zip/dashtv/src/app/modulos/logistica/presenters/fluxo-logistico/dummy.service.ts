import { Injectable } from '@angular/core';
import * as  moment from 'moment';

@Injectable({
   providedIn: 'root'
})
export class DummyService {

   constructor() { }
   // ACO CEARENSE INDUSTRIAL LTDA
   // ADAMA BRASIL S/A
   // 6	AMBEV - JACAREI
   // 3	ARCELORMITTAL - IRACEMÁPOLIS - SP
   // 4	BRAVO SERVICOS LOGISTICOS LTDA
   // 8	BUNGE ALIMENTOS - LUZIANIA - GO
   // 15	CARAMURU - RIO VERDE-GO II
   // 5	CERVEJARIA CIDADE IMPERIAL PETROPOL
   // 1	G10 TRANSPORTES - BRASILIA-DF
   // 13	INDUSTRIA DE OLEO E FARELO
   // 12	JBS S/A
   // 10	LIMAGRAIN BRASIL S.A.
   // 16	PETROBRAS - LONDRINA-PR
   // 17	RURAL TECNICA
   // 9	SARTCO - LADARIO-MS
   // 7	SINOBRAS
   // 2	USIMINAS - RIO DAS PEDRAS - SP
   getDados() {
      return {
         graficos: {
            percentualAutomatizado: [
               { chave: 'Automatizado', valor: 1000 },
               { chave: 'Manual', valor: 500 },
            ],
            tempoMedioCCG: [
               { chave: 'Frota', valor: 150 },
               { chave: 'Agregado', valor: 140 },
               { chave: 'Terceiro', valor: 130 },
            ],
            tempoMedioQuantidade: [
               { chave: '< 1 min', valor: 50 },   // QUANTIDADE
               { chave: '< 30 min', valor: 25 },  // QUANTIDADE
               { chave: '< 1 hora', valor: 15 }, // QUANTIDADE
               { chave: '> 1 Hora', valor: 3 },   // QUANTIDADE
            ],
            tempoMedioUltimosDias: [
               { chave: '21/01', valor: 3200 }, // tempo em segundos
               { chave: '22/01', valor: 1800 },
               { chave: '23/01', valor: 1200 },
            ],
            tempoMedioG10UltimosDias: [
               { chave: '21/01', valor: 3200 }, // tempo em segundos
               { chave: '22/01', valor: 1800 },
               { chave: '23/01', valor: 1200 },
            ],
            automatizacaoUltimosDias: [
               { chave: '21/01', valor: 0.25 }, // percentual
               { chave: '22/01', valor: 0.25 }, // percentual
               { chave: '23/01', valor: 0.50 }, // percentual
            ]
         },
         listas: {
            tempoEmissaoCTE: [
               { documento: 'CTE 4589 (Bunge)', tempo: 1800 }, // tempo em segundos
               { documento: 'CTE 4590 (Bunge)', tempo: 5000 }, // tempo em segundos
               { documento: 'CTE 4591 (Bunge)', tempo: 50000 }, // tempo em segundos
               { documento: 'CTE 4592 (Bunge)', tempo: 50000 }, // tempo em segundos
               { documento: 'CTE 4593 (Bunge)', tempo: 500000 }, // tempo em segundos
               { documento: 'CTE 4594 (Bunge)', tempo: 500 }, // tempo em segundos
               { documento: 'CTE 4595 (Bunge)', tempo: 500 }, // tempo em segundos
               { documento: 'CTE 4595 (Bunge)', tempo: 500 }, // tempo em segundos
               { documento: 'CTE 4595 (Bunge)', tempo: 500 }, // tempo em segundos
               { documento: 'CTE 4595 (Bunge)', tempo: 500 }, // tempo em segundos
            ],
            tempoMedioCliente: [
               { cliente: 'Cliente 01', tempo: 3600 }, // tempo em segundos
               { cliente: 'Cliente 02', tempo: 1800 }, // tempo em segundos
               { cliente: 'Cliente 03', tempo: 1200 }, // tempo em segundos
               { cliente: 'Cliente 04', tempo: 1200 }, // tempo em segundos
               { cliente: 'Cliente 05', tempo: 960 }, // tempo em segundos
               { cliente: 'Cliente 05', tempo: 860 }, // tempo em segundos
               { cliente: 'Cliente 05', tempo: 300 }, // tempo em segundos
               { cliente: 'Cliente 05', tempo: 300 }, // tempo em segundos
               { cliente: 'Cliente 05', tempo: 300 }, // tempo em segundos
               { cliente: 'Cliente 05', tempo: 300 }, // tempo em segundos

            ]
         },
         indicadores: {
            tempoMedioHora: 3600, // segundos
            tempoMedioHoje: 1800, // segundos
            tempoMedioUltimosDias: 600, // segundos Ultimos 3 dias
         }
      };
   }
}
