import { Component, OnInit, OnDestroy } from '@angular/core';
import { Usuario, NavigationService, ClienteService } from 'src/app/shared';
import { environment } from 'src/environments/environment';
import SetInterval from 'set-interval';
import io from 'socket.io-client';
import { DummyService } from './dummy.service';
import * as  moment from 'moment';
import { timeout } from 'rxjs/operators';
import { UtilitarioService } from 'src/app/shared/services/common/utilitario.service';


@Component({
   selector: 'app-fluxo-logistico',
   templateUrl: './fluxo-logistico.component.html',
   styleUrls: ['./fluxo-logistico.component.scss']
})
export class FluxoLogisticoComponent implements OnInit, OnDestroy {
   public user: Usuario = Usuario.instance;
   // Config Socket
   socket_io: any;
   socket_rota = 'fluxo_logistico';
   socket_metodo = 'getFluxoLogistico';
   socket_filtro: any;
   /***/

   datasource = {
      graficos: {
         percentualAutomatizado: [],
         tempoMedioCCG: [],
         tempoMedioQuantidade: [],
         tempoMedioUltimosDias: [],
         tempoMedioG10UltimosDias: [],
         automatizacaoUltimosDias: [],
      },
      listas: {
         tempoEmissaoCTE: [],
         tempoMedioCliente: [],
         percentualAutomatizado: [],
         tempoMedioCCG: [],

      },
      indicadores: {
         tempoMedioHora: '',
         tempoMedioHoje: '',
         tempoMedioUltimosDias: ''
      }
   };

   visualizacao: any;
   loadingVisible = false;
   constructor(
      public navigation: NavigationService,
      private _clienteS: ClienteService,
      public utilitario: UtilitarioService
   ) {
      this.navigation.loaderTela = true;
      this.navigation.hideTimeBar = false;
      this.navigation.timer_troca_tela = 60000; // importante para funcionar corretamente a troca de tela

      this.user.showIconOpcoes = false;
      this.user.showIconFiltro = false;
      this.user.showFiltroOpcoes = false;
      this.user.showIconTemplates = false;
      this.user.showTemplates = false;

      this.visualizacao = 'Diario';

      this.socket_io = io(environment.socket_end_point + '/' + this.socket_rota);
      this.socket_filtro = {
         base: (this._clienteS.clienteAtivo !== 'KMM' ? this._clienteS.clienteAtivo : environment.end_point_base_dev).toLowerCase(),
         periodo: this.visualizacao.toLowerCase()
      };

      // tslint:disable-next-line: max-line-length
      console.log('SOCKET::', environment.socket_end_point + '/' + this.socket_rota + '/' + this.socket_metodo, '[filtro]', this.socket_filtro);


   }

   ngOnInit() {
      this.socket().then(() => {
         this.navigation.trocaDash();
         this.navigation.loaderTela = false;
      });
   }

   ngOnDestroy(): void {
      this.socket_io.disconnect();
      SetInterval.clear('trocaTela');
   }

   async socket() {
      try {
         // console.log('entrando no socket');

         this.loadingVisible = true;
         this.socket_io.emit(this.socket_metodo, this.socket_filtro);
         // let tempo = timeout(10000);
         this.socket_io.on(this.socket_rota, (data) => {
            console.log('data', data, this.socket_filtro);
            this.datasource = data;
            this.sanitize();
            this.loadingVisible = false;
         });
      } catch (error) {
         this.loadingVisible = false;
         console.log('error => ', error);
      }
   }

   sanitize() {
      if (this.datasource.indicadores) {
         const indicadores = this.datasource.indicadores;
         indicadores.tempoMedioUltimosDias = this.utilitario.convertTime(Number(indicadores.tempoMedioUltimosDias));
         indicadores.tempoMedioHoje = this.utilitario.convertTime(Number(indicadores.tempoMedioHoje));
         indicadores.tempoMedioHora = this.utilitario.convertTime(Number(indicadores.tempoMedioHora));
      }
      if (this.datasource.graficos) {
         const graficos = this.datasource.graficos;

         if (graficos.tempoMedioCCG) {
            graficos.tempoMedioCCG.reverse();
         }

      }
      if (this.datasource.listas) {
         const listas = this.datasource.listas;
         if (listas.tempoEmissaoCTE) {
            listas.tempoEmissaoCTE.map(e => {
               e.tempo = this.utilitario.convertTime(e.valor);
            });
         }

         if (listas.tempoMedioCliente) {
            listas.tempoMedioCliente.map(e => {
               e.tempo = this.utilitario.convertTime(e.valor);
            });
         }

         if (listas.tempoMedioCCG) {
            listas.tempoMedioCCG.map(e => {
               e.tempo = this.utilitario.convertTime(e.valor);
            });
         }
      }

   }



}
