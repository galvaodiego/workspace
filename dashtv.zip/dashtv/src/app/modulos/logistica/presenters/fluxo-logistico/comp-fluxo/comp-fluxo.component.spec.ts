import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompFluxoComponent } from './comp-fluxo.component';

describe('CompFluxoComponent', () => {
  let component: CompFluxoComponent;
  let fixture: ComponentFixture<CompFluxoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompFluxoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompFluxoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
