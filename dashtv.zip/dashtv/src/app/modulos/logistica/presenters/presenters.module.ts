import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PresentersRouting } from './presenters.routing';
import { ComponentsModule } from 'src/app/shared/components/components.module';
import { FeaturesModule } from '../features/features.module';
import { DxDataGridModule, DxChartModule, DxPieChartModule, DxPopupModule, DxScrollViewModule, DxSelectBoxModule, DxCircularGaugeModule, DxLinearGaugeModule, DxSliderModule, DxRadioGroupModule, DxCheckBoxModule, DxMultiViewModule, DxTagBoxModule, DxDateBoxModule, DxLoadPanelModule, DxGalleryModule } from 'devextreme-angular';
import { SharedModule } from 'src/app/shared/shared.module';

// Componentes
import { CargaComponent } from './carga/carga.component';
import { ControleSolicitacoesComponent } from './controle-solicitacoes/controle-solicitacoes.component';
import { DemandaDisponibilidadeComponent } from './demanda-disponibilidade/demanda-disponibilidade.component';
import { DescargaComponent } from './descarga/descarga.component';
import { MetasComponent } from './metas/metas.component';
import { ParqueamentoComponent } from './parqueamento/parqueamento.component';
import { TempoEmissaoComponent } from './tempo-emissao/tempo-emissao.component';
import { TrafegoOcorrenciasComponent } from './trafego-ocorrencias/trafego-ocorrencias.component';
import { TransitTimeComponent } from './transit-time/transit-time.component';
import { TransitTimeV2Component } from './transit-time_v2/transit-time.component';
import { ViagensComponent } from './viagens/viagens.component';
import { DocumentacaoComponent } from './documentacao/documentacao.component';
import { AlertaIndicadoresComponent } from './alerta-indicadores/alerta-indicadores.component';
import { ProdutividadeComponent } from './produtividade/produtividade.component';
import { VelocidadeComponent } from './velocidade/velocidade.component';
import { PerformanceEmpresaComponent } from './performance-empresa/performance-empresa.component';
import { KpiDescargaComponent } from './kpi-descarga/kpi-descarga.component';
import { PreventivasComponent } from './preventivas/preventivas.component';
import { ControleTrafegoComponent } from './controle-trafego/controle-trafego.component';
import { EmbarquesAgendamentoComponent } from './embarques-agendamento/embarques-agendamento.component';
import { OcorrenciasComponent } from './ocorrencias/ocorrencias.component';
import { TipoComponent } from './produtividade/tipo/tipo.component';
import { EmpresaComponent } from './produtividade/empresa/empresa.component';
import { SolicitacoesComponent } from './solicitacoes/solicitacoes.component';
import { AcompanhamentoOcorrenciasComponent } from './acompanhamento-ocorrencias/acompanhamento-ocorrencias.component';
import { AoCardComponent } from './acompanhamento-ocorrencias/ao-card/ao-card.component';
import { SolicitacoesPendentesComponent } from './solicitacoes-pendentes/solicitacoes-pendentes.component';
import { AcompanhamentoLogisticoComponent } from './acompanhamento-logistico/acompanhamento-logistico.component';
import { AcompanhamentoDescargaComponent } from './acompanhamento-descarga/acompanhamento-descarga.component';
import { PeriodoComponent } from './produtividade/periodo/periodo.component';
import { DisponibilidadeMotoristasComponent } from './disponibilidade-motoristas/disponibilidade-motoristas.component';
import { FluxoLogisticoComponent } from './fluxo-logistico/fluxo-logistico.component';
import { CompFluxoComponent } from './fluxo-logistico/comp-fluxo/comp-fluxo.component';
import { RastreamentoColetaComponent } from './rastreamento-coleta/rastreamento-coleta.component';
import { NivelServicoComponent } from './nivel-servico/nivel-servico.component';
import { AutomatizacaoComponent } from './automatizacao/automatizacao.component';
import { Cargav2Component } from './cargav2/cargav2.component';
import { Descargav2Component } from './descargav2/descargav2.component';

@NgModule({
    imports: [
        CommonModule,
        PresentersRouting,
        ComponentsModule,
        FeaturesModule,
        DxDataGridModule,
        DxChartModule,
        DxPieChartModule,
        DxPopupModule,
        DxScrollViewModule,
        DxCircularGaugeModule,
        DxSelectBoxModule,
        DxLinearGaugeModule,
        DxPopupModule,
        DxSliderModule,
        DxRadioGroupModule,
        DxCheckBoxModule,
        SharedModule,
        DxMultiViewModule,
        DxTagBoxModule,
        DxDateBoxModule,
        DxLoadPanelModule,
        DxGalleryModule,
    ],
    declarations: [
        CargaComponent,
        ControleSolicitacoesComponent,
        DemandaDisponibilidadeComponent,
        DescargaComponent,
        MetasComponent,
        ParqueamentoComponent,
        TempoEmissaoComponent,
        TrafegoOcorrenciasComponent,
        TransitTimeComponent,
        TransitTimeV2Component,
        ViagensComponent,
        DocumentacaoComponent,
        AlertaIndicadoresComponent,
        ProdutividadeComponent,
        VelocidadeComponent,
        PerformanceEmpresaComponent,
        KpiDescargaComponent,
        PreventivasComponent,
        ControleTrafegoComponent,
        EmbarquesAgendamentoComponent,
        OcorrenciasComponent,
        TipoComponent,
        EmpresaComponent,
        SolicitacoesComponent,
        AcompanhamentoOcorrenciasComponent,
        AoCardComponent,
        SolicitacoesPendentesComponent,
        AcompanhamentoLogisticoComponent,
        AcompanhamentoDescargaComponent,
        PeriodoComponent,
        DisponibilidadeMotoristasComponent,
        FluxoLogisticoComponent,
        CompFluxoComponent,
        RastreamentoColetaComponent,
        NivelServicoComponent,
        AutomatizacaoComponent,
        Cargav2Component,
        Descargav2Component
    ],
})
export class PresentersModule { }
