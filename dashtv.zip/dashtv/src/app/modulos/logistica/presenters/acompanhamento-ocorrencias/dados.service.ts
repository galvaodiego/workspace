import { Injectable } from '@angular/core';
import { pathToFileURL } from 'url';

@Injectable({
   providedIn: 'root'
})
export class DadosService {

   constructor() { }

   getDados() {
      const obj = {
         'viagens': [
            {
               'origem': 'SP',
               'destino': 'MS',
               'num_romaneio': 1,
               'nome': 'Teste 1',
               'telefone': '(99) 99999-9999',
               'data_agendada': '01/01/2019',
               'status': 1, // 1 - Em aberto, 2 - Sendo tratadas, 3 - Finalizada
               'data_evento': '01/01/2019 04:00:00',
               'evento_id': 1,
               'evento_desc': 'Carga Tombada',
               'regiao': 'norte'
            },
            {
               'origem': 'SP',
               'destino': 'MS',
               'num_romaneio': 1,
               'nome': 'Teste 2',
               'telefone': '(99) 99999-9999',
               'data_agendada': '01/01/2019',
               'status': 2, // 1 - Em aberto, 2 - Sendo tratadas, 3 - Finalizada
               'data_evento': '01/01/2019 04:00:00',
               'evento_id': 1,
               'evento_desc': 'Carga Tombada',
               'regiao': 'norte'
            },
            {
               'origem': 'SP',
               'destino': 'MS',
               'num_romaneio': 1,
               'nome': 'Teste 3',
               'telefone': '(99) 99999-9999',
               'data_agendada': '01/01/2019',
               'status': 3, // 1 - Em aberto, 2 - Sendo tratadas, 3 - Finalizada
               'data_evento': '01/01/2019 04:00:00',
               'evento_id': 1,
               'evento_desc': 'Carga Tombada',
               'regiao': 'norte'
            },
            {
               'origem': 'SP',
               'destino': 'MS',
               'num_romaneio': 1,
               'nome': 'Teste 1',
               'telefone': '(99) 99999-9999',
               'data_agendada': '01/01/2019',
               'status': 1, // 1 - Em aberto, 2 - Sendo tratadas, 3 - Finalizada
               'data_evento': '01/01/2019 04:00:00',
               'evento_id': 1,
               'evento_desc': 'Carga Tombada',
               'regiao': 'sul'
            },
            {
               'origem': 'SP',
               'destino': 'MS',
               'num_romaneio': 1,
               'nome': 'Teste 4',
               'telefone': '(99) 99999-9999',
               'data_agendada': '01/01/2019',
               'status': 2, // 1 - Em aberto, 2 - Sendo tratadas, 3 - Finalizada
               'data_evento': '01/01/2019 04:00:00',
               'evento_id': 1,
               'evento_desc': 'Carga Tombada',
               'regiao': 'sudeste'
            },
            {
               'origem': 'SP',
               'destino': 'MS',
               'num_romaneio': 1,
               'nome': 'Teste 5',
               'telefone': '(99) 99999-9999',
               'data_agendada': '01/01/2019',
               'status': 3, // 1 - Em aberto, 2 - Sendo tratadas, 3 - Finalizada
               'data_evento': '01/01/2019 04:00:00',
               'evento_id': 1,
               'evento_desc': 'Carga Tombada',
               'regiao': 'norte'
            },
            {
               'origem': 'SP',
               'destino': 'MS',
               'num_romaneio': 1,
               'nome': 'Teste 6',
               'telefone': '(99) 99999-9999',
               'data_agendada': '01/01/2019',
               'status': 1, // 1 - Em aberto, 2 - Sendo tratadas, 3 - Finalizada
               'data_evento': '01/01/2019 04:00:00',
               'evento_id': 1,
               'evento_desc': 'Carga Tombada',
               'regiao': 'norte'
            },
            {
               'origem': 'SP',
               'destino': 'MS',
               'num_romaneio': 1,
               'nome': 'Teste 7',
               'telefone': '(99) 99999-9999',
               'data_agendada': '01/01/2019',
               'status': 1, // 1 - Em aberto, 2 - Sendo tratadas, 3 - Finalizada
               'data_evento': '01/01/2019 04:00:00',
               'evento_id': 1,
               'evento_desc': 'Carga Tombada',
               'regiao': 'nordeste'
            },
            {
               'origem': 'SP',
               'destino': 'MS',
               'num_romaneio': 1,
               'nome': 'Teste 8',
               'telefone': '(99) 99999-9999',
               'data_agendada': '01/01/2019',
               'status': 2, // 1 - Em aberto, 2 - Sendo tratadas, 3 - Finalizada
               'data_evento': '01/01/2019 04:00:00',
               'evento_id': 1,
               'evento_desc': 'Carga Tombada',
               'regiao': 'norte'
            },
            {
               'origem': 'SP',
               'destino': 'MS',
               'num_romaneio': 1,
               'nome': 'Teste 9',
               'telefone': '(99) 99999-9999',
               'data_agendada': '01/01/2019',
               'status': 2, // 1 - Em aberto, 2 - Sendo tratadas, 3 - Finalizada
               'data_evento': '01/01/2019 04:00:00',
               'evento_id': 1,
               'evento_desc': 'Carga Tombada',
               'regiao': 'sul'
            },
         ]
      };
      return obj;
   }

   getOcorrencias() {
      const obj = [
         {
            tipo: 1, // 1 - Tipo X, 2 - Tipo Y .....
            descricao: 'Atraso na entrega',
            valor: 10
         },
         {
            tipo: 2, // 1 - Tipo X, 2 - Tipo Y .....
            descricao: 'Avaria no carregamento',
            valor: 8
         },
         {
            tipo: 3, // 1 - Tipo X, 2 - Tipo Y .....
            descricao: 'Carga tombada',
            valor: 25
         },
         {
            tipo: 4, // 1 - Tipo X, 2 - Tipo Y .....
            descricao: 'Divergência de cadastro',
            valor: 3
         },
         {
            tipo: 5, // 1 - Tipo X, 2 - Tipo Y .....
            descricao: 'Outros',
            valor: 100
         }
      ];

      return obj;
   }

   getIcone(tipo) {
      let path = 'assets/icon/acomp_ocorrencias/carga_inserida.png';
      if (tipo) {
         path = 'assets/icon/acomp_ocorrencias/' + tipo + '.png';
      }


   }

}
