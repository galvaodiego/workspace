import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { Usuario, NavigationService, GatewayService } from 'src/app/shared';

import SetInterval from 'set-interval';
import * as _ from 'underscore';
import * as moment from 'moment';
import 'moment/locale/pt-br';


// dummy temporario
import { DadosService } from './dados.service';
import { interval } from 'rxjs';
import { NotificacaoService } from 'src/app/shared/services/common/notificacao.service';
import { FormGroup, FormBuilder } from '@angular/forms';
import { ThrowStmt } from '@angular/compiler';
import { DxPopupComponent } from 'devextreme-angular';

@Component({
   selector: 'app-acompanhamento-ocorrencias',
   templateUrl: './acompanhamento-ocorrencias.component.html',
   styleUrls: ['./acompanhamento-ocorrencias.component.scss']
})
export class AcompanhamentoOcorrenciasComponent implements OnInit, OnDestroy {
   @ViewChild('popFiltro', { static: false }) popFiltro: DxPopupComponent;
   public user: Usuario = Usuario.instance;
   public filtroForm: FormGroup;
   visoes = [];
   visaoAtiva: string;
   ocorrencias_aberto = [];

   viagens_aberto = [];
   viagens_tratadas = [];
   viagens_finalizadas = [];

   entregas_finalizadas: number;

   glossario = [
      { id: 107, legenda: 'Carga Inserida' },
      { id: 110, legenda: 'Transferencia Aberta' },
      { id: 113, legenda: 'CTRC vinculado' },
      { id: 115, legenda: 'Carga Gerada pelo CTRC (Carga Seca)' },
      { id: 214, legenda: 'Falta de Pedido de Venda' },
      { id: 216, legenda: 'Avaria Transportes/Qualidade' },
      { id: 219, legenda: 'Falta de Produto' },
      { id: 224, legenda: 'Atraso na Entrega' },
      { id: 227, legenda: 'Divergencia Cadastro' },
      { id: 228, legenda: 'Erro da Transportadora' },
      { id: 230, legenda: 'Carga Tombada' },
      { id: 231, legenda: 'Entrega Programada' },
      { id: 232, legenda: 'Falta de Espaço no Cliente' },
      { id: 235, legenda: 'Falta de Agendamento' },
      { id: 238, legenda: 'Favaria no Carregamento' },
      { id: 242, legenda: 'Entrega Realizada' },
      { id: 245, legenda: 'Veículo Quebrado' },
      { id: 253, legenda: 'Sem ocorrência' },
   ];
   loadingVisible = false;

   parametros = {
      regiao: null,
      num_conhecimento: null
   };

   constructor(
      public navigation: NavigationService,
      private _gateway: GatewayService,
      private dados: DadosService,
      private notificacao: NotificacaoService,
      private formBuilder: FormBuilder,
   ) {
      this.navigation.loaderTela = true;
      this.navigation.hideTimeBar = false;
      this.navigation.timer_troca_tela = 120000; // importante para funcionar corretamente a troca de tela

      this.user.showIconOpcoes = false;
      this.user.showIconFiltro = true;
      this.user.showFiltroOpcoes = false;
      this.user.showIconTemplates = false;
      this.user.showTemplates = false;
      this.entregas_finalizadas = 0;
   }

   ngOnInit() {
      this.getData().then(() => { this.navigation.trocaDash(); });
      this.getRegiao();
      this._buildForm();
   }

   ngOnDestroy() {
      SetInterval.clear('trocaTela');
   }

   private _buildForm() {
      this.filtroForm = this.formBuilder.group({
         num_conhecimento: null,
      });
   }

   filtrar() {
      this.parametros.num_conhecimento = this.filtroForm.get('num_conhecimento').value;
      this.getData();
      this.popFiltro.instance.hide();
      // return false;
   }

   async getData() {
      try {
         this.loadingVisible = true;
         const regiao = JSON.parse(localStorage.getItem('acomp-oco-visao'));
         if (regiao) {
            this.visaoAtiva = regiao;
         } else {
            this.visaoAtiva = 'sul';
         }
         this.parametros.regiao = this.visaoAtiva;
         const response: any = await this._gateway.backendCall('M4002', 'getAcompOcorrencia', this.parametros);
         console.log('response:', response);

         if (response.dash_ocorrencias.viagens.length > 0) {
            this.entregas_finalizadas = Math.floor(response.dash_ocorrencias.ocorrencias_perc[0].valor * 100);
            if (response.dash_ocorrencias.ocorrencias_agrup) {
               this.ocorrencias_aberto = response.dash_ocorrencias.ocorrencias_agrup;

               this.ocorrencias_aberto.map(e => {
                  e.path = 'assets/icon/acomp_ocorrencias/' + e.tipo + '.png';
               });

            }

            let viagens = response.dash_ocorrencias.viagens;
            const filtro = JSON.parse(localStorage.getItem('acomp-oco-visao'));

            if (filtro) {
               this.visaoAtiva = filtro;
               viagens = viagens.filter(e => {
                  return e.regiao.toLowerCase() === filtro.toLowerCase();
               });
            }

            // console.log(viagens);


            this.viagens_aberto = viagens.filter(e => {
               return e.status === 1;
            });
            this.viagens_tratadas = viagens.filter(e => {
               return e.status === 2;
            });
            this.viagens_finalizadas = viagens.filter(e => {
               return e.status === 3;
            });

         } else {
            this.notificacao.toast('Nenhuma viagem encontrada para a região: ' + this.visaoAtiva.toUpperCase(), 'error');
            this.limpaFiltro();
         }



         // this.ocorrencias_aberto = this.dados.getOcorrencias();
         this.loadingVisible = false;
         this.navigation.loaderTela = false;
      } catch (error) {
         console.log(error);
      }
   }

   async getRegiao() {
      try {
         const response: any = await this._gateway.backendCall('M4002', 'getRegiaoOcorrencia');
         const regioes = response.regiao;
         regioes.map(e => {
            e.regiao = e.regiao.toLowerCase();
         });
         this.visoes = regioes;
      } catch (error) {
         console.log(error);
      }
   }

   unique(array) {
      const flags = [], output = [], l = array.length;
      for (let i = 0; i < l; i++) {
         if (flags[array[i].regiao]) {
            continue;
         }
         flags[array[i].regiao] = true;
         output.push(array[i].regiao);
      }

      return output;
   }

   navegaVisoes(visao) {
      localStorage.setItem('acomp-oco-visao', JSON.stringify(visao));
      this.getData();
   }

   limpaFiltro() {
      localStorage.removeItem('acomp-oco-visao');
      this.getData();
   }

   getImg(tipo) {
      return 'assets/icon/acomp_ocorrencias/' + tipo + '.png';
   }

}
