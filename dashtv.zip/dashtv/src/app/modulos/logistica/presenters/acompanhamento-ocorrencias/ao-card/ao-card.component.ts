import { Component, OnInit, Input, AfterViewInit, ChangeDetectorRef } from '@angular/core';
import * as moment from 'moment';
import { DadosService } from '../dados.service';

@Component({
   selector: 'app-ao-card',
   templateUrl: './ao-card.component.html',
   styleUrls: ['./ao-card.component.scss']
})
export class AoCardComponent implements OnInit, AfterViewInit {
   @Input() card: any;
   private diff: any;
   positivo: boolean;
   path: string;
   constructor(
      private dados: DadosService,
      private cdRef: ChangeDetectorRef
   ) { }

   ngOnInit() {
   }

   ngAfterViewInit(): void {
      this.path = 'assets/icon/acomp_ocorrencias/' + this.card.evento_id + '.png';
      setInterval(() => {
         const now = moment();
         const evento = moment(this.card.data_evento);

         if (evento > now) {
            this.diff = evento.diff(now);
            this.positivo = true;

         } else {
            this.diff = now.diff(evento);
            this.positivo = false;
         }
         const tempTime = moment.duration(this.diff);
         const h = tempTime.hours();
         const m = tempTime.minutes();
         const s = tempTime.seconds();


         let hora = h.toString();
         let minutes = m.toString();
         let segundos = s.toString();
         if ((h) < 10) {
            hora = '0' + h.toString();
         }

         if ((m) < 10) {
            minutes = '0' + m.toString();
         }

         if ((s) < 10) {
            segundos = '0' + s.toString();
         }

         this.card.diferenca = hora + ':' + minutes + ':' + segundos;
      }, 1000);

      this.cdRef.detectChanges();
   }


}
