import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { NavigationService, Usuario, UsuarioService, GatewayService, ClienteService } from 'src/app/shared';
import { DxPopupComponent, DxTagBoxComponent } from 'devextreme-angular';
import { ViagensService } from '../../services/viagens.service';

import io from 'socket.io-client';
import * as _ from 'underscore';

import { environment } from 'src/environments/environment';
import { TemplateService } from 'src/app/shared/services/template.service';
import { ActivatedRoute } from '@angular/router';

@Component({
   selector: 'app-feature-logistica-viagens',
   templateUrl: './viagens.component.html',
   styleUrls: ['./viagens.component.scss']
})
export class ViagensComponent implements OnInit, OnDestroy {
   @ViewChild('popTemplates', { static: false }) popTemplates: DxPopupComponent;

   @ViewChild('filtroCliente', { static: false }) filtroCliente: DxTagBoxComponent;
   @ViewChild('filtroDestino', { static: false }) filtroDestino: DxTagBoxComponent;
   @ViewChild('filtroMercadoria', { static: false }) filtroMercadoria: DxTagBoxComponent;
   @ViewChild('filtroRota', { static: false }) filtroRota: DxTagBoxComponent;
   @ViewChild('popFiltro', { static: false }) popFiltro: DxPopupComponent;


   public user: Usuario = Usuario.instance;

   visualizacao: any;
   org: any;
   usuario: any;
   dash: any;
   template: any = {};
   modelo_template = 1;
   loadingVisible = false;

   // Config elemento-grafico
   grafico_pizza_legenda = true;
   grafico_pizza_label = false;
   /***/

   // Config Socket
   socket_io: any;
   socket_rota = 'viagem';
   socket_metodo = 'getViagem';
   /***/

   periodo = 'anual';

   // FILTROS
   listaFiltroCliente: any = [];
   listaFiltroMercadoria: any = [];
   listaFiltroDestino: any = [];
   listaFiltroRota: any = [];
   filtros: any = {
      cliente: [],
      mercadoria: [],
      destino: [],
      rota: []
   };
   tipo_info: any = ['Semanal', 'Mensal', 'Anual'];
   selectedItensCliente = [];
   selectedItensDestino = [];
   selectedItensMercadoria = [];
   selectedItensRota = [];
   /***/


   constructor(
      public navigation: NavigationService,
      public UsuarioService: UsuarioService,
      private _gateway: GatewayService,
      private _clienteS: ClienteService,
      private _viagensService: ViagensService,
      private templateService: TemplateService,
      private route: ActivatedRoute

   ) {
      this.navigation.timer = 0;
      this.navigation.loaderTela = true;
      this.navigation.timer_troca_tela = 60000; // importante para funcionar corretamente a troca de tela
      this.user.showIconOpcoes = false;
      this.user.showIconFiltro = true;
      this.user.showFiltroOpcoes = false;
      this.user.showIconTemplates = true;
      this.user.showTemplates = false;
      this.visualizacao = 'Mensal';
      this.socket_io = io(environment.socket_end_point + '/' + this.socket_rota);

   }

   ngOnInit() {
      this.loadingVisible = true;
      const tipo = localStorage.getItem('tipoVisualizacao-viagem');
      const filtros = localStorage.getItem('filtros-viagem');
      const viagensConfigPie = JSON.parse(localStorage.getItem('viagensConfigPie-viagem'));
      if (tipo) {
         this.visualizacao = tipo;
      }

      if (filtros) {
         this.filtros = JSON.parse(filtros);
         this.selectedItensCliente = this.filtros.cliente;
         this.selectedItensDestino = this.filtros.destino;
         this.selectedItensMercadoria = this.filtros.mercadoria;
         this.selectedItensRota = this.filtros.rota;

         if (this.filtroCliente) {
            this.filtroCliente.selectedItems = this.filtroCliente.value = this.filtros.cliente;
         }

         if (this.filtroDestino) {
            this.filtroDestino.selectedItems = this.filtroDestino.value = this.filtros.destino;
         }

         if (this.filtroMercadoria) {
            this.filtroMercadoria.selectedItems = this.filtroMercadoria.value = this.filtros.mercadoria;
         }

         if (this.filtroRota) {
            this.filtroRota.selectedItems = this.filtroRota.value = this.filtros.rota;
         }
      }

      if (viagensConfigPie) {
         this.grafico_pizza_legenda = viagensConfigPie.grafico_pizza_legenda;
         this.grafico_pizza_label = viagensConfigPie.grafico_pizza_label;
      }
      this.socket().then(() => {
         this.navigation.trocaDash();
         this.loadingVisible = false;
         this.navigation.loaderTela = false;
      });
   }

   async socket() {
      try {
         const filtro = {
            base: (this._clienteS.clienteAtivo !== 'KMM' ? this._clienteS.clienteAtivo : environment.end_point_base_dev).toLowerCase(),
            periodo: this.visualizacao.toLowerCase()
         };
         if (this.filtros.cliente.length > 0) {
            Object.assign(filtro, {
               cliente: this.filtros.cliente
            });
         }
         if (this.filtros.destino.length > 0) {
            Object.assign(filtro, {
               destino: this.filtros.destino
            });
         }
         if (this.filtros.mercadoria.length > 0) {
            Object.assign(filtro, {
               mercadoria: this.filtros.mercadoria
            });
         }
         if (this.filtros.rota.length > 0) {
            Object.assign(filtro, {
               rota: this.filtros.rota
            });
         }

         if (this.route.snapshot.data['versao'] === 2) {
            this.socket_io.emit(this.socket_metodo + '_v2', filtro);
         } else {
            this.socket_io.emit(this.socket_metodo, filtro);
         }

         this.socket_io.on(this.socket_rota, (data) => {
            console.log('data', data);

            data.origemDestino.map((element) => {
               Object.assign(element, { 'origem': element.origem_destino.uf_origem, 'destino': element.origem_destino.uf_destino });
            });

            // AQUI DEFINE OS SELECTS COM OS DADOS ENVIADOS, PARA O FILTRO.
            const clientes = [];
            data.viagemCiente.forEach(element => {
               clientes.push(element.cliente);
            });
            const destinos = [];
            data.viagemDestino.forEach(element => {
               destinos.push(element.destino);
            });
            const mercadorias = [];
            data.viagemMercadoria.forEach(element => {
               mercadorias.push(element.mercadoria);
            });
            const rotas = [];
            data.viagemRota.forEach(element => {
               rotas.push(element.rota);
            });

            this.listaFiltroCliente = _.uniq(clientes).sort();
            this.listaFiltroDestino = _.uniq(destinos).sort();
            this.listaFiltroMercadoria = _.uniq(mercadorias).sort();
            this.listaFiltroRota = _.uniq(rotas).sort();
            // console.log('filtro:', filtro, 'data:', data);

            this.getTemplate(data);
         });
      } catch (error) {
         console.log('error => ', error);
      }
   }

   getTemplate(matriz) {
      this.org = JSON.parse(localStorage.getItem('kmm_bi-dash|' + this._clienteS.discover() + '-organizacional'));
      this.usuario = JSON.parse(localStorage.getItem('kmm_bi-dash|' + this._clienteS.discover() + '-usuario'));

      this.dash = this.usuario.listaDashboards.filter(element => {
         if (this.route.snapshot.data['versao'] === 2) {
            return element.path === 'logistica/viagens_v2';
         } else {
            return element.path === 'logistica/viagens';
         }
      });
      const parametros = {
         usuario_bi_id: this.org.usuario.usuarioBiId,
         dash_id: this.dash[0].dash_id
      };

      // console.log('parametros', parametros);
      this.templateService.backendCall(parametros, 'post', 'get').then((res: any) => {
         if (res.dados && res.dados.length > 0) {
            this.preparaLayout(res.dados, matriz)
         }
         this.loadingVisible = false;
      })
   }

   preparaLayout(tmp, matriz) {
      this.modelo_template = tmp[0].modelo_id;
      const slots = tmp[0].slots;

      for (let index = 0; index < slots.length; index++) {
         if (slots[index] > 0) {
            switch (index) {
               case 0: // slot 1
                  Object.assign(this.template, {
                     slot_1: this._viagensService.getDefinicoes(slots[index], this.visualizacao, matriz)
                  });
                  break;
               case 1: // slot 2
                  Object.assign(this.template, {
                     slot_2: this._viagensService.getDefinicoes(slots[index], this.visualizacao, matriz)
                  });
                  break;
               case 2: // slot 3
                  Object.assign(this.template, {
                     slot_3: this._viagensService.getDefinicoes(slots[index], this.visualizacao, matriz)
                  });
                  break;
               case 3: // slot 4
                  Object.assign(this.template, {
                     slot_4: this._viagensService.getDefinicoes(slots[index], this.visualizacao, matriz)
                  });
                  break;
               case 4: // slot 5
                  Object.assign(this.template, {
                     slot_5: this._viagensService.getDefinicoes(slots[index], this.visualizacao, matriz)
                  });
                  break;
               case 5: // slot 6
                  Object.assign(this.template, {
                     slot_6: this._viagensService.getDefinicoes(slots[index], this.visualizacao, matriz)
                  });
                  break;
               case 6: // slot 7
                  Object.assign(this.template, {
                     slot_7: this._viagensService.getDefinicoes(slots[index], this.visualizacao, matriz)
                  });
                  break;
               case 7: // slot 8
                  Object.assign(this.template, {
                     slot_8: this._viagensService.getDefinicoes(slots[index], this.visualizacao, matriz)
                  });
                  break;
            }
         }
      }
   }

   ngOnDestroy() {
      clearInterval(this.navigation.trocaTela);
      clearInterval(this.navigation.tempoProgress);
      this.socket_io.disconnect();
   }

   aplicaFiltro(e) {
      if (typeof (e) !== 'undefined') {
         if (e.name === 'selectedItems') {
            switch (e.element.id) {
               case 'filtroCliente':
                  this.filtros.cliente = e.value;
                  break;
               case 'filtroDestino':
                  this.filtros.destino = e.value;
                  break;
               case 'filtroMercadoria':
                  this.filtros.mercadoria = e.value;
                  break;
               case 'filtroRota':
                  this.filtros.rota = e.value;
                  break;
            }
         }
      }
   }

   filtrar() {
      localStorage.setItem('filtros-viagens', JSON.stringify(this.filtros));
      this.popFiltro.visible = false;
      this.socket();
   }
   onValueChangedVisualizacao(e) {
      localStorage.setItem('tipoVisualizacao-viagens', e.value);
      this.visualizacao = e.value;
      this.socket();
      this.popFiltro.instance.hide();
   }
   limparFiltro() {
      localStorage.removeItem('filtros-viagens');
      this.filtroCliente.instance.reset();
      this.filtroDestino.instance.reset();
      this.filtroMercadoria.instance.reset();
      this.filtroRota.instance.reset();
      this.filtrar();
   }
   customizeLabelGrafico(arg: any) {
      return arg.valueText + ' (' + arg.percentText + ')';
   }

   reciver(e) {
      if (e.mensagem) {
         this.popTemplates.instance.hide();
         location.reload();
      }
   }

   configGraficoPizza() {
      const obj = {
         grafico_pizza_legenda: this.grafico_pizza_legenda,
         grafico_pizza_label: this.grafico_pizza_label,
      };
      localStorage.setItem('viagensConfigPie-viagem', JSON.stringify(obj));
      location.reload();

   }

}
