import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';

import io from 'socket.io-client';
import { AutomatizacaoService } from '../../services/automatizacao.service';
import { Usuario, NavigationService, EstruturaOrganizacionalService, ClienteService, GatewayService } from 'src/app/shared';
import { environment } from 'src/environments/environment';
import { TemplateService } from 'src/app/shared/services/template.service';
import { DxPopupComponent } from 'devextreme-angular';

@Component({
  selector: 'app-automatizacao',
  templateUrl: './automatizacao.component.html',
  styleUrls: ['./automatizacao.component.scss']
})
export class AutomatizacaoComponent implements OnInit, OnDestroy {
  @ViewChild('popTemplates', { static: false }) popTemplates: DxPopupComponent;

  public user: Usuario = Usuario.instance;
  // Config Socket
  socket_io: any;
  socket_rota = 'automacao';
  socket_metodo = 'getAutomacao';
  socket_filtro: any;
  /***/
  loadingVisible = false;
  template: any = {};
  modelo_template = 1;
  visualizacao: any;
  org: any;
  usuario: any;
  dash: any;
  constructor(
    public navigation: NavigationService,
    public orgS: EstruturaOrganizacionalService,
    private _clienteS: ClienteService,
    private _gateway: GatewayService,
    private _automatizacaoService: AutomatizacaoService,
    private templateService: TemplateService
    // private _dummy: AutomatizacaoDummyService
  ) {
    this.navigation.loaderTela = true;
    this.navigation.hideTimeBar = false;
    this.navigation.timer_troca_tela = 120000; // importante para funcionar corretamente a troca de tela

    this.user.showIconOpcoes = false;
    this.user.showIconFiltro = false;
    this.user.showFiltroOpcoes = false;
    this.user.showIconTemplates = true;
    this.user.showTemplates = false;

    this.socket_io = io(environment.socket_end_point + '/' + this.socket_rota);
    this.socket_filtro = {
      base: (this._clienteS.clienteAtivo !== 'KMM' ? this._clienteS.clienteAtivo : environment.end_point_base_dev).toLowerCase(),
    };
  }

  ngOnInit() {
    this.socket().then(() => {
      this.navigation.trocaDash();
      this.navigation.loaderTela = false;
    });
  }

  ngOnDestroy(): void {
    this.socket_io.disconnect();
  }

  reciver(e) {
    if (e.mensagem) {
      this.popTemplates.instance.hide();
      location.reload();
    }
  }

  async socket() {
    try {
      // const data = this._dummy.getResult();
      // console.log('data', data);
      // this.getTemplate(data);

      this.loadingVisible = true;
      this.socket_io.emit(this.socket_metodo, this.socket_filtro);
      this.socket_io.on(this.socket_rota, (data) => {
        console.log('filtro', this.socket_filtro);
        console.log('retorno', data);
        this.loadingVisible = false;
        this.getTemplate(data);
      });
    } catch (error) {
      console.log('error => ', error);
    }
  }

  getTemplate(matriz) {
    this.loadingVisible = true;
    this.org = JSON.parse(localStorage.getItem('kmm_bi-dash|' + this._clienteS.discover() + '-organizacional'));
    this.usuario = JSON.parse(localStorage.getItem('kmm_bi-dash|' + this._clienteS.discover() + '-usuario'));

    this.dash = this.usuario.listaDashboards.filter(element => {
      return element.path === 'logistica/automatizacao';
    });
    const parametros = {
      usuario_bi_id: this.org.usuario.usuarioBiId,
      dash_id: this.dash[0].dash_id
    };

    // console.log('parametros', parametros);
    this.templateService.backendCall(parametros, 'post', 'get').then((res: any) => {
      if (res.dados && res.dados.length > 0) {
        this.preparaLayout(res.dados, matriz)
      }
      this.loadingVisible = false;
    })
  }

  preparaLayout(tmp, matriz) {
    this.modelo_template = tmp[0].modelo_id;
    const slots = tmp[0].slots;

    for (let index = 0; index < slots.length; index++) {
      if (slots[index] > 0) {
        switch (index) {
          case 0: // slot 1
            Object.assign(this.template, {
              slot_1: this._automatizacaoService.getDefinicoes(slots[index], matriz)
            });
            break;
          case 1: // slot 2
            Object.assign(this.template, {
              slot_2: this._automatizacaoService.getDefinicoes(slots[index], matriz)
            });
            break;
          case 2: // slot 3
            Object.assign(this.template, {
              slot_3: this._automatizacaoService.getDefinicoes(slots[index], matriz)
            });
            break;
          case 3: // slot 4
            Object.assign(this.template, {
              slot_4: this._automatizacaoService.getDefinicoes(slots[index], matriz)
            });
            break;
          case 4: // slot 5
            Object.assign(this.template, {
              slot_5: this._automatizacaoService.getDefinicoes(slots[index], matriz)
            });
            break;
          case 5: // slot 6
            Object.assign(this.template, {
              slot_6: this._automatizacaoService.getDefinicoes(slots[index], matriz)
            });
            break;
          case 6: // slot 7
            Object.assign(this.template, {
              slot_7: this._automatizacaoService.getDefinicoes(slots[index], matriz)
            });
            break;
          case 7: // slot 8
            Object.assign(this.template, {
              slot_8: this._automatizacaoService.getDefinicoes(slots[index], matriz)
            });
            break;
        }
      }
    }
  }

}
