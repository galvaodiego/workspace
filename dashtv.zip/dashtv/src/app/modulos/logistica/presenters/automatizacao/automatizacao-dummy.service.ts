import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AutomatizacaoDummyService {

  constructor() { }
  private getAcoMensal() {
    const array = [];
    for (let index = 1; index < 10; index++) {
      array.push({
        cliente: 'Cliente ' + index,
        faturamento: 10000 * index,
        fat_automatizado: 50000 * index,
        operacoes: 10 * index,
        automatizadas: 8 * index
      });

    }
    return array;
  }
  private getIntUsuario() {
    const array = [];
    for (let index = 1; index < 10; index++) {
      array.push({
        usuario: 'Usuario ' + index,
        quantidade: 100 * index
      });

    }
    return array;
  }
  private getAcoDiario() {
    const array = [];
    for (let index = 1; index < 10; index++) {
      array.push({
        data: '2020-07-20',
        total_cte: 10 * index,
        percent_automatizado: 0.10 * index,
        cte_automacao: 12 * index
      });

    }
    return array;
  }
  private getOpeAuto() {
    const array = [];
    for (let index = 1; index < 10; index++) {
      array.push({
        cliente: 'Cliente ' + index,
        operacoes_auto: 2 * index
      });

    }
    return array;
  }
  getResult() {
    return {
      indicadores: {
        total_emitido: { faturamento: 550000, quantidade: 55 },
        total_automatizado: { faturamento: 50000, quantidade: 10 },
        percent_automatizado: { porcentagem: 9.04, quantidade: 18.2 },
        tempo_emissao: '1 min e 30s'
      },
      listas: {
        acompanhamento_mensal: this.getAcoMensal(),
        integracao_por_usuario: this.getIntUsuario(),
        acompanhamento_diario: this.getAcoDiario(),
        operacoes_automatizadas: this.getOpeAuto()
      }
    };
  }
}
