import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AutomatizacaoComponent } from './automatizacao.component';

describe('AutomatizacaoComponent', () => {
  let component: AutomatizacaoComponent;
  let fixture: ComponentFixture<AutomatizacaoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AutomatizacaoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AutomatizacaoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
