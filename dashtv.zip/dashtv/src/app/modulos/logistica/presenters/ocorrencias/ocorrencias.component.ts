import { Component, OnInit, OnDestroy } from '@angular/core';
import { NavigationService, GatewayService, Usuario } from 'src/app/shared';
import SetInterval from 'set-interval';
import * as _ from 'underscore';

@Component({
   selector: 'app-ocorrencias',
   templateUrl: './ocorrencias.component.html',
   styleUrls: ['./ocorrencias.component.scss']
})
export class OcorrenciasComponent implements OnInit, OnDestroy {
   public user: Usuario = Usuario.instance;

   por_area = [];
   abertas = [];
   por_motivo = [];
   custos_gerados = [];
   finalizados = [];

   constructor(
      public navigation: NavigationService,
      private _gateway: GatewayService,
   ) {
      this.navigation.loaderTela = true;
      this.navigation.hideTimeBar = false;
      this.navigation.timer_troca_tela = 60000; // importante para funcionar corretamente a troca de tela

      this.user.showIconOpcoes = false;
      this.user.showIconFiltro = false;
      this.user.showFiltroOpcoes = false;
      this.user.showIconTemplates = false;
      this.user.showTemplates = false;
   }

   ngOnInit() {
      this.getData().then(() => { this.navigation.trocaDash(); });
   }

   ngOnDestroy() {
      SetInterval.clear('trocaTela');
      SetInterval.clear('intervalo_tabelas');
   }

   async getData() {
      try {
         const response: any = await this._gateway.backendCall('M4002', 'getOcorrenciasDash');
         console.log('response:', response);
         this.por_area = response.dash_descarga.oco_areas;
         this.abertas = response.dash_descarga.oco_abertas;
         // this.por_motivo = response.dash_descarga.oco_motivo;
         this.por_motivo = _.sortBy(response.dash_descarga.oco_motivo, 'valor').reverse();
         this.custos_gerados = response.dash_descarga.oco_custos;
         this.finalizados = response.dash_descarga.oco_finalizadas;

         this.navigation.loaderTela = false;
      } catch (error) {
         console.log(error);
      }
   }

   customizeTextLabel(arg) {
      return arg.argumentText + ': ' + arg.valueText + ' (' + arg.percentText + ')';
   }
   customizeLabel = (arg: any) => {
      return {
         customizeText(e: any) {
            if (arg.series.tag) {
               switch (arg.series.tag) {
                  case 'numero':
                     return e.value;
                     break;
                  case 'valor':
                     return 'R$ ' + e.valueText;
                     break;
               }
            } else {
               return 'R$ ' + e.valueText;
            }
         }
      };
   }

}
