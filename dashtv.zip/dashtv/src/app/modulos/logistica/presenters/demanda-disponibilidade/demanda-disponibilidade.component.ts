import { Component, OnInit } from '@angular/core';

import * as moment from 'moment';
import 'moment/locale/pt-br';
import notify from 'devextreme/ui/notify';

import { Usuario, NavigationService, UsuarioService, ClienteService } from 'src/app/shared';
import { MapaService } from 'src/app/shared/components/kmm-mapa/mapa/mapa.service';
import { Estados } from 'src/app/shared/components/kmm-mapa/entities/';
import { DadosRegiaoEstado } from 'src/app/shared/components/kmm-mapa/entities/regiaoEstado.service';
import { GoogleMapsService } from 'src/app/shared/components/kmm-mapa/mapa/maps-google.service';
import { NotificacaoService } from 'src/app/shared/services/common/notificacao.service';

@Component({
   selector: 'app-feature-logistica-demanda-disponibilidade',
   templateUrl: './demanda-disponibilidade.component.html',
   styleUrls: ['./demanda-disponibilidade.component.scss']
})
export class DemandaDisponibilidadeComponent implements OnInit {

   public user: Usuario = Usuario.instance;
   public dataHoje = '';
   public showPopupMes = false;

   // Controla a Seleção do Modo Automatico [Por Região, Por Estado, Por Região-Estado]
   public filtroModoAut = false;

   ///////////////////////////////////////
   //              ARRAYS               //
   ///////////////////////////////////////
   public markerSelecionado: any = [];
   public allMarkers: any;

   ///////////////////////////////////////
   //         ESTADOS BRASILEIROS       //
   ///////////////////////////////////////

   public estadosBrasil: Array<any> = [];
   public estadosVisiveis: Array<any> = [];
   public estadosReset: Array<any> = [];
   public estadoSelecionado: Array<any> = [];
   public estadoSelecionou = '';

   ///////////////////////////////////////
   //         REGIÕES BRASILEIRAS       //
   ///////////////////////////////////////

   public regioesBrasil: Array<any> = [];
   public regioesVisiveis: Array<any> = [];
   public regiaoSelecionado: Array<any> = [];
   public regiaoSelecionou = '';
   public regioesEstados: Array<Array<Estados>> = [];  // Possui as regiões e os seus estados

   ///////////////////////////////////////
   //              MAPA                 //
   ///////////////////////////////////////

   // Controla o Modo da Aplicação [Manual = false, Automatico = true]
   public btnTourMap = false;
   // Controla se o Mapa ta fixo na Tela
   public mapafixo = false;
   // Controla o Intervalo de Alteração dos Estados no Modo Automatico
   public intervalo: any;
   // Indice que mostra qual estado o Modo Automático deve mostrar
   public indiceEstado = 0;
   // Indice que mostra qual regiao o Modo Automático deve mostrar
   public indiceRegiao = 0;
   // Indice que mostra qual regiao e seus estados o Modo Automático deve mostrar
   public indiceRegiaoEstado = 0;

   constructor(
      public navigation: NavigationService,
      public regiaoEstado: DadosRegiaoEstado,
      public userProvider: UsuarioService,
      public mapaS: MapaService,
      public googleMaps: GoogleMapsService,
      public clienteS: ClienteService,
      private _notificacao: NotificacaoService

   ) {
      this.navigation.loaderTela = true;
      this.navigation.timer_troca_tela = 30000; // importante para funcionar corretamente a troca de tela

      this.estadosBrasil = this.regiaoEstado.getEstados(); // Recebe a lista de estados do Brasil
      this.regioesBrasil = this.regiaoEstado.getRegioes(); // Recebe a lista de regioes do Brasil
      this.eventEstadoLotes(); // Chama os Estados que possuem Lotes
      this.eventIndicadoresSelecionado(); // Recebe as Informações do Marker Selecionado no Mapa
      this.dataHoje = moment().format('LL');
   }

   ngOnInit() { }

   customizePointGrafico(pointInfo: any) {
      if (pointInfo.argument == 'Viagens agendadas') {
         return { color: '#45b854' };
      } else if (pointInfo.argument == 'Solicitação sem Agendamento') {
         return { color: '#fd9a18' };
      } else if (pointInfo.argument == 'Canceladas') {
         return { color: '#ed1c24' };
      }
   }

   customizeLabelGrafico(arg: any) {
      return arg.percentText;
   }




   ///////////////////////////////////////////////////
   //             ATUALIZAÇÃO AUTOMATICA            //
   ///////////////////////////////////////////////////

   /**
   * Atualiza a Tela da Aplicação
   */
   public atualizaTela() {
      clearInterval(this.navigation.trocaTela);
      clearInterval(this.navigation.tempoProgress);
      this.googleMaps.marcadores = [];
      this.googleMaps.mirrorMarcadores = [];
      // this.mapaS.getMapa();
      this.countIndicadores(this.allMarkers);
   }

   ///////////////////////////////////////
   //          MAPA E TOURMAP           //
   ///////////////////////////////////////

   /**
   * Controla se o mapa esta no Modo automatico
   */
   public tourMapControl() {
      this.btnTourMap = !this.btnTourMap;
      this.indiceEstado = 0;
      if (typeof (this.intervalo) === 'undefined') {
         return;
      } else {
         clearInterval(this.intervalo);
      }
   }

   /**
   * Modo Automático do Mapa, Navega pelos Estados ou Por Regioes
   * @param  selecao | estado, regiao, região-estado
   */
   public tourMap(selecao) {
      this._notificacao.toast('Será feito um Tour por ' + selecao.toUpperCase() + ' mostrando os lotes disponíveis.');
      setTimeout(() => {
         this._notificacao.toast('Carregando...', 12000);
      }, 3000);

      if (selecao == 'estado') {
         this.intervalo = setInterval(() => {
            let estado: any = {};
            estado = this.setVisibleTileMapEstado(this.indiceEstado);
            this.prepareZoomMapa(estado.lat, estado.lng, estado.sigla, estado.zoom);
            this.countIndicadores(1, estado.sigla, estado.descricao);
         }, 15000);
      } else if (selecao == 'regiao') {
         this.intervalo = setInterval(() => {
            let regiao: any = {};
            regiao = this.setVisibleTileMapRegiao(this.indiceRegiao);
            this.prepareZoomMapa(regiao.lat, regiao.lng, regiao.sigla, regiao.zoom);
            this.countIndicadores(2, regiao.sigla, regiao.descricao);
         }, 15000);
      } else {
         this.intervalo = setInterval(() => {
            this.regioesVisiveis.forEach(
               (regiao) => {
                  const estados = this.estadosVisiveis.filter(
                     (estado) => estado.regiao == regiao.sigla
                  );
                  this.regioesEstados.push(estados);
               }
            );

            let estado: any = {};
            estado = this.findEstado();
            this.setNewEstadosVisiveis();
            this.prepareZoomMapa(estado.lat, estado.lng, estado.sigla, estado.zoom);
            this.regiaoSelecionou = estado.regiao;
            this.countIndicadores(1, estado.sigla, estado.descricao);
            if (this.indiceEstado == this.regioesEstados[this.indiceRegiao].length - 1) {
               if (this.indiceRegiao == this.regioesEstados.length - 1) {
                  this.indiceRegiao = 0;
                  this.indiceEstado = 0;
               } else {
                  this.indiceRegiao++;
                  this.indiceEstado = 0;
               }
            } else {
               this.indiceEstado++;
            }
         }, 7000);
      }

   }

   public findEstado() {
      return this.regioesEstados[this.indiceRegiao][this.indiceEstado];
   }

   /**
    * Controla o Indice do TourMap
    * @param atual indice
    */
   public setVisibleTileMapEstado(atual: number) {
      if (this.indiceEstado == this.estadosVisiveis.length - 1) {
         this.indiceEstado = 0;
      } else {
         this.indiceEstado++;
      }
      return this.estadosVisiveis[atual];
   }

   /**
    * Controla o Indice do TourMap das Regiões
    * @param atual indice
    */
   public setVisibleTileMapRegiao(atual: number) {
      if (this.indiceRegiao == this.regioesBrasil.length - 1) {
         this.indiceRegiao = 0;
      } else {
         this.indiceRegiao++;
      }
      return this.regioesBrasil[atual];
   }

   /**
   * Envio para o Service o Estado Selecionado
   * @param estado | Estado Selecionado
   */
   public prepareZoomMapa(lat, lng, sigla, zoom) {
      this.estadoSelecionou = sigla;
      this.regiaoSelecionou = sigla;
      this.estadoSelecionado = [lat, lng, zoom];
      return this.googleMaps.dispatcherZoom.emit(this.estadoSelecionado);
   }

   /**
    * Seta o Estado Visiveis conforme a Regiao Selecionada
    */
   public setNewEstadosVisiveis() {
      this.estadosVisiveis = this.regioesEstados[this.indiceRegiao];
   }

   /*
   * Recebe os Estados que Possuem Lotes
   */
   public eventEstadoLotes() {
      // evento que recebe os estados que possuem lotes
      this.googleMaps.dispatcherEstados.subscribe(
         (item: Array<any>) => {
            this.estadosReset = item;
            item = item.filter(
               (el) => {
                  return (el.length > 0);
               }
            );
            this.estadosVisiveis = this.estadosBrasil.filter(
               (estado) => {
                  return item.some(
                     (el) => el === estado.sigla
                  );
               }
            );

            /**
             * ESSE AQUI PODE SACAR FORA QUANDO O BANCO JA RETORNAR A REGIÃO.
             */
            this.estadosVisiveis.forEach(
               (el, index, oArray) => {
                  let obj = {};
                  obj = this.estadosBrasil.find(estado => estado.sigla == el.sigla);
                  oArray[index] = Object.assign(el, obj);
               }
            );
            this.regioesVisiveis = this.regioesBrasil.filter(
               (regiao) => {
                  return this.estadosVisiveis.some(
                     (el) => el.regiao === regiao.sigla
                  );
               }
            );
         }
      );
   }

   /*
   * Recebe as regioes que Possuem Lotes
   */
   public eventRegiaoLotes() {
      // evento que recebe as regiões que possuem lotes
      this.googleMaps.dispatcherRegiao.subscribe(
         (item: Array<any>) => {
            item = item.filter(
               (el) => {
                  return (el.length > 0);
               }
            );
            this.regioesVisiveis = this.regioesBrasil.filter(
               (regiao) => {
                  return item.some(
                     (el) => el === regiao.sigla
                  );
               }
            );
         }
      );
   }

   public resetaEstados() {
      this.estadosVisiveis = this.estadosBrasil.filter(
         (estado) => {
            return this.estadosReset.some(
               (el) => el === estado.sigla
            );
         }
      );
   }


   /**
   * Mata a execução do Modo Automático
   * -- Limpa o SetInterval do Tour
   * -- Ajusta o Zoom do Mapa para ver o mapa completo do Brasil
   * -- Traz os Indicadores Default (Empresa)
   * -- Fecha os Menus Laterais
   */
   public exitModoAutomatico() {
      this.markerSelecionado = [];
      this.btnTourMap = false;
      this.estadoSelecionou = '';
      this.regiaoSelecionou = '';
      this.indiceEstado = 0;
      this.indiceRegiao = 0;
      this.resetaEstados();
      this.googleMaps.showMarkerDetalhes = false;
      this.googleMaps.limpaFiltros();
      clearInterval(this.intervalo);
   }



   ///////////////////////////////////////
   //           INDICADORES             //
   ///////////////////////////////////////

   /**
   *  Indicadores recebem os valores da Empresa
   *  enquanto não tem estado ou Região selecionada
   * @param flag 1 - Estado Selecionado, 2 Regiao Selecionada
   * @param item :: Estado ou Regiao Selecionada
   */
   public countIndicadores(flag?, item?, descricao?) {
      let meuArray = [];

      if (flag == 1) {
         meuArray = this.allMarkers.filter(el => el.uf_coleta.toLowerCase() === item.toLowerCase());
      } else if (flag == 2) {
         meuArray = [];
         let estado;
         estado = this.estadosBrasil.filter(el => el.regiao.toLowerCase() === item.toLowerCase());
         this.allMarkers.forEach(
            (el) => {
               estado.forEach(
                  (it) => {
                     if (el.uf_coleta === it.sigla) {
                        meuArray.push(el);
                     }
                  }
               );
            }
         );
      } else {
         meuArray = this.allMarkers;
      }

   }

   /**
    * Indicadores Recebem os Dados do Lote Selecionado no Mapa
    */
   public eventIndicadoresSelecionado() {
      this.googleMaps.dispatcherMarker.subscribe(
         (item: any) => {
            this.navigation.loaderTela = false;
            this.markerSelecionado = item;
         }
      );
   }


}
