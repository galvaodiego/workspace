import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DemandaDisponibilidadeComponent } from './demanda-disponibilidade.component';

describe('DemandaDisponibilidadeComponent', () => {
  let component: DemandaDisponibilidadeComponent;
  let fixture: ComponentFixture<DemandaDisponibilidadeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DemandaDisponibilidadeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DemandaDisponibilidadeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
