import { Component, OnInit, OnDestroy } from '@angular/core';

import { Usuario, NavigationService, GatewayService } from 'src/app/shared';

import * as moment from 'moment';
import 'moment/locale/pt-br';
import SetInterval from 'set-interval';


// import * as $ from 'jquery';
// import 'jquery-knob';

@Component({
    selector: 'app-metas',
    templateUrl: './metas.component.html',
    styleUrls: ['./metas.component.scss']
})
export class MetasComponent implements OnInit, OnDestroy {

    public user: Usuario = Usuario.instance;

    public dataHoje: string;

    public dataSourceFat: any;
    public dataSourceTon: any;

    public indicadores: any;

    public operacaoFat: any;
    public operacaoTon: any;
    public listaTendencia: any;

    //Troca de Graficos
    public interval: any;
    public tabGrafico: string = 'fat';

    constructor(
        public navigation: NavigationService,
        private _gateway: GatewayService
    ) {
        this.dataHoje = moment().format('DD/MM');
        this.navigation.loaderTela = true;
        this.user.showIconOpcoes = false;
    }

    ngOnInit() { }

    ngOnDestroy() {
      SetInterval.clear('trocaTela');
      SetInterval.clear('intervalo_tabelas');
    }


    async getData() {
        try {
            const response: any = await this._gateway.backendCall('M4002', 'getAcompLogistico');
            this.navigation.loaderTela = false;
            this.dataSourceFat = response.tabela[0][0]; // Faturamento Diário da Empresa
            this.operacaoFat = response.tabela[0][1]; // Faturamento das Operações 
            this.dataSourceTon = response.tabela[1][0]; // Tonelagem Diária da Empresa
            this.operacaoTon = response.tabela[1][1]; // Tonelagem das Operações
            this.indicadores = response.tabela[2]; // Indicadores Gerais
            this.listaTendencia = response.tabela[1][2];  // Tendencia das Operações (Faturamento e Tonelagem)

            // //Inicializa o Gauge
            // $(function () {
            //     $(".knob").knob();
            // });

        } catch (error) {
            console.log(error);
        }

    }

    /**
    * Customiza o Label de Cada Barra
    */
    public customizeLabelFat = (arg: any) => {
        return {
            visible: true,
            customizeText: function (e: any) {
                return 'R$ ' + e.valueText;
            }
        };
    }


    /**
     * REALIZA A ALTERNÂNCIA ENTRE OS ESTOQUES
   */
    public switchTabs() {
        this.interval = setInterval(
            tabs => {
                if (this.tabGrafico == 'fat') {
                    this.tabGrafico = 'ton'
                } else if (this.tabGrafico == 'ton') {
                    this.tabGrafico = 'fat'
                }
            }, 150000);
    }

}
