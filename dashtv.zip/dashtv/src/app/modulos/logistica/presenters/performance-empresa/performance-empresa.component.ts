import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { Usuario, NavigationService, GatewayService } from 'src/app/shared';
import { DxPopupComponent } from 'devextreme-angular';

@Component({
   selector: 'app-performance-empresa',
   templateUrl: './performance-empresa.component.html',
   styleUrls: ['./performance-empresa.component.scss']
})
export class PerformanceEmpresaComponent implements OnInit {
   @ViewChild('popFiltro', { static: false }) popFiltro: DxPopupComponent;
   public user: Usuario = Usuario.instance;
   datasource: Array<any>;
   tipoRomaneio: string;
   showPop = false;
   loadingVisible = false;
   dadosRomaneio = [];
   opcoesFiltro = [];

   filtroForm: FormGroup;
   parametros = {
      operacao: null
   };
   operacaoAtiva = [];

   constructor(
      public navigation: NavigationService,
      private _gateway: GatewayService,
      private _formBuilder: FormBuilder
   ) {
      this.navigation.loaderTela = true;
      this.navigation.hideTimeBar = false;
      this.navigation.timer_troca_tela = 30000; // importante para funcionar corretamente a troca de tela

      this.user.showIconOpcoes = false;
      this.user.showIconFiltro = true;
      this.user.showFiltroOpcoes = false;
      this.user.showIconTemplates = false;
      this.user.showTemplates = false;

      this.filtroForm = this._formBuilder.group({
         operacao: new FormControl({ value: null })
      });
   }

   ngOnInit() {
      this.getOpcoesFiltro();
      this.getData().then(() => { this.navigation.trocaDash(); });
   }

   async getData() {
      try {
         const ls = JSON.parse(localStorage.getItem('perf-empresa-filtro'));
         if (ls) {
            if (ls.operacao) {
               this.filtroForm.get('operacao').setValue(ls.operacao);
            }

            this.parametros = ls;
         }
         const response: any = await this._gateway.backendCall('M4002', 'getPerfomanceEmpresa', this.parametros);
         console.log('response:', response);
         this.datasource = response.PerformanceEmpresa[0];
         this.operacaoAtiva = this.opcoesFiltro.filter(e => {
            return e.valor === this.parametros.operacao;
         });
         this.navigation.loaderTela = false;



      } catch (error) {
         console.log(error);
      }
   }

   async getOpcoesFiltro() {
      try {
         const response: any = await this._gateway.backendCall('M4002', 'getFiltroPerformanceEmpresa');
         // console.log('response-filtro:', response);
         this.opcoesFiltro = response.filtro;
      } catch (error) {
         console.log(error);
      }
   }

   async getRomaneios(origem: number) {
      try {
         this.loadingVisible = true;
         const response: any = await this._gateway.backendCall('M4002', 'getPerfomanceLista', { tipo_data: origem });
         console.log(response.lista);
         this.dadosRomaneio = response.lista;
         this.tipoRomaneio = (origem === 1 ? 'Hoje' : 'Mensal');
         this.loadingVisible = false;
         this.showPop = true;
      } catch (error) {
         console.log('getRomaneios ERROR:', error);
      }
   }


   getColor(valor) {
      if (valor < 90) {
         return '#ac0202';
      } else if (valor > 90 && valor < 95) {
         return '#fbff05';
      } else {
         return '#669966';
      }
   }


   aplicar() {
      const filtro = this.filtroForm.value;
      if (filtro.operacao) {
         Object.assign(this.parametros, {
            operacao: filtro.operacao
         });
      }
      localStorage.setItem('perf-empresa-filtro', JSON.stringify(this.parametros));
      this.popFiltro.instance.hide();
      this.navigation.loaderTela = true;
      this.getData();
   }

   limpar() {
      localStorage.removeItem('perf-empresa-filtro');
      this.parametros = { operacao: null };
      this.resetForm();
      this.popFiltro.instance.hide();
      this.navigation.loaderTela = true;
      this.getData();
   }

   resetForm() {
      this.filtroForm = this._formBuilder.group({
         operacao: new FormControl({ value: null })
      });
   }

}
