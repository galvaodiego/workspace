import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DisponibilidadeMotoristasComponent } from './disponibilidade-motoristas.component';

describe('DisponibilidadeMotoristasComponent', () => {
  let component: DisponibilidadeMotoristasComponent;
  let fixture: ComponentFixture<DisponibilidadeMotoristasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DisponibilidadeMotoristasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DisponibilidadeMotoristasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
