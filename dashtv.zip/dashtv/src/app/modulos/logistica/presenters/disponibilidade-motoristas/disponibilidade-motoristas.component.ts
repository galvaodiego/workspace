import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import SetInterval from 'set-interval';
import { Usuario, NavigationService, GatewayService } from 'src/app/shared';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { DxDataGridComponent } from 'devextreme-angular';

@Component({
   selector: 'app-disponibilidade-motoristas',
   templateUrl: './disponibilidade-motoristas.component.html',
   styleUrls: ['./disponibilidade-motoristas.component.scss']
})
export class DisponibilidadeMotoristasComponent implements OnInit, OnDestroy {
   @ViewChild('tabela', { static: false }) tabela: DxDataGridComponent;

   public user: Usuario = Usuario.instance;
   cardList = [];
   gridDataSource = null;

   // config Multiview
   views: Array<any>;
   porPagina = 5;
   pages = 0;
   // fim -- config Multiview
   index_tabela = 0;
   constructor(
      public navigation: NavigationService,
      private _gateway: GatewayService,
      iconRegistry: MatIconRegistry,
      sanitizer: DomSanitizer
   ) {
      this.navigation.loaderTela = true;
      this.navigation.hideTimeBar = false;
      this.navigation.timer_troca_tela = 120000; // importante para funcionar corretamente a troca de tela

      this.user.showIconOpcoes = false;
      this.user.showIconFiltro = false;
      this.user.showFiltroOpcoes = false;
      this.user.showIconTemplates = false;
      this.user.showTemplates = false;
      iconRegistry.addSvgIcon('map', sanitizer.bypassSecurityTrustResourceUrl('assets/images/svg/map.svg'));
      iconRegistry.addSvgIcon('calendar-clock', sanitizer.bypassSecurityTrustResourceUrl('assets/images/svg/calendar-clock.svg'));
   }

   ngOnInit() {
      this.getData().then(() => { this.navigation.trocaDash(); });
      setInterval(() => {
         this.trocaPagina();
      }, 30000);
   }

   trocaPagina() {
      // tabela
      if (this.tabela) {
         const total_pd = this.tabela.instance.pageCount();
         if (total_pd > 1) {
            if (this.index_tabela === total_pd - 1) {
               this.index_tabela = 0;
            } else {
               this.index_tabela++;
            }
            this.tabela.instance.pageIndex(this.index_tabela);
         }
      }
   }

   ngOnDestroy() {
      SetInterval.clear('trocaTela');
   }

   async getData() {
      try {
         const response: any = await this._gateway.backendCall('M4002', 'getMotoristaDash');
         console.log('response:', response);
         if (response) {
            this.gridDataSource = response.motorista_disp;
         }
         this.navigation.loaderTela = false;
      } catch (error) {
         this.navigation.loaderTela = false;
         console.log(error);
      }
   }



   paginate(array, page_size, page_number) {
      --page_number; // because pages logically start with 1, but technically with 0
      return array.slice(page_number * page_size, (page_number + 1) * page_size);
   }

   gridDataSourcePrep(e) {
      if (e.rowType === 'header') {
         e.cellElement.style.paddingTop = '15px';
         e.cellElement.style.paddingBottom = '15px';
         e.cellElement.style.fontSize = '35px';
         e.cellElement.style.lineHeight = '35px';

      }

      if (typeof (e.data) !== 'undefined') {
         e.cellElement.style.paddingTop = '15px';
         e.cellElement.style.paddingBottom = '15px';
         e.cellElement.style.color = '#ffffff';
         if (e.data.modalidade === 'FROTA') {
            e.cellElement.style.backgroundColor = '#1d62a1';
         } else {
            e.cellElement.style.backgroundColor = '#216d03';
         }
         e.cellElement.style.fontSize = '40px';

      }
   }

}
