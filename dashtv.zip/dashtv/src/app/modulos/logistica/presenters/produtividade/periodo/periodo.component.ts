import { Component, OnInit, Input } from '@angular/core';

@Component({
   selector: 'app-periodo',
   templateUrl: './periodo.component.html',
   styleUrls: ['./periodo.component.scss']
})
export class PeriodoComponent implements OnInit {
   @Input() dados: any;
   colorChart = [
      '#FB7764',
      '#73D47F',
      '#FED85E',
      '#D47683',
      '#DDE392',
      '#757AB2',
      '#4DDAC1',
      '#F4C99A',
      '#80DD9B',
      '#F998B3',
      '#4AAAA0',
      '#A5AEF1',
   ];
   constructor() { }

   ngOnInit() {
   }

   customizeLabelPeriodo(e) {
      console.log(e);
      return e.seriesName;
   }

   onCellPrepared(e: any) {
      if (e.rowType === 'header') {
         e.cellElement.style.paddingTop = '5px';
         e.cellElement.style.paddingBottom = '5px';
         e.cellElement.style.fontSize = '1rem';
      }

      if (typeof (e.data) !== 'undefined') {
         e.cellElement.style.paddingTop = '5px';
         e.cellElement.style.paddingBottom = '5px';
         e.cellElement.style.fontSize = '1.5rem';
      }

   }

}
