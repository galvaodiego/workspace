import { Component, OnInit, Input } from '@angular/core';

@Component({
   selector: 'app-empresa',
   templateUrl: './empresa.component.html',
   styleUrls: ['./empresa.component.scss']
})
export class EmpresaComponent implements OnInit {
   @Input() dados: any;

   constructor() { }

   ngOnInit() {
   }

}
