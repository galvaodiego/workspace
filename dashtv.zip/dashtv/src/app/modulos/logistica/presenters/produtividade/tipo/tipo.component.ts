import { Component, OnInit, Input } from '@angular/core';

@Component({
   selector: 'app-tipo',
   templateUrl: './tipo.component.html',
   styleUrls: ['./tipo.component.scss']
})
export class TipoComponent implements OnInit {
   @Input() dados: any;

   constructor() {}

   ngOnInit() {}

}
