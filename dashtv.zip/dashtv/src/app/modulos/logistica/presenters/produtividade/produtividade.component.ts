import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { Usuario, NavigationService, EstruturaOrganizacionalService, GatewayService, ClienteService } from 'src/app/shared';
import { environment } from 'src/environments/environment';

import io from 'socket.io-client';
import * as moment from 'moment';
import { NotificacaoService } from 'src/app/shared/services/common/notificacao.service';
import { DxPopupComponent } from 'devextreme-angular';
import { ActivatedRoute } from '@angular/router';
@Component({
   selector: 'app-produtividade',
   templateUrl: './produtividade.component.html',
   styleUrls: ['./produtividade.component.scss']
})
export class ProdutividadeComponent implements OnInit, OnDestroy {
   @ViewChild('popFiltro', { static: false }) popFiltro: DxPopupComponent;
   public user: Usuario = Usuario.instance;
   total_empresa = {
      descricao: '',
      total_realizado: 0,
      total_previsto: 0,
      percentual: 0
   };
   total_coordenador: any = [];
   loadingVisible = true;

   // Config Socket
   socket_io: any;
   socket_rota = 'produtividade';
   socket_metodo = 'getProdutividade';
   socket_filtro: any;
   /***/


   // Filtro
   minDate = new Date(2019, 0, 1);
   maxDate = new Date();
   currentDate = new Date();
   /***/

   datasource: object = {};
   origem = 1;

   constructor(
      public navigation: NavigationService,
      public orgS: EstruturaOrganizacionalService,
      private _clienteS: ClienteService,
      private _notificacao: NotificacaoService,
      private route: ActivatedRoute,


   ) {
      this.navigation.loaderTela = true;
      this.navigation.hideTimeBar = false;
      this.navigation.timer_troca_tela = 60000; // importante para funcionar corretamente a troca de tela

      this.user.showIconOpcoes = false;
      this.user.showIconFiltro = false;
      this.user.showFiltroOpcoes = false;
      this.user.showIconTemplates = false;
      this.user.showTemplates = false;

      this.socket_io = io(environment.socket_end_point + '/' + this.socket_rota);
      this.socket_filtro = {
         base: (this._clienteS.clienteAtivo !== 'KMM' ? this._clienteS.clienteAtivo : environment.end_point_base_dev).toLowerCase(),
      };

   }

   ngOnInit() {
      this.loadingVisible = true;

      this.socket().then(() => {
         this.navigation.trocaDash();
         this.navigation.loaderTela = false;
      });
   }

   ngOnDestroy(): void {
      this.socket_io.disconnect();
   }

   async socket() {
      this.route.data.subscribe(v => {
         this.origem = v.tipo;
      });

      Object.assign(this.socket_filtro, {
         empresa: (this.origem - 1)
      });
      try {
         this.socket_io.emit(this.socket_metodo, this.socket_filtro);
         this.socket_io.on(this.socket_rota, (data) => {
            console.log('parametros', this.socket_filtro, 'data', data, 'this.origem', this.origem);

            if (data.TotalEmpresa.length > 0) {
               let percentual_empresa = (data.TotalEmpresa[0].valor / data.TotalEmpresa[0].meta) * 100;
               if (percentual_empresa > 100) {
                  percentual_empresa = 100;
               }
               Object.assign(data.TotalEmpresa[0], {
                  percentual: percentual_empresa
               });
               this.total_coordenador = this.calculoPercentual(data.ProdutividadePeriodo);
               this.total_empresa = data.TotalEmpresa[0];
               Object.assign(this.datasource, {
                  total_coordenador: this.total_coordenador,
                  total_empresa: this.total_empresa
               });

               if (this.origem === 3) {
                  this.datasource = {
                     mapeamento: ['Usuário 01', 'Usuário 02', 'Usuário 03'],
                     lista: [
                        {
                           periodo: 'Jan',
                           meta0: 1000,
                           meta1: 2000,
                           meta2: 3000,
                           realizado0: 3000,
                           realizado1: 2000,
                           realizado2: 1000,
                        },
                        {
                           periodo: 'Fev',
                           meta0: 1000,
                           meta1: 2000,
                           meta2: 3000,
                           realizado0: 3000,
                           realizado1: 2000,
                           realizado2: 1000,
                        },
                        {
                           periodo: 'Mar',
                           meta0: 1000,
                           meta1: 2000,
                           meta2: 3000,
                           realizado0: 3000,
                           realizado1: 2000,
                           realizado2: 1000,
                        },
                        {
                           periodo: 'Abr',
                           meta0: 1000,
                           meta1: 2000,
                           meta2: 3000,
                           realizado0: 3000,
                           realizado1: 2000,
                           realizado2: 1000,
                        },
                        {
                           periodo: 'Mai',
                           meta0: 1000,
                           meta1: 2000,
                           meta2: 3000,
                           realizado0: 3000,
                           realizado1: 2000,
                           realizado2: 1000,
                        },
                        {
                           periodo: 'Jun',
                           meta0: 1000,
                           meta1: 2000,
                           meta2: 3000,
                           realizado0: 3000,
                           realizado1: 2000,
                           realizado2: 1000,
                        },
                        {
                           periodo: 'Jul',
                           meta0: 1000,
                           meta1: 2000,
                           meta2: 3000,
                           realizado0: 3000,
                           realizado1: 2000,
                           realizado2: 1000,
                        },
                        {
                           periodo: 'Ago',
                           meta0: 1000,
                           meta1: 2000,
                           meta2: 3000,
                           realizado0: 3000,
                           realizado1: 2000,
                           realizado2: 1000,
                        },
                        {
                           periodo: 'Set',
                           meta0: 1000,
                           meta1: 2000,
                           meta2: 3000,
                           realizado0: 3000,
                           realizado1: 2000,
                           realizado2: 1000,
                        },
                        {
                           periodo: 'Out',
                           meta0: 1000,
                           meta1: 2000,
                           meta2: 3000,
                           realizado0: 3000,
                           realizado1: 2000,
                           realizado2: 1000,
                        },
                        {
                           periodo: 'Nov',
                           meta0: 14000,
                           meta1: 24000,
                           meta2: 34000,
                           realizado0: 34000,
                           realizado1: 24000,
                           realizado2: 14000,
                        },
                        {
                           periodo: 'Dez',
                           meta0: 10000,
                           meta1: 20000,
                           meta2: 30000,
                           realizado0: 3000,
                           realizado1: 2000,
                           realizado2: 1000,
                        },
                     ]
                  };
               }
            } else {
               this._notificacao.toast('Nenhuma informação encontrada', 'error');
            }
            this.loadingVisible = false;

         });
      } catch (error) {
         console.log('error => ', error);
      }
   }

   calculoPercentual(data: Array<any>) {
      data.map((e) => {
         const a = (e.valor / e.meta) * 100;
         e.percentual = (a > 100 ? 100 : a);
      });

      return data;
   }

   changeMes(e) {
      if (e.name === 'value') {
         console.log('alterou o mes:', moment(e.value).format('DD/MM/YYYY'));
         Object.assign(this.socket_filtro, {
            mes: moment(e.value).format('DD/MM/YYYY')
         });
         this.socket_io.emit(this.socket_metodo, this.socket_filtro);
         this.popFiltro.instance.hide();
      }
   }

   customizeText(arg: any) {
      return arg.valueText + ' %';
   }

}
