import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Descargav2Component } from './descargav2.component';

describe('Descargav2Component', () => {
  let component: Descargav2Component;
  let fixture: ComponentFixture<Descargav2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Descargav2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Descargav2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
