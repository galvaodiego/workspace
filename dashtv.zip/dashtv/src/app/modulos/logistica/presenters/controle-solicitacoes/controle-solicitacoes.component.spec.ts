import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ControleSolicitacoesComponent } from './controle-solicitacoes.component';

describe('ControleSolicitacoesComponent', () => {
  let component: ControleSolicitacoesComponent;
  let fixture: ComponentFixture<ControleSolicitacoesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ControleSolicitacoesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ControleSolicitacoesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
