import { Component, OnInit, OnDestroy } from '@angular/core';

import { Usuario, NavigationService } from 'src/app/shared';

import * as moment from 'moment';
import 'moment/locale/pt-br';

@Component({
   selector: 'app-controle-solicitacoes',
   templateUrl: './controle-solicitacoes.component.html',
   styleUrls: ['./controle-solicitacoes.component.scss']
})
export class ControleSolicitacoesComponent implements OnInit, OnDestroy {

   public user: Usuario = Usuario.instance;

   public dataHoje = '';
   public dataSolicitacoes: any = [];
   public dataEmissoes: any = [];
   public dataResumoSegmentos: any = [];
   public listaNotasAguardando: any = [];

   constructor(
      public navigation: NavigationService,
   ) {
      this.navigation.timer_troca_tela = 30000; // importante para funcionar corretamente a troca de tela
   }

   ngOnInit() {
      this.navigation.loaderTela = false;
      this.dataHoje = moment().format('DD/MM/YYYY');
      this.getDados();
   }

   ngOnDestroy() { }


   public getDados() {
      this.dataSolicitacoes = [
         {
            'descricao': '6h00',
            'criada': 3,
            'atendida': 2
         },
         {
            'descricao': '7h00',
            'criada': 7,
            'atendida': 7
         },
         {
            'descricao': '8h00',
            'criada': 4,
            'atendida': 4
         },
         {
            'descricao': '9h00',
            'criada': 6,
            'atendida': 5
         },
         {
            'descricao': '10h00',
            'criada': 15,
            'atendida': 12
         },
         {
            'descricao': '11h00',
            'criada': 8,
            'atendida': 4
         }
      ];


      this.dataEmissoes = [
         {
            'descricao': 'Emitido',
            'val': 50
         }, {
            'descricao': 'Aguardando Emissão',
            'val': 80
         }
      ];

      this.dataResumoSegmentos = [
         {
            'descricao': 'ADITIVO EM PO BIO',
            'qtde_nf': 5,
            'qtde_solic': 10,
            'qtde_emissao': 2,
         },
         {
            'descricao': 'CONTAINER',
            'qtde_nf': 4,
            'qtde_solic': 10,
            'qtde_emissao': 2,
         },
         {
            'descricao': 'EXPORTAÇÃO BIO',
            'qtde_nf': 7,
            'qtde_solic': 10,
            'qtde_emissao': 2,
         },
         {
            'descricao': 'GRANEIS LIQUIDOS',
            'qtde_nf': 3,
            'qtde_solic': 10,
            'qtde_emissao': 2,
         },
         {
            'descricao': 'LIQUIDO BIO',
            'qtde_nf': 9,
            'qtde_solic': 10,
            'qtde_emissao': 2,
         },
         {
            'descricao': 'MERCADO INTERNO',
            'qtde_nf': 16,
            'qtde_solic': 10,
            'qtde_emissao': 2,
         }
      ];


      this.listaNotasAguardando = [
         {
            'num_nf': 154541,
            'data_emissao': '14/01/2019',
            'destinatario': 'CJ LOGISTICS',
            'produto': 'SOJA',
            'valor': 5412
         },
         {
            'num_nf': 154540,
            'data_emissao': '14/01/2019',
            'destinatario': 'CJ LOGISTICS',
            'produto': 'SOJA',
            'valor': 9587
         },
         {
            'num_nf': 154539,
            'data_emissao': '14/01/2019',
            'destinatario': 'CJ LOGISTICS',
            'produto': 'SOJA',
            'valor': 7889
         }
      ];


   }

   /**
    * Customiza o Valor do Label
    * @param arg argumentos do Evento
    */
   customizeLabelEmissao(arg: any) {
      return arg.valueText + ' (' + arg.percentText + ')';
   }

}
