import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';

import { Usuario, GatewayService, NavigationService } from 'src/app/shared';
import SetInterval from 'set-interval';
import { DxDataGridComponent } from 'devextreme-angular';
import * as _ from 'underscore';


@Component({
   selector: 'app-feature-logistica-parqueamento',
   templateUrl: './parqueamento.component.html',
   styleUrls: ['./parqueamento.component.scss']
})
export class ParqueamentoComponent implements OnInit, OnDestroy {
   @ViewChild('parqueamentoGrid', { static: false }) parqueamentoGrid: DxDataGridComponent;

   public user: Usuario = Usuario.instance;

   public totalParqueados: number;

   // Arrays
   public ativoReferencia: any = [];
   public listaParqueados: any = [];
   public listaIndicadores: Array<any> = [];
   index_parqueamentoGrid = 0;

   constructor(
      public navigation: NavigationService,
      private _gateway: GatewayService
   ) {
      this.navigation.loaderTela = true;
      this.navigation.timer_troca_tela = 60000; // importante para funcionar corretamente a troca de tela

   }

   ngOnInit() {
      this.getData().then(() => {
         this.navigation.trocaDash();
         SetInterval.start(() => {
            this.trocaPagina();
         }, 5000, 'intervalo_tabelas');
      });
   }

   ngOnDestroy() {
      SetInterval.clear('trocaTela');
      SetInterval.clear('intervalo_tabelas');
   }

   /**
   * Resgata os dados da Base
   * @returns {Promise<any>} - retorna a chamada do backendCall.
   */
   public async getData(): Promise<any> {
      return this._gateway.backendCall('M4002', 'getParqueamento').then(
         (result: any) => {
            console.log('data:', result);

            this.navigation.loaderTela = false;
            result.parqueados.grafico.map((x) => {
               x.valor = Number(x.valor);
            });
            this.ativoReferencia = _.sortBy(result.parqueados.grafico, 'valor');
            this.listaParqueados = result.parqueados.lista;
            this.listaIndicadores = result.parqueados.indicadores;

            this.totalParqueados = this.listaIndicadores
               .map((tupla, index) => {
                  if (index <= 3) {
                     return Number.parseFloat(tupla['valor']);
                  } else {
                     return 0;
                  }
               })
               .reduce((anterior, atual) => {
                  return (anterior + atual);
               }, 0);

         }
      );
   }

   customizeLabel(point: any) {

      if (point.argument.toLowerCase() === 'others' || point.argumentText.toLowerCase() === 'others') {
         return 'Outros: ' + point.valueText;
      } else {
         return point.argumentText + ': ' + point.valueText;
      }
   }

   customizeLabel2(arg: any) {
      return arg.valueText + ' (' + arg.percentText + ')';
   }

   customizeLegend(arg: any) {
      if (arg.pointName.toLowerCase() === 'others') {
         return 'Outros';
      } else {
         return arg.pointName;
      }
   }

   trocaPagina() {
      if (this.parqueamentoGrid) {
         const total_pd = this.parqueamentoGrid.instance.pageCount();
         if (total_pd > 1) {
            if (this.index_parqueamentoGrid === total_pd - 1) {
               this.index_parqueamentoGrid = 0;
            } else {
               this.index_parqueamentoGrid++;
            }
            this.parqueamentoGrid.instance.pageIndex(this.index_parqueamentoGrid);
         }
      }
   }

}
