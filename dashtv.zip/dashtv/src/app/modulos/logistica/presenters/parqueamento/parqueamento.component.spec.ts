import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ParqueamentoComponent } from './parqueamento.component';

describe('ParqueamentoComponent', () => {
  let component: ParqueamentoComponent;
  let fixture: ComponentFixture<ParqueamentoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ParqueamentoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ParqueamentoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
