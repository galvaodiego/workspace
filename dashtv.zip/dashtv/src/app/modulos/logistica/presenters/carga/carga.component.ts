import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { Usuario, NavigationService, GatewayService, UsuarioService, ClienteService } from 'src/app/shared';

import notify from 'devextreme/ui/notify';
import SetInterval from 'set-interval';
import io from 'socket.io-client';
import { environment } from 'src/environments/environment';

// Plugins
import * as _ from 'underscore';
import { DxDataGridComponent, DxPopupComponent } from 'devextreme-angular';

@Component({
   selector: 'app-feature-logistica-carga',
   templateUrl: './carga.component.html',
   styleUrls: ['./carga.component.scss']
})
export class CargaComponent implements OnInit, OnDestroy {
   @ViewChild('destinadoGrid', { static: false }) destinadoGrid: DxDataGridComponent;
   @ViewChild('cteGrid', { static: false }) cteGrid: DxDataGridComponent;
   @ViewChild('popFiltro', { static: false }) popFiltro: DxPopupComponent;

   public user: Usuario = Usuario.instance;

   public tipoData: string;

   public indicador: any = {
      qtd_destinados: 0,
      qtd_previstos: 0,
      qtd_atrasados: 0,
      qtd_aguardando_ctes: 0
   };

   public listaAguardandoCte: Array<any> = [];
   public listaCargaAguardando: Array<any> = [];
   public listaCargaAtraso: Array<any> = [];

   index_dest: number;
   index_cte: number;

   tolerancia = 5;
   tipo_tolerancia_opcoes = ['Minutos', 'Horas'];
   tipo_tolerancia = 'Horas';
   base_calculo = this.tolerancia;
   tempo = 300;
   fonte_grid = 14;
   controle_tempo_tela: number;
   controle_tempo_tabela: number;
   org: any;
   // Config Socket
   socket_io: any;
   socket_rota = 'carga';
   socket_metodo = 'getCarga';
   socket_filtro: any;
   /***/
   constructor(
      public navigation: NavigationService,
      public UsuarioService: UsuarioService,
      private _gateway: GatewayService,
      public clienteS: ClienteService

   ) {
      this.navigation.loaderTela = true;
      this.navigation.timer_troca_tela = 60000; // importante para funcionar corretamente a troca de tela
      this.controle_tempo_tela = this.navigation.timer_troca_tela / 1000;
      this.controle_tempo_tabela = 5;
      this.user.showMenuOpcoes = false;
      this.user.showIconOpcoes = false;
      this.user.showIconFiltro = true;
      this.user.showFiltroOpcoes = false;
      this.user.showIconTemplates = false;
      this.user.showTemplates = false;
      this.tipoData = 'CARGA';
      this.index_dest = this.index_cte = 0;
      this.socket_io = io(environment.socket_end_point + '/' + this.socket_rota);
      this.socket_filtro = {
         base: (this.clienteS.clienteAtivo !== 'KMM' ? this.clienteS.clienteAtivo : environment.end_point_base_dev).toLowerCase(),
         token: this.user.token
      };

      const clienteSelecionado = JSON.parse(localStorage.getItem('cliente-selecionado'));
      if (clienteSelecionado) {
         Object.assign(this.socket_filtro, {
            url: clienteSelecionado.url
         });
      }
   }


   ngOnInit() {
      // this.navigation.timer_troca_tela = 300000;
      const config = JSON.parse(localStorage.getItem('carga-configuracao'));
      if (config) {
         if (config.tolerancia) {
            this.tipo_tolerancia = config.tolerancia.tipo_tolerancia;
            this.tolerancia = config.tolerancia.valor;
         }

         if (config.font_grid) {
            this.fonte_grid = Number(config.font_grid);
         }

         if (config.tempos.troca_tela) {
            this.controle_tempo_tela = config.tempos.troca_tela;
            this.navigation.timer_troca_tela = this.controle_tempo_tela * 1000;
         }

         if (config.tempos.troca_tabela) {
            this.controle_tempo_tabela = config.tempos.troca_tabela;
         }
      }

      this.getModelo('destinadoGrid');
      this.getModelo('cteGrid');

      SetInterval.start(() => {
         this.trocaPagina();
      }, this.controle_tempo_tabela * 1000, 'intervalo_tabelas');

      this.getData().then(() => { this.navigation.trocaDash(); });

   }

   ngOnDestroy() {
      SetInterval.clear('trocaTela');
      SetInterval.clear('intervalo_tabelas');
   }


   async getData() {
      this.org = JSON.parse(localStorage.getItem('kmm_bi-dash|' + this.clienteS.discover() + '-organizacional'));
      const parametros = {
         usuario: this.org.usuario
      };

      try {
         // const response: any = await this._gateway.backendCall('M4002', 'getCarga', parametros);
         // console.log('res', response);

         this.socket_io.emit(this.socket_metodo, this.socket_filtro);
         this.socket_io.on(this.socket_rota, (response) => {
            console.log('filtro:', this.socket_filtro);
            console.log('resposta:', response);
            this.navigation.loaderTela = false;
            this.listaAguardandoCte = response.telacarga.aguardandoCte;
            this.listaCargaAtraso = response.telacarga.cargaAtraso;
            this.listaCargaAguardando = response.telacarga.cargaAguardando;
            this.indicador.qtd_destinados = this.listaCargaAtraso.length;
            this.indicador.qtd_atrasados = this.listaCargaAtraso.reduce(
               (prev, curr) => {
                  return (curr.tempo_min < 0 ? prev + 1 : prev + 0);
               }, 0
            );
            this.indicador.qtd_previstos = this.listaCargaAtraso.reduce(
               (prev, curr) => {
                  return (curr.tempo_min > 0 ? prev + 1 : prev + 0);
               }, 0
            );
            this.indicador.qtd_aguardando_ctes = this.listaAguardandoCte.length;
         });
      } catch (error) {
         console.log(error);
      }
   }
   aplicar = () => {
      this.base_calculo = this.tolerancia;
      if (this.tipo_tolerancia === 'Horas') {
         this.base_calculo = this.base_calculo * 60;
      }

      const config = {
         tolerancia: {
            tipo_tolerancia: this.tipo_tolerancia,
            valor: this.tolerancia,
            base_calculo: this.base_calculo
         },
         font_grid: this.fonte_grid,
         tempos: {
            troca_tela: this.controle_tempo_tela,
            troca_tabela: this.controle_tempo_tabela
         }
      };

      localStorage.setItem('carga-configuracao', JSON.stringify(config));

      location.reload();

   }
   validaAtraso(valor) {
      const tempo_atraso = Math.floor(valor * 1440); // transforma dias em minutos.
      const config = JSON.parse(localStorage.getItem('carga-configuracao'));

      if (config) {
         if (config.tolerancia) {
            this.tempo = config.tolerancia.base_calculo;
         }

         if (tempo_atraso > this.tempo) {
            return true;
         } else {
            return false;
         }

      }

   }

   public onCellPrepared(e: any) {
      if (e.rowType === 'header') {
         e.cellElement.style.paddingTop = '5px';
         e.cellElement.style.paddingBottom = '5px';
         e.cellElement.style.fontSize = '1rem';
      }

      if (typeof (e.data) !== 'undefined') {
         if (typeof (e.data.tempo_atraso) !== 'undefined') {
            // if (e.data.tempo_min < 0) {
            if (this.validaAtraso(e.data.tempo_atraso)) {
               e.cellElement.style.color = '#fd0e06';
               e.cellElement.style.fontWeight = 'bold';
               e.cellElement.style.fontSize = (this.fonte_grid + 2) + 'px';
            } else {
            }
         }
         e.cellElement.style.fontSize = this.fonte_grid + 'px';
      }

   }

   public onCellPrepared2(e: any) {
      if (e.rowType === 'header') {
         e.cellElement.style.paddingTop = '5px';
         e.cellElement.style.paddingBottom = '5px';
         e.cellElement.style.fontSize = '1rem';
      }

      if (typeof (e.data) !== 'undefined') {
         if (e.data.tempo_min < 0) {
            e.cellElement.style.color = '#fd0e06';
            e.cellElement.style.fontWeight = 'bold';
            e.cellElement.style.fontSize = (this.fonte_grid + 2) + 'px';
         } else {
            e.cellElement.style.fontSize = this.fonte_grid + 'px';
         }

      }

   }

   onToolbarPreparing = (e: any) => {
      const toolbaropems = e.toolbarOptions.opems;
      const toolbarItems = e.toolbarOptions.items;
      const dataGrid = e;

      const obj = this;
      toolbarItems.push({
         widget: 'dxButton',
         options: {
            hint: 'Salvar modelo',
            icon: 'save', onClick: function () {
               obj.saveState(e.element.id);
            }
         },
         location: 'after'
      });


   }

   saveState(contextName) {
      const json = localStorage.getItem(contextName);
      this.saveModelo(json, contextName);
      notify({
         message: 'Modelo salvo com sucesso!',
         type: 'success',
         displayTime: 3000,
         closeOnClick: true,
         width: function () {
            return window.innerWidth / 2.8;
         }
      });


   }
   async saveModelo(json, contextName) {
      const org = JSON.parse(localStorage.getItem('kmm_bi-dash|' + this.clienteS.discover() + '-organizacional'));
      try {
         const parametros = {
            grid_ref: contextName,
            usuario: org.usuario.usuario,
            json_colunas: json
         };

         const response_get: any = await this._gateway.backendCall('M4002', 'getModeloGrid', parametros);
         let operation = 'insModeloGrid';
         if (response_get.modelo_grid.length > 0) {
            console.log('entrou no get', response_get);

            Object.assign(parametros, {
               modelo_grid_id: response_get.modelo_grid[0].modelo_grid_id
            });
            operation = 'altModeloGrid';
         }

         const response: any = await this._gateway.backendCall('M4002', operation, parametros);
         return response;

      } catch (error) {
         console.log(error);
      }

   }

   async getModelo(contextName) {
      const org = JSON.parse(localStorage.getItem('kmm_bi-dash|' + this.clienteS.discover() + '-organizacional'));
      try {
         const parametros = {
            grid_ref: contextName,
            usuario: org.usuario.usuario,
         };

         const response: any = await this._gateway.backendCall('M4002', 'getModeloGrid', parametros);

         if (response.modelo_grid) {
            switch (contextName) {
               case 'destinadoGrid':
                  if (this.destinadoGrid) {
                     this.destinadoGrid.instance.state(JSON.parse(response.modelo_grid[0].json_colunas));
                  }

                  break;
               case 'cteGrid':
                  if (this.cteGrid) {
                     this.cteGrid.instance.state(JSON.parse(response.modelo_grid[0].json_colunas));
                  }
                  break;
            }
         }

      } catch (error) {
         console.log(error);
      }

   }

   trocaPagina() {
      // destinadoGrid
      if (this.destinadoGrid) {
         const total_pd = this.destinadoGrid.instance.pageCount();
         if (total_pd > 1) {
            if (this.index_dest === total_pd - 1) {
               this.index_dest = 0;
            } else {
               this.index_dest++;
            }
            this.destinadoGrid.instance.pageIndex(this.index_dest);
         }
      }


      // cteGrid
      if (this.cteGrid) {
         const total_td = this.cteGrid.instance.pageCount();
         if (total_td > 1) {
            if (this.index_cte === total_td - 1) {
               this.index_cte = 0;
            } else {
               this.index_cte++;
            }
            this.cteGrid.instance.pageIndex(this.index_cte);
         }
      }

   }


}
