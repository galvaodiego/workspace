import { Injectable } from '@angular/core';

@Injectable({
   providedIn: 'root'
})
export class DummyService {

   constructor() { }

   getDados() {
      return {
         previsaoColeta: '24/01/2020',
         totalColetadas: [
            { chave: 'Total', valor: 1000 },
            { chave: 'Coletadas', valor: 500 },
         ],
         solicitacoesColeta: [
            {
               numSolicitacao: 123400000,
               coleta: 'Muller Fogões',
               entrega: 'Transportador Sulista',
               notas: [
                  {
                     numNota: 61234,
                     emitente: 'CRONO AZUL',
                     volume: 12,
                     valor: 201.14
                  },
                  {
                     numNota: 61235,
                     emitente: 'CRONO AZUL',
                     volume: 10,
                     valor: 201.14
                  },
                  {
                     numNota: 61236,
                     emitente: 'CRONO AZUL',
                     volume: 13,
                     valor: 201.14
                  },
               ]
            },
            {
               numSolicitacao: 1235,
               coleta: 'Muller Fogões',
               entrega: 'Transportador Sulista',
               notas: [
                  {
                     numNota: 61234,
                     emitente: 'CRONO AZUL',
                     volume: 12,
                     valor: 201.14
                  },
                  {
                     numNota: 61235,
                     emitente: 'CRONO AZUL',
                     volume: 10,
                     valor: 201.14
                  },
                  {
                     numNota: 61236,
                     emitente: 'CRONO AZUL',
                     volume: 13,
                     valor: 201.14
                  },
               ]
            },
            {
               numSolicitacao: 1236,
               coleta: 'Muller Fogões',
               entrega: 'Transportador Sulista',
               notas: [
                  {
                     numNota: 61234,
                     emitente: 'CRONO AZUL',
                     volume: 12,
                     valor: 201.14
                  },
                  {
                     numNota: 61235,
                     emitente: 'CRONO AZUL',
                     volume: 10,
                     valor: 201.14
                  },
                  {
                     numNota: 61236,
                     emitente: 'CRONO AZUL',
                     volume: 13,
                     valor: 201.14
                  },
               ]
            },
            {
               numSolicitacao: 1237,
               coleta: 'Muller Fogões',
               entrega: 'Transportador Sulista',
               notas: [
                  {
                     numNota: 61234,
                     emitente: 'CRONO AZUL',
                     volume: 12,
                     valor: 201.14
                  },
                  {
                     numNota: 61235,
                     emitente: 'CRONO AZUL',
                     volume: 10,
                     valor: 201.14
                  },
                  {
                     numNota: 61236,
                     emitente: 'CRONO AZUL',
                     volume: 13,
                     valor: 201.14
                  },
               ]
            },
            {
               numSolicitacao: 1238,
               coleta: 'Muller Fogões',
               entrega: 'Transportador Sulista',
               notas: [
                  {
                     numNota: 61234,
                     emitente: 'CRONO AZUL',
                     volume: 12,
                     valor: 201.14
                  },
                  {
                     numNota: 61235,
                     emitente: 'CRONO AZUL',
                     volume: 10,
                     valor: 201.14
                  },
                  {
                     numNota: 61236,
                     emitente: 'CRONO AZUL',
                     volume: 13,
                     valor: 201.14
                  },
               ]
            },
            {
               numSolicitacao: 1239,
               coleta: 'Muller Fogões',
               entrega: 'Transportador Sulista',
               notas: [
                  {
                     numNota: 61234,
                     emitente: 'CRONO AZUL',
                     volume: 12,
                     valor: 201.14
                  },
                  {
                     numNota: 61235,
                     emitente: 'CRONO AZUL',
                     volume: 10,
                     valor: 201.14
                  },
                  {
                     numNota: 61236,
                     emitente: 'CRONO AZUL',
                     volume: 13,
                     valor: 201.14
                  },
               ]
            },
         ],
         situacaoCD: [
            {
               descricao: 'CD MUELLER SÃO BERNARDO',
               indoAoCD: [
                  { num_sol: 123, dataPrev: '24/01/2020', volume: 23 },
                  { num_sol: 321, dataPrev: '28/01/2020', volume: 18 },
               ],
               noCD: [
                  { num_sol: 123, dataPrev: '24/01/2020', volume: 23 },
                  { num_sol: 321, dataPrev: '28/01/2020', volume: 18 },
               ],
            },
            {
               descricao: 'CD MUELLER SÃO JOSÉ',
               indoAoCD: [
                  { num_sol: 123, dataPrev: '24/01/2020', volume: 23 },
                  { num_sol: 321, dataPrev: '28/01/2020', volume: 18 },
               ],
               noCD: [
                  { num_sol: 123, dataPrev: '24/01/2020', volume: 23 },
                  { num_sol: 321, dataPrev: '28/01/2020', volume: 18 },
               ],
            },
            {
               descricao: 'CD MUELLER SÃO BERNARDO 3',
               indoAoCD: [
                  { num_sol: 123, dataPrev: '24/01/2020', volume: 23 },
                  { num_sol: 321, dataPrev: '28/01/2020', volume: 18 },
               ],
               noCD: [
                  { num_sol: 123, dataPrev: '24/01/2020', volume: 23 },
                  { num_sol: 321, dataPrev: '28/01/2020', volume: 18 },
               ],
            },
            {
               descricao: 'CD MUELLER SÃO JOSÉ 4',
               indoAoCD: [
                  { num_sol: 123, dataPrev: '24/01/2020', volume: 23 },
                  { num_sol: 321, dataPrev: '28/01/2020', volume: 18 },
               ],
               noCD: [
                  { num_sol: 123, dataPrev: '24/01/2020', volume: 23 },
                  { num_sol: 321, dataPrev: '28/01/2020', volume: 18 },
               ],
            }
         ],
         entregasDestinatario: [
            {
               numViagem: 123,
               numSolicitacao: 123,
               numNF: 123456,
               mercado: 'Fogão',
               porcent: 80,
               status: 1
            },
            {
               numViagem: 123,
               numSolicitacao: 123,
               numNF: 123456,
               mercado: 'Fogão 2',
               porcent: 50,
               status: 2
            },
            {
               numViagem: 123,
               numSolicitacao: 123,
               numNF: 123456,
               mercado: 'Fogão 3',
               porcent: 25,
               status: 3
            }
         ],
         viagensEncerradas: [
            { chave: 'Em viagem', valor: 50 },
            { chave: 'Encerradas', valor: 85 }
         ]
      };
   }
}
