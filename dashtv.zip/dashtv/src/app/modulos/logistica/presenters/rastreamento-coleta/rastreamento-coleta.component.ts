import { Component, OnInit, OnDestroy, ChangeDetectorRef, AfterViewChecked } from '@angular/core';
import { Usuario, NavigationService, GatewayService } from 'src/app/shared';
import SetInterval from 'set-interval';
import { DummyService } from './dummy.service';

@Component({
   selector: 'app-rastreamento-coleta',
   templateUrl: './rastreamento-coleta.component.html',
   styleUrls: ['./rastreamento-coleta.component.scss']
})
export class RastreamentoColetaComponent implements OnInit, OnDestroy, AfterViewChecked {
   public user: Usuario = Usuario.instance;
   loadingVisible = true;
   datasource = null;
   viewsSol = [];
   viewsSitu = [];
   pages = 0;
   pagesSitu = 0;

   constructor(
      public navigation: NavigationService,
      private _gateway: GatewayService,
      private _dummy: DummyService,
      private cdRef: ChangeDetectorRef
   ) {
      this.navigation.loaderTela = true;
      this.navigation.hideTimeBar = false;
      this.navigation.timer_troca_tela = 60000; // importante para funcionar corretamente a troca de tela

      this.user.showIconOpcoes = false;
      this.user.showIconFiltro = false;
      this.user.showFiltroOpcoes = false;
      this.user.showIconTemplates = false;
      this.user.showTemplates = false;
   }

   ngOnInit() {
      this.getData().then(() => { this.navigation.trocaDash(); });
   }

   async getData() {
      try {
         const response: any = await this._gateway.backendCall('M4002', 'getDashColetas');
         console.log('response:', response);
         // this.datasource = this._dummy.getDados();
         this.datasource = response.dashColetas;
         this.multiView(this.datasource.solicitacoesColeta);
         this.multiView2(this.datasource.situacaoCD);
         this.navigation.loaderTela = false;
         this.loadingVisible = false;
      } catch (error) {
         console.log(error);
      }
   }
   ngOnDestroy(): void {
      SetInterval.clear('trocaTela');
   }

   ngAfterViewChecked() {
      this.cdRef.detectChanges();
   }

   multiView(dados: Array<any>, porPagina = 4) {
      this.viewsSol = [];
      this.pages = Math.ceil(dados.length / porPagina);
      for (let index = 0; index < this.pages; index++) {
         this.viewsSol.push(this.paginate(dados, porPagina, index + 1));
      }
   }

   multiView2(dados: Array<any>, porPagina = 2) {
      this.viewsSitu = [];
      this.pagesSitu = Math.ceil(dados.length / porPagina);
      for (let index = 0; index < this.pagesSitu; index++) {
         this.viewsSitu.push(this.paginate(dados, porPagina, index + 1));
      }
   }

   paginate(array, page_size, page_number) {
      --page_number;
      return array.slice(page_number * page_size, (page_number + 1) * page_size);
   }

   customizeTextLabel(arg: any) {
      return arg.percentText;
   }

   gridNotas = (e: any) => {
      if (e.rowType === 'header') {
         e.cellElement.style.paddingTop = '5px';
         e.cellElement.style.paddingBottom = '5px';
      }

      if (typeof (e.data) !== 'undefined') {
         e.cellElement.style.paddingTop = '5px';
         e.cellElement.style.paddingBottom = '5px';
      }
   }

   public setColor(e) {
      if (typeof (e.key) !== 'undefined') {
         let color = '';
         switch (e.key.status) {
            case 0:
               color = '#186b2a';
               break;
            case 1:
               color = '#8d1616';
               break;
            case 2:
               color = '#c6c912';
               break;

            default:
               color = '#186b2a';
               break;
         }

         return color;
      }
   }
}
