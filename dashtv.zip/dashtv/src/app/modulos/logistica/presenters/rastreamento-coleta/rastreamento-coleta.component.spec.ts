import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RastreamentoColetaComponent } from './rastreamento-coleta.component';

describe('RastreamentoColetaComponent', () => {
  let component: RastreamentoColetaComponent;
  let fixture: ComponentFixture<RastreamentoColetaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RastreamentoColetaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RastreamentoColetaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
