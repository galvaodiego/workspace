import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { Usuario, NavigationService, GatewayService, ClienteService } from 'src/app/shared';
import { DxMultiViewComponent } from 'devextreme-angular';
import io from 'socket.io-client';
import { environment } from 'src/environments/environment';
import { ActivatedRoute } from '@angular/router';

@Component({
   selector: 'app-preventivas',
   templateUrl: './preventivas.component.html',
   styleUrls: ['./preventivas.component.scss']
})
export class PreventivasComponent implements OnInit, OnDestroy {
   @ViewChild('multiview1', { static: false }) multiview1: DxMultiViewComponent;
   @ViewChild('multiview2', { static: false }) multiview2: DxMultiViewComponent;

   user: Usuario = Usuario.instance;
   cavalo_mecanico: Array<any>;
   semi_reboque: Array<any>;
   views_cm: Array<any> = [];
   views_sr: Array<any> = [];
   pages_cm = 0;
   pages_sr = 0;
   porPagina = 12;
   // Config Socket
   socket_io: any;
   socket_rota = 'preventivas';
   socket_metodo = 'getPreventivas';
   socket_filtro: any;
   /***/
   org: any;
   constructor(
      public navigation: NavigationService,
      private _gateway: GatewayService,
      private _clienteS: ClienteService,
      private route: ActivatedRoute
   ) {
      this.navigation.loaderTela = true;
      this.navigation.hideTimeBar = false;
      this.navigation.timer_troca_tela = 30000; // importante para funcionar corretamente a troca de tela

      this.user.showIconOpcoes = false;
      this.user.showIconFiltro = false;
      this.user.showFiltroOpcoes = false;
      this.user.showIconTemplates = false;
      this.user.showTemplates = false;

      this.socket_io = io(environment.socket_end_point + '/' + this.socket_rota);
      this.socket_filtro = {
         base: (this._clienteS.clienteAtivo !== 'KMM' ? this._clienteS.clienteAtivo : environment.end_point_base_dev).toLowerCase(),
         token: this.user.token,
      };

      const clienteSelecionado = JSON.parse(localStorage.getItem('cliente-selecionado'));
      if (clienteSelecionado) {
         Object.assign(this.socket_filtro, {
            url: clienteSelecionado.url
         });
      }
   }

   ngOnInit() {
      this.getData().then(() => { this.navigation.trocaDash(); });
   }

   ngOnDestroy(): void {

   }

   async getData() {
      try {
         // const response: any = await this._gateway.backendCall('M4002', 'getVeiculoPreventiva');
         // console.log('response:', response);
         // this.cavalo_mecanico = response.preventivas[0];

         this.org = JSON.parse(localStorage.getItem('kmm_bi-dash|' + this._clienteS.discover() + '-organizacional'));
         Object.assign(this.socket_filtro, {
            usuario: this.org.usuario.usuario
         });

         if (this.route.snapshot.data['versao'] === 2) {
            this.socket_io.emit(this.socket_metodo + '_v2', this.socket_filtro);
         } else {
            this.socket_io.emit(this.socket_metodo, this.socket_filtro);
         }
         this.socket_io.on(this.socket_rota, (response) => {
            console.log('enviando o filtro', this.socket_filtro);
            console.log('recebendo o retorno', response);
            this.multiViewCM(response.preventivas[0].veiculo_preventiva);
            this.multiViewSR(response.preventivas[1].veiculo_preventiva);
            this.semi_reboque = response.preventivas[1];
            this.navigation.loaderTela = false;
         });
      } catch (error) {
         console.log(error);
      }
   }

   multiViewCM(dados) {
      this.views_cm = [];
      this.pages_cm = Math.ceil(dados.length / this.porPagina);
      for (let index = 0; index < this.pages_cm; index++) {
         this.views_cm.push(this.paginate(dados, this.porPagina, index + 1));
      }

      // controla a troca de paginas
      setInterval(() => {
         this.trocaViewCM(this.pages_cm);
      }, 10000);
   }

   multiViewSR(dados) {
      this.views_sr = [];
      this.pages_sr = Math.ceil(dados.length / this.porPagina);
      for (let index = 0; index < this.pages_sr; index++) {
         this.views_sr.push(this.paginate(dados, this.porPagina, index + 1));
      }

      // controla a troca de paginas
      setInterval(() => {
         this.trocaViewSR(this.pages_sr);
      }, 10000);
   }

   paginate(array, page_size, page_number) {
      --page_number; // because pages logically start with 1, but technically with 0
      return array.slice(page_number * page_size, (page_number + 1) * page_size);
   }

   trocaViewCM(paginas) {
      if (this.multiview1.selectedIndex === paginas - 1) {
         this.multiview1.selectedIndex = 0;
      } else {
         this.multiview1.selectedIndex = this.multiview1.selectedIndex + 1;
      }
   }

   trocaViewSR(paginas) {
      if (this.multiview2.selectedIndex === paginas - 1) {
         this.multiview2.selectedIndex = 0;
      } else {
         this.multiview2.selectedIndex = this.multiview2.selectedIndex + 1;
      }
   }

}
