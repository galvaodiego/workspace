import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { DxPopupComponent } from 'devextreme-angular';
import { Usuario, NavigationService, EstruturaOrganizacionalService, ClienteService, GatewayService } from 'src/app/shared';
import { environment } from 'src/environments/environment';
import { SolicitacoesService } from '../../services/solicitacoes.service';

import io from 'socket.io-client';

import * as moment from 'moment';
import { TemplateService } from 'src/app/shared/services/template.service';


@Component({
   selector: 'app-solicitacoes',
   templateUrl: './solicitacoes.component.html',
   styleUrls: ['./solicitacoes.component.scss']
})
export class SolicitacoesComponent implements OnInit, OnDestroy {
   @ViewChild('popFiltro', { static: false }) popFiltro: DxPopupComponent;
   @ViewChild('popTemplates', { static: false }) popTemplates: DxPopupComponent;

   public user: Usuario = Usuario.instance;
   template: any = {};
   modelo_template = 1;
   loadingVisible = false;
   visualizacao: any;
   org: any;
   usuario: any;
   dash: any;
   // Config Socket
   socket_io: any;
   // socket_rota = 'solicitacao';
   // socket_metodo = 'getSolicitacao';
   socket_rota = 'central_carga';
   socket_metodo = 'getCentralCarga';
   socket_filtro: any;
   /***/

   diff: any;
   constructor(
      public navigation: NavigationService,
      public orgS: EstruturaOrganizacionalService,
      private _clienteS: ClienteService,
      private _solicitacoesService: SolicitacoesService,
      private _gateway: GatewayService,
      private templateService: TemplateService


   ) {
      this.navigation.loaderTela = true;
      this.navigation.hideTimeBar = false;
      this.navigation.timer_troca_tela = 120000; // importante para funcionar corretamente a troca de tela

      this.user.showIconOpcoes = false;
      this.user.showIconFiltro = false;
      this.user.showFiltroOpcoes = false;
      this.user.showIconTemplates = true;
      this.user.showTemplates = false;
      this.visualizacao = 'diario';

      this.socket_io = io(environment.socket_end_point + '/' + this.socket_rota);
      this.socket_filtro = {
         base: (this._clienteS.clienteAtivo !== 'KMM' ? this._clienteS.clienteAtivo : environment.end_point_base_dev).toLowerCase(),
         periodo: this.visualizacao.toLowerCase()
      };

   }

   ngOnInit() {
      this.socket().then(() => {
         this.navigation.trocaDash();
         this.navigation.loaderTela = false;
      });
   }

   ngOnDestroy(): void {
      this.socket_io.disconnect();
   }

   async socket() {
      try {
         this.loadingVisible = true;
         this.socket_io.emit(this.socket_metodo, this.socket_filtro);
         this.socket_io.on(this.socket_rota, (data) => {
            console.log('filtro', this.socket_filtro);
            console.log('retorno', data);
            this._solicitacoesService.ultimaAtualizacao = data.atualizacao[0].valor;
            data.lista_rom_fat.map(e => {
               if (e.DATA_TERMINO_CARGA != null) {
                  const now = moment();
                  const evento = moment(e.DATA_TERMINO_CARGA);

                  if (evento > now) {
                     this.diff = evento.diff(now);

                  } else {
                     this.diff = now.diff(evento);
                  }
                  const tempTime = moment.duration(this.diff);
                  const d = tempTime.days();
                  const h = tempTime.hours();
                  const m = tempTime.minutes();
                  const s = tempTime.seconds();

                  let day = d.toString();
                  let hora = h.toString();
                  let minutes = m.toString();
                  let segundos = s.toString();


                  if (d < 10) {
                     day = '0' + d.toString();
                  }

                  if (h < 10) {
                     hora = '0' + h.toString();
                  }

                  if (m < 10) {
                     minutes = '0' + m.toString();
                  }

                  if (s < 10) {
                     segundos = '0' + s.toString();
                  }
                  e.TEMPO_AGUARDANDO = day + ' dia(s)  ' + hora + ':' + minutes + ':' + segundos;

               } else {
                  e.TEMPO_AGUARDANDO = null;
               }
            });
            data.lista_rom_fat2.map(e => {
               if (e.DATA_TERMINO_CARGA != null) {
                  const now = moment();
                  const evento = moment(e.DATA_TERMINO_CARGA);

                  if (evento > now) {
                     this.diff = evento.diff(now);

                  } else {
                     this.diff = now.diff(evento);
                  }
                  const tempTime = moment.duration(this.diff);
                  const d = tempTime.days();
                  const h = tempTime.hours();
                  const m = tempTime.minutes();
                  const s = tempTime.seconds();

                  let day = d.toString();
                  let hora = h.toString();
                  let minutes = m.toString();
                  let segundos = s.toString();


                  if (d < 10) {
                     day = '0' + d.toString();
                  }

                  if (h < 10) {
                     hora = '0' + h.toString();
                  }

                  if (m < 10) {
                     minutes = '0' + m.toString();
                  }

                  if (s < 10) {
                     segundos = '0' + s.toString();
                  }
                  e.TEMPO_AGUARDANDO = day + ' dia(s)  ' + hora + ':' + minutes + ':' + segundos;

               } else {
                  e.TEMPO_AGUARDANDO = null;
               }
            });

            this.loadingVisible = false;
            this.getTemplate(data);
         });
      } catch (error) {
         console.log('error => ', error);
      }
   }

   getTemplate(matriz) {
      this.org = JSON.parse(localStorage.getItem('kmm_bi-dash|' + this._clienteS.discover() + '-organizacional'));
      this.usuario = JSON.parse(localStorage.getItem('kmm_bi-dash|' + this._clienteS.discover() + '-usuario'));

      this.dash = this.usuario.listaDashboards.filter(element => {
         return element.path === 'logistica/central-de-carga' || element.path === 'logistica/solicitacoes';
      });
      const parametros = {
         usuario_bi_id: this.org.usuario.usuarioBiId,
         dash_id: this.dash[0].dash_id
      };

      // console.log('parametros', parametros);
      this.templateService.backendCall(parametros, 'post', 'get').then((res: any) => {
         if (res.dados && res.dados.length > 0) {
            this.preparaLayout(res.dados, matriz)
         }
         this.loadingVisible = false;
      })
   }

   preparaLayout(tmp, matriz) {
      this.modelo_template = tmp[0].modelo_id;
      const slots = tmp[0].slots;

      for (let index = 0; index < slots.length; index++) {
         if (slots[index] > 0) {
            switch (index) {
               case 0: // slot 1
                  Object.assign(this.template, {
                     slot_1: this._solicitacoesService.getDefinicoes(slots[index], this.visualizacao, matriz)
                  });
                  break;
               case 1: // slot 2
                  Object.assign(this.template, {
                     slot_2: this._solicitacoesService.getDefinicoes(slots[index], this.visualizacao, matriz)
                  });
                  break;
               case 2: // slot 3
                  Object.assign(this.template, {
                     slot_3: this._solicitacoesService.getDefinicoes(slots[index], this.visualizacao, matriz)
                  });
                  break;
               case 3: // slot 4
                  Object.assign(this.template, {
                     slot_4: this._solicitacoesService.getDefinicoes(slots[index], this.visualizacao, matriz)
                  });
                  break;
               case 4: // slot 5
                  Object.assign(this.template, {
                     slot_5: this._solicitacoesService.getDefinicoes(slots[index], this.visualizacao, matriz)
                  });
                  break;
               case 5: // slot 6
                  Object.assign(this.template, {
                     slot_6: this._solicitacoesService.getDefinicoes(slots[index], this.visualizacao, matriz)
                  });
                  break;
               case 6: // slot 7
                  Object.assign(this.template, {
                     slot_7: this._solicitacoesService.getDefinicoes(slots[index], this.visualizacao, matriz)
                  });
                  break;
               case 7: // slot 8
                  Object.assign(this.template, {
                     slot_8: this._solicitacoesService.getDefinicoes(slots[index], this.visualizacao, matriz)
                  });
                  break;
            }
         }

      }
   }

   reciver(e) {
      if (e.mensagem) {
         this.popTemplates.instance.hide();
         location.reload();
      }
   }

}
