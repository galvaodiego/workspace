import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { Usuario, NavigationService, ClienteService } from 'src/app/shared';

import io from 'socket.io-client';
import { environment } from 'src/environments/environment';
import { DxDataGridComponent } from 'devextreme-angular';
import SetInterval from 'set-interval';


@Component({
  selector: 'app-nivel-servico',
  templateUrl: './nivel-servico.component.html',
  styleUrls: ['./nivel-servico.component.scss']
})
export class NivelServicoComponent implements OnInit, OnDestroy {
  @ViewChild('tabela1', { static: false }) tabela1: DxDataGridComponent;
  @ViewChild('tabela2', { static: false }) tabela2: DxDataGridComponent;
  @ViewChild('tabela3', { static: false }) tabela3: DxDataGridComponent;
  @ViewChild('tabela4', { static: false }) tabela4: DxDataGridComponent;
  tabela1_index = 0;
  tabela2_index = 0;
  tabela3_index = 0;
  tabela4_index = 0;
  public user: Usuario = Usuario.instance;
  loadingVisible = false;
  // Config Socket
  socket_io: any;
  socket_rota = 'nivel_servico';
  socket_metodo = 'getNivelServico';
  socket_filtro: any;
  /***/
  datasource = {};
  constructor(
    public navigation: NavigationService,
    private _clienteS: ClienteService,
  ) {
    this.navigation.loaderTela = true;
    this.navigation.hideTimeBar = false;
    this.navigation.timer_troca_tela = 60000; // importante para funcionar corretamente a troca de tela

    this.user.showIconOpcoes = false;
    this.user.showIconFiltro = false;
    this.user.showFiltroOpcoes = false;
    this.user.showIconTemplates = false;
    this.user.showTemplates = false;
    this.socket_io = io(environment.socket_end_point + '/' + this.socket_rota);
    this.socket_filtro = {
      base: (this._clienteS.clienteAtivo !== 'KMM' ? this._clienteS.clienteAtivo : environment.end_point_base_dev).toLowerCase(),
    };
  }

  ngOnInit() {
    SetInterval.start(() => { this.trocaPagina(); }, 10000, 'intervalo_tabelas');
    this.socket().then(() => {
      this.navigation.trocaDash();
      this.navigation.loaderTela = false;
    });
  }
  ngOnDestroy(): void {
    this.socket_io.disconnect();
    SetInterval.clear('intervalo_tabelas');
  }

  trocaPagina() {
    if (this.tabela1) {
      const total_pd = this.tabela1.instance.pageCount();
      if (total_pd > 1) {
        if (this.tabela1_index === total_pd - 1) {
          this.tabela1_index = 0;
        } else {
          this.tabela1_index++;
        }
        this.tabela1.instance.pageIndex(this.tabela1_index);
      }
    }

    if (this.tabela2) {
      const total_pd = this.tabela2.instance.pageCount();
      if (total_pd > 1) {
        if (this.tabela2_index === total_pd - 1) {
          this.tabela2_index = 0;
        } else {
          this.tabela2_index++;
        }
        this.tabela2.instance.pageIndex(this.tabela2_index);
      }
    }
    if (this.tabela3) {
      const total_pd = this.tabela3.instance.pageCount();
      if (total_pd > 1) {
        if (this.tabela3_index === total_pd - 1) {
          this.tabela3_index = 0;
        } else {
          this.tabela3_index++;
        }
        this.tabela3.instance.pageIndex(this.tabela3_index);
      }
    }
    if (this.tabela4) {
      const total_pd = this.tabela4.instance.pageCount();
      if (total_pd > 1) {
        if (this.tabela4_index === total_pd - 1) {
          this.tabela4_index = 0;
        } else {
          this.tabela4_index++;
        }
        this.tabela4.instance.pageIndex(this.tabela4_index);
      }
    }

  }

  async socket() {
    try {
      this.loadingVisible = true;
      this.socket_io.emit(this.socket_metodo, this.socket_filtro);
      this.socket_io.on(this.socket_rota, (data) => {
        console.log('filtro', this.socket_filtro);
        console.log('retorno', data);
        if (data.lista) {
          const lista = data.lista;
          if (lista.viagem.length > 0) {
            lista.viagem.map(e => {
              e.nivel_servico = e.nivel_servico / 100;
            });
          }
          if (lista.carga.length > 0) {
            lista.carga.map(e => {
              e.nivel_servico = e.nivel_servico / 100;
            });
          }
          if (lista.descarga.length > 0) {
            lista.descarga.map(e => {
              e.nivel_servico = e.nivel_servico / 100;
            });
          }
        }
        this.datasource = data;
        this.loadingVisible = false;
      });
    } catch (error) {
      console.log('error => ', error);
    }
  }

  onCellPrepared(e: any) {
    if (e.rowType === 'header' || e.rowType === 'totalFooter') {
      e.cellElement.style.paddingTop = '5px';
      e.cellElement.style.paddingBottom = '5px';
      e.cellElement.style.backgroundColor = '#6DA9D6';
      e.cellElement.style.color = '#ffffff';

    }

    if (typeof (e.data) !== 'undefined') {
      e.cellElement.style.paddingTop = '5px';
      e.cellElement.style.paddingBottom = '5px';
      e.cellElement.style.border = '0';
      e.cellElement.style.color = '#666666';
      // console.log('...', e.data);

      // if (e.data.nivel_servico !== 'undefined') {
      //   e.cellElement.style.fontWeight = 'bolder';

      //   if (e.data.nivel_servico >= 0 && e.data.nivel_servico <= 30) {
      //     e.cellElement.style.color = '#A62222';
      //   } else if (e.data.nivel_servico >= 31 && e.data.nivel_servico <= 50) {
      //     e.cellElement.style.color = '#F09000';
      //   } else if (e.data.nivel_servico >= 51 && e.data.nivel_servico <= 70) {
      //     e.cellElement.style.color = '#F7D766';
      //   } else if (e.data.nivel_servico >= 71 && e.data.nivel_servico <= 100) {
      //     e.cellElement.style.color = '#51BB4F';
      //   }
      // } else {
      //   e.cellElement.style.color = '#666666';
      // }

    }
  }

  getNivel(nivel) {
    nivel = nivel * 100;
    let classe = '';
    if (nivel >= 0 && nivel <= 30) {
      classe = 'n1';
    } else if (nivel >= 31 && nivel <= 50) {
      classe = 'n2';
    } else if (nivel >= 51 && nivel <= 70) {
      classe = 'n3';
    } else if (nivel >= 71 && nivel <= 100) {
      classe = 'n4';
    }
    return classe;
  }

}
