import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NivelServicoComponent } from './nivel-servico.component';

describe('NivelServicoComponent', () => {
  let component: NivelServicoComponent;
  let fixture: ComponentFixture<NivelServicoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NivelServicoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NivelServicoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
