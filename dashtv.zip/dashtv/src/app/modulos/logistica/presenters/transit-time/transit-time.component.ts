import { Component, OnInit, ViewChild, OnDestroy, Injector } from '@angular/core';
import { DxDataGridComponent } from 'devextreme-angular';
import * as moment from 'moment';
import 'moment/locale/pt-br';
import SetInterval from 'set-interval';
import io from 'socket.io-client';
import { Usuario, NavigationService, GatewayService, EstruturaOrganizacionalService, ClienteService } from 'src/app/shared';
import notify from 'devextreme/ui/notify';
import { environment } from 'src/environments/environment';


@Component({
   selector: 'app-feature-logistica-transit-time',
   templateUrl: './transit-time.component.html',
   styleUrls: ['./transit-time.component.scss']
})
export class TransitTimeComponent implements OnInit, OnDestroy {

   @ViewChild(DxDataGridComponent, { static: false }) dataGrid: DxDataGridComponent;
   @ViewChild('gridTransitTime', { static: false }) gridTransitTime: DxDataGridComponent;
   public user: Usuario = Usuario.instance;
   public listaTransit: Array<any> = [];
   public indicadores: any = {};
   public dataHoje = '';
   public showJustificativa = true;
   public showColumnsOptions;

   // Personalizações dos Filtros
   public dataFiltroTransit: any = [];
   public dataFiltroTransitJanela: any = [];

   parametro = '';
   org: any;

   // Config Socket
   socket_io: any;
   socket_rota = 'transit_time';
   socket_metodo = 'getTransitTime';
   socket_filtro: any;
   /***/
   constructor(
      public navigation: NavigationService,
      public orgS: EstruturaOrganizacionalService,
      private _gateway: GatewayService,
      protected _injector: Injector,
      public clienteS: ClienteService
   ) {
      this.navigation.loaderTela = true;
      this.navigation.timer_troca_tela = 60000; // importante para funcionar corretamente a troca de tela

      this.user.showMenuOpcoes = true;
      this.dataSourceHeadFilter();

      this.socket_io = io(environment.socket_end_point + '/' + this.socket_rota);
      this.socket_filtro = {
         base: (this.clienteS.clienteAtivo !== 'KMM' ? this.clienteS.clienteAtivo : environment.end_point_base_dev).toLowerCase(),
         token: this.user.token,
      };

      const clienteSelecionado = JSON.parse(localStorage.getItem('cliente-selecionado'));
      if (clienteSelecionado) {
         Object.assign(this.socket_filtro, {
            url: clienteSelecionado.url
         });
      }
   }


   ngOnInit() {
      this.getData().then(() => { this.navigation.trocaDash(); });
   }


   ngOnDestroy() {
      SetInterval.clear('trocaTela');
   }

   /**
   * Resgata as Informações de Transit Time
    */
   async getData() {
      const grupo_negociador = JSON.parse(localStorage.getItem(this.clienteS.discover() + '-grupo_negociador'));
      if (grupo_negociador) {
         const ids = [];
         grupo_negociador.forEach(element => {
            ids.push(element.grupo_id);
         });
         Object.assign(this.socket_filtro, {
            cod_grupo_negociador: ids
         });
      }
      this.org = JSON.parse(localStorage.getItem('kmm_bi-dash|' + this.clienteS.discover() + '-organizacional'));
      // const parametrosBd = { organizacional_id: this.orgS.getOrgEmpresa(), usuario: this.org.usuario };
      try {
         // const response_old: any = await this._gateway.backendCall('M4002', 'getTransitTime', parametrosBd);
         // console.log('resp', response_old, 'parametros', parametrosBd);
         Object.assign(this.socket_filtro, {
            usuario: this.org.usuario.usuario
         });
         this.socket_io.emit(this.socket_metodo, this.socket_filtro);
         this.socket_io.on(this.socket_rota, (response) => {
            console.log('rota / metodo:', this.socket_rota + '/' + this.socket_metodo);
            console.log('filtro:', this.socket_filtro);
            console.log('resposta:', response);
            this.navigation.loaderTela = false;
            this.listaTransit = response.TransitTime;
            this.parametro = response.TransitTime[0].parametro;
            this.getDatas();
            this.validaFront();
            this.calculaContadores(this.listaTransit);
            this.getModelo('gridTransitTime');
         });
      } catch (error) {
         console.log('erro TT ->', error);
      }
   }

   /**
   * Resgata as Data de Hoje
   */
   async getDatas() {
      try {
         const response: any = await this._gateway.backendCall('M4002', 'getDataFormat');
         this.dataHoje = response.Datas[1].valor;
      } catch (error) {
         this.dataHoje = moment().format('DD/MM');
         console.log(error);
      }
   }

   /**
    * Valida os Dados para o Front
    *  -- Corrige o TransitTime null para 0
    *  -- Se não tiver Justificativa Oculta a Coluna
    */
   public validaFront() {
      const temp = [];
      this.listaTransit.forEach(
         (el) => {
            if (el.nac_percentual_executado == null) {
               el.nac_percentual_executado = 0;
            }
            if (el.transit_time == null || el.transit_time === 'undefined') {
               el.transit_time = 0;
            }

            if (el.justificativa !== '' || el.justificativa != null) {
               temp.push(el);
            }
         }
      );

      if (temp.length === 0) {
         this.showJustificativa = false;
      } else {
         this.showJustificativa = true;
      }
   }


   /**
    * Realiza os Calculos dos Indicadores
    */
   public calculaContadores(listaDeDados) {
      const previsto = [], possibilidade = [], atraso = [];

      listaDeDados.forEach(
         (el) => {
            if (el.parametro == null || typeof (el.nac_no_prazo_rota) == 'undefined') {
               const value = Number(el.nac_percentual_executado);
               if ((value > 0) && (value <= 30)) {
                  previsto.push(el);
               } else if ((value > 30 && value <= 60)) {
                  possibilidade.push(el);
               } else if ((value > 60)) {
                  atraso.push(el);
               }
            } else {
               let prazo = 0;
               if (el.parametro == 'rota') {
                  prazo = Number(el.nac_no_prazo_rota);
               } else {
                  prazo = Number(el.nac_no_prazo);
               }
               if (prazo == 1) {
                  previsto.push(el);
               } else if (prazo == 2) {
                  possibilidade.push(el);
               } else if (prazo == 0) {
                  atraso.push(el);
               }
            }
         }
      );

      this.indicadores = {
         // 'total_viagens': this.listaTransit.length,
         'total_viagens': listaDeDados.length,
         'servico': parseFloat(((previsto.length + possibilidade.length) / listaDeDados.length * 100).toFixed(0)),
         'previsto': previsto.length,
         'possibilidade': possibilidade.length,
         'atraso': atraso.length,
      };

   }



   /**
    * Aplica os Filtros que o Devextreme realiza
    * @param e evento
    */
   public aplicaFiltros(e) {

      // Estabelece um limite de registro por paginas
      this.dataGrid.instance.pageSize(10000);

      // Recebe o dataSource Filtrado pelo Devextreme
      const realTimeFilterDevExtreme: any = this.dataGrid.instance.getDataSource();

      // Chama a função pra Re Calcular os Indicadores
      this.calculaContadores(realTimeFilterDevExtreme._items);

   }

   /**
   * Seta a cor da ProgressBar
   * @param number
   */
   public setColor(e) {
      if (typeof (e.key) !== 'undefined') {
         let color = '';

         // nac_no_prazo_rota é o correto, mas se não vier, utiliza a regra de nac_percentual_executado
         if (e.key.nac_no_prazo_rota == null || typeof (e.key.nac_no_prazo_rota) == 'undefined') {

            // Regra para quem não usa configura o TT no KMM
            const value = Number(e.key.nac_percentual_executado);
            if ((value > 0) && (value <= 30)) {
               color = '#27ae60';
            } else if ((value > 30 && value <= 60)) {
               color = '#f39c12';
            } else if ((value > 60)) {
               color = '#e74c3c';
            }
         } else {
            const prazo = Number(e.key.nac_no_prazo_rota);
            if (prazo == 1) {
               color = '#27ae60';
            } else if (prazo == 2) {
               color = '#f39c12';
            } else if (prazo == 0) {
               color = '#e74c3c';
            }
         }
         return color;
      }
   }

   /**
   * Seta a cor da ProgressBar
   * @param number
   */
   public setColor2(e) {
      if (typeof (e.key) !== 'undefined') {
         let color = '';

         const prazo = Number(e.key.nac_no_prazo);
         if (prazo == 1) {
            color = '#27ae60';
         } else if (prazo == 2) {
            color = '#f39c12';
         } else if (prazo == 0) {
            color = '#e74c3c';
         }
         return color;
      }
   }



   /**
  * Função Para Alterar o Estilo da Tabela
  * @param e Evento recebido pelo componente
  */
   public onCellPrepared(e) {
      e.cellElement.style.fontSize = '1.2em';
      e.cellElement.style.fontWeight = '700';

      // Pinta as Linhas de Cabeçalho e Filtros
      if (e.rowType == 'header') {
         e.cellElement.style.paddingTop = '3px';
         e.cellElement.style.paddingBottom = '3px';
         e.cellElement.style.lineHeight = '18px';
         e.cellElement.style.textAlign = 'center';
      } else if (e.rowType == 'filter') {
         // e.cellElement.bgColor = '#e2e2e2';
         // e.cellElement.style.color = '#000000';
      } else {
         e.cellElement.style.padding = '7px';
      }

      if (typeof (e.key) !== 'undefined') {
         if (e.key.nac_no_prazo_rota == null || typeof (e.key.nac_no_prazo_rota) == 'undefined') {

            // Regra para quem não usa configura o TT no KMM
            if (e.key.executado_horas == 1) {
               e.cellElement.bgColor = '#be322e';
               e.cellElement.style.color = '#ffffff';
            }
         } else {
            if (e.key.tempo_atraso < 0) {
               e.cellElement.bgColor = '#be322e';
               e.cellElement.style.color = '#ffffff';
            }
         }
      }

   }

   /**
   * Exibe o ColumnChooser do Grid
   */
   public showColumns() {
      this.dataGrid.instance.showColumnChooser();
      // this.gridTT.TransitTimeGrid.dxDataGrid.instance.showColumnChooser()
   }


   /**
    *  Monta Array com as Opções que o Filtro Conterá
    */
   public dataSourceHeadFilter() {

      this.dataFiltroTransit = [{
         text: '0% - 30%',
         value: ['nac_percentual_executado', '<', 30]
      }, {
         text: '30% - 50%',
         value: [
            ['nac_percentual_executado', '>=', 30],
            ['nac_percentual_executado', '<', 50]
         ]
      }, {
         text: '50% - 80%',
         value: [
            ['nac_percentual_executado', '>=', 50],
            ['nac_percentual_executado', '<', 80]
         ]
      }, {
         text: '80% - 100%',
         value: [
            ['nac_percentual_executado', '>=', 80],
            ['nac_percentual_executado', '<=', 100]
         ]
      }];


      this.dataFiltroTransitJanela = [{
         text: '0% - 30%',
         value: ['transit_time', '<', 30]
      }, {
         text: '30% - 50%',
         value: [
            ['transit_time', '>=', 30],
            ['transit_time', '<', 50]
         ]
      }, {
         text: '50% - 80%',
         value: [
            ['transit_time', '>=', 50],
            ['transit_time', '<', 80]
         ]
      }, {
         text: '80% - 100%',
         value: [
            ['transit_time', '>=', 80],
            ['transit_time', '<=', 100]
         ]
      }];


   }

   onToolbarPreparing = (e: any) => {
      const toolbaropems = e.toolbarOptions.opems;
      const toolbarItems = e.toolbarOptions.items;
      const dataGrid = e;

      const obj = this;
      toolbarItems.push({
         widget: 'dxButton',
         options: {
            hint: 'Salvar modelo',
            icon: 'save', onClick: function () {
               obj.saveState(e.element.id);
            }
         },
         location: 'after'
      });


   }

   saveState(contextName) {
      const json = localStorage.getItem(contextName);
      this.saveModelo(json, contextName);
      notify({
         message: 'Modelo salvo com sucesso!',
         type: 'success',
         displayTime: 3000,
         closeOnClick: true,
         width: function () {
            return window.innerWidth / 2.8;
         }
      });


   }
   async saveModelo(json, contextName) {
      const org = JSON.parse(localStorage.getItem('kmm_bi-dash|' + this.clienteS.discover() + '-organizacional'));
      try {
         const parametros = {
            grid_ref: contextName,
            usuario: org.usuario.usuario,
            json_colunas: json
         };

         const response_get: any = await this._gateway.backendCall('M4002', 'getModeloGrid', parametros);
         let operation = 'insModeloGrid';
         if (response_get.modelo_grid.length > 0) {
            Object.assign(parametros, {
               modelo_grid_id: response_get.modelo_grid[0].modelo_grid_id
            });
            operation = 'altModeloGrid';
         }

         const response: any = await this._gateway.backendCall('M4002', operation, parametros);
         // console.log(operation, response, 'parametros:', parametros);

         return response;

      } catch (error) {
         console.log(error);
      }

   }

   async getModelo(contextName) {
      const org = JSON.parse(localStorage.getItem('kmm_bi-dash|' + this.clienteS.discover() + '-organizacional'));
      try {
         const parametros = {
            grid_ref: contextName,
            usuario: org.usuario.usuario,
         };

         const response: any = await this._gateway.backendCall('M4002', 'getModeloGrid', parametros);
         // console.log('getModeloGrid', response, 'parametros:', parametros);

         if (response.modelo_grid.length > 0) {
            if (this.gridTransitTime) {
               // console.log('chegou aqui', response);
               this.gridTransitTime.instance.state(JSON.parse(response.modelo_grid[0].json_colunas));
            }
         }

      } catch (error) {
         console.log(error);
      }

   }
}
