import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TransitTimeComponent } from './transit-time.component';

describe('TransitTimeComponent', () => {
  let component: TransitTimeComponent;
  let fixture: ComponentFixture<TransitTimeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TransitTimeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TransitTimeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
