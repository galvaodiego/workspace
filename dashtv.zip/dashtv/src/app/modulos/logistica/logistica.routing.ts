import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const LOGISTICA_ROUTES: Routes = [
   {
      path: '',
      loadChildren: 'src/app/modulos/logistica/presenters/presenters.module#PresentersModule',
   }
];

export const LogisticaRouting: ModuleWithProviders = RouterModule.forChild(LOGISTICA_ROUTES);
