import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const PORTO_ROUTES: Routes = [
    {
        path: '',
        loadChildren: 'src/app/modulos/porto/presenters/presenters.module#PresentersModule',
    }
];

export const PortoRouting: ModuleWithProviders = RouterModule.forChild(PORTO_ROUTES);