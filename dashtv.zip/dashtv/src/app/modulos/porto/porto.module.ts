import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PortoRouting } from './porto.routing';


@NgModule({
  imports: [
    CommonModule,
    PortoRouting
  ]
})
export class PortoModule { }
