import { Component, OnInit, Input, AfterViewInit } from '@angular/core';

@Component({
   selector: 'app-estoque-cards',
   templateUrl: './estoque-cards.component.html',
   styleUrls: ['./estoque-cards.component.scss']
})
export class EstoqueCardsComponent implements OnInit, AfterViewInit {
   @Input() view;
   @Input() porPagina;

   itens: Array <any>;
   constructor() { }

   ngOnInit() {
      this.itens = this.view;
   }

   ngAfterViewInit(): void {

   }

}
