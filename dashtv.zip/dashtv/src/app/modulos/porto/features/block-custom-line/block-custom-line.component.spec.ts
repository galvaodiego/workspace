import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BlockCustomLineComponent } from './block-custom-line.component';

describe('BlockCustomLineComponent', () => {
  let component: BlockCustomLineComponent;
  let fixture: ComponentFixture<BlockCustomLineComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BlockCustomLineComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BlockCustomLineComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
