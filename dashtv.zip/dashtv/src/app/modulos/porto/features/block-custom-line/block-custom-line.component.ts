import { AfterViewInit, Component, Input, OnChanges, OnDestroy, SimpleChanges, ViewChild } from '@angular/core';
import { DxDataGridComponent } from 'devextreme-angular';
import SetInterval from 'set-interval';


@Component({
   selector: 'app-block-custom-line',
   templateUrl: './block-custom-line.component.html',
   styleUrls: ['./block-custom-line.component.scss']
})
export class BlockCustomLineComponent implements OnDestroy, AfterViewInit, OnChanges {
   @ViewChild('gridDetalhes', { static: false }) gridDetalhes: DxDataGridComponent;
   index_grid = 0;

   @Input() titulo: string;
   @Input() datasource: any;
   @Input() atual: any;
   @Input() customStyleB1 = { width: '70%' };
   @Input() porPagina = 8;
   @Input() name: string;
   dataSourceGrid = [];
   colunas = [
      { dataField: 'data', caption: 'Dia', alignment: 'center', width: 'auto' },
      { dataField: 'total', caption: 'Realizado', alignment: 'center', width: 'auto', format: { type: 'fixedPoint', precision: 0 } },
      { dataField: 'meta', caption: 'Meta', alignment: 'center', width: 'auto', format: { type: 'fixedPoint', precision: 0 } },
   ]
   constructor() {
   }


   ngOnChanges(changes: SimpleChanges): void {
      if (this.name === 'prodDia') {
         this.colunas[0].caption = 'Hora';
      } else if (this.name === 'prodAno') {
         this.colunas[0].caption = 'Mês';
      }

      this.dataSourceGrid = this.datasource.filter(e => {
         return e.total != null;
      })
   }



   ngAfterViewInit() {
      const instance = this.gridDetalhes.instance;
      SetInterval.start(() => {
         this.trocaPagina(instance);
      }, 10000, 'intervalo_tabelas_' + this.gridDetalhes.accessKey);

   }

   ngOnDestroy() {
      SetInterval.clear('intervalo_tabelas_' + this.gridDetalhes.accessKey);
   }

   public onCellPrepared(e: any) {
      if (e.rowType === 'header') {
         e.cellElement.style.paddingTop = '5px';
         e.cellElement.style.paddingBottom = '5px';
         e.cellElement.style.backgroundColor = '#666';
         e.cellElement.style.color = '#fff';

      }

      if (typeof (e.data) !== 'undefined') {
         e.cellElement.style.paddingTop = '5px';
         e.cellElement.style.paddingBottom = '5px';
         e.cellElement.style.fontSize = '20px';
      }

   }

   customizePoint = (arg: any) => {
      const currentdate = new Date();
      const hora = currentdate.getHours();
      if (Number(arg.argument.substring(0, 2) == hora)) {
         return {
            border: { color: '#666666', visible: true },
            size: 22,
         };
      }
   }

   trocaPagina(instance) {
      const total_pd = instance.pageCount();
      if (total_pd > 1) {
         if (this.index_grid === total_pd - 1) {
            this.index_grid = 0;
         } else {
            this.index_grid++;
         }
         instance.pageIndex(this.index_grid);
      }
   }

}
