import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EstoqueCardsComponent } from './estoque-cards/estoque-cards.component';
import { DxChartModule, DxDataGridModule, DxLinearGaugeModule } from 'devextreme-angular';
import { BlockCustomLineComponent } from './block-custom-line/block-custom-line.component';

@NgModule({
   declarations: [
      EstoqueCardsComponent,
      BlockCustomLineComponent
   ],
   imports: [
      CommonModule,
      DxLinearGaugeModule,
      DxChartModule,
      DxDataGridModule,

   ],
   exports: [
      EstoqueCardsComponent,
      BlockCustomLineComponent
   ]
})
export class FeaturesModule { }
