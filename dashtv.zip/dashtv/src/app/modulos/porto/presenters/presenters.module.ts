import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PresentersRouting } from './presenters.routing';
import {
   DxDataGridModule,
   DxTabsModule,
   DxChartModule,
   DxPieChartModule,
   DxScrollViewModule,
   DxCircularGaugeModule,
   DxSelectBoxModule,
   DxTemplateModule,
   DxAccordionModule,
   DxMultiViewModule,
   DxCheckBoxModule,
   DxSliderModule,
   DxLinearGaugeModule,
   DxFormModule,
   DxNumberBoxModule,
   DxBoxModule,
   DxPopupModule,
   DxTagBoxModule
} from 'devextreme-angular';

import {
   MatFormFieldModule,
   MatSelectModule,
   MatDialogModule,
   MatButtonModule,
   MatIconModule
} from '@angular/material';

//Componentes
import { NavioComponent } from './navio/navio.component';
import { ImportadoresComponent } from './importadores/importadores.component';
import { DescargaComponent } from './descarga/descarga.component';
import { CargaComponent } from './carga/carga.component';
import { CargaP2Component } from './cargap2/cargap2.component';
import { EstoqueComponent } from './estoque/estoque.component';
import { FeaturesModule } from '../features/features.module';
import { AtendimentoGiroComponent } from './atendimento-giro/atendimento-giro.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BoxFiltroComponent } from './cargap2/box-filtro/box-filtro.component';


@NgModule({
   declarations: [
      NavioComponent,
      ImportadoresComponent,
      DescargaComponent,
      CargaComponent,
      CargaP2Component,
      EstoqueComponent,
      AtendimentoGiroComponent,
      BoxFiltroComponent,
   ],
   imports: [
      CommonModule,
      PresentersRouting,
      FormsModule,
      ReactiveFormsModule,
      DxDataGridModule,
      DxTabsModule,
      DxChartModule,
      DxPieChartModule,
      DxScrollViewModule,
      DxCircularGaugeModule,
      DxSelectBoxModule,
      DxAccordionModule,
      DxTemplateModule,
      DxMultiViewModule,
      DxCheckBoxModule,
      DxSliderModule,
      DxLinearGaugeModule,
      DxFormModule,
      DxNumberBoxModule,
      DxBoxModule,
      FeaturesModule,
      DxPopupModule,
      DxTagBoxModule,
      MatFormFieldModule,
      MatSelectModule,
      MatDialogModule,
      MatButtonModule,
      MatIconModule

   ],
   entryComponents: [BoxFiltroComponent],
})
export class PresentersModule { }
