import { ModuleWithProviders } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";

import { GuardaRotas } from "src/app/shared";
import { NavioComponent } from "./navio/navio.component";
import { ImportadoresComponent } from "./importadores/importadores.component";
import { DescargaComponent } from "./descarga/descarga.component";
import { CargaComponent } from "./carga/carga.component";
import { CargaP2Component } from "./cargap2/cargap2.component";
import { EstoqueComponent } from "./estoque/estoque.component";
import { AtendimentoGiroComponent } from "./atendimento-giro/atendimento-giro.component";

const modulo = 'porto';
const PRESENTERS_ROUTES: Routes = [
   {
      path: 'navio',
      canActivate: [GuardaRotas],
      component: NavioComponent,
      data: { modulo }
   },
   {
      path: 'importadores',
      canActivate: [GuardaRotas],
      component: ImportadoresComponent,
      data: { modulo }
   },
   {
      path: 'descarga',
      canActivate: [GuardaRotas],
      component: DescargaComponent,
      data: { modulo }
   },
   {
      path: 'carga',
      canActivate: [GuardaRotas],
      component: CargaComponent,
      data: { modulo }
   },
   {
      path: 'gmo-terminal',
      canActivate: [GuardaRotas],
      component: CargaP2Component,
      data: {
         origem: 2, // terminal
         modulo
      }
   },
   {
      path: 'gmo-fabrica',
      canActivate: [GuardaRotas],
      component: CargaP2Component,
      data: {
         origem: 1, // fabrica
         modulo
      }
   },
   {
      path: 'estoque',
      canActivate: [GuardaRotas],
      component: EstoqueComponent,
      data: { modulo }
   },
   {
      path: 'estoque-terminal',
      canActivate: [GuardaRotas],
      component: EstoqueComponent,
      data: {
         origem: 1, // terminal
         modulo
      }
   },
   {
      path: 'estoque-fabrica',
      canActivate: [GuardaRotas],
      component: EstoqueComponent,
      data: {
         origem: 2, // fabrica
         modulo
      }
   },
   {
      path: 'atendimento-giro',
      canActivate: [GuardaRotas],
      component: AtendimentoGiroComponent,
      data: { modulo }
   },
];

export const PresentersRouting: ModuleWithProviders = RouterModule.forChild(PRESENTERS_ROUTES);