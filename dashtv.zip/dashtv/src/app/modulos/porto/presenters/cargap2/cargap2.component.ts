import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';

import { NavigationService, Usuario, UsuarioService, GatewayService, EstruturaOrganizacionalService } from 'src/app/shared';

import { ActivatedRoute } from '@angular/router';
import SetInterval from 'set-interval';
import * as moment from 'moment';

// Plugins
import * as _ from 'underscore';
import { LocalStorageService } from 'ngx-webstorage';
import { NotificacaoService } from 'src/app/shared/services/common/notificacao.service';
import { DxMultiViewComponent, DxPopupComponent } from 'devextreme-angular';
import { MatDialog } from '@angular/material/dialog';
import { BoxFiltroComponent } from './box-filtro/box-filtro.component';


@Component({
   selector: 'app-carga-p2',
   templateUrl: './cargap2.component.html',
   styleUrls: ['./cargap2.component.scss']
})
export class CargaP2Component implements OnInit, OnDestroy {
   @ViewChild('multiview', { static: false }) multiview: DxMultiViewComponent;
   @ViewChild('popFiltro', { static: false }) popFiltro: DxPopupComponent;

   public user: Usuario = Usuario.instance;

   public tipoData: string;
   public listaTempoDescarga: Array<any> = [];
   public listaPrevisaoDescarga: Array<any> = [];

   cards: any = [];
   t1: any = [];
   t2: any = [];
   t3: any = [];
   t4: any = [];
   t5: any = [];
   t6: any = [];
   t7: any = [];
   t8: any = [];
   entradas_gmo: any = [];
   tempos_range: any = [
      { val: 45, desc: 'até 45 min' },
      { val: 60, desc: 'até 1 hora' },
      { val: 120, desc: 'até 2 horas' },
      { val: 180, desc: 'até 3 horas' },
      { val: 300, desc: 'até 5 horas' },
      { val: 420, desc: 'até 7 horas' }
   ];

   filtro_op: Array<any>;

   form_periodos = {
      grupo_1: '',
      grupo_2: '',
      grupo_3: '',
      grupo_4: '',
      filtro_operacao: [],
   };

   mostraConfig = false;
   showConfig = false;
   textoBtnConfig = 'Exibe configurações';

   barColor = {
      color1: '#0e0e3f',
      color2: '#339933',
      color3: '#b7580b',
      color4: '#d82724',
   };


   // MULTIVIEW ENTRADAS GMO
   views: Array<any>;
   porPagina: number;
   pages = 0;
   subtitle = [];
   titulo_atual: string;
   // FIM - MULTIVIEW ENTRADAS GMO

   origem;
   constructor(
      public navigation: NavigationService,
      public UsuarioService: UsuarioService,
      public orgS: EstruturaOrganizacionalService,
      private _gateway: GatewayService,
      private _storage: LocalStorageService,
      private route: ActivatedRoute,
      private _notificacao: NotificacaoService,
      public dialog: MatDialog

   ) {
      this.navigation.loaderTela = true;
      this.navigation.timer_troca_tela = 60000; // importante para funcionar corretamente a troca de tela

      this.user.showIconOpcoes = false;
      this.user.showIconFiltro = false;
      this.user.showFiltroOpcoes = false;
      this.tipoData = 'CARGAP2';
   }

   ngOnInit() {
      this.getData().then(() => { this.navigation.trocaDash(); });

   }

   openDialog() {
      const dialogRef = this.dialog.open(BoxFiltroComponent, {
         data: {
            filtro_op: this.filtro_op,
            tempos_range: this.tempos_range
         }
      });
      dialogRef.afterClosed().subscribe(result => {
         if (result.limpar) {
            this.limparFiltro();
         } else {
            Object.assign(this.form_periodos, result.filtro);
            this.salvaConfiguracao();
         }
      });
   }

   ngOnDestroy() {
      SetInterval.clear('trocaTela');
   }

   async getData() {
      try {
         let tipo_gmo = null;
         this.route.data.subscribe(v => {
            tipo_gmo = v.origem;
         });

         const parametrosBd = {
            tipo_gmo: tipo_gmo
         };

         switch (tipo_gmo) {
            case 1:
               this.origem = 'periodos_fabrica';

               break;
            case 2:
               this.origem = 'periodos_terminal';

               break;

         }

         const periodo = this._storage.retrieve(this.origem);
         if (periodo) {
            Object.assign(parametrosBd, {
               grupo_1: periodo.grupo_1,
               grupo_2: periodo.grupo_2,
               grupo_3: periodo.grupo_3,
               grupo_4: periodo.grupo_4,
               // filtro_op: JSON.stringify(periodo.filtro_operacao).replace(/[\[\]]/g, '')
               filtro_op: periodo.filtro_operacao.toString()
            });

            Object.assign(this.form_periodos, periodo);

         }
         const filtros: any = await this._gateway.backendCall('M4002', 'getTipoOpePorto', parametrosBd);
         console.log('parametrosBd', parametrosBd);
         // console.log('filtros', filtros);
         this.filtro_op = filtros.operacao;

         const response: any = await this._gateway.backendCall('M4002', 'getTemposGMO', parametrosBd);
         console.log('res:', response);

         this.t1 = response.dash_gmo.t1;
         this.t2 = response.dash_gmo.t2;
         this.t3 = response.dash_gmo.t3;
         this.t4 = response.dash_gmo.t4;
         this.t5 = response.dash_gmo.t5;
         this.t6 = response.dash_gmo.t6;
         this.t7 = response.dash_gmo.t7;
         this.t8 = response.dash_gmo.t8;


         // this.entradas_gmo = response.dash_gmo.media_dia;
         this.entradas_gmo.push(response.dash_gmo.media_dia); // embarques dia atual
         this.entradas_gmo.push(response.dash_gmo.dia_anterior); // embarques (08/10) |D-1
         this.entradas_gmo.push(response.dash_gmo.sete_dias); // embarques ultimos 7 dias
         this.entradas_gmo.push(response.dash_gmo.trinta_dias); // embarques ultimos 30 dias
         this.subtitle.push('Expedição: Dia atual');
         const d = new Date();
         d.setDate(d.getDate() - 1);
         this.subtitle.push('Expedição: ' + moment(d).format('DD/MM/YYYY'));
         this.subtitle.push('Expedição: Ultimos 7 dias');
         this.subtitle.push('Expedição: Ultimos 30 dias');
         this.titulo_atual = this.subtitle[0];

         this.multiView();

         this.cards = response.dash_gmo.gmo_status;
         this.navigation.loaderTela = false;
      } catch (error) {
         console.log(error);
      }

   }

   validaCampos(form) {
      if (form.grupo_1 === '' || form.grupo_2 === '' || form.grupo_3 === '' || form.grupo_4 === '') {
         return false;
      } else {
         return true;
      }
   }

   toggle() {
      this.mostraConfig = !this.mostraConfig;
      if (this.mostraConfig) {
         this.textoBtnConfig = 'Esconde configurações';
      } else {
         this.textoBtnConfig = 'Exibe configurações';
      }
   }

   salvaConfiguracao_old() {
      if (this.validaCampos(this.form_periodos)) {
         this._storage.store(this.origem, this.form_periodos);
         this.getData();
         this.toggle();
         this.popFiltro.instance.hide();
         this._notificacao.toast('Dados salvos com sucesso!');
      } else {
         this._notificacao.toast('Todos os campos são obrigatórios!', 'error');
      }
   }

   salvaConfiguracao() {
      this._storage.store(this.origem, this.form_periodos);
      this.getData();
      // this.toggle();
      // this.popFiltro.instance.hide();
      this._notificacao.toast('Dados salvos com sucesso!');
   }

   customizeLabel = (arg: any) => {
      if (arg.value > 0) {
         return {
            position: 'inside',
            visible: true,
            // backgroundColor: '#666',
            customizeText: function (e: any) {
               return e.valueText;
            }
         };
      }
   }

   multiView() {
      this.views = [];
      this.pages = 4;
      for (let index = 0; index < this.pages; index++) {
         this.views.push(this.entradas_gmo[index]);
      }

      // controla a troca de paginas
      SetInterval.start(() => {
         this.trocaView(this.pages);
      }, 10000, 'trocaView');
   }

   trocaView(paginas) {
      if (this.multiview.selectedIndex === paginas - 1) {
         this.multiview.selectedIndex = 0;
         this.titulo_atual = this.subtitle[0];
      } else {
         this.multiview.selectedIndex = this.multiview.selectedIndex + 1;
         this.titulo_atual = this.subtitle[this.multiview.selectedIndex];
      }
   }

   limparFiltro_old() {
      if (confirm('Deseja limpar o filtro atual?')) {
         this._storage.clear(this.origem);
         this.form_periodos = {
            grupo_1: '',
            grupo_2: '',
            grupo_3: '',
            grupo_4: '',
            filtro_operacao: [],
         };
         this.getData();
         this.toggle();
         this.popFiltro.instance.hide();
         this._notificacao.toast('Filtro limpo com sucesso!');
      }
   }
   limparFiltro() {
      this._storage.clear(this.origem);
      this.form_periodos = {
         grupo_1: '',
         grupo_2: '',
         grupo_3: '',
         grupo_4: '',
         filtro_operacao: [],
      };
      this.getData();
      // this.toggle();
      // this.popFiltro.instance.hide();
      this._notificacao.toast('Filtro limpo com sucesso!');
   }

}
