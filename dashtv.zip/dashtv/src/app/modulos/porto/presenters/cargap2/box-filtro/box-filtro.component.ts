import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Inject } from '@angular/core';
@Component({
  selector: 'app-box-filtro',
  templateUrl: './box-filtro.component.html',
  styleUrls: ['./box-filtro.component.scss']
})
export class BoxFiltroComponent implements OnInit {
  formFiltro: FormGroup;
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    private dialogRef: MatDialogRef<BoxFiltroComponent>,
    private fb: FormBuilder
  ) { }

  ngOnInit() {
    this.montaFormFiltro()
  }

  montaFormFiltro() {
    this.formFiltro = this.fb.group({
      grupo_1: [null, Validators.required],
      grupo_2: [null, Validators.required],
      grupo_3: [null, Validators.required],
      grupo_4: [null, Validators.required],
      filtro_operacao: [null, Validators.required],
    })
  }

  salvaConfiguracao() {
    this.dialogRef.close({ filtro: this.formFiltro.value, limpar: false });
  }

  limparFiltro(e) {
    e.preventDefault();
    this.formFiltro.reset();
    this.dialogRef.close({ filtro: null, limpar: true });
  }

}
