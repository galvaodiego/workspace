import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BoxFiltroComponent } from './box-filtro.component';

describe('BoxFiltroComponent', () => {
  let component: BoxFiltroComponent;
  let fixture: ComponentFixture<BoxFiltroComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BoxFiltroComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BoxFiltroComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
