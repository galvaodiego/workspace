import { Component, OnInit, OnDestroy } from '@angular/core';
import { NavigationService, Usuario, UsuarioService, EstruturaOrganizacionalService } from 'src/app/shared';
import SetInterval from 'set-interval';

@Component({
   selector: 'app-atendimento-giro',
   templateUrl: './atendimento-giro.component.html',
   styleUrls: ['./atendimento-giro.component.scss']
})
export class AtendimentoGiroComponent implements OnInit, OnDestroy {
   public user: Usuario = Usuario.instance;
   gauge = 50;

   constructor(
      public navigation: NavigationService,
      public UsuarioService: UsuarioService,
      public orgS: EstruturaOrganizacionalService,
   ) {
      this.navigation.loaderTela = true;
      this.navigation.timer_troca_tela = 30000; // importante para funcionar corretamente a troca de tela

      this.user.showIconOpcoes = false;
      this.user.showIconFiltro = false;
      this.user.showFiltroOpcoes = false;
   }

   ngOnInit() {
      this.getData().then(() => { this.navigation.trocaDash(); });
   }


   ngOnDestroy() {
      SetInterval.clear('trocaTela');
   }

   async getData() {
      try {
         const parametrosBd = { organizacional_id: this.orgS.getOrgEmpresa() };
         // const response: any = await this._gateway.backendCall('M4002', 'getCargaGMO', parametrosBd);
         // console.log('response:', response);

         this.navigation.loaderTela = false;

      } catch (error) {
         console.log(error);
      }

   }

}
