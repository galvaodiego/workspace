import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';

import { NavigationService, Usuario, UsuarioService, GatewayService, EstruturaOrganizacionalService } from 'src/app/shared';

import { DxMultiViewComponent } from 'devextreme-angular';
import { ActivatedRoute } from '@angular/router';



// Plugins
import * as _ from 'underscore';
import SetInterval from 'set-interval';

@Component({
   selector: 'app-estoque',
   templateUrl: './estoque.component.html',
   styleUrls: ['./estoque.component.scss']
})
export class EstoqueComponent implements OnInit, OnDestroy {
   @ViewChild('multiview', { static: false }) multiview: DxMultiViewComponent;
   public user: Usuario = Usuario.instance;

   public tipoData: string;
   public listaTempoDescarga: Array<any> = [];
   public listaPrevisaoDescarga: Array<any> = [];

   dados = [];
   maisInformacoes = false;
   arrowClass = 'fas fa-chevron-circle-down';
   views: Array<any>;

   porPagina: number;
   pages = 0;

   opcoes: Array<any>;
   boxes_options: Array<any> = [];
   selectedItensBoxes: Array<any> = [];
   tipo_estoque = 'estoque_terminal';

   constructor(
      public navigation: NavigationService,
      public UsuarioService: UsuarioService,
      public orgS: EstruturaOrganizacionalService,
      private _gateway: GatewayService,
      private route: ActivatedRoute
   ) {
      this.navigation.loaderTela = true;
      this.navigation.timer_troca_tela = 60000; // importante para funcionar corretamente a troca de tela
      // this.navigation.timer_troca_tela = 500000; // importante para funcionar corretamente a troca de tela

      this.user.showIconOpcoes = false;
      this.user.showIconFiltro = true;
      this.user.showFiltroOpcoes = false;
      this.tipoData = 'ESTOQUE';
      this.opcoes = [
         { value: 12, description: '12 itens por página' },
         { value: 8, description: '8 itens por página' },
         { value: 6, description: '6 itens por página' },
         { value: 4, description: '4 itens por página' }
      ];

      const pp = localStorage.getItem('porPagina');
      if (pp != undefined) {
         this.porPagina = Number(pp);
      } else {
         // this.porPagina = 12;
         this.porPagina = 8;
      }
   }

   ngOnInit() {
      let tipo_estoque = null;
      this.route.data.subscribe(v => {
         tipo_estoque = v.origem;
      });

      switch (tipo_estoque) {
         case 1:
            this.tipo_estoque = 'estoque_terminal';
            break;

         case 2:
            this.tipo_estoque = 'estoque_fabrica';
            break;
      }

      const filtroBox = JSON.parse(localStorage.getItem('filtroBox_' + this.tipo_estoque));
      if (filtroBox) {
         this.selectedItensBoxes = filtroBox;
      }
      this.getData().then(() => { this.navigation.trocaDash(); });
   }

   ngOnDestroy() {
      SetInterval.clear('trocaTela');
      SetInterval.clear('trocaView');
   }

   format(value) {
      return value + '%';
   }

   replaceComma(value) {
      return value.replace(',', ', ');
   }

   async getData() {
      try {
         let tipo_estoque = null;
         this.route.data.subscribe(v => {
            tipo_estoque = v.origem;
         });

         const parametrosBd = {
            tipo_estoque: tipo_estoque
         };
         const response: any = await this._gateway.backendCall('M4002', 'getEstoque', parametrosBd);
         console.log('response', response);

         this.navigation.loaderTela = false;
         this.dados = response.location;
         this.dados.map((dado) => {
            dado.navio = this.replaceComma(dado.navio);
            dado.produto = this.replaceComma(dado.produto);
         });


         const boxes = [];
         const op = [... this.dados];
         op.forEach(element => {
            boxes.push(element.box_id);
         });
         this.boxes_options = _.uniq(boxes);

         if (this.selectedItensBoxes.length > 0) {
            const box = this.dados.filter(element => {
               return this.selectedItensBoxes.indexOf(element.box_id) !== -1;
            });
            this.dados = box;
         }

         this.multiView();

      } catch (error) {
         console.log(error);
      }

   }

   multiView() {
      this.views = [];
      this.pages = Math.ceil(this.dados.length / this.porPagina);
      for (let index = 0; index < this.pages; index++) {
         this.views.push(this.paginate(this.dados, this.porPagina, index + 1));
      }

      // controla a troca de paginas
      SetInterval.start(() => {
         this.trocaView(this.pages);
      }, 10000, 'trocaView');
   }

   paginate(array, page_size, page_number) {
      --page_number; // because pages logically start with 1, but technically with 0
      return array.slice(page_number * page_size, (page_number + 1) * page_size);
   }

   mostrarTodos() {
      this.maisInformacoes = !this.maisInformacoes;
      if (this.maisInformacoes) {
         this.arrowClass = 'fas fa-chevron-circle-up';
      } else {
         this.arrowClass = 'fas fa-chevron-circle-down';
      }
   }

   customizeText(arg: any) {
      return arg.valueText + '%';
   }

   trocaView(paginas) {
      if (this.multiview.selectedIndex === paginas - 1) {
         this.multiview.selectedIndex = 0;
      } else {
         this.multiview.selectedIndex = this.multiview.selectedIndex + 1;
      }
   }

   display(e) {
      this.porPagina = e.value;
      localStorage.setItem('porPagina', this.porPagina.toString());
      this.getData();
   }

   salvarBox() {
      if (this.selectedItensBoxes.length > 0) {
         localStorage.setItem('filtroBox_' + this.tipo_estoque, JSON.stringify(this.selectedItensBoxes));
         location.reload();
      }
   }

   limparFiltro() {
      this.selectedItensBoxes = [];
      localStorage.removeItem('filtroBox_' + this.tipo_estoque);
      location.reload();
   }

}
