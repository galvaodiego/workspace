import { Component, OnInit, OnDestroy } from '@angular/core';

import { NavigationService, Usuario, UsuarioService, GatewayService, EstruturaOrganizacionalService, ClienteService } from 'src/app/shared';


// Plugins
import * as _ from 'underscore';
import { LocalStorageService } from 'ngx-webstorage';
import notify from 'devextreme/ui/notify';
import { Observable } from 'rxjs';
import SetInterval from 'set-interval';
import { NotificacaoService } from 'src/app/shared/services/common/notificacao.service';



@Component({
   selector: 'app-carga',
   templateUrl: './carga.component.html',
   styleUrls: ['./carga.component.scss']
})
export class CargaComponent implements OnInit, OnDestroy {

   public user: Usuario = Usuario.instance;

   public tipoData: string;
   public listaTempoDescarga: Array<any> = [];
   public listaPrevisaoDescarga: Array<any> = [];

   producaoDia: any = [];
   producaoMes: any = [];
   producaoAno: any = [];
   producaoDia_atual = {};
   producaoMes_atual = {};
   producaoAno_atual = {};
   importador: any = [];
   produto: any = [];
   configuracoes: any = {};
   textoBtnConfig = 'Exibe configurações';
   mostraConfig = false;
   showConfig = false;
   produto_label = true;
   importador_label = true;
   variaveis = [];
   key_storage = 'carga-configuracao';
   totalProduto = 0;

   constructor(
      public navigation: NavigationService,
      public UsuarioService: UsuarioService,
      public orgS: EstruturaOrganizacionalService,
      private _gateway: GatewayService,
      private _storage: LocalStorageService,
      private _clienteS: ClienteService,
      private _notificacao: NotificacaoService


   ) {
      this.navigation.loaderTela = true;
      this.navigation.timer_troca_tela = 60000; // importante para funcionar corretamente a troca de tela

      this.user.showIconOpcoes = false;
      this.tipoData = 'CARGA';
      this.user.showIconFiltro = true;
      this.user.showFiltroOpcoes = false;
   }

   ngOnInit() {
      const label_produto = localStorage.getItem('carga-label-produto');
      const label_importador = localStorage.getItem('carga-label-importador');
      if (label_produto) {
         this.produto_label = JSON.parse(label_produto);
      }

      if (label_importador) {
         this.importador_label = JSON.parse(label_importador);
      }
      this.getVariaveis();

      this.getData().then(() => { this.navigation.trocaDash(); });

   }

   ngOnDestroy() {
      SetInterval.clear('trocaTela');
   }


   async getData() {
      try {
         const parametrosBd = { organizacional_id: this.orgS.getOrgEmpresa() };
         const response: any = await this._gateway.backendCall('M4002', 'getCargaGMO', parametrosBd);
         if (response.dash_carga.saldo_produtos.length > 0) {
            response.dash_carga.saldo_produtos.map(e => {
               this.totalProduto += e.saldo
            });
         }
         console.log('response:', response);
         this.producaoDia = response.dash_carga.dist_diaria;
         this.producaoMes = response.dash_carga.dist_mensal;
         this.producaoAno = response.dash_carga.dist_ano;
         this.produto = _.sortBy(response.dash_carga.saldo_produtos, 'saldo').reverse();
         const importadores = _.sortBy(response.dash_carga.saldo_import, 'saldo');
         this.importador = importadores.reverse();

         const metaHora = this.configuracoes.meta_diaria / this.producaoDia.length;
         let agrega = 0;
         for (let index = 0; index < this.producaoDia.length; index++) {
            this.producaoDia[index]['meta'] = metaHora + agrega;
            agrega = this.producaoDia[index]['meta'];
         }
         this.producaoDia_atual = this.getAtual(1, this.producaoDia);
         this.producaoMes_atual = this.getAtual(2, this.producaoMes);
         this.producaoAno_atual = this.getAtual(3, this.producaoAno);
         this.navigation.loaderTela = false;

      } catch (error) {
         console.log(error);
      }

   }
   getVariaveis() {
      const org = JSON.parse(localStorage.getItem('kmm_bi-dash|' + this._clienteS.discover() + '-organizacional'));
      const padrao_meta_diaria = 10000;
      const parametros = {
         modulo: 'porto',
         usuario_bi_id: org.usuario.usuarioBiId,
         key: this.key_storage,
      };

      this._gateway.backendCall('M4002', 'getParamDash', parametros).then((res: any) => {
         if (res.parametros_dash.length > 0) {
            localStorage.setItem(this.key_storage, res.parametros_dash[0].parametros);
            this.variaveis = res.parametros_dash;
         }
         const data = JSON.parse(localStorage.getItem(this.key_storage));
         if (data) {
            Object.assign(this.configuracoes, {
               meta_diaria: data.meta_diaria,
            });
         } else {

            // Seta os dados padrões
            Object.assign(this.configuracoes, {
               meta_diaria: padrao_meta_diaria,
            });
         }
      });
   }
   salvaConfiguracao() {
      if (this.configuracoes.meta_diaria === null) {
         this.configuracoes.meta_diaria = 0;
      }
      const org = JSON.parse(localStorage.getItem('kmm_bi-dash|' + this._clienteS.discover() + '-organizacional'));
      const param = JSON.stringify(this.configuracoes);
      localStorage.setItem(this.key_storage, param);
      const parametros = {
         modulo: 'porto',
         usuario_bi_id: org.usuario.usuarioBiId,
         key: this.key_storage,
         parametros: param,
      };
      let operacao = 'insParamDash';
      if (this.variaveis.length > 0) {
         operacao = 'altParamDash';
         Object.assign(parametros, {
            parametros_dash_id: this.variaveis[0].parametros_dash_id
         });
      }
      // console.log(operacao, 'salvando config', parametros);

      this._gateway.backendCall('M4002', operacao, parametros).then((res: any) => {
         this.getData();
         this._notificacao.toast('Configuração salva com sucesso');
      });

   }

   customizeLegend = (arg: any) => {
      let valor = 0;
      this.produto.forEach(element => {
         if (element.produto === arg.pointName) {
            valor = element.saldo;
         }
      });

      this.importador.forEach(element => {
         if (element.produto === arg.pointName) {
            valor = element.saldo;
         }
      });
      return arg.pointName + ' ( ' + valor.toLocaleString('pt-BR', { style: 'decimal' }) + ' )';
   }

   thousands_separators(num) {
      const num_parts = num.toString().split('.');
      num_parts[0] = num_parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, '.');
      return num_parts.join('.');
   }

   customizeTextLabel(arg) {
      return arg.valueText + ' (' + arg.percentText + ')';
   }

   getMeses() {
      return [
         { num: '01', ext: 'Jan' },
         { num: '02', ext: 'Fev' },
         { num: '03', ext: 'Mar' },
         { num: '04', ext: 'Abr' },
         { num: '05', ext: 'Mai' },
         { num: '06', ext: 'Jun' },
         { num: '07', ext: 'Jul' },
         { num: '08', ext: 'Ago' },
         { num: '09', ext: 'Set' },
         { num: '10', ext: 'Out' },
         { num: '11', ext: 'Nov' },
         { num: '12', ext: 'Dez' }
      ];
   }

   getAtual(origem, array) {
      const currentdate = new Date();
      const retorno = {};
      const meses: any = this.getMeses();
      let refer = 0;
      switch (origem) {
         case 1: // produção x dia
            refer = currentdate.getHours();
            break;
         case 2: // produção x mes
            refer = currentdate.getDate();
            break;
         case 3: // produção x ano
            refer = currentdate.getMonth();
            break;
      }

      array.forEach(element => {
         if (origem !== 3) {
            if (Number(element.data.substring(0, 2)) === refer) {
               Object.assign(retorno, {
                  realizado: element.total,
                  meta: element.meta
               });
            }
         } else {
            if (element.data === meses[refer].num || element.data === meses[refer].ext) {
               Object.assign(retorno, {
                  realizado: element.total,
                  meta: element.meta
               });
            }
         }
      });

      return retorno;
   }


   customizePointPM = (arg: any) => {
      const currentdate = new Date();
      const dia = currentdate.getDate();
      if (Number(arg.argument.substring(0, 2) == dia)) {
         return {
            border: { color: '#666666', visible: true },
            size: 22,
         };
      }
   }
   customizePointPA = (arg: any) => {
      const currentdate = new Date();
      const meses: any = this.getMeses();
      const mes = currentdate.getMonth();
      if (arg.argument === meses[mes].num || arg.argument === meses[mes].ext) {
         return {
            border: { color: '#666666', visible: true },
            size: 22,
         };
      }
   }

   toggle(e) {
      e.path[2].children[1].hidden = !e.path[2].children[1].hidden;

      if (e.path[2].children[1].hidden) {
         this.textoBtnConfig = 'Exibe configurações';
      } else {
         this.textoBtnConfig = 'Esconde configurações';
      }
   }

   alternaLeg(tipo) {
      switch (tipo) {
         case 'produto':
            this.produto_label = !this.produto_label;
            localStorage.setItem('carga-label-produto', this.produto_label.toString());
            break;
         case 'importador':
            this.importador_label = !this.importador_label;
            localStorage.setItem('carga-label-importador', this.importador_label.toString());
            break;
      }
   }

   customizeTextLabelSerie = (e) => {
      // console.log(e)
      const p = (e.value * 100) / this.totalProduto;
      return e.valueText + ' (' + Math.ceil(p) + '%) ';
   }

}
