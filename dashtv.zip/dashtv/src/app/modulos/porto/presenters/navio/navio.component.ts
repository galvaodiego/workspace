import { Component, OnInit, OnDestroy, ViewChild, AfterViewInit } from '@angular/core';

import { NavigationService, Usuario, UsuarioService, GatewayService, EstruturaOrganizacionalService } from 'src/app/shared';

// Plugins
import * as _ from 'underscore';
import { DxDataGridComponent, DxTabsModule, DxTabsComponent } from 'devextreme-angular';
import SetInterval from 'set-interval';

@Component({
   selector: 'app-navio',
   templateUrl: './navio.component.html',
   styleUrls: ['./navio.component.scss']
})
export class NavioComponent implements OnInit, OnDestroy {
   @ViewChild(DxDataGridComponent, { static: false }) gridContainer: DxDataGridComponent;
   @ViewChild('tempoOperacaoGrid', { static: false }) tempoOperacaoGrid: DxDataGridComponent;
   @ViewChild(DxTabsComponent, { static: false }) apiTabs: DxTabsComponent;

   public user: Usuario = Usuario.instance;
   navio: any = {};
   tabs: any = [];
   navios: any = [];
   index_to = 0;


   constructor(
      public navigation: NavigationService,
      // tslint:disable-next-line: no-shadowed-variable
      public UsuarioService: UsuarioService,
      public orgS: EstruturaOrganizacionalService,
      private _gateway: GatewayService
   ) {
      this.navigation.loaderTela = true;
      this.navigation.timer_troca_tela = 30000; // importante para funcionar corretamente a troca de tela

      this.user.showIconOpcoes = false;
      this.user.showIconFiltro = false;
      this.user.showFiltroOpcoes = false;
   }

   selectTab(e) {
      this.navio = e.itemData;
   }

   ngOnInit() {
      SetInterval.start(() => {
         this.trocaPagina();
      }, 5000, 'intervalo_tabelas');

      this.getData().then(() => { this.navigation.trocaDash(); });

   }

   ngOnDestroy() {
      SetInterval.clear('trocaTela');
      SetInterval.clear('intervalo_tabelas');
   }


   async getData() {
      try {
         const parametrosBd = { organizacional_id: this.orgS.getOrgEmpresa() };
         const response: any = await this._gateway.backendCall('M4002', 'getNavioInfo', parametrosBd);
         console.log('RESPONSE:', response);
         if (response.navios) {
            this.navios = response.navios;
            this.navio = this.navios[0];
         }
         this.navigation.loaderTela = false;
      } catch (error) {
         console.log(error);
      }

   }

   onRowPreparedEvent(e) {
      if (e.rowType === 'data' && (e.data.operando === 1 || e.data.tipo === 'Operando')) {
         e.rowElement.style.backgroundColor = 'green';
         e.rowElement.style.color = '#ffffff';

      }
   }

   trocaPagina() {
      // GridTempoOp
      const total_to = this.tempoOperacaoGrid.instance.pageCount();
      if (total_to > 1) {
         if (this.index_to === total_to - 1) {
            this.index_to = 0;
         } else {
            this.index_to++;
         }
         this.tempoOperacaoGrid.instance.pageIndex(this.index_to);
      }

   }

}
