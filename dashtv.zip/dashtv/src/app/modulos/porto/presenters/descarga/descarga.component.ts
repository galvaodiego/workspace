import { Component, OnInit, OnDestroy } from '@angular/core';

import { NavigationService, Usuario, UsuarioService, GatewayService, EstruturaOrganizacionalService, ClienteService } from 'src/app/shared';

// Plugins
import * as _ from 'underscore';
import { LocalStorageService } from 'ngx-webstorage';
import SetInterval from 'set-interval';
import { NotificacaoService } from 'src/app/shared/services/common/notificacao.service';


@Component({
   selector: 'app-feature-logistica-descarga',
   templateUrl: './descarga.component.html',
   styleUrls: ['./descarga.component.scss']
})
export class DescargaComponent implements OnInit, OnDestroy {

   public user: Usuario = Usuario.instance;

   public tipoData: string;
   public listaTempoDescarga: Array<any> = [];
   public listaPrevisaoDescarga: Array<any> = [];

   public indicador: any = {
      viajando: 0,
      previsto: 0,
      atrasado: 0,
      descarga: 0
   };


   producaoHora = [];
   producaoMes = [];
   producaoAno = [];
   producaoHora_atual = {};
   producaoMes_atual = {};
   producaoAno_atual = {};

   tempoOperacao = [];
   gauge = [];
   navios = [];
   painelControle: any = {};
   textoBtnConfig = 'Exibe configurações';
   mostraConfig = false;
   showConfig = false;

   variaveis = [];
   key_storage = 'descarga-configuracao';


   constructor(
      public navigation: NavigationService,
      public UsuarioService: UsuarioService,
      public orgS: EstruturaOrganizacionalService,
      private _gateway: GatewayService,
      private _storage: LocalStorageService,
      private _clienteS: ClienteService,
      private _notificacao: NotificacaoService

   ) {
      this.navigation.loaderTela = true;
      this.navigation.timer_troca_tela = 60000; // importante para funcionar corretamente a troca de tela

      this.user.showIconOpcoes = false;
      this.user.showIconFiltro = true;
      this.user.showFiltroOpcoes = false;
      this.tipoData = 'DESCARGA';
   }

   ngOnInit() {
      this.getVariaveis();
      this.getData().then(() => { this.navigation.trocaDash(); });
   }

   ngOnDestroy() {
      SetInterval.clear('trocaTela');
   }

   async getData() {
      try {
         const parametrosBd = {
            organizacional_id: this.orgS.getOrgEmpresa(),
         };

         const response: any = await this._gateway.backendCall('M4002', 'getPortoDescarga', parametrosBd);
         console.log('descarga-response::', response);

         this.navigation.loaderTela = false;
         this.producaoHora = response.dash_descarga.dist_diaria;
         this.producaoMes = response.dash_descarga.dist_mensal;
         this.producaoAno = response.dash_descarga.dist_ano;
         this.navios = response.dash_descarga.navios;
         this.gauge = response.dash_descarga.perf_descarga;

         const metaHora = this.painelControle.meta_diaria / this.producaoHora.length;
         let agrega = 0;
         for (let index = 0; index < this.producaoHora.length; index++) {
            this.producaoHora[index]['meta'] = metaHora + agrega;
            agrega = this.producaoHora[index]['meta'];
         }

         this.producaoHora_atual = this.getAtual(1, this.producaoHora);
         this.producaoMes_atual = this.getAtual(2, this.producaoMes);
         this.producaoAno_atual = this.getAtual(3, this.producaoAno);

      } catch (error) {
         console.log(error);
      }

   }

   getVariaveis() {
      const org = JSON.parse(localStorage.getItem('kmm_bi-dash|' + this._clienteS.discover() + '-organizacional'));
      const padrao_meta_diaria = 10000;
      const parametros = {
         modulo: 'porto',
         usuario_bi_id: org.usuario.usuarioBiId,
         key: this.key_storage,
      };

      this._gateway.backendCall('M4002', 'getParamDash', parametros).then((res: any) => {
         if (res.parametros_dash.length > 0) {
            localStorage.setItem(this.key_storage, res.parametros_dash[0].parametros);
            this.variaveis = res.parametros_dash;
         }
         const data = JSON.parse(localStorage.getItem(this.key_storage));
         if (data) {
            Object.assign(this.painelControle, {
               range_1: data.range_1,
               range_2: data.range_2,
               range_3: data.range_3,
               meta_diaria: data.meta_diaria,
               nivel_servico: data.nivel_servico,
            });
         } else {

            // Seta os dados padrões
            Object.assign(this.painelControle, {
               range_1: 700,
               range_2: 900,
               range_3: 2000,
               meta_diaria: padrao_meta_diaria,
               nivel_servico: 489,
            });
         }
      });
   }

   salvaConfiguracao() {
      const org = JSON.parse(localStorage.getItem('kmm_bi-dash|' + this._clienteS.discover() + '-organizacional'));
      const param = JSON.stringify(this.painelControle);
      localStorage.setItem(this.key_storage, param);
      const parametros = {
         modulo: 'porto',
         usuario_bi_id: org.usuario.usuarioBiId,
         key: this.key_storage,
         parametros: param,
      };
      let operacao = 'insParamDash';
      if (this.variaveis.length > 0) {
         operacao = 'altParamDash';
         Object.assign(parametros, {
            parametros_dash_id: this.variaveis[0].parametros_dash_id
         });
      }
      // console.log(operacao, 'salvando config', parametros);

      this._gateway.backendCall('M4002', operacao, parametros).then((res: any) => {
         this.getData();
         this._notificacao.toast('Configuração salva com sucesso');
      });

   }

   customizeTooltip(arg) {
      return {
         text: arg.valueText
      };
   }

   toggle(e) {
      e.path[2].children[1].hidden = !e.path[2].children[1].hidden;

      if (e.path[2].children[1].hidden) {
         this.textoBtnConfig = 'Exibe configurações';
      } else {
         this.textoBtnConfig = 'Esconde configurações';
      }
   }

   getAtual(origem, array) {
      const currentdate = new Date();
      const retorno = {};
      const meses: any = this.getMeses();
      let refer = 0;
      switch (origem) {
         case 1: // produção x dia
            refer = currentdate.getHours();
            break;
         case 2: // produção x mes
            refer = currentdate.getDate();
            break;
         case 3: // produção x ano
            refer = currentdate.getMonth();
            break;
      }

      array.forEach(element => {
         if (origem !== 3) {
            if (Number(element.data.substring(0, 2)) === refer) {
               Object.assign(retorno, {
                  realizado: element.total,
                  meta: element.meta
               });
            }
         } else {
            if (element.data === meses[refer].num || element.data === meses[refer].ext) {
               Object.assign(retorno, {
                  realizado: element.total,
                  meta: element.meta
               });
            }
         }
      });

      return retorno;
   }

   customizePoint = (arg: any) => {
      const currentdate = new Date();
      const hora = currentdate.getHours();
      if (Number(arg.argument.substring(0, 2) == hora)) {
         return {
            border: { color: '#666666', visible: true },
            size: 22,
         };
      }
   }
   customizePointPM = (arg: any) => {
      const currentdate = new Date();
      const dia = currentdate.getDate();
      if (Number(arg.argument.substring(0, 2) == dia)) {
         return {
            border: { color: '#666666', visible: true },
            size: 22,
         };
      }
   }
   customizePointPA = (arg: any) => {
      const currentdate = new Date();
      const meses: any = this.getMeses();
      const mes = currentdate.getMonth();
      if (arg.argument === meses[mes].num || arg.argument === meses[mes].ext) {
         return {
            border: { color: '#666666', visible: true },
            size: 22,
         };
      }
   }

   getMeses() {
      return [
         { num: '01', ext: 'Jan' },
         { num: '02', ext: 'Fev' },
         { num: '03', ext: 'Mar' },
         { num: '04', ext: 'Abr' },
         { num: '05', ext: 'Mai' },
         { num: '06', ext: 'Jun' },
         { num: '07', ext: 'Jul' },
         { num: '08', ext: 'Ago' },
         { num: '09', ext: 'Set' },
         { num: '10', ext: 'Out' },
         { num: '11', ext: 'Nov' },
         { num: '12', ext: 'Dez' }
      ];
   }


}
