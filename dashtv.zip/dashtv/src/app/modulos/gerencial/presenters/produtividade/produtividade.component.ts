import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Usuario, NavigationService, EstruturaOrganizacionalService, GatewayService, ClienteService } from 'src/app/shared';
import notify from 'devextreme/ui/notify';


@Component({
   selector: 'app-produtividade',
   templateUrl: './produtividade.component.html',
   styleUrls: ['./produtividade.component.scss']
})
export class ProdutividadeComponent implements OnInit {
   public user: Usuario = Usuario.instance;
   tipo_ds: any;
   empresa_ds: any;

   tabs = [
      {
         id: 0,
         text: 'Por Tipo',
         icon: 'group',
         content: 'Por tipo',
         contexto: 'tipo'
      },
      {
         id: 1,
         text: 'Empresa',
         icon: 'product',
         content: 'Empresa',
         contexto: 'empresa'
      },
   ];
   tabContent: string;
   tabContexto: string;
   baseUrl = '';
   constructor(
      private _router: Router,
      public navigation: NavigationService,
      public orgS: EstruturaOrganizacionalService,
      private _gateway: GatewayService,
      private _cliente: ClienteService
   ) {
      this.navigation.loaderTela = false;
      this.navigation.hideTimeBar = true;
      this.user.showIconOpcoes = false;

   }

   ngOnInit() {
      const clienteSelecionado = JSON.parse(localStorage.getItem('cliente-selecionado'));
      if (clienteSelecionado) {
         this.baseUrl = clienteSelecionado.url;
      }

      this.getData().then(
         (result) => {
            this.getData().then(
               () => {
                  this.navigation.timer = 0;
               }
            );
         }
      );
   }

   async getData() {
      try {
         this.tabContent = this.tabs[0].content;
         this.tabContexto = this.tabs[0].contexto;
         const organizacional_id = this.orgS.getOrgEmpresa();
         const origem = 'listaUsuario';
         const response_tipo: any = await this._gateway.backendCall('M4002', 'getMetaGerencial', {
            organizacional_id: organizacional_id, origem: origem, tipo: 1
         });
         const response_empresa: any = await this._gateway.backendCall('M4002', 'getMetaGerencial', {
            organizacional_id: organizacional_id, origem: origem, tipo: 2
         });
         console.log(response_tipo, response_empresa);

         this.tipo_ds = response_tipo.meta;
         this.empresa_ds = response_empresa.meta;
         this.navigation.loaderTela = false;
      } catch (error) {
         console.log(error);
      }
   }

   selectTab(e) {
      this.tabContent = this.tabs[e.itemIndex].content;
      this.tabContexto = this.tabs[e.itemIndex].contexto;
   }


   toast(msg, cor?, tempo?) {
      notify({
         message: msg,
         type: cor ? cor : 'success',
         displayTime: tempo ? tempo : 3000,
         closeOnClick: true,
         width: function () {
            return window.innerWidth / 2.8;
         }
      });
   }

   back() {
      this._router.navigate(['gerencial/painel']);
   }


}
