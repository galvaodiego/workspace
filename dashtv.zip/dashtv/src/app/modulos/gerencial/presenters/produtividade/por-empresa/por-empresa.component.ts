import { Component, OnInit, Input } from '@angular/core';
import { NotificacaoService } from 'src/app/shared/services/common/notificacao.service';
import { GatewayService } from 'src/app/shared';

import * as moment from 'moment';
import 'moment/locale/pt-br';
import { IfStmt } from '@angular/compiler';

@Component({
   selector: 'app-por-empresa',
   templateUrl: './por-empresa.component.html',
   styleUrls: ['./por-empresa.component.scss']
})
export class PorEmpresaComponent implements OnInit {
   @Input() dataSource: any;

   constructor(
      private _notificacao: NotificacaoService,
      private _gateway: GatewayService
   ) { }

   ngOnInit() { }

   async save(data, operation) {
      if (data.data_base) {
         data.data_base = moment(data.data_base).format('YYYY-MM-DD');
      }
      const response: any = await this._gateway.backendCall('M4002', operation, data);
      let status = 'success';

      if (response && response.mensagem.status === 0) {
         status = 'error';
      }

      this._notificacao.toast(response.mensagem.mensagem, status);
      return response.mensagem;
   }

   insert = (e) => {
      if (e.data.valor && e.data.data_base) {
         this.save(e.data, 'insertMeta').then((res) => {
            if (res.id) {
               e.data.id = res.id;
            }
            e.component.refresh();
         });

      }
   }

   update = (e) => {
      if (e.data.valor && e.data.data_base) {
         this.save(e.data, 'updateMeta');
      }
   }

   delete = (e) => {
      if (e.data.id) {
         this.save(e.data, 'deleteMeta');
      }
   }

}
