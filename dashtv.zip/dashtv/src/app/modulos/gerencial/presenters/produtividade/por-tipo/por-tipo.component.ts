import { Component, OnInit, Input } from '@angular/core';
import { NotificacaoService } from 'src/app/shared/services/common/notificacao.service';
import { GatewayService } from 'src/app/shared';

@Component({
   selector: 'app-por-tipo',
   templateUrl: './por-tipo.component.html',
   styleUrls: ['./por-tipo.component.scss']
})
export class PorTipoComponent implements OnInit {
   @Input() dataSource: any;
   options_controle: any = [
      { valor: 0, descricao: 'Não' },
      { valor: 1, descricao: 'Sim' },
   ];
   constructor(
      private _notificacao: NotificacaoService,
      private _gateway: GatewayService
   ) { }

   ngOnInit() {}
   async saveAll() {
      const gridDataSource = [...this.dataSource];
      const response: any = await this._gateway.backendCall('M4002', 'atualizaMeta', { 'meta': gridDataSource });
      if (response && response.mensagem.status === 1) {
         this._notificacao.toast('Dados salvos com sucesso!');
      } else {
         this._notificacao.toast('Não foi possivel salvar os dados!', 'error');
      }
   }
   onToolbarPreparing = (e) => {
      const toolbarItems = e.toolbarOptions.items;
      const comp = this;
      toolbarItems.forEach(function (item) {
         if (item.name === 'saveButton') {
            Object.assign(item.options, {
               onClick: function () {
                  e.component.saveEditData();
                  comp.saveAll();
                  e.component.refresh();
               }
            });
         }
      });

   }
}
