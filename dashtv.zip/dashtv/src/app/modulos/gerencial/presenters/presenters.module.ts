import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PresentersRouting } from './presenters.routing';
import { PainelComponent } from './painel/painel.component';
import { UsuarioBiDashComponent } from './usuario-bi-dash/usuario-bi-dash.component';
import { DxTabsModule, DxSelectBoxModule, DxFormModule, DxCheckBoxModule, DxDataGridModule, DxButtonModule, DxPopupModule } from 'devextreme-angular';
import { ProdutividadeComponent } from './produtividade/produtividade.component';
import { ControleAlertasComponent } from './controle-alertas/controle-alertas.component';
import { PorEmpresaComponent } from './produtividade/por-empresa/por-empresa.component';
import { PorTipoComponent } from './produtividade/por-tipo/por-tipo.component';

@NgModule({
   imports: [
      CommonModule,
      PresentersRouting,
      DxTabsModule,
      DxSelectBoxModule,
      DxFormModule,
      DxCheckBoxModule,
      DxDataGridModule,
      DxButtonModule,
      DxPopupModule

   ],
   declarations: [
      PainelComponent,
      UsuarioBiDashComponent,
      ProdutividadeComponent,
      ControleAlertasComponent,
      PorEmpresaComponent,
      PorTipoComponent,

   ],
})
export class PresentersModule { }
