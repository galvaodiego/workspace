import { ModuleWithProviders } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { GuardaRotas } from 'src/app/shared';

// Componentes
import { PainelComponent } from './painel/painel.component';
import { UsuarioBiDashComponent } from './usuario-bi-dash/usuario-bi-dash.component';
import { ProdutividadeComponent } from './produtividade/produtividade.component';
import { ControleAlertasComponent } from './controle-alertas/controle-alertas.component';

const modulo = 'gerencial';
const PRESENTERS_ROUTES: Routes = [
    {
        path: 'painel',
        canActivate: [GuardaRotas],
        component: PainelComponent,
        data: { modulo }
    },
    {
        path: 'usuario-bi-dash',
        canActivate: [GuardaRotas],
        component: UsuarioBiDashComponent,
        data: { modulo }
    },
    {
        path: 'produtividade',
        canActivate: [GuardaRotas],
        component: ProdutividadeComponent,
        data: { modulo }
    },
    {
        path: 'controle-alertas',
        canActivate: [GuardaRotas],
        component: ControleAlertasComponent,
        data: { modulo }
    },
];

export const PresentersRouting: ModuleWithProviders = RouterModule.forChild(PRESENTERS_ROUTES);