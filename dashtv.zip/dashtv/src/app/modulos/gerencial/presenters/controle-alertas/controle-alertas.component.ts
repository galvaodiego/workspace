import { Component, OnInit } from '@angular/core';
import { Usuario, NavigationService, EstruturaOrganizacionalService, GatewayService, ClienteService } from 'src/app/shared';
import { Router } from '@angular/router';
import notify from 'devextreme/ui/notify';


@Component({
   selector: 'app-controle-alertas',
   templateUrl: './controle-alertas.component.html',
   styleUrls: ['./controle-alertas.component.scss']
})
export class ControleAlertasComponent implements OnInit {
   user: Usuario = Usuario.instance;
   datasource: any;
   indicadores: any;
   showOpcoes: boolean;
   departamentos: Array<any>;

   constructor(
      private _router: Router,
      public navigation: NavigationService,
      public orgS: EstruturaOrganizacionalService,
      private _gateway: GatewayService,
      private _cliente: ClienteService
   ) {
      this.navigation.loaderTela = false;
      this.navigation.hideTimeBar = true;
      this.user.showIconOpcoes = false;
      this.showOpcoes = false;
   }

   ngOnInit() {
      // getControleAlertas
      this._gateway.backendCall('M4002', 'getControleAlertas').then((res: any) => {
         console.log('res', res);
         this.datasource = res.controle_alertas;
      });
      //getIndicadores
      this._gateway.backendCall('M4002', 'getIndicadores').then((res: any) => {
         console.log('res', res);
         this.indicadores = res.indicadores;
      });

      // getOperadores
      this._gateway.backendCall('M4002', 'getOperadores').then((res: any) => {
         console.log('res', res);
         this.departamentos = res.operadores;
      });
   }

   alt(e) {
      const obj = Object.assign({}, e.oldData, e.newData);
      Object.assign(e, {
         data: obj
      });

      const ativo = e.data.ativo;

      Object.assign(e.data, {
         controle_alertas_id: e.key,
         ativo: (ativo ? 1 : 0)
      });

      this._gateway.backendCall('M4002', 'altControleAlertas', e.data).then((res: any) => {
         this.toast(res.mensagem);
      });
   }

   back() {
      this._router.navigate(['gerencial/painel']);
   }

   toast(msg, cor?, tempo?) {
      notify({
         message: msg,
         type: cor ? cor : 'success',
         displayTime: tempo ? tempo : 3000,
         closeOnClick: true,
         width: function () {
            return window.innerWidth / 2.8;
         }
      });
   }

   onToolbarPreparing = (e) => {
      const toolbarItems = e.toolbarOptions.items;
      const comp = this;
      toolbarItems.forEach(function (item) {
         if (item.name === 'saveButton') {
            Object.assign(item.options, {
               onClick: function () {
                  e.component.saveEditData();
                  comp.saveAll();
                  e.component.refresh();
               }
            });
         }
      });

   }

   saveAll() {
      const gridDataSource = [...this.departamentos];
      const dataModel = {
         'operador': gridDataSource
      };

      dataModel.operador.map((item) => {
         item.controla = (item.controla ? 1 : 0)
      });

      this._gateway.backendCall('M4002', 'altOperador', dataModel).then((res: any) => {
         this.toast(res.mensagem.mensagem);
      });


   }

}
