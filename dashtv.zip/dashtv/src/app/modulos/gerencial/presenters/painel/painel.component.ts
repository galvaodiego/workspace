import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { NavigationService, Usuario, GatewayService, EstruturaOrganizacionalService, EstruturaOrganizacional } from 'src/app/shared';
import notify from 'devextreme/ui/notify';

@Component({
   selector: 'app-painel',
   templateUrl: './painel.component.html',
   styleUrls: ['./painel.component.scss']
})
export class PainelComponent implements OnInit, OnDestroy {

   public user: Usuario = Usuario.instance;
   private _org: EstruturaOrganizacional = EstruturaOrganizacional.instance;


   modulos: any = [];


   constructor(
      public navigation: NavigationService,
      public orgS: EstruturaOrganizacionalService,
      private _gateway: GatewayService,
      private _router: Router,
   ) {
      this.navigation.loaderTela = false;
      this.navigation.hideTimeBar = true;
      this.user.showIconOpcoes = false;
   }

   ngOnInit() {
      this.getData().then(
         (result) => {

         }
      );
   }

   ngOnDestroy() {
      clearInterval(this.navigation.trocaTela);
      clearInterval(this.navigation.tempoProgress);
   }


   async getData() {
      try {
         const parametrosBd = { organizacional_id: this.orgS.getOrgEmpresa(), usuario_bi_id: this._org.usuario.usuarioBiId };
         const response: any = await this._gateway.backendCall('1811-APPGESTOR', 'getModulosUsuario', parametrosBd);
         console.log('response:', response);
         this.modulos = response.modulo;
         this.navigation.loaderTela = false;
      } catch (error) {
         console.log(error)
      }

   }

   carregaModulo(modulo) {
      console.log('Modulo selecionado:', modulo);
      
      switch (modulo) {
         case 'Gerencial':
            // console.log('Carregando o módulo ' + modulo + '...');
            this._router.navigate(['gerencial/usuario-bi-dash']);
            break;

         case 'Produtividade':
            // console.log('Carregando o módulo ' + modulo + '...');
            this._router.navigate(['gerencial/produtividade']);
            break;

         case 'Controle de Alertas':
            // console.log('Carregando o módulo ' + modulo + '...');
            this._router.navigate(['gerencial/controle-alertas']);
            break;

         default:
            this.toast('O módulo ' + modulo + ' ainda não possui tela gerencial', 'warning');
            break;
      }
   }

   toast(msg, tipo) {
      notify({
         message: msg,
         type: tipo,
         displayTime: 3000,
         closeOnClick: true,
      });
   }
}
