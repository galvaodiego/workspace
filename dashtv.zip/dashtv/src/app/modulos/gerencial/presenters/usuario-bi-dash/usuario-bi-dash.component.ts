import { Component, OnInit } from '@angular/core';
import { Usuario, NavigationService, EstruturaOrganizacionalService, GatewayService } from 'src/app/shared';
import { Router } from '@angular/router';

import notify from 'devextreme/ui/notify';

@Component({
   selector: 'app-usuario-bi-dash',
   templateUrl: './usuario-bi-dash.component.html',
   styleUrls: ['./usuario-bi-dash.component.scss']
})
export class UsuarioBiDashComponent implements OnInit {
   public user: Usuario = Usuario.instance;

   tabs: any = [
      {
         id: 0,
         text: 'Usuário',
         icon: 'user',
         content: 'User tab content'
      },
      {
         id: 1,
         text: 'Usuário / Dash',
         icon: 'chart',
         content: 'Comment tab content'
      }
   ];

   ativo_options: any = [
      { value: 1, description: 'Sim' },
      { value: 0, description: 'Não' },
   ];

   dataModel = {
      usuario: '',
      ativo: 1
   };

   dataModel2 = {
      usuario: '',
      dashboard: ''
   };

   listaUsuario: any = [];
   listaUsuarioDash: any = [];
   usuarios: any = [];
   dashboards: any = [];

   selectedTab = 0;

   constructor(
      private _router: Router,
      public navigation: NavigationService,
      public orgS: EstruturaOrganizacionalService,
      private _gateway: GatewayService,
   ) {
      this.navigation.loaderTela = false;
      this.navigation.hideTimeBar = true;
      this.user.showIconOpcoes = false;
   }

   ngOnInit() {
      // this.getData('listaUsuario');
      // this.getData('listaUsuarioDash');

      // console.log(this.listaUsuario, this.listaUsuarioDash);

      this.getData().then(
         (result) => {
            this.getData().then(
               () => {
                  this.navigation.timer = 0;
               }
            );
         }
      );
   }

   selectTab(e) {
      this.selectedTab = e.itemIndex;
   }

   async cad(origem, acao, e) {
      switch (acao) {
         case 'insert':
            switch (origem) {
               case 'listaUsuario':
                  const response_ins: any = await this._gateway.backendCall('1811-APPGESTOR', 'insUsuarioBi', e.data);
                  this.toast(response_ins.mensagem, 'success');
                  break;

               case 'listaUsuarioDash':
                  const response_ins_ud: any = await this._gateway.backendCall('1811-APPGESTOR', 'insUsuarioDash', e.data);
                  this.toast(response_ins_ud.mensagem, 'success');
                  break;
            }

            break;
         case 'update':
            switch (origem) {
               case 'listaUsuario':
                  Object.assign(e.data, {
                     usuario_bi_id: e.key
                  });

                  console.log('data:', e);

                  const response_ins: any = await this._gateway.backendCall('1811-APPGESTOR', 'altUsuarioBi', e.data);
                  this.toast(response_ins.mensagem, 'success');
                  break;

               case 'listaUsuarioDash':
                  Object.assign(e.data, {
                     usuario_bi_dash_id: e.key
                  });
                  const response_ins_ud: any = await this._gateway.backendCall('1811-APPGESTOR', 'altUsuarioDash', e.data);
                  this.toast(response_ins_ud.mensagem, 'success');
                  break;
            }
            break;
         case 'delete':
            switch (origem) {
               case 'listaUsuario':
                  const response_ins: any = await this._gateway.backendCall('1811-APPGESTOR', 'delUsuarioBi', e.data);
                  this.toast(response_ins.mensagem, 'success');
                  break;

               case 'listaUsuarioDash':
                  const response_ins_ud: any = await this._gateway.backendCall('1811-APPGESTOR', 'delUsuarioDash', e.data);
                  this.toast(response_ins_ud.mensagem, 'success');
                  break;
            }
            break;

      }
      this.getData();
   }


   async getData() {
      try {
         const parametrosBd = { organizacional_id: this.orgS.getOrgEmpresa(), origem: 'listaUsuario' };
         const response1: any = await this._gateway.backendCall('1811-APPGESTOR', 'getUsuarioDash', parametrosBd);
         this.listaUsuario = response1.usuario_dash;

         const parametrosBd2 = { organizacional_id: this.orgS.getOrgEmpresa(), origem: 'listaUsuarioDash' };
         const response2: any = await this._gateway.backendCall('1811-APPGESTOR', 'getUsuarioDash', parametrosBd2);
         this.listaUsuarioDash = response2.usuario_dash;

         const param = { organizacional_id: this.orgS.getOrgEmpresa() };
         const response_u: any = await this._gateway.backendCall('1811-APPGESTOR', 'getUsuarioBi', param);
         const response_d: any = await this._gateway.backendCall('1811-APPGESTOR', 'getDash', param);

         this.usuarios = response_u.usuario_bi;
         this.dashboards = response_d.dash;

         this.navigation.loaderTela = false;
      } catch (error) {
         console.log(error);
      }
   }

   toast(msg, tipo) {
      notify({
         message: msg,
         type: tipo,
         displayTime: 3000,
         closeOnClick: true,
      });
   }

   ajustaObj(origem, acao, options) {
      const obj = Object.assign({}, options.oldData, options.newData);
      Object.assign(options,{
         data: obj
      });

      this.cad(origem, acao, options);
   }

   back() {
      this._router.navigate(['gerencial/painel']);
   }

}
