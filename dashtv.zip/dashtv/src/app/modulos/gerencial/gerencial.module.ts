import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GerencialRouting } from './gerencial.routing';

@NgModule({
   imports: [
      CommonModule,
      GerencialRouting
  ]
})
export class GerencialModule { }
