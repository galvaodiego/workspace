import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const GERENCIAL_ROUTES: Routes = [
    {
        path: '',
        loadChildren: 'src/app/modulos/gerencial/presenters/presenters.module#PresentersModule',
    }
];

export const GerencialRouting: ModuleWithProviders = RouterModule.forChild(GERENCIAL_ROUTES);