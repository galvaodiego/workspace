import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PresentersRouting } from './presenters.routing';
import { FeaturesModule } from '../features/features.module';

// Componentes
import { DashboardView } from './dashboard.view';
import { RecebiveisComponent } from './recebiveis/recebiveis.component';
import { DxLoadPanelModule, DxDataGridModule, DxChartModule } from 'devextreme-angular';

@NgModule({
    imports: [
        CommonModule,
        PresentersRouting,
        FeaturesModule,
        DxLoadPanelModule,
        DxDataGridModule,
        DxChartModule
    ],
    declarations: [
        DashboardView,
        RecebiveisComponent
    ],
})
export class PresentersModule { }
