import { ModuleWithProviders } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { GuardaRotas } from 'src/app/shared';

// Componentes
import { DashboardView } from './dashboard.view';
import { RecebiveisComponent } from './recebiveis/recebiveis.component';
const modulo = 'financeiro';
const PRESENTERS_ROUTES: Routes = [
    {
        path: 'faturamento',
        component: DashboardView,
        canActivate: [GuardaRotas],
        data: {
            pageTitle: 'Faturamento',
            dashboard: 'faturamento',
            modulo,
            versao: 1
        }
    },
    {
        path: 'faturamento_v2',
        component: DashboardView,
        canActivate: [GuardaRotas],
        data: {
            pageTitle: 'Faturamento',
            dashboard: 'faturamento',
            modulo,
            versao: 2
        }
    },
    {
      path: 'recebiveis',
      canActivate: [GuardaRotas],
      component: RecebiveisComponent,
      data: { modulo }
   },
];

export const PresentersRouting: ModuleWithProviders = RouterModule.forChild(PRESENTERS_ROUTES);
