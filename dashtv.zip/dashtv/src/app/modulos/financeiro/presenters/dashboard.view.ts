import { Component } from '@angular/core';

@Component({
    template: `<app-feature-financeiro-faturamento></app-feature-financeiro-faturamento>`
})
export class DashboardView {

    constructor() { }

}