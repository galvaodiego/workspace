import { Component, OnInit, OnDestroy } from '@angular/core';
import SetInterval from 'set-interval';
import { Usuario, NavigationService, GatewayService } from 'src/app/shared';

import * as moment from 'moment';
import { getPalette } from 'devextreme/viz/palette';
import { UtilitarioService } from 'src/app/shared/services/common/utilitario.service';


@Component({
   selector: 'app-recebiveis',
   templateUrl: './recebiveis.component.html',
   styleUrls: ['./recebiveis.component.scss']
})
export class RecebiveisComponent implements OnInit, OnDestroy {
   public user: Usuario = Usuario.instance;
   datasource: any = [];
   loadingVisible = true;
   fatuEmpresa = '00:00:00';
   recupComprovante = '00:00:00';


   constructor(
      public navigation: NavigationService,
      private _gateway: GatewayService,
      public utilitario: UtilitarioService
   ) {
      this.navigation.loaderTela = true;
      this.navigation.hideTimeBar = false;
      this.navigation.timer_troca_tela = 120000; // importante para funcionar corretamente a troca de tela

      this.user.showIconOpcoes = false;
      this.user.showIconFiltro = true;
      this.user.showFiltroOpcoes = false;
      this.user.showIconTemplates = false;
      this.user.showTemplates = false;
   }

   ngOnInit() {
      this.getData().then(() => { this.navigation.trocaDash(); });
   }

   ngOnDestroy() {
      SetInterval.clear('trocaTela');
   }

   async getData() {
      try {
         const response: any = await this._gateway.backendCall('M4002', 'getFinanceiroDash');
         console.log('response:', response);
         this.datasource = response.telaTemposFinan;

         if (this.datasource.tempoEmpresa) {
            this.fatuEmpresa = this.utilitario.convertTime(this.datasource.tempoEmpresa[0].valor);
         }

         if (this.datasource.tempoRecupEmpresa) {
            this.recupComprovante = this.utilitario.convertTime(this.datasource.tempoRecupEmpresa[0].valor);
         }


         if (this.datasource.docSemComp) {
            const listas = this.datasource.docSemComp;
            if (listas) {
               listas.map(e => {
                  e.valor = this.utilitario.convertTime(e.tempo);
               });
            }
         }

         if (this.datasource.docSemFaturar) {
            const listas = this.datasource.docSemFaturar;
            if (listas) {
               listas.map(e => {
                  e.valor = this.utilitario.convertTime(e.tempo);
               });
            }
         }

         if (this.datasource.tempoClientes) {
            const top5 = this.datasource.tempoClientes.slice(0, 5);
            this.datasource.tempoClientes = top5.reverse();

         }

         if (this.datasource.tempoRecupClientes) {
            const top5 = this.datasource.tempoRecupClientes.slice(0, 5);
            this.datasource.tempoRecupClientes = top5.reverse();
         }

         if (this.datasource.percAbertCliente) {
            const top5 = this.datasource.percAbertCliente.slice(0, 5);
            this.datasource.percAbertCliente = top5.reverse();
         }


         this.loadingVisible = false;
         this.navigation.loaderTela = false;
      } catch (error) {
         console.log(error);
      }
   }

   gridsDocs(e: any) {
      if (e.rowType === 'header') {
         e.cellElement.style.paddingTop = '5px';
         e.cellElement.style.paddingBottom = '5px';
      }

      if (typeof (e.data) !== 'undefined') {
         e.cellElement.style.paddingTop = '5px';
         e.cellElement.style.paddingBottom = '5px';
      }
   }

   customizePointMultiple = (arg: any) => {
      const tipo = 'Soft';

      const palette = getPalette(tipo);
      const index = arg.index % (palette.simpleSet.length - 1);
      return { color: palette.simpleSet[index] };
   }

   customizeLabel = (arg: any) => {
      const obj = this;
      return {
         customizeText(e: any) {
            return obj.utilitario.convertTime(e.value);
         }
      };
   }

}
