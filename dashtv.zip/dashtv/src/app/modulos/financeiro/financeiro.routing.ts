import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const FINANCEIRO_ROUTES: Routes = [
    {
        path: '',
        loadChildren: 'src/app/modulos/financeiro/presenters/presenters.module#PresentersModule',
    }
];

export const FinanceiroRouting: ModuleWithProviders = RouterModule.forChild(FINANCEIRO_ROUTES)
