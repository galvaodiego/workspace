import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DxChartModule, DxPieChartModule, DxPopupModule, DxTagBoxModule, DxRadioGroupModule, DxDataGridModule, DxScrollViewModule, DxCheckBoxModule, DxLoadPanelModule, DxButtonModule } from 'devextreme-angular';

import { SharedModule } from 'src/app/shared/shared.module';

// Componentes
import { FaturamentoComponent } from './faturamento/faturamento-dashboard.component';

@NgModule({
    imports: [
        CommonModule,
        SharedModule,
        DxChartModule,
        DxPieChartModule,
        DxPopupModule,
        DxTagBoxModule,
        DxRadioGroupModule,
        DxDataGridModule,
        DxScrollViewModule,
        DxCheckBoxModule,
        DxLoadPanelModule,
        DxButtonModule
    ],
    declarations: [
        FaturamentoComponent
    ],
    exports: [
        FaturamentoComponent
    ],
})
export class FeaturesModule { }
