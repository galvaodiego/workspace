import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';

import { NavigationService, Usuario, UsuarioService, GatewayService, ClienteService } from 'src/app/shared';
import { DxTagBoxComponent, DxPieChartComponent, DxPopupComponent } from 'devextreme-angular';
import { FaturamentoService } from '../../services/faturamento.service';

import * as _ from 'underscore';
import SetInterval from 'set-interval';

import io from 'socket.io-client';
import { environment } from 'src/environments/environment';
import { NotificacaoService } from 'src/app/shared/services/common/notificacao.service';
import { TemplateService } from 'src/app/shared/services/template.service';
import { ActivatedRoute } from '@angular/router';

@Component({
   selector: 'app-feature-financeiro-faturamento',
   templateUrl: './faturamento-dashboard.component.html',
   styleUrls: ['./faturamento-dashboard.component.scss']
})
export class FaturamentoComponent implements OnInit, OnDestroy {
   @ViewChild('filtroCliente', { static: false }) filtroCliente: DxTagBoxComponent;
   @ViewChild('filtroDestino', { static: false }) filtroDestino: DxTagBoxComponent;
   @ViewChild('filtroPlaca', { static: false }) filtroPlaca: DxTagBoxComponent;
   @ViewChild('filtroMercadoria', { static: false }) filtroMercadoria: DxTagBoxComponent;
   @ViewChild('filtroModalidade', { static: false }) filtroModalidade: DxTagBoxComponent;
   @ViewChild('filtroCarroceria', { static: false }) filtroCarroceria: DxTagBoxComponent;

   @ViewChild('chartMercadoriaPie', { static: false }) chartMercadoriaPie: DxPieChartComponent;
   @ViewChild('popFiltro', { static: false }) popFiltro: DxPopupComponent;
   @ViewChild('popTemplates', { static: false }) popTemplates: DxPopupComponent;

   public user: Usuario = Usuario.instance;

   // FILTROS
   listaFiltroCliente: any = [];
   listaFiltroMercadoria: any = [];
   listaFiltroDestino: any = [];
   listaFiltroPlaca: any = [];
   listaFiltroModalidade: any = [];
   listaFiltroCarroceria: any = [];
   filtros: any = {
      cliente: [],
      mercadoria: [],
      destino: [],
      placa: [],
      modalidade: [],
      carroceria: []
   };
   tipo_info: any = ['Semanal', 'Mensal', 'Anual'];
   selectedItensCliente = [];
   selectedItensDestino = [];
   selectedItensPlaca = [];
   selectedItensMercadoria = [];
   selectedItensModalidade = [];
   selectedItensCarroceria = [];

   visualizacao: any;

   // Troca de Graficos
   public interval: any;
   public tabGrafico: string;

   org: any;
   usuario: any;
   dash: any;
   template: any;

   modelo_template: number;
   loadingVisible = false;

   // Config elemento-grafico
   por_veiculos_opcoes = ['Placa', 'Frota'];
   por_veiculos_indicador = 'Placa';
   grafico_pizza_legenda = true;
   grafico_pizza_label = false;
   /***/

   // Config Socket
   socket_io: any;
   socket_rota = 'faturamento';
   socket_metodo = 'getFaturamento';
   socket_filtro: any;
   /***/
   periodo = 'anual';
   modo_auto_status = 'normal';
   modo_automatico = false;
   tempo_troca_visualizacao: number;

   constructor(
      public navigation: NavigationService,
      public UsuarioService: UsuarioService,
      private _gateway: GatewayService,
      private _clienteS: ClienteService,
      private _faturamentoService: FaturamentoService,
      private _notificacao: NotificacaoService,
      private templateService: TemplateService,
      private route: ActivatedRoute,
   ) {
      this.navigation.timer = 0;
      this.navigation.loaderTela = true;
      this.navigation.timer_troca_tela = 120000; // importante para funcionar corretamente a troca de tela
      this.tempo_troca_visualizacao = 10000; // troca entre Semanal/Mensal/Anual

      this.user.showIconOpcoes = false;
      this.user.showIconFiltro = true;
      this.user.showFiltroOpcoes = false;
      this.user.showIconTemplates = true;
      this.user.showTemplates = false;
      const tipo = localStorage.getItem('tipoVisualizacao');
      if (tipo) {
         this.visualizacao = this.tabGrafico = tipo;
      } else {
         this.visualizacao = this.tabGrafico = 'Mensal';
      }
      this.template = {};
      this.modelo_template = 1;

      this.socket_io = io(environment.socket_end_point + '/' + this.socket_rota);
      this.socket_filtro = {
         base: (this._clienteS.clienteAtivo !== 'KMM' ? this._clienteS.clienteAtivo : environment.end_point_base_dev).toLowerCase(),
         periodo: this.visualizacao.toLowerCase()
      };
   }

   ngOnInit() {
      this.loadingVisible = true;
      const filtros = localStorage.getItem('filtros');
      const tipoFatVeiculo = localStorage.getItem('faturamento-tipoFatVeiculo');
      const faturamentoConfigPie = JSON.parse(localStorage.getItem('faturamentoConfigPie'));
      const modo_automatico = JSON.parse(localStorage.getItem('faturamento-modo-automatico'));

      if (filtros) {
         this.filtros = JSON.parse(filtros);
         this.selectedItensCliente = this.filtros.cliente;
         this.selectedItensDestino = this.filtros.destino;
         this.selectedItensPlaca = this.filtros.placa;
         this.selectedItensMercadoria = this.filtros.mercadoria;
         this.selectedItensModalidade = this.filtros.modalidade;
         this.selectedItensCarroceria = this.filtros.carroceria;

         if (this.filtroCliente) {
            this.filtroCliente.selectedItems = this.filtroCliente.value = this.filtros.cliente;
         }

         if (this.filtroDestino) {
            this.filtroDestino.selectedItems = this.filtroDestino.value = this.filtros.destino;
         }

         if (this.filtroCarroceria) {
            this.filtroCarroceria.selectedItems = this.filtroCarroceria.value = this.filtros.carroceria;
         }

         if (this.filtroMercadoria) {
            this.filtroMercadoria.selectedItems = this.filtroMercadoria.value = this.filtros.mercadoria;
         }

         if (this.filtroModalidade) {
            this.filtroModalidade.selectedItems = this.filtroModalidade.value = this.filtros.modalidade;
         }

         if (this.filtroPlaca) {
            this.filtroPlaca.selectedItems = this.filtroPlaca.value = this.filtros.placa;
         }
      }

      if (tipoFatVeiculo) {
         this.por_veiculos_indicador = tipoFatVeiculo;
      }

      if (faturamentoConfigPie) {
         this.grafico_pizza_legenda = faturamentoConfigPie.grafico_pizza_legenda;
         this.grafico_pizza_label = faturamentoConfigPie.grafico_pizza_label;
      }

      if (modo_automatico != null) {
         this.modo_automatico = modo_automatico;
         if (this.modo_automatico) {
            this.modo_auto_status = 'success';
         } else {
            this.modo_auto_status = 'normal';
         }
         this.modoAutomatico();
      }

      this.socket().then(() => {
         this.navigation.trocaDash();
         this.loadingVisible = false;
         this.navigation.loaderTela = false;
      });

   }

   async socket() {
      try {

         if (this.filtros.cliente.length > 0) {
            Object.assign(this.socket_filtro, {
               cliente: this.filtros.cliente
            });
         }
         if (this.filtros.destino.length > 0) {
            Object.assign(this.socket_filtro, {
               destino: this.filtros.destino
            });
         }
         if (this.filtros.carroceria.length > 0) {
            Object.assign(this.socket_filtro, {
               carroceria: this.filtros.carroceria
            });
         }
         if (this.filtros.mercadoria.length > 0) {
            Object.assign(this.socket_filtro, {
               mercadoria: this.filtros.mercadoria
            });
         }
         if (this.filtros.modalidade.length > 0) {
            Object.assign(this.socket_filtro, {
               modalidade: this.filtros.modalidade
            });
         }
         if (this.filtros.placa.length > 0) {
            Object.assign(this.socket_filtro, {
               placa: this.filtros.placa
            });
         }

         if (this.route.snapshot.data['versao'] === 2) {
            this.socket_io.emit(this.socket_metodo + '_v2', this.socket_filtro);
            // console.log('metodo',this.socket_metodo + '_v2');
         } else {
            this.socket_io.emit(this.socket_metodo, this.socket_filtro);
            // console.log('metodo',this.socket_metodo);
         }
         this.socket_io.on(this.socket_rota, (data) => {
            console.log('data', data, 'filtro:', this.socket_filtro);

            data.faturamentoDestino.map((element, index) => {
               Object.assign(element, { '#': index + 1 });
            });
            data.faturamentoPlaca.map((element, index) => {
               Object.assign(element, { '#': index + 1, });
            });
            data.faturamentoFilial.map((element, index) => {
               Object.assign(element, { '#': index + 1, });
            });

            // AQUI DEFINE OS SELECTS COM OS DADOS ENVIADOS, PARA O FILTRO.
            const clientes = [];
            data.faturamentoCliente.forEach(element => {
               clientes.push(element.cliente);
            });
            const destinos = [];
            data.faturamentoDestino.forEach(element => {
               destinos.push(element.destino);
            });
            const placas = [];
            data.faturamentoPlaca.forEach(element => {
               placas.push(element.placa);
            });
            const mercadorias = [];
            data.faturamentoMercadoria.forEach(element => {
               mercadorias.push(element.mercadoria);
            });
            const modalidades = [];
            data.faturamentoModalidade.forEach(element => {
               modalidades.push(element.modalidade);
            });
            const carrocerias = [];
            data.faturamentoCarroceria.forEach(element => {
               carrocerias.push(element.tipoCarroceria);
            });

            this.listaFiltroCliente = _.uniq(clientes).sort();
            this.listaFiltroDestino = _.uniq(destinos).sort();
            this.listaFiltroPlaca = _.uniq(placas).sort();
            this.listaFiltroMercadoria = _.uniq(mercadorias).sort();
            this.listaFiltroModalidade = _.uniq(modalidades).sort();
            this.listaFiltroCarroceria = _.uniq(carrocerias).sort();

            // console.log('filtro:', filtro, 'data:', data);
            this.getTemplate(data);
         });
      } catch (error) {
         console.log('error => ', error);
      }
   }

   ngOnDestroy() {
      SetInterval.clear('trocaTela');
      SetInterval.clear('modo_automatico');
      this.socket_io.disconnect();
   }

   getTemplate(matriz) {
      this.org = JSON.parse(localStorage.getItem('kmm_bi-dash|' + this._clienteS.discover() + '-organizacional'));
      this.usuario = JSON.parse(localStorage.getItem('kmm_bi-dash|' + this._clienteS.discover() + '-usuario'));

      this.dash = this.usuario.listaDashboards.filter(element => {
         if (this.route.snapshot.data['versao'] === 2) {
            return element.path === 'financeiro/faturamento_v2';
         } else {
            return element.path === 'financeiro/faturamento';
         }
      });
      const parametros = {
         usuario_bi_id: this.org.usuarioBiId ? this.org.usuarioBiId : this.org.usuario.usuarioBiId,
         dash_id: this.dash[0].dash_id
      };

      // console.log('parametros', parametros);
      this.templateService.backendCall(parametros, 'post', 'get').then((res: any) => {
         if (res.dados && res.dados.length > 0) {
            this.preparaLayout(res.dados, matriz)
         }
         this.loadingVisible = false;
      })

   }

   preparaLayout(tmp, matriz) {
      this.modelo_template = tmp[0].modelo_id;
      const slots = tmp[0].slots;

      for (let index = 0; index < slots.length; index++) {
         if (slots[index] > 0) {
            switch (index) {
               case 0: // slot 1
                  Object.assign(this.template, {
                     slot_1: this._faturamentoService.getDefinicoes(slots[index], this.visualizacao, matriz)
                  });
                  break;
               case 1: // slot 2
                  Object.assign(this.template, {
                     slot_2: this._faturamentoService.getDefinicoes(slots[index], this.visualizacao, matriz)
                  });
                  break;
               case 2: // slot 3
                  Object.assign(this.template, {
                     slot_3: this._faturamentoService.getDefinicoes(slots[index], this.visualizacao, matriz)
                  });
                  break;
               case 3: // slot 4
                  Object.assign(this.template, {
                     slot_4: this._faturamentoService.getDefinicoes(slots[index], this.visualizacao, matriz)
                  });
                  break;
               case 4: // slot 5
                  Object.assign(this.template, {
                     slot_5: this._faturamentoService.getDefinicoes(slots[index], this.visualizacao, matriz)
                  });
                  break;
               case 5: // slot 6
                  Object.assign(this.template, {
                     slot_6: this._faturamentoService.getDefinicoes(slots[index], this.visualizacao, matriz)
                  });
                  break;
               case 6: // slot 7
                  Object.assign(this.template, {
                     slot_7: this._faturamentoService.getDefinicoes(slots[index], this.visualizacao, matriz)
                  });
                  break;
            }
         }
      }
   }

   customizeLabelGrafico(arg: any) {
      let text: string;
      if (typeof (arg.valueText.split(',')) != 'undefined') {
         text = arg.valueText.split(',');
      } else {
         text = arg.valueText;
      }

      return 'R$ ' + text[0] + ' (' + arg.percentText + ')';
   }

   aplicaFiltro(e) {
      if (typeof (e) !== 'undefined') {
         if (e.name === 'selectedItems') {
            switch (e.element.id) {
               case 'filtroCliente':
                  this.filtros.cliente = e.value;
                  break;
               case 'filtroDestino':
                  this.filtros.destino = e.value;
                  break;
               case 'filtroPlaca':
                  this.filtros.placa = e.value;
                  break;
               case 'filtroMercadoria':
                  this.filtros.mercadoria = e.value;
                  break;
               case 'filtroModalidade':
                  this.filtros.modalidade = e.value;
                  break;
               case 'filtroCarroceria':
                  this.filtros.carroceria = e.value;
                  break;
            }
         }
      }
   }

   filtrar() {
      localStorage.setItem('filtros', JSON.stringify(this.filtros));
      this.popFiltro.visible = false;
      this.socket();
   }

   limparFiltro() {
      localStorage.removeItem('filtros');
      this.filtroCliente.instance.reset();
      this.filtroDestino.instance.reset();
      this.filtroPlaca.instance.reset();
      this.filtroMercadoria.instance.reset();
      this.filtroModalidade.instance.reset();
      this.filtroCarroceria.instance.reset();
      this.filtrar();
   }

   onValueChangedVisualizacao(e) {
      localStorage.setItem('tipoVisualizacao', e.value);
      this.visualizacao = e.value;
      this.tabGrafico = e.value;
      // this.socket();
      Object.assign(this.socket_filtro, {
         periodo: e.value.toLowerCase()
      });
      this.socket_io.emit(this.socket_metodo, this.socket_filtro);
      this.popFiltro.instance.hide();

   }

   onValueChangedFatVei(e) {
      localStorage.setItem('faturamento-tipoFatVeiculo', e.value);
      this.por_veiculos_indicador = e.value;
      location.reload();
   }

   reciver(e) {
      if (e.mensagem) {
         this.popTemplates.instance.hide();
         location.reload();
      }
   }


   configGraficoPizza() {
      const obj = {
         grafico_pizza_legenda: this.grafico_pizza_legenda,
         grafico_pizza_label: this.grafico_pizza_label,
      };
      localStorage.setItem('faturamentoConfigPie', JSON.stringify(obj));
      location.reload();

   }

   acionaModoAutomatico() {
      this.modo_automatico = !this.modo_automatico;
      let msg = '';
      let tipo = 'success';
      if (this.modo_automatico) {
         this.modo_auto_status = 'success';
         msg = 'Modo Automático Ativado';
      } else {
         this.modo_auto_status = 'normal';
         msg = 'Modo Automático Desativado';
         tipo = 'info';
      }
      localStorage.setItem('faturamento-modo-automatico', JSON.stringify(this.modo_automatico));
      this._notificacao.toast(msg, tipo);
      this.modoAutomatico();
   }

   modoAutomatico() {
      let i = 0;
      if (this.modo_automatico) {
         SetInterval.start(() => {
            this.visualizacao = this.tipo_info[i];
            i++;
            if (i === this.tipo_info.length) {
               i = 0;
            }

            console.log('Visualização ', this.visualizacao);
         }, this.tempo_troca_visualizacao, 'modo_automatico');
      } else {
         SetInterval.clear('modo_automatico');
         console.log('Parou modo automático');

      }
   }

}
