import { Injectable } from '@angular/core';
import * as _ from 'underscore';


@Injectable({
   providedIn: 'root'
})
export class FaturamentoService {

   constructor() { }

   getDefinicoes(tipo, visualizacao, matriz) {
      const obj = {};
      switch (tipo) {
         case 1:
            Object.assign(obj, {
               tipo: 'linha-horizontal-meta',
               vf: 'valor',
               af: 'data',
               datasource: matriz.faturamentoPeriodo,
               titulo: 'Faturamento ' + visualizacao,
            });

            return obj;
            break;
         case 2:
            Object.assign(obj, {
               tipo: 'faturamento-por-veiculo',
               af: null,
               vf: null,
               titulo: 'Faturamento ' + visualizacao + ' por Veículo',
               datasource: matriz.faturamentoPlaca
            });
            return obj;
            break;

         case 3:
            Object.assign(obj, {
               tipo: 'faturamento-por-destino',
               af: null,
               vf: null,
               titulo: 'Faturamento ' + visualizacao + ' por Destino',
               datasource: matriz.faturamentoDestino
            });
            return obj;
            break;
         case 4:
            Object.assign(obj, {
               tipo: 'box-titulo-valor',
               af: null,
               vf: null,
               titulo: 'Faturamento Total ' + visualizacao,
               datasource: this.getTotalFaturamento(matriz.faturamentoPeriodo)
            });
            return obj;
            break;
         case 5:
            Object.assign(obj, {
               tipo: 'pie-leg-right',
               af: 'cliente',
               vf: 'valor',
               titulo: 'Faturamento ' + visualizacao + ' por Cliente',
               datasource: this.getFatCliente(matriz.faturamentoCliente)
            });
            return obj;
            break;
         case 6:
            Object.assign(obj, {
               tipo: 'box-titulo-valor',
               af: null,
               vf: null,
               titulo: 'Faturamento Médio ' + visualizacao + ' por emissão',
               datasource: this.getFatMediaViagens(matriz.faturamentoPeriodo)
            });
            return obj;
            break;
         case 7:
            Object.assign(obj, {
               tipo: 'pie-leg-right',
               af: 'mercadoria',
               vf: 'valor',
               titulo: 'Faturamento ' + visualizacao + ' por Mercadoria',
               datasource: this.getFatMercadoria(matriz.faturamentoMercadoria)
            });
            return obj;
            break;
         case 8:
            Object.assign(obj, {
               tipo: 'pie-leg-right',
               af: 'modalidade',
               vf: 'valor',
               titulo: 'Faturamento ' + visualizacao + ' por Modalidade',
               datasource: this.getFatModalidade(matriz.faturamentoModalidade)
            });
            return obj;
            break;
         case 9:
            Object.assign(obj, {
               tipo: 'pie-leg-right',
               af: 'carroceria',
               vf: 'valor',
               titulo: 'Faturamento ' + visualizacao + ' por Carroceria',
               datasource: this.getFatCarroceria(matriz.faturamentoCarroceria)
            });
            return obj;
            break;
         case 10:
            Object.assign(obj, {
               tipo: 'box-titulo-valor',
               af: null,
               vf: null,
               titulo: 'Faturamento Total ' + visualizacao + ' Previsto',
               datasource: this.getTotalFatPrevisto(matriz.faturamentoPeriodo)
            });
            return obj;
            break;
         case 11:
            Object.assign(obj, {
               tipo: 'barra-horizontal',
               af: 'cliente',
               vf: 'valor',
               titulo: 'Faturamento Top 10 - ' + visualizacao,
               datasource: this.getFatCliente(matriz.faturamentoCliente).reverse()
            });
            return obj;
            break;
         case 12:
            Object.assign(obj, {
               tipo: 'pie-leg-right',
               af: 'filial',
               vf: 'valor',
               titulo: 'Faturamento ' + visualizacao + ' por Filial',
               datasource: this.getFatFilial(matriz.faturamentoFilial)
            });
            return obj;
            break;
         case 13:
            Object.assign(obj, {
               tipo: 'faturamento-por-filial',
               af: null,
               vf: null,
               tipo_legenda: 'valor',
               titulo: 'Faturamento ' + visualizacao + ' por Filial',
               datasource: matriz.faturamentoFilial
            });
            return obj;
            break;
         case 14:
            Object.assign(obj, {
               tipo: 'faturamento-por-periodo-tbl',
               tipo_legenda: 'valor',
               datasource: matriz.faturamentoPeriodo,
               titulo: 'Faturamento ' + visualizacao,
            });
            return obj;
            break;
      }
   }

   getFatCliente(matriz) {
      let lista = [], top10 = [];
      lista = _.sortBy(matriz, 'valor').reverse();
      if (lista.length > 10) {
         let novoSaldo = 0;
         let novoSaldoMeta = 0;
         lista.forEach((element, i) => {
            if (i > 9) {
               novoSaldo += element.valor;
               novoSaldoMeta += element.meta;
            } else {
               top10.push({ cliente: element.cliente, valor: element.valor, meta: element.meta });
            }
         });

         // retirado na tarefa: 140343 -- solicitação do Heder
         // if (novoSaldo > 0) {
         //    top10.push({ cliente: 'OUTROS', valor: novoSaldo, meta: novoSaldoMeta });
         // }
      } else {
         top10 = lista;
      }

      return top10;

   }

   getFatMercadoria(matriz) {
      let lista = [], top10 = [];
      lista = _.sortBy(matriz, 'valor').reverse();
      if (lista.length > 10) {
         let novoSaldo = 0;
         lista.forEach((element, i) => {
            if (i > 9) {
               novoSaldo += element.valor;
            } else {
               top10.push({ mercadoria: element.mercadoria, valor: element.valor });
            }
         });

         if (novoSaldo > 0) {
            top10.push({ mercadoria: 'OUTROS', valor: novoSaldo });
         }
      } else {
         top10 = lista;
      }

      return top10;
   }

   getFatMediaViagens(matriz) {
      let viagem = 0, valor = 0, total = 0;

      matriz.forEach(element => {
         viagem = viagem + element.viagens;
         total += element.valor;
      });
      valor = total / viagem;
      return valor;
   }

   getSubstituicaoMensal(matriz) {
      let sub = 0;
      matriz.forEach(element => {
         sub = sub + element.subistituto;
      });
      return sub;
   }

   getFatModalidade(matriz) {
      let lista = [], top10 = [];
      lista = _.sortBy(matriz, 'valor').reverse();
      if (lista.length > 10) {
         let novoSaldo = 0;
         lista.forEach((element, i) => {
            if (i > 9) {
               novoSaldo += element.valor;
            } else {
               top10.push({ modalidade: element.modalidade, valor: element.valor });
            }
         });

         if (novoSaldo > 0) {
            top10.push({ modalidade: 'OUTROS', valor: novoSaldo });
         }
      } else {
         top10 = lista;
      }

      return top10;
   }

   getFatCarroceria(matriz) {
      let lista = [], top10 = [];
      lista = _.sortBy(matriz, 'valor').reverse();
      if (lista.length > 10) {
         let novoSaldo = 0;
         lista.forEach((element, i) => {
            if (i > 9) {
               novoSaldo += element.valor;
            } else {
               top10.push({ carroceria: element.tipoCarroceria, valor: element.valor });
            }
         });

         if (novoSaldo > 0) {
            top10.push({ carroceria: 'OUTROS', valor: novoSaldo });
         }
      } else {
         top10 = lista;
      }

      return top10;
   }

   getTotalFaturamento(matriz) {
      return matriz.map((tupla: any) => {
         return Number.parseFloat(tupla['valor']);
      }).reduce((anterior: any, atual: any) => {
         return (anterior + atual);
      }, 0);
   }

   getTotalFatPrevisto(matriz) {
      return matriz.map((tupla: any) => {
         return Number.parseFloat(tupla['meta']);
      }).reduce((anterior: any, atual: any) => {
         return (anterior + atual);
      }, 0);
   }

   getFatFilial(matriz) {
      let lista = [], top10 = [];
      lista = _.sortBy(matriz, 'valor').reverse();
      if (lista.length > 10) {
         let novoSaldo = 0;
         lista.forEach((element, i) => {
            if (i > 9) {
               novoSaldo += element.valor;
            } else {
               top10.push({ filial: element.filial, valor: element.valor });
            }
         });

         if (novoSaldo > 0) {
            top10.push({ filial: 'OUTROS', valor: novoSaldo });
         }
      } else {
         top10 = lista;
      }

      return top10;
   }

}
