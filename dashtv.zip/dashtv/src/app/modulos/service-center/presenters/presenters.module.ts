import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PresentersRouting } from './presenters.routing';
import { FeaturesModule } from '../features/features.module';

import { ChartModule } from 'angular2-chartjs';
import { DxChartModule, DxDataGridModule, DxPieChartModule, DxPopupModule } from 'devextreme-angular';

import { ComponentsModule } from 'src/app/shared/components/components.module';

//Componentes
import { AtendimentosComponent } from './atendimentos/atendimentos.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { FiliaisComponent } from './filiais/filiais.component';


@NgModule({
    imports: [
        CommonModule,
        PresentersRouting,
        FeaturesModule,
        ComponentsModule,

        ChartModule,
        DxChartModule,
        DxPieChartModule,
        DxDataGridModule,
        DxPopupModule
    ],
    declarations: [
        AtendimentosComponent,
        DashboardComponent,
        FiliaisComponent,
    ],
})
export class PresentersModule { }
