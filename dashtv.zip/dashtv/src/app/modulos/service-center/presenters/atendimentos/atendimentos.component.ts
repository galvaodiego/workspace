import { Component, OnInit, OnDestroy } from '@angular/core';

import { GatewayService, NavigationService, Usuario } from 'src/app/shared';
import SetInterval from 'set-interval';

@Component({
   selector: 'app-atendimentos',
   templateUrl: './atendimentos.component.html',
   styleUrls: ['./atendimentos.component.scss']
})
export class AtendimentosComponent implements OnInit, OnDestroy {

   public user: Usuario = Usuario.instance;

   public listaAtendimentosAbertos: Array<any> = [];
   public tempoMedio: any;

   constructor(
      public _gateway: GatewayService,
      public navigation: NavigationService,
   ) {
      this.navigation.loaderTela = true;
      this.navigation.timer_troca_tela = 30000; // importante para funcionar corretamente a troca de tela

      this.user.showIconOpcoes = false;
   }

   ngOnInit() {
      this.getData().then(() => { this.navigation.trocaDash(); });
   }

   ngOnDestroy() {
      SetInterval.clear('trocaTela');
      SetInterval.clear('intervalo_tabelas');
   }

   async getData() {
      try {
         const response: any = await this._gateway.backendCall('M4002', 'getListaAtendimentos');
         this.navigation.loaderTela = false;
         this.tempoMedio = response.atendimentos.tempo_medio;
         this.listaAtendimentosAbertos = response.atendimentos.lista_atendimentos;
      } catch (error) {
         console.log('Erro nos Atendimentos -> ', error);
      }
   }


   /**
   * Função Para Alterar o Estilo da Tabela
   * @param e Evento recebido pelo componente
   */

   onCellPrepared(e: any) {
      e.cellElement.style.fontSize = '1.2em';
      e.cellElement.style.fontWeight = '700';
      e.cellElement.style.padding = '0.5rem';
   }

}
