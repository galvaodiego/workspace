import { Component, OnInit, OnDestroy } from '@angular/core';
import { ChartjsModel, Usuario, NavigationService, GatewayService, UsuarioService } from 'src/app/shared';

import * as moment from 'moment';
import 'moment/locale/pt-br';
import SetInterval from 'set-interval';


@Component({
   selector: 'app-dashboard',
   templateUrl: './dashboard.component.html',
   styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit, OnDestroy {

   public user: Usuario = Usuario.instance;
   public interval: any;
   public graphic = false;
   public totalAtPendentes: any = [];
   public atGroup: any = [];
   public mapaCalorTurno: Array<any> = [];
   public mapaCalorHora: Array<any> = [];
   public mapaCalorHoraMirror: Array<any> = [];
   public indicadores: Array<any> = [];
   public atAberto: Array<any> = [];
   public atCliente: Array<any> = [];
   public tempoAtendimento: Array<any> = [];
   public tempoMedioDiaAnterior: any = {};
   public tempoMedioDia: any = {};
   public tempoMedioUltimaHora: any = {};
   public barChartOptions: any = {
      maintainAspectRatio: true,
      scales: {
         yAxes: [{
            ticks: {
               beginAtZero: true,
            },
         }],
         xAxes: [{
            ticks: {
               fontSize: 10
            }
         }]
      }
   };

   public barChartOptionsHour: any = {
      maintainAspectRatio: true,
      scales: {
         yAxes: [{
            ticks: {
               beginAtZero: true,
            },
         }],
         xAxes: [{
            ticks: {
               fontSize: 10
            },
            categoryPercentage: 1.0,
            barPercentage: 1.0
         }]
      }
   };

   public dataBarChartTurn: any = {};
   public dataBarChartHour: any = {};
   public timer: number;
   public hourIndicator: number;

   constructor(public navigation: NavigationService, private _gateway: GatewayService, public UsuarioService: UsuarioService) {
      this.hourIndicator = this.setValueProgress();
      this.navigation.loaderTela = true;
      this.navigation.timer_troca_tela = 30000; // importante para funcionar corretamente a troca de tela

      this.user.showIconOpcoes = false;
   }


   ngOnInit() {
      this.getData().then(() => {
         this.navigation.trocaDash();
         if (this.user.listaDashboards.length == 1) {
            this.hourIndicator = this.setValueProgress();
         }
      });

      this.switchTabs();
   }

   ngOnDestroy() {
      SetInterval.clear('trocaTela');
      clearInterval(this.interval);
   }

   /*
   * Monta o objeto de configuração das informações do gráfico
   */
   public setChartModel(data: any, type: string) {
      const object: ChartjsModel = new ChartjsModel();
      const dataset: Array<number> = [];
      const colors: Array<string> = [];
      const label = 'Tempo médio (min)';
      data.forEach(item => {
         let value: number;
         value = parseFloat(item.tempo_medio);
         item.tempo_medio_at = this.tempoMedioDiaAnterior.quantidade_old;
         object.addLabelItem(item.hora.toString());
         dataset.push(value);
         if (item.tempo_medio <= 0.3 * item.tempo_medio_at) {
            colors.push('rgb(117,125,138)');
         } else if ((item.tempo_medio > 0.3 * item.tempo_medio_at && item.tempo_medio <= 0.5 * item.tempo_medio_at)) {
            colors.push('rgb(23,210,222)'); // vHeatMap11
         } else if ((item.tempo_medio > 0.5 * item.tempo_medio_at && item.tempo_medio <= 0.6 * item.tempo_medio_at)) {
            colors.push('rgb(23,165,221)'); // vHeatMap10
         } else if ((item.tempo_medio > 0.6 * item.tempo_medio_at && item.tempo_medio <= 0.8 * item.tempo_medio_at)) {
            colors.push('rgb(23,119,221)'); // vHeatMap9
         } else if ((item.tempo_medio > 0.8 * item.tempo_medio_at && item.tempo_medio <= 0.9 * item.tempo_medio_at)) {
            colors.push('rgb(24,74,220)'); // vHeatMap8
         } else if ((item.tempo_medio > 0.9 * item.tempo_medio_at && item.tempo_medio <= item.tempo_medio_at)) {
            colors.push('rgb(24,29,220)'); // vHeatMap7
         } else if ((item.tempo_medio > item.tempo_medio_at && item.tempo_medio <= 1.1 * item.tempo_medio_at)) {
            colors.push('rgb(64,25,220)'); // vHeatMap6
         } else if ((item.tempo_medio > 1.1 * item.tempo_medio_at && item.tempo_medio <= 1.3 * item.tempo_medio_at)) {
            colors.push('rgb(109,25,219)'); // vHeatMap5
         } else if ((item.tempo_medio > 1.3 * item.tempo_medio_at && item.tempo_medio <= 1.5 * item.tempo_medio_at)) {
            colors.push('rgb(153,25,219)'); // vHeatMap4
         } else if ((item.tempo_medio > 1.5 * item.tempo_medio_at && item.tempo_medio <= 2 * item.tempo_medio_at)) {
            colors.push('rgb(197,26,218)'); // vHeatMap3
         } else if (item.tempo_medio > 2 * item.tempo_medio_at) {
            colors.push('rgb(218,26,195)'); // vHeatMap2
         } else {
            colors.push('rgb(255,255,255)'); // vHeatMapNull
         }
      });
      object.addDatasetItem({
         data: dataset,
         label: label,
         backgroundColor: colors,
         borderColor: colors
      });
      return object;
   }


   /*
    * Retorna a classe css que modifica a cor da média da última hora
    */
   public getClassByTime(value: number): string {
      let color = '';
      if ((value > 0) && (value <= 10)) {
         color = 'i-ultima-hora-0';
      } else if ((value > 10 && value <= 15)) {
         color = 'i-ultima-hora-1';
      } else if ((value > 15 && value <= 20)) {
         color = 'i-ultima-hora-2';
      } else if ((value > 20 && value < 30)) {
         color = 'i-ultima-hora-3';
      } else if ((value >= 30)) {
         color = 'i-ultima-hora-4';
      }
      return color;
   }

   /*
    * Retorna o valor em % para preenchimento do progress bar
    */
   public setValueProgress(): number {
      const value = (Number(moment().format('mm')) / 60) * 100;
      return parseFloat(value.toFixed(0));
   }

   /*
    * Devolve  o índice de um item no array para colorir na interface.
    */
   public setIndex(item) {
      // acrescenta 1 pra corrigir o Sass que não usa o índice 0.
      return this.indicadores.findIndex(element => element.status === item.status) + 1;
   }

   /*
    * Pega os dados do servidor
    */
   public async getData(): Promise<any> {
      return this._gateway.backendCall('M4002', 'getCentralAtendimentos').then((res: any) => {
         console.log('res', res);
         this.navigation.loaderTela = false;
         // Indicadores
         this.indicadores = res.central_atendimentos.indicadores;
         // Listagens
         this.atAberto = res.central_atendimentos.atend_abertos_funcionario;
         this.atCliente = res.central_atendimentos.atend_abertos_cliente;
         // Tempos de AT
         console.log('--->', res.central_atendimentos.tempo_atendimento);

         this.tempoAtendimento = res.central_atendimentos.tempo_atendimento;
         // tslint:disable-next-line: max-line-length
         this.tempoMedioDiaAnterior = this.tempoAtendimento.find(element => element.intervalo.toLowerCase() == 'Médio dia anterior (minuto)'.toLowerCase());
         // tslint:disable-next-line: max-line-length
         this.tempoMedioDia = this.tempoAtendimento.find(element => element.intervalo.toLowerCase() == 'Média dia atual (minuto)'.toLowerCase());
         // tslint:disable-next-line: max-line-length
         this.tempoMedioUltimaHora = this.tempoAtendimento.find(element => element.intervalo.toLowerCase() == 'Médio Ultima Hora'.toLowerCase());
         this.mapaCalorTurno = res.central_atendimentos.heatmap_turno;
         // Gráfico mapa de Calor Hora
         this.dataBarChartHour = {
            labels: this.setChartModel(res.central_atendimentos.heatmap_hora, 'bar-hour').labels,
            datasets: this.setChartModel(res.central_atendimentos.heatmap_hora, 'bar-hour').datasets,
         };
         // Gráfico AT por Grupo
         this.atGroup = res.central_atendimentos.grupo_atendimentos;
         this.atGroup = this.getDataAt(this.atGroup);
      });
   }

   /**
    * Retorna o resultado no Formato do Chart
    * @param lista dados
    */
   public getDataAt(lista: Array<any>) {
      const listaDataAt: Array<any> = [];
      lista.forEach(element => {
         listaDataAt.push(element);
      });
      return listaDataAt;
   }

   /**
   * REALIZA A ALTERNÂNCIA ENTRE AS TABS
   */
   private switchTabs() {
      this.interval = setInterval(tabs => {
         this.graphic = !this.graphic;
      }, 15000);
   }
}
