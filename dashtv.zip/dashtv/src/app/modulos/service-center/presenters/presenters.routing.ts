import { ModuleWithProviders } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";

import { GuardaRotas } from "src/app/shared";

//Componentes
import { DashboardComponent } from "./dashboard/dashboard.component";
import { AtendimentosComponent } from "./atendimentos/atendimentos.component";
import { FiliaisComponent } from './filiais/filiais.component';
const modulo = 'service-center';
const PRESENTERS_ROUTES: Routes = [
    {
        path: 'dashboard',
        canActivate: [GuardaRotas],
        component: DashboardComponent,
        data: { modulo }
    },
    {
        path: 'lista-atendimentos',
        canActivate: [GuardaRotas],
        component: AtendimentosComponent,
        data: { modulo }
    },
    {
        path: 'filiais',
        canActivate: [GuardaRotas],
        component: FiliaisComponent,
        data: { modulo }
    }
];

export const PresentersRouting: ModuleWithProviders = RouterModule.forChild(PRESENTERS_ROUTES);