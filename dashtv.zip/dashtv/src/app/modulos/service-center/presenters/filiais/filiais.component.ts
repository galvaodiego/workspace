import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';

import { DxDataGridComponent } from 'devextreme-angular';
import { Usuario, NavigationService, UsuarioService, GatewayService } from 'src/app/shared';

import * as moment from 'moment';
import 'moment/locale/pt-br';
import SetInterval from 'set-interval';


@Component({
   selector: 'app-filiais',
   templateUrl: './filiais.component.html',
   styleUrls: ['./filiais.component.scss']
})
export class FiliaisComponent implements OnInit, OnDestroy {


   @ViewChild("gridFiliais", { static: false }) gridFiliais: DxDataGridComponent
   @ViewChild("gridProtocolos", { static: false }) gridProtocolos: DxDataGridComponent

   public user: Usuario = Usuario.instance;

   public dataHoje: string = '';
   public popupFiliais: boolean = false;
   public popupMensagem: boolean = false;

   public listaFiliais: any = [];

   public filialSelecionada: any = [];
   public filialSelecionadaTipo: any = [];
   public filialSelecionadaProtocolos: any = [];

   constructor(
      public navigation: NavigationService,
      public userProvider: UsuarioService,
      private _gateway: GatewayService
   ) {
      this.navigation.loaderTela = true;
      this.navigation.timer_troca_tela = 60000; // importante para funcionar corretamente a troca de tela

      this.user.showIconOpcoes = false;
   }

   ngOnInit() {
      this.dataHoje = moment().format('LL');
      this.getData().then(() => { this.navigation.trocaDash(); });
   }

   ngOnDestroy() {
      SetInterval.clear('trocaTela');
   }

   /**
    * Resgata os Dados
    */
   async getData() {
      let parametrosBd = { filiais: this.user.filiais };

      try {
         const response: any = await this._gateway.backendCall('M4002', 'getFiliais', parametrosBd);

         this.navigation.loaderTela = false;
         console.log('response filiais', response);
         this.listaFiliais = response.filiais;

         //Se Houver Filial Selecionada no Storage, resgata. Se não pega a 1ª do resultado
         let filtroStorage: any = this.user.listaDashboards[this.user.listaDashboards.findIndex(element => element.dash_id == this.user.selectedDashboard)].filters;

         if (typeof (filtroStorage.tipo) !== 'undefined') {
            this.escolheFilial('getFilters');
         } else {
            this.filialSelecionada = response.filiais[0];

            if (typeof (this.filialSelecionada) !== 'undefined') {
               this.filialSelecionadaProtocolos = this.filialSelecionada.tipo[0].mensagens;
               this.filialSelecionadaTipo = this.filialSelecionada.tipo[0].descricao;
            }
         }
      } catch (error) {
         console.log(error)
      }
   }

   /**
    * Alterna entre Filiais
    */
   public escolheFilial(modo: any) {
      if (modo == 'getFilters') {
         this.filialSelecionada = this.user.listaDashboards[this.user.listaDashboards.findIndex(element => element.dash_id == this.user.selectedDashboard)].filters;
         this.filialSelecionadaProtocolos = this.filialSelecionada.tipo[0].mensagens;
         this.filialSelecionadaTipo = this.filialSelecionada.tipo[0].descricao;
         this.setFilters(this.user.selectedDashboard, this.filialSelecionada);
      } else {
         this.popupFiliais = false;
         this.filialSelecionada = this.gridFiliais.selectedRowKeys[0];
         this.filialSelecionadaProtocolos = this.filialSelecionada.tipo[0].mensagens;
         this.filialSelecionadaTipo = this.filialSelecionada.tipo[0].descricao;
         this.setFilters(this.user.selectedDashboard, this.filialSelecionada);
      }
   }


   /**
    *  Altera o Conteudo da lista de Protocolos conforme card selecionado
    * @param item card Selecionado
    */
   public escolheTipo(item: any) {
      this.filialSelecionadaTipo = item.descricao;
      this.filialSelecionadaProtocolos = item.mensagens
   }


   /**
    * Visualiza a Mensagem
    * @param e evento
    */
   public openMensagem(e: any) {
      if (typeof (e.data) !== 'undefined') {
         if (e.data.situacao_id == 5) {
            this.popupMensagem = true;
            setTimeout(() => {
               document.getElementById("htmlMsg").innerHTML = e.data.mensagem_texto;
            }, 10);
         }
      }
   }

	/**
    * Função Para Alterar o Estilo da Tabela
    * @param e Evento recebido pelo componente
    */
   public onCellPrepared(e: any) {
      e.cellElement.style.fontSize = '1rem';
      e.cellElement.style.fontWeight = '500';
      e.cellElement.style.padding = '5px 15px 5px 15px';

      if (typeof (e.data) !== 'undefined') {
         if (e.column.caption == 'Mensagem') {
            e.cellElement.style.color = '#' + e.data.cor;
         }
      }

      if (e.rowType == 'group') {
         e.cellElement.style.backgroundColor = '#c7c7c7';
         e.cellElement.style.color = '#000000';
         e.cellElement.style.padding = '3px';
      }
   }

   /**
   *  Salva o filtro do painel na sessão.
   * @param {number} id - Id do dash que contém o filtro
   * @param {Array<any>} parameters - Parâmetros do filtro
   */

   public setFilters(id: number, parameters) {
      this.user.listaDashboards[this.user.listaDashboards.findIndex(element => element.dash_id == id)].filters = parameters;
      this.userProvider.save();
   }

   /**
   *  Resgata o filtro do painel da sessão.
   * @param {number} id - ID do dash que contém o filtro
   */
   public getFilters(id: number) {
      let filters = this.user.listaDashboards[this.user.listaDashboards.findIndex(element => element.dash_id == id)].filters;
      return filters;
   }

}
