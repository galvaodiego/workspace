import { Component, Input, ViewChild, AfterViewInit } from '@angular/core';

import { GridComponent } from 'src/app/shared/components/grid/grid.component';
import { GridColumn } from 'src/app/shared/';

@Component({
    selector: 'app-feature-service-center-atendimentos-grid',
    template: `
    <div class="card">
        <div class="body pd-table">
            <app-grid #atendimentosGrid [dataSource]="dataSourceForGrid"></app-grid>
        </div>
    </div>
    `
})
export class AtendimentosGrid implements AfterViewInit {

    @ViewChild('atendimentosGrid', { static: true }) atendimentosGrid: GridComponent;

    @Input('dados') dados: any;

    dataSourceForGrid: any = {};

    columns = [
        GridColumn.Text({ dataField: 'situacao', caption: 'Situação', alignment: 'center' }),
        GridColumn.Text({ dataField: 'categoria', caption: 'Categoria', alignment: 'center' }),
        GridColumn.Text({ dataField: 'codigo', caption: 'Código', alignment: 'center' }),
        GridColumn.Datetime({ dataField: 'abertura', caption: 'Abertura', alignment: 'center'}),
        GridColumn.Datetime({ dataField: 'expectativa', caption: 'Expectativa', alignment: 'center'}),
        GridColumn.Text({ dataField: 'cliente', caption: 'Cliente', alignment: 'center' }),
        GridColumn.Text({ dataField: 'tempo_aberto', caption: 'Tempo Aberto', alignment: 'center' }),
    ];

    ngAfterViewInit() {
        this.dataSourceForGrid = {
            contextName: 'atendimentosGrid',
            arrayResult: this.dados,
            columns: this.columns,
            options: {}
        };
    }

}