import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ComponentsModule } from 'src/app/shared/components/components.module';


//Componentes
import { AtendimentosGrid } from './grids/atendimentos.grid';

@NgModule({
    imports: [
        CommonModule,
        ComponentsModule
    ],
    declarations: [
        AtendimentosGrid
    ],
    exports: [
        AtendimentosGrid
    ],
})
export class FeaturesModule { }
