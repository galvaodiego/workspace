import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ServiceCenterRouting } from './service-center.routing';

@NgModule({
    imports: [
        CommonModule,
        ServiceCenterRouting
    ]
})
export class ServiceCenterModule { }