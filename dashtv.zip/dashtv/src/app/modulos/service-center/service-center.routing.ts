import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const SERVICECENTER_ROUTES: Routes = [
    {
        path: '',
        loadChildren: 'src/app/modulos/service-center/presenters/presenters.module#PresentersModule',
    }
];

export const ServiceCenterRouting: ModuleWithProviders = RouterModule.forChild(SERVICECENTER_ROUTES);