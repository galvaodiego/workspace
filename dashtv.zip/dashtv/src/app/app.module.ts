/////////////////////////////////
//           ANGULAR           //
/////////////////////////////////
import { BrowserModule } from '@angular/platform-browser';
import { NgModule, LOCALE_ID } from '@angular/core';
import { HttpModule } from '@angular/http';
import { NgxWebstorageModule } from 'ngx-webstorage';
import { RouterModule } from '@angular/router';
import { LoadingBarHttpModule } from '@ngx-loading-bar/http';

/////////////////////////////////
//          APP E KMM          //
/////////////////////////////////
import { AppComponent } from './app.component';
import { AppRouting } from './app.routing';

/////////////////////////////////
//           MODULOS           //
/////////////////////////////////
import { AutenticacaoModule } from './modulos/autenticacao/autenticacao.module';
import { SharedModule } from './shared/shared.module';
import { ComponentsModule } from './shared/components/components.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

@NgModule({
    declarations: [
        AppComponent,
    ],
    imports: [
        BrowserModule,
        NgxWebstorageModule,
        NgxWebstorageModule.forRoot({ prefix: 'kmm_bi-dash', separator: '|', caseSensitive: true }),
        HttpModule,
        LoadingBarHttpModule,
        RouterModule,
        AppRouting,

        //MÓDULOS DA APLICAÇÃO
        AutenticacaoModule,
        SharedModule, // Componentes compartilhados na App
        ComponentsModule, BrowserAnimationsModule
    ],
    providers: [
        { provide: LOCALE_ID, useValue: 'pt' },
    ],
    bootstrap: [AppComponent]
})
export class AppModule { }