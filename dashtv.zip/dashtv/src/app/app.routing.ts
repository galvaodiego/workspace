import { Routes, RouterModule } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';

import { NotFoundComponent } from './shared/components/not-found/not-found.component';

const APP_ROUTES: Routes = [
    {
        path: 'financeiro',
        loadChildren: './modulos/financeiro/financeiro.module#FinanceiroModule'
    },
    {
        path: 'jornada',
        loadChildren: './modulos/jornada/jornada.module#JornadaModule'
    },
    {
        path: 'logistica',
        loadChildren: './modulos/logistica/logistica.module#LogisticaModule'
    },
    {
        path: 'manutencao',
        loadChildren: './modulos/manutencao/manutencao.module#ManutencaoModule'
    },
    {
        path: 'service-center',
        loadChildren: './modulos/service-center/service-center.module#ServiceCenterModule'
    },
    {
        path: 'porto',
        loadChildren: './modulos/porto/porto.module#PortoModule'
    },
    {
        path: 'gerencial',
        loadChildren: './modulos/gerencial/gerencial.module#GerencialModule'
    },
    {
        path: 'suprimentos',
        loadChildren: './modulos/suprimentos/suprimentos.module#SuprimentosModule'
    },
   //  {
   //      path: '**',
   //      component: NotFoundComponent
   //  }
];
export const AppRouting: ModuleWithProviders = RouterModule.forRoot(APP_ROUTES, {
    // enableTracing: true  //console.log das Rotas
});
