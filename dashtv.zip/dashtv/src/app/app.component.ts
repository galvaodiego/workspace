import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, NavigationEnd } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { filter, map, switchMap } from 'rxjs/operators'

import { ClienteService, Usuario, UsuarioService, EstruturaOrganizacionalService, NavigationService } from 'src/app/shared';

@Component({
   selector: 'app-root',
   templateUrl: './app.component.html',
   styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {

   private _user: Usuario = Usuario.instance;

   constructor(
      private _router: Router,
      private _clienteS: ClienteService,
      private _userProvider: UsuarioService,
      private _acRoute: ActivatedRoute,
      private _titleS: Title,
      public navigation: NavigationService,
      private _orgProvider: EstruturaOrganizacionalService
   ) {

      // Define o Cliente que esta acessando
      this._clienteS.discover();

      console.log('Cliente Selecionado: ', this._clienteS.discover());


      // Inicia o Storage do Usuário
      this._userProvider.init().then(
         (user) => {

            // Inicia o Storage do Organizacional
            this._orgProvider.init().then(
               (org) => {

                  if (this._user.isLogged) {
                     if (this._user.plataforma_tipo !== 2) {
                        // tslint:disable-next-line: max-line-length
                        const dashs = this._user.listaDashboards[this._user.listaDashboards.findIndex(element => element.dash_id == this._user.selectedDashboard)];
                        this._router.navigate([dashs.path]);
                     }

                  } else {
                     this._router.navigate(['']);
                  }

               }
            )
         }
      );
   }

   ngOnInit() {
      console.log('navigation.loaderTela: ', this.navigation.loaderTela, 'navigation.hideTimeBar: ', this.navigation.hideTimeBar);

      this._router.events
         .pipe(filter(event => event instanceof NavigationEnd))
         .pipe(map(() => this._acRoute))
         .pipe(map(route => {
            while (route.firstChild) { route = route.firstChild; }
            return route;
         }))
         .pipe(switchMap(route => route.data))
         .subscribe((event => {
            if (typeof (this._user.listaDashboards[
               this._user.listaDashboards.findIndex(element => element.dash_id == this._user.selectedDashboard)
            ]) !== 'undefined') {
               this._user.selectedDashDescricao = this._user.listaDashboards[
                  this._user.listaDashboards.findIndex(element => element.dash_id == this._user.selectedDashboard)
               ].descricao;
               this._titleS.setTitle('KMM BI | ' + this._user.selectedDashDescricao);
            }
         }))
   }


   /**
    * Retorna se o Usuário está Logado
    */
   public isAuthenticated() {
      return this._user.isLogged;
   }

}
