export const environment = {
  production: true,
  version: '1.2.16',
  activeLogs: true,
  socket_end_point: 'https://kmm-bi.herokuapp.com',
  socket_end_point_base: 'https://kmm-base.herokuapp.com',
  socket_end_point_vm: 'https://torre-backend.kmm.com.br',
  tempo_troca_tela: 10, // min
  tempoReprocess: 59, //sec
  tempoEsperaSocket: 10000 //milisec
};
