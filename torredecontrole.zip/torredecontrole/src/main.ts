import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app/app.module';
import { environment } from './environments/environment';

if (environment.production) {
   enableProdMode();
}

// CONFIGS EM PT-BR DO ANGULAR
import localePt from '@angular/common/locales/pt';
import { registerLocaleData } from '@angular/common';
registerLocaleData(localePt);

//          DEVEXTREME         //

import 'devextreme-intl';
import * as messagesPt from './assets/devextreme-pt.json';
import config from 'devextreme/core/config';
import { loadMessages, locale } from 'devextreme/localization';

config({
   defaultCurrency: 'BRL',
   decimalSeparator: ',',
   thousandsSeparator: '.'
});

loadMessages(messagesPt.default);
locale('pt-BR');

// platformBrowserDynamic().bootstrapModule(AppModule)
//    .catch(err => console.error(err));

platformBrowserDynamic().bootstrapModule(AppModule).then(() => {
   if ('serviceWorker' in navigator && environment.production) {
      navigator.serviceWorker.register('OneSignalSDKWorker.js');
   }
}).catch(err => console.log(err));
