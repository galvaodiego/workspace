import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { Page404Component } from './modulos/home/page404/page404.component';
import { AutenticacaoLoginComponent } from './modulos/autenticacao/autenticacao-login/autenticacao-login.component';


const routes: Routes = [
   { path: '', component: AutenticacaoLoginComponent },
   { path: 'dashboard', loadChildren: () => import('./modulos/dashboard/dashboard.module').then(m => m.DashboardModule) },
   { path: 'viagens', loadChildren: () => import('./modulos/viagens/viagens.module').then(m => m.ViagensModule) },
   { path: 'carga', loadChildren: () => import('./modulos/carga/carga.module').then(m => m.CargaModule) },
   { path: 'descarga', loadChildren: () => import('./modulos/descarga/descarga.module').then(m => m.DescargaModule) },
   { path: 'tempo-carga', loadChildren: () => import('./modulos/tempo-carga/tempo-carga.module').then(m => m.TempoCargaModule) },
   { path: 'tempo-descarga', loadChildren: () => import('./modulos/tempo-descarga/tempo-descarga.module').then(m => m.TempoDescargaModule) },
   { path: 'tempo-viagem', loadChildren: () => import('./modulos/tempo-viagem/tempo-viagem.module').then(m => m.TempoViagemModule) },
   { path: 'tempo-destinado', loadChildren: () => import('./modulos/tempo-destinado/tempo-destinado.module').then(m => m.TempoDestinadoModule) },
   { path: 'alertas', loadChildren: () => import('./modulos/alertas/alertas.module').then(m => m.AlertasModule) },
   { path: 'alertas-carga', loadChildren: () => import('./modulos/alertas-carga/alertas-carga.module').then(m => m.AlertasCargaModule) },
   { path: 'alertas-descarga', loadChildren: () => import('./modulos/alertas-descarga/alertas-descarga.module').then(m => m.AlertasDescargaModule) },
   { path: 'alertas-viagem', loadChildren: () => import('./modulos/alertas-viagem/alertas-viagem.module').then(m => m.AlertasViagemModule) },
   { path: 'alertas-destinado', loadChildren: () => import('./modulos/alertas-destinado/alertas-destinado.module').then(m => m.AlertasDestinadoModule) },
   { path: 'veiculos-inoperantes', loadChildren: () => import('./modulos/veiculos-inoperantes/veiculos-inoperantes.module').then(m => m.VeiculosInoperantesModule) },
   { path: 'veiculos-vazios', loadChildren: () => import('./modulos/veiculos-vazios/veiculos-vazios.module').then(m => m.VeiculosVaziosModule) },
   { path: 'mv', loadChildren: () => import('./modulos/mv/mv.module').then(m => m.MvModule) },
   { path: '**', component: Page404Component }
];

@NgModule({
   imports: [RouterModule.forRoot(
      routes,
      { enableTracing: false } // <-- debugging purposes only
   )],
   exports: [RouterModule]
})
export class AppRoutingModule { }
