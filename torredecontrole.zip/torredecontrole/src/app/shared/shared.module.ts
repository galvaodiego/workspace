import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DxChartModule, DxDataGridModule, DxGalleryModule, DxPopupModule } from 'devextreme-angular';
import { DevextremeModule } from './modules/devextreme/devextreme.module';

import { RouterModule } from '@angular/router';
import { CountdownModule } from 'ngx-countdown';
import { MaterialModule } from './modules/material/material.module';
import { NgSelectModule } from '@ng-select/ng-select';

// components
import { NavBarComponent } from './components/nav-bar/nav-bar.component';
import { TreeListComponent } from './components/tree-list/tree-list.component';
import { NavBarMobileComponent } from './components/nav-bar-mobile/nav-bar-mobile.component';
import { LogoutScreenComponent } from './components/logout-screen/logout-screen.component';
import { FloatBoxComponent } from './components/float-box/float-box.component';
import { KpiImageComponent } from './components/kpi-image/kpi-image.component';
import { KpiCentralComponent } from './components/kpi-central/kpi-central.component';
import { ProgressBarVComponent } from './components/progress-bar-v/progress-bar-v.component';
import { LeafMapComponent } from './components/leaf-map/leaf-map.component';
import { DataGridDinamicoComponent } from './components/data-grid-dinamico/data-grid-dinamico.component';
import { KpiTempoComponent } from './components/kpi-tempo/kpi-tempo.component';
import { GalleryComponent } from './components/gallery/gallery.component';
import { AutoplayNavComponent } from './components/autoplay-nav/autoplay-nav.component';
import { FiltroGeralComponent } from './components/filtro-geral/filtro-geral.component';
import { LastUpdateComponent } from './components/last-update/last-update.component';
import { ChartBarComponent } from './components/chart-bar/chart-bar.component';
import { BlockTempoChartComponent } from './components/block-tempo-chart/block-tempo-chart.component';
import { PreviewListaExportComponent } from './components/preview-lista-export/preview-lista-export.component';
import { SeletorComponenteComponent } from './components/seletor-componente/seletor-componente.component';
import { AlertasIndicadoresComponent } from './components/alertas-indicadores/alertas-indicadores.component';
import { ReprocessandoComponent } from './components/reprocessando/reprocessando.component';



@NgModule({
   declarations: [
      NavBarComponent,
      TreeListComponent,
      NavBarMobileComponent,
      LogoutScreenComponent,
      FloatBoxComponent,
      KpiImageComponent,
      KpiCentralComponent,
      ProgressBarVComponent,
      LeafMapComponent,
      DataGridDinamicoComponent,
      KpiTempoComponent,
      GalleryComponent,
      AutoplayNavComponent,
      FiltroGeralComponent,
      LastUpdateComponent,
      ChartBarComponent,
      BlockTempoChartComponent,
      PreviewListaExportComponent,
      SeletorComponenteComponent,
      AlertasIndicadoresComponent,
      ReprocessandoComponent
   ],
   imports: [
      CommonModule,
      RouterModule,
      MaterialModule,
      DevextremeModule,
      DxPopupModule,
      DxDataGridModule,
      FormsModule,
      ReactiveFormsModule,
      DxGalleryModule,
      CountdownModule,
      NgSelectModule,
      DxChartModule
   ],
   exports: [
      MaterialModule,
      DevextremeModule,
      NavBarComponent,
      NavBarMobileComponent,
      TreeListComponent,
      KpiImageComponent,
      KpiCentralComponent,
      ProgressBarVComponent,
      LeafMapComponent,
      DataGridDinamicoComponent,
      KpiTempoComponent,
      GalleryComponent,
      AutoplayNavComponent,
      FiltroGeralComponent,
      LastUpdateComponent,
      ChartBarComponent,
      BlockTempoChartComponent,
      SeletorComponenteComponent,
      AlertasIndicadoresComponent,
      ReprocessandoComponent
   ],
})
export class SharedModule { }
