import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
   DxMultiViewModule,
   DxLoadPanelModule,
   DxTreeListModule,
   DxDataGridModule,
   DxPopupModule,
   DxScrollViewModule,
   DxCircularGaugeModule,
   DxChartModule,
   DxPieChartModule,
   DxMapModule,
   DxVectorMapModule,
   DxDateBoxModule,
   DxTagBoxModule
} from 'devextreme-angular';



@NgModule({
   declarations: [],
   imports: [
      CommonModule,
      DxMultiViewModule,
      DxLoadPanelModule,
      DxTreeListModule,
      DxDataGridModule,
      DxPopupModule,
      DxScrollViewModule,
      DxCircularGaugeModule,
      DxChartModule,
      DxPieChartModule,
      DxMapModule,
      DxVectorMapModule,
      DxDateBoxModule,
      DxTagBoxModule
   ],
   exports: [
      DxMultiViewModule,
      DxLoadPanelModule,
      DxTreeListModule,
      DxDataGridModule,
      DxPopupModule,
      DxScrollViewModule,
      DxCircularGaugeModule,
      DxChartModule,
      DxPieChartModule,
      DxMapModule,
      DxVectorMapModule,
      DxDateBoxModule,
      DxTagBoxModule

   ]
})
export class DevextremeModule { }
