export interface Config {
   showNotificacoes: boolean;
}

export class DashPermission {
   // tslint:disable-next-line:variable-name
   dash_id: number;
   descricao: string;
   // tslint:disable-next-line:variable-name
   num_dash: number;
   path: string;
   filters: any;
}

export class Usuario {

   public static get instance(): Usuario {
      if (this._instance == null) {
         this._instance = new Usuario();
      }
      return this._instance;
   }

   constructor() {
      this.isDebug = false;
   }

   public get usuario(): string {
      return this._usuario;
   }

   public set usuario(value: string) {
      this._usuario = value != null ? value.toLowerCase() : value;

   }

   public get senha(): string {
      return this._senha;
   }

   public set senha(value: string) {
      this._senha = value;
   }

   public get ambiente(): string {
      return this._ambiente;
   }

   public set ambiente(value: string) {
      this._ambiente = value != null ? value.toLowerCase() : value;

   }

   public get cliente(): string {
      return this._cliente;
   }

   public set cliente(value: string) {
      this._cliente = value != null ? value.toUpperCase() : value;

   }

   public get ultimoLogin(): string {
      return this._ultimoLogin;
   }

   public set ultimoLogin(value: string) {
      this._ultimoLogin = value != null ? value.toUpperCase() : value;

   }

   public get url(): string {
      return this._url;
   }

   public set url(value: string) {
      if (value && value.length && value[value.length - 1] != '/') {
         value += '/';
      }
      this._url = value;

   }

   public get codGestao(): number {
      return this._codGestao;
   }

   public set codGestao(value: number) {
      this._codGestao = value;
   }

   public get codPessoa(): number {
      return this._codPessoa;
   }

   public set codPessoa(value: number) {
      this._codPessoa = value;
   }

   public get identificador(): number {
      return this._identificador;
   }

   public set identificador(value: number) {
      this._identificador = value;
   }

   public get filiais(): string {
      return this._filiais;
   }

   public set filiais(value: string) {
      this._filiais = value;

   }

   public get token(): string {
      return this._token;
   }

   public set token(value: string) {
      this._token = value;

   }

   public get isDebug(): boolean {
      return this._isDebug;
   }

   public set isDebug(value: boolean) {
      this._isDebug = value;
   }

   public get isLogged(): boolean {
      return this._isLogged != null ? this._isLogged : false;
   }

   public set isLogged(value: boolean) {
      this._isLogged = value;
   }

   public get listaModulos(): Array<DashPermission> {
      return this._listaModulos;
   }

   public set listaModulos(value: Array<DashPermission>) {
      this._listaModulos = value;
   }

   public get selectedModulo(): number {
      return this._selectedModulo;
   }

   public set selectedModulo(value: number) {
      this._selectedModulo = value;
   }

   public get tvUsuarioId(): number {
      return this._tvUsuarioId;
   }

   public set tvUsuarioId(value: number) {
      this._tvUsuarioId = value;
   }

   public get userType(): string {
      return this._userType;
   }

   public set userType(value: string) {
      this._userType = value;
   }

   public get timerTela(): number {
      return this._timerTela;
   }

   public set timerTela(value: number) {
      this._timerTela = value;
   }

   public get plataforma_tipo(): number {
      return this._plataforma_tipo;
   }

   public set plataforma_tipo(value: number) {
      this._plataforma_tipo = value;
   }

   public get ref(): string {
      return this._ref;
   }
   public set ref(value: string) {
      this._ref = value;
   }
   public get tokenSocket(): string {
      return this._tokenSocket;
   }
   public set tokenSocket(value: string) {
      this._tokenSocket = value;
   }


   private static _instance: Usuario;
   private _usuario: string;
   private _senha: string;
   private _plataforma_tipo: number;
   private _ambiente: string;
   private _url: string;
   private _ultimoLogin: string;
   private _cliente: string;
   private _ref: string;
   private _codGestao: number;
   private _codPessoa: number;
   private _identificador: number;
   private _filiais: string;
   private _token: string;
   private _tokenSocket: string;
   private _isLogged: boolean;
   private _isDebug: boolean;
   private _listaModulos: Array<DashPermission>;
   private _selectedModulo: number;
   private _tvUsuarioId: number;

   private _userType: string;
   private _timerTela: number;

   public logout() {
      this.usuario = '';
      this.codGestao = null;
      this.codPessoa = null;
      this.filiais = null;
      this.token = null;
      this.tokenSocket = null;
      this.identificador = null;
      this.isLogged = false;
      this.cliente = '';
      this.ref = '';
      this.listaModulos = null;
      this.selectedModulo = null;
      this.tvUsuarioId = null;
      this.userType = null;
      this.timerTela = null;
   }

}
