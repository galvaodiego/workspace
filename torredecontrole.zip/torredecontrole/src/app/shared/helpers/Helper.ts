export default class Helper {
    private pad(num) {
        return ("0" + num).slice(-2);
    }

    public hhmmss(secs) {
        let minutes = Math.floor(secs / 60);
        secs = secs % 60;
        const hours = Math.floor(minutes / 60)
        minutes = minutes % 60;
        return `${hours}:${this.pad(minutes)}:${this.pad(secs)}`;
    }
}
