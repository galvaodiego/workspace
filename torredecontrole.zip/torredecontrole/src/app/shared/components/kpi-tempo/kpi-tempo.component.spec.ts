import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KpiTempoComponent } from './kpi-tempo.component';

describe('KpiTempoComponent', () => {
  let component: KpiTempoComponent;
  let fixture: ComponentFixture<KpiTempoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KpiTempoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KpiTempoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
