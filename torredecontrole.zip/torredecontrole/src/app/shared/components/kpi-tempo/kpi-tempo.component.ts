import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-kpi-tempo',
  templateUrl: './kpi-tempo.component.html',
  styleUrls: ['./kpi-tempo.component.scss']
})
export class KpiTempoComponent implements OnInit {
  @Input() color: string;
  @Input() title: string;
  @Input() value: string;
  @Input() list: Array<any>;
  @Input() icon: string;
  @Input() tempo: string;

  constructor() { }

  ngOnInit() {
  }

}
