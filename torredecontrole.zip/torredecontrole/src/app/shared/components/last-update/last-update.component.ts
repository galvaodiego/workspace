import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import * as moment from 'moment';
@Component({
  selector: 'app-last-update',
  templateUrl: './last-update.component.html',
  styleUrls: ['./last-update.component.scss']
})
export class LastUpdateComponent implements OnChanges {
  @Input() data: string;
  constructor() {
    moment.locale('pt-br');
  }
  ngOnChanges(changes: SimpleChanges): void {
    const prepara = changes.data.currentValue.substr(0, 19);
    this.data = moment(prepara).format('LLL');
  }



}
