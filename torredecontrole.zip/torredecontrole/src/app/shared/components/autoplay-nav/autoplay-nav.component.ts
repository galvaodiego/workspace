import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { CountdownComponent } from 'ngx-countdown';
import { environment } from 'src/environments/environment';
import { AutoplayService } from '../../services/autoplay.service';
@Component({
  selector: 'app-autoplay-nav',
  templateUrl: './autoplay-nav.component.html',
  styleUrls: ['./autoplay-nav.component.scss']
})
export class AutoplayNavComponent implements OnInit {
  @ViewChild('cd') cd: CountdownComponent;
  countDownConfig = {
    leftTime: (environment.tempo_troca_tela * 60),
    format: 'mm:ss',
  };
  constructor(
    private autoplay: AutoplayService,
    private router: Router,
  ) { }

  ngOnInit() { }

  handleEvent(e) {
    if (e.action === 'done') {
      this.next();
    }
  }

  next() {
    const url = this.router.url;
    const rotasDisp = this.autoplay.rotas.filter(e => {
      return e.visible === true
    });
    this.autoplay.atual = rotasDisp.map(x => x.path).indexOf(url);
    if (this.autoplay.atual === rotasDisp.length - 1) {

      const r = this.autoplay.rotas.filter(e => {
        return e.visible === true
      })
      if (r.length > 1) {
        this.router.navigate([rotasDisp[0].path]);
      } else {
        this.refresh()
      }


    } else {
      this.router.navigate([rotasDisp[this.autoplay.atual + 1].path]);
    }
    setTimeout(() => {
      this.cd.restart();
    }, 1000);
  }

  prev() {
    const url = this.router.url;
    const rotasDisp = this.autoplay.rotas.filter(e => {
      return e.visible === true
    });
    this.autoplay.atual = rotasDisp.map(x => x.path).indexOf(url);
    if (this.autoplay.atual === 0) {
      this.router.navigate([rotasDisp[rotasDisp.length - 1].path]);
    } else {
      this.router.navigate([rotasDisp[this.autoplay.atual - 1].path]);
    }
    setTimeout(() => {
      this.cd.restart();
    }, 1000);
  }

  refresh() {
    location.reload();
  }

}
