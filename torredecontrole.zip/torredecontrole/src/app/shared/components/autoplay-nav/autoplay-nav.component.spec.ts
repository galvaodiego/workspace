import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AutoplayNavComponent } from './autoplay-nav.component';

describe('AutoplayNavComponent', () => {
  let component: AutoplayNavComponent;
  let fixture: ComponentFixture<AutoplayNavComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AutoplayNavComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AutoplayNavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
