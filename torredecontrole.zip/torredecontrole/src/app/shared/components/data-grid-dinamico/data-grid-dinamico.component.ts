import { Component, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { DxDataGridComponent } from 'devextreme-angular';
import SetInterval from 'set-interval';

import { Workbook } from 'exceljs';
import { saveAs } from 'file-saver';
import { exportDataGrid } from 'devextreme/excel_exporter';

@Component({
  selector: 'app-data-grid-dinamico',
  templateUrl: './data-grid-dinamico.component.html',
  styleUrls: ['./data-grid-dinamico.component.scss']
})
export class DataGridDinamicoComponent implements OnInit, OnDestroy {
  @ViewChild('dataGrid') dataGrid: DxDataGridComponent;
  @Input() datasource;
  @Input() pageSize = 10;
  @Input() allowColumnReordering = true;
  @Input() allowColumnResizing = true;
  @Input() rowAlternationEnabled = true;
  @Input() showBorders = true;
  @Input() columnChooser = false;
  @Input() stateStoring = false;
  @Input() storageKey = 'storage';
  @Input() columns;
  @Input() nome;
  @Input() export = false;
  @Input() fileName = 'exportarDados';

  dataGridIndex = 0;
  constructor() { }

  ngOnInit() {
    // SetInterval.start(() => { this.trocaPagina(); }, 10000, 'intervalo_tabelas');
  }

  ngOnDestroy(): void {
    SetInterval.clear('intervalo_tabelas');
  }

  getBG(c) {
    let color = '#5B63F7';
    if (c === 'nivel_servico') {
      color = '#20A7DF';
    } else if (c === 'programacao') {
      color = '#6930D2';
    } else if (c === 'produtividade') {
      color = '#5B63F7';
    } else if (c === 'monitoramento') {
      color = '#355F92';
    }
    return color;
  }

  getIcon(t) {
    let path = 'assets/images/torre/kpi-clock.png';
    if (t === 'nivel_servico') {
      path = 'assets/images/torre/kpi-clock2.png';
    } else if (t === 'programacao') {
      path = 'assets/images/torre/kpi-clock3.png';
    } else if (t === 'monitoramento') {
      path = 'assets/images/torre/kpi-clock4.png';
    }
    return path;
  }

  onCellPrepared(e) {

    if (e.rowType === 'header') {
      e.cellElement.style.backgroundColor = '#283245';
      e.cellElement.style.fontFamily = 'Fira Sans';
      if (this.nome === 'gridAlerta') {
        e.cellElement.style.fontSize = '34px';
        e.cellElement.style.lineHeight = '34px';
      } else {
        e.cellElement.style.fontSize = '14px';
      }
      e.cellElement.style.fontWeight = '500';
      e.cellElement.style.color = '#878787';
    }

    if (typeof (e.data) !== 'undefined') {

      e.cellElement.style.fontFamily = 'Fira Sans';
      if (this.nome === 'gridAlerta') {
        e.cellElement.style.fontSize = '34px';
        e.cellElement.style.lineHeight = '34px';
      } else {
        e.cellElement.style.fontSize = '14px';
      }
      e.cellElement.style.fontWeight = '300';
      e.cellElement.style.border = '0px';

      if (e.rowIndex % 2 === 0) {
        e.cellElement.style.backgroundColor = '#283245';
        e.cellElement.style.color = '#fff';
      } else {
        e.cellElement.style.backgroundColor = '#525A69';
        e.cellElement.style.color = '#ccc';
      }

      if (e.data.TEMPO_ABERTO_PERMITIDO === 0) {
        e.cellElement.style.color = '#FF0000';
      }


    }


    if (this.nome === 'gridDash') {
      if (e.rowType === 'header') {
        e.cellElement.style.fontSize = '20px';
        e.cellElement.style.lineHeight = '21px';
        e.cellElement.style.fontWeight = '500';
        e.cellElement.style.paddingTop = '5px';
        e.cellElement.style.paddingBottom = '5px';
        e.cellElement.style.color = '#ffffff';
      }

      if (typeof (e.data) !== 'undefined') {
        e.cellElement.style.fontSize = '20px';
        e.cellElement.style.lineHeight = '21px';
        e.cellElement.style.fontWeight = 'bold';
        e.cellElement.style.paddingTop = '2px';
        e.cellElement.style.paddingBottom = '2px';
      }
    }
  }


  trocaPagina() {
    if (this.dataGrid) {
      const totalPd = this.dataGrid.instance.pageCount();
      if (totalPd > 1) {
        if (this.dataGridIndex === totalPd - 1) {
          this.dataGridIndex = 0;
        } else {
          this.dataGridIndex++;
        }
        this.dataGrid.instance.pageIndex(this.dataGridIndex);
      }
    }

  }

  onExporting = (e) => {
    const workbook = new Workbook();
    const worksheet = workbook.addWorksheet('DadosExportados');

    exportDataGrid({
      component: e.component,
      worksheet: worksheet,
      autoFilterEnabled: true
    }).then(() => {
      workbook.xlsx.writeBuffer().then((buffer) => {
        saveAs(new Blob([buffer], { type: 'application/octet-stream' }), this.fileName + '.xlsx');
      });
    });
    e.cancel = true;
  }

}
