import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DataGridDinamicoComponent } from './data-grid-dinamico.component';

describe('DataGridDinamicoComponent', () => {
  let component: DataGridDinamicoComponent;
  let fixture: ComponentFixture<DataGridDinamicoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DataGridDinamicoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DataGridDinamicoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
