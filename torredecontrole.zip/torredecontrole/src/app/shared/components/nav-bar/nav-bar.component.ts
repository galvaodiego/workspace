import { Component, OnInit, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { MediaMatcher } from '@angular/cdk/layout';
import { Platform } from '@angular/cdk/platform';
import { Usuario } from '../../models/usuario.model';
import { environment } from 'src/environments/environment';
import { confirm } from 'devextreme/ui/dialog';
import { Router } from '@angular/router';
import { AutoplayService } from '../../services/autoplay.service';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';


@Component({
   selector: 'app-nav-bar',
   templateUrl: './nav-bar.component.html',
   styleUrls: ['./nav-bar.component.scss']
})
export class NavBarComponent implements OnInit, OnDestroy {
   public user: Usuario = Usuario.instance;
   mobileQuery: MediaQueryList;
   compAtivo = 'logout';
   // tslint:disable-next-line: variable-name
   private _mobileQueryListener: () => void;
   version: string;
   cliente = {
      path: 'assets/images/clientes/kmm.png',
      descricao: 'KMM Engenharia de Software'
   };

   popupVisible = false;
   prod: any;
   listaNav = [];
   temAlerta = false;
   visaoForm: FormGroup;
   box_vis = false;
   constructor(
      changeDetectorRef: ChangeDetectorRef,
      media: MediaMatcher,
      public platform: Platform,
      private router: Router,
      public autoplay: AutoplayService,
      private fb: FormBuilder

   ) {
      const configForm = {}
      this.autoplay.rotas.forEach(element => {
         configForm[element.controlName] = element.visible
      });
      
      if (this.autoplay.visao) {
         this.visaoForm = this.fb.group(this.autoplay.visao);
      } else {
         this.visaoForm = this.fb.group(configForm);
      }
      this.listaNav = this.autoplay.rotas;

      const al = JSON.parse(localStorage.getItem('alerta-em-aberto'));
      if (al) {
         this.temAlerta = true;
         this.listaNav.map(e => {
            if (e.name === 'Alertas') {
               e.icon = 'menu-alertas-y.png';
            }
         });
      }

      this.mobileQuery = media.matchMedia('(max-width: 600px)');
      this._mobileQueryListener = () => changeDetectorRef.detectChanges();
      // tslint:disable-next-line: deprecation
      this.mobileQuery.addListener(this._mobileQueryListener);
      this.version = environment.version;
      this.prod = environment.production;
      const clienteSelecionado = JSON.parse(localStorage.getItem('cliente-selecionado'));
      if (clienteSelecionado) {
         this.cliente.path = clienteSelecionado.logo;
         this.cliente.descricao = clienteSelecionado.nome;
      }
   }

   ngOnInit() {

   }

   ngOnDestroy(): void {
      // tslint:disable-next-line: deprecation
      this.mobileQuery.removeListener(this._mobileQueryListener);
   }


   atualizar() {
      location.reload();
   }

   public logout() {
      const result = confirm(`Você tem certeza que deseja encerrar a sessão?`, 'Sair');
      result.then((dialogResult) => {
         if (dialogResult) {
            this.user.logout();
            localStorage.clear();
            this.router.navigate(['']);
         }
      });
   }

   getDetalhesMenu(modulo) {
      const obj = {
         nome: '',
         path: '',
         icon: '',
         mat_icon: ''
      };
      switch (modulo) {
         case 'extrato-faturamento':
            Object.assign(obj, {
               nome: 'Extrato de Faturamento',
               path: '/financeiro/extrato-faturamento',
               icon: 'extrato-faturamento', mat_icon: 'attach_money'
            });
            break;
         case 'acompanhamento-diario':
            Object.assign(obj, {
               nome: 'Acompanhamento Diário',
               path: '/logistico/acompanhamento-diario',
               icon: 'acomp-diario',
               mat_icon: 'date_range'
            });
            break;
         case 'controle-frete':
            Object.assign(obj, {
               nome: 'Controle de Frete',
               path: '/logistico/controle-frete',
               icon: 'controle-frete',
               mat_icon: 'local_shipping'
            });
            break;
         case 'mapa-abastecimento':
            Object.assign(obj, {
               nome: 'Mapa de Abastecimento',
               path: '/suprimentos/mapa-abastecimento',
               icon: 'mapa-abastecimento',
               mat_icon: 'local_gas_station'
            });
            break;

         default:
            Object.assign(obj, {
               nome: 'Permissão Pendente de Módulo: Contate o suporte!',
               path: '/',
               icon: 'app_blocking',
               mat_icon: 'app_blocking'
            });
            break;
      }

      return obj;
   }


   visaoSubmit() {
      this.autoplay.setVisao(this.visaoForm.value)
      this.box_vis = false;
   }

   restaurar(e) {
      e.preventDefault();
      const cliente = JSON.parse(localStorage.getItem('cliente-selecionado'));
      localStorage.removeItem('tabs-active-view')
      setTimeout(() => {
         location.reload();
      }, 500)
   }

   menuShowToggle() {
      this.autoplay.menuShow = !this.autoplay.menuShow;
      localStorage.setItem('menu-show', JSON.stringify(this.autoplay.menuShow));
   }

}
