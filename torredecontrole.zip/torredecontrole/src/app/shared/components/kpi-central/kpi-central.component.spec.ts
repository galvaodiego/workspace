import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KpiCentralComponent } from './kpi-central.component';

describe('KpiCentralComponent', () => {
  let component: KpiCentralComponent;
  let fixture: ComponentFixture<KpiCentralComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KpiCentralComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KpiCentralComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
