import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-kpi-central',
  templateUrl: './kpi-central.component.html',
  styleUrls: ['./kpi-central.component.scss']
})
export class KpiCentralComponent implements OnInit {
  @Input() path: string;
  @Input() alt: string;
  @Input() value: any;
  @Input() title: string;
  @Input() subtitle: string;
  @Input() color = '#5b63f7';

  constructor() { }

  ngOnInit() {
  }

}
