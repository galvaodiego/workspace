import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProgressBarVComponent } from './progress-bar-v.component';

describe('ProgressBarVComponent', () => {
  let component: ProgressBarVComponent;
  let fixture: ComponentFixture<ProgressBarVComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProgressBarVComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProgressBarVComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
