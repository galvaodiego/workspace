import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-progress-bar-v',
  templateUrl: './progress-bar-v.component.html',
  styleUrls: ['./progress-bar-v.component.scss']
})
export class ProgressBarVComponent implements OnInit {
  @Input() title: string;
  @Input() valueLabel: string;
  @Input() value = 50;
  @Input() showPerc = false;
  @Input() color = '#5B63F7';
  constructor() { }

  ngOnInit() {
  }

}
