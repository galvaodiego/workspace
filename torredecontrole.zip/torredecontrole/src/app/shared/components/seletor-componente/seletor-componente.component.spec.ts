import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SeletorComponenteComponent } from './seletor-componente.component';

describe('SeletorComponenteComponent', () => {
  let component: SeletorComponenteComponent;
  let fixture: ComponentFixture<SeletorComponenteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SeletorComponenteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SeletorComponenteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
