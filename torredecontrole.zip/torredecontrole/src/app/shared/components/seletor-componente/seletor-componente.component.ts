import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-seletor-componente',
  templateUrl: './seletor-componente.component.html',
  styleUrls: ['./seletor-componente.component.scss']
})
export class SeletorComponenteComponent implements OnInit {
  componenteSelecionado: number;
  @Input() componentes: any = [];
  @Input() origem: string;
  @Output() resposta = new EventEmitter();
  showOpcoes = false;
  key: string;
  constructor() { }

  ngOnInit() {
    this.key = this.origem + '-componente-selecionado';
    const cs = localStorage.getItem(this.key);
    if (cs) {
      this.componenteSelecionado = Number(cs);
      this.resposta.emit({ selecao: this.componenteSelecionado })
    }

  }

  selecionar(ev) {
    localStorage.setItem(this.key, ev.value)
    this.resposta.emit({ selecao: ev.value })
    this.showOpcoes = false;
  }

}
