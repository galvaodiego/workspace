import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-kpi-image',
  templateUrl: './kpi-image.component.html',
  styleUrls: ['./kpi-image.component.scss']
})
export class KpiImageComponent implements OnInit {
  @Input() path: string;
  @Input() alt: string;
  @Input() title: string;
  @Input() subtitle: string;
  @Input() value: number;
  @Input() imgPosition = 'left';
  @Input() secondVal;
  @Input() imgCustomStyle: any;
  constructor() { }

  ngOnInit() {
  }

}
