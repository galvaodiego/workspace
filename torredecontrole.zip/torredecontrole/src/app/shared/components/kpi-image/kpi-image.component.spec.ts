import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KpiImageComponent } from './kpi-image.component';

describe('KpiImageComponent', () => {
  let component: KpiImageComponent;
  let fixture: ComponentFixture<KpiImageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KpiImageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KpiImageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
