import { AfterViewInit, Component, Input, Output, OnDestroy, EventEmitter, OnChanges, SimpleChanges, ViewChild, ElementRef, ViewContainerRef, AfterViewChecked } from '@angular/core';
import { FormControl } from '@angular/forms';
import 'leaflet/dist/images/marker-shadow.png';
import 'leaflet/dist/images/marker-icon.png';
import * as L from 'leaflet';
import { NgSelectConfig } from '@ng-select/ng-select';
@Component({
  selector: 'app-leaf-map',
  templateUrl: './leaf-map.component.html',
  styleUrls: ['./leaf-map.component.scss']
})
export class LeafMapComponent implements AfterViewInit, OnDestroy {
  placas = new FormControl();
  @Input() name = 'map_';
  @Input() cardTitle: string;
  @Input() listaPlacas: string[] = [];
  @Output() resposta = new EventEmitter();
  @Input() legenda = []; // cores: vermelho, amarelo, verde, laranja, azul
  @Input() dados;
  @Input() center = {
    lat: -12.297068292853805,
    lng: -55.705128205128204
  };
  @Input() zoom = 5;
  @Input() mapCustomStyle = { height: '440px' };
  @Input() accessToken = 'pk.eyJ1Ijoicm9kcmlnby1ldiIsImEiOiJja2FyN3VqajQwaXByMnhxbG5pZWFxb29zIn0.4jEbhTwy8YdBemsRfZbFVg';
  markers = new L.FeatureGroup();
  mapa: L.Map;

  placasSelecionadas;
  constructor(
    private config: NgSelectConfig
  ) {
    this.config.notFoundText = 'Nenhum registro encontrado';
    this.config.appendTo = 'body';
    this.config.bindValue = 'value';
  }

  ngOnDestroy(): void {
    if (this.mapa) {
      this.mapa.remove();
    }
  }


  ngAfterViewInit(): void {
    const container = document.getElementById(this.name);
    if (container) {
      setTimeout(() => {
        this.initMapa();
      }, 1000);
    }
  }




  initMapa() {
    // Creating map options
    const mapOptions = {
      layers: [
        L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token={accessToken}', {
          // tslint:disable-next-line:max-line-length
          attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
          maxZoom: 18,
          id: 'mapbox/streets-v11',
          tileSize: 512,
          zoomOffset: -1,
          accessToken: this.accessToken
        })
      ],
      zoom: this.zoom,
      center: L.latLng(this.center.lat, this.center.lng)
    };
    const container = document.getElementById(this.name);
    if (container) {
      const mapId = 'Map_' + Math.random()
      const div = document.createElement('div');
      div.setAttribute('id', mapId);
      div.setAttribute('style', 'width: 100%; height: 100%;');
      container.appendChild(div);
      this.mapa = L.map(mapId, mapOptions);
      // add markers
      if (this.dados) {
        const semcoord = [];
        this.dados.forEach(element => {
          if (element.LATITUDE && element.LONGITUDE) {
            const pos = L.latLng(element.LATITUDE, element.LONGITUDE);
            const marker = L.marker(pos, {
              icon: this.getIcon(element.COR),
              title: 'ROMANEIO: ' + element.NUM_ROMANEIO + '\n' + 'PLACA: ' + element.PLACA_CONTROLE
            });
            marker.bindPopup('PLACA: ' + element.PLACA_CONTROLE).on('click', (e) => {
              const placas = [];
              placas.push(element.PLACA_CONTROLE);
              this.resposta.emit({ placa: placas });
            });
            this.markers.addLayer(marker);
          } else {
            semcoord.push(element);
          }
        });

        if (semcoord.length > 0) {
          console.log('SEM COORDENADA NO RETORNO', semcoord);
        }

        // this.mapa.flyTo(pos, 8);
        this.mapa.addLayer(this.markers);
      }

      this.mapa.on('contextmenu', event => {
        console.log('right click info: ', event);
      });
      // this.mapa.on('click', event => {
      //   console.log('click info: ', event);
      // });
    }

  }

  getIcon(cor) {
    const icon = L.icon({
      iconUrl: 'assets/images/torre/marker-' + cor + '.png',
      iconSize: [16, 16],
      iconAnchor: [16, 16],
    });
    return icon;
  }

  filtrar() {
    // console.log('filtrar', this.placasSelecionadas);
    if (this.placasSelecionadas) {
      this.resposta.emit({ placa: this.placasSelecionadas });
    } else {
      this.resposta.emit({ placa: null });
    }
  }

  limparFiltro() {
    this.resposta.emit({ placa: null });
  }
}
