import { Component, Input, OnInit } from '@angular/core';
@Component({
  selector: 'app-chart-bar',
  templateUrl: './chart-bar.component.html',
  styleUrls: ['./chart-bar.component.scss']
})
export class ChartBarComponent implements OnInit {
  @Input() datasource: Array<any>;
  @Input() chave: string = 'chave';
  @Input() valor: string = 'valor';
  @Input() rotated = false;
  @Input() showLegend = false;
  @Input() showAxisLabel = true;
  @Input() showLabel = true;
  @Input() showGrid = false;
  @Input() convertTime = false;
  @Input() fullLabel = false;
  @Input() formatLabel = {
    type: 'fixedPoint',
    precision: '0'
  };
  @Input() verticalAlignment = 'bottom';
  @Input() horizontalAlignment = 'center';
  @Input() paleta = ['#1561AD', '#1B7EE0', '#60A3E6'];
  @Input() faixaCorteTime = [28800, 43200];
  @Input() faixaCorteNumber = [5, 10];
  @Input() customStyle: any;
  constructor() { }

  ngOnInit() {
  }

  customizeTextLabelAxis(e) {
    return "<p class='axisLabelTxt'>" + e.valueText + '</p>';
  }

  customizePoint = (e) => {
    let cores = this.paleta;
    let cor = cores[0];
    const valor = e.data.valor;
    // console.log('fx-corte',this.faixaCorteNumber);

    if (this.convertTime) {
      if (valor <= this.faixaCorteTime[0]) {
        cor = cores[2];
      } else if (valor > this.faixaCorteTime[0] && valor <= this.faixaCorteTime[1]) {
        cor = cores[1];
      } else {
        cor = cores[0];
      }
    } else {

      if (valor <= this.faixaCorteNumber[0]) {
        cor = cores[2];
      } else if (valor > this.faixaCorteNumber[0] && valor <= this.faixaCorteNumber[1]) {
        cor = cores[1];
      } else {
        cor = cores[0];
      }

    }

    return { color: cor, hoverStyle: { color: cor }, fontSize: 45 };


  }

  customizeLabel = (arg: any) => {
    return {
      visible: true,
      backgroundColor: "transparent",
      fontWeight: "bold",
    };

  }

  customizeTextLabelSerie = (e) => {
    let txt = e.valueText
    if (this.convertTime) {
      txt = this.hhmmss(e.value)
    }
    if (this.fullLabel) {
      return e.argumentText + ': ' + txt;
    } else {
      return txt;
    }
  }

  pad(num) {
    return ("0" + num).slice(-2);
  }

  hhmmss(secs) {
    let minutes = Math.floor(secs / 60);
    secs = secs % 60;
    const hours = Math.floor(minutes / 60)
    minutes = minutes % 60;
    return `${hours}:${this.pad(minutes)}:${this.pad(secs)}`;
  }

}
