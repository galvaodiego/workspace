import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BlockTempoChartComponent } from './block-tempo-chart.component';

describe('BlockTempoChartComponent', () => {
  let component: BlockTempoChartComponent;
  let fixture: ComponentFixture<BlockTempoChartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BlockTempoChartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BlockTempoChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
