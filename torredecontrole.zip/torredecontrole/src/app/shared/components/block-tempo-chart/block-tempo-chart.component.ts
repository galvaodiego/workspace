import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-block-tempo-chart',
  templateUrl: './block-tempo-chart.component.html',
  styleUrls: ['./block-tempo-chart.component.scss']
})
export class BlockTempoChartComponent implements OnInit {
  @Input() titulo: string;
  @Input() className: string;
  @Input() datasource: any;
  @Input() convertTime = false;
  @Input() rotated = false;
  @Input() showAxisLabel = true;
  @Input() fullLabel = false;
  @Input() paleta = ['#1561AD', '#1B7EE0', '#60A3E6'];
  @Input() faixaCorteTime = [28800, 43200];
  @Input() faixaCorteNumber = [5, 10];
  customStyleGraficos = { height: "370px" }
  constructor() { }

  ngOnInit() {
  }

}
