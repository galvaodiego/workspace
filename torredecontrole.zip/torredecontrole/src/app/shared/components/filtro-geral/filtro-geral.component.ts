import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder } from '@angular/forms';
import { NavigationEnd, Router } from '@angular/router';
import io from 'socket.io-client';
import { environment } from 'src/environments/environment';
import { Usuario } from '../../models/usuario.model';
import { FiltroAtivoService } from '../../services/filtro-ativo.service';
@Component({
  selector: 'app-filtro-geral',
  templateUrl: './filtro-geral.component.html',
  styleUrls: ['./filtro-geral.component.scss'],
})
export class FiltroGeralComponent implements OnInit {
  public user: Usuario = Usuario.instance;
  socketIo: any;
  socketFiltro: any;
  isShown = false;
  form: FormGroup;
  gridOpt = [];
  segOpt = [];
  cliOpt = [];
  ttOpt = [];
  ccgOpt = [];
  tipoAlertaOpt = [];
  situRomaneioOpt = [];
  classificacaoOpt = [];
  modalidadeReferenciaOpt = [];
  classificacaoViagemOpt = [];
  sliderVal = 0;
  show: any;
  constructor(
    private filtroAtivo: FiltroAtivoService,
    private router: Router,
    private fb: FormBuilder
  ) {
    this.montaForm();
    this.router.events.subscribe((val) => {
      if (val instanceof NavigationEnd) {
        this.montaForm();
        // console.log('url', val.url);

        switch (val.url) {
          case '/dashboard/painel-dashboard':
            this.show.tempo_permitido = false;
            break;
          case '/carga/painel-carga':
          case '/descarga/painel-descarga':
            this.show.transit_time = false;
            break;
          case '/alertas/painel-alerta':
            this.show.transit_time = false;
            this.show.tipo_alerta = true;
            this.show.situacao_romaneio = true;
            break;
          case '/tempo-carga/painel-tempo-carga':
          case '/tempo-descarga/painel-tempo-descarga':
            Object.assign(this.show, {
              grid: true,
              segmento: true,
              cliente: true,
              ccg: true,
              transit_time: false,
              tempo_permitido: false,
              tipo_alerta: false,
              situacao_romaneio: false,
              classificacao: true,
              modalidade_referencia: true,
              classificacao_viagem: false
            })
            break;
          case '/tempo-destinado/painel-tempo-destinado':
            Object.assign(this.show, {
              grid: true,
              segmento: true,
              cliente: true,
              ccg: true,
              transit_time: false,
              tempo_permitido: false,
              tipo_alerta: false,
              situacao_romaneio: false,
              classificacao: false,
              modalidade_referencia: true,
              classificacao_viagem: false
            })
            break;
          case '/tempo-viagem/painel-tempo-viagem':
            Object.assign(this.show, {
              grid: true,
              segmento: true,
              cliente: true,
              ccg: true,
              transit_time: false,
              tempo_permitido: false,
              tipo_alerta: false,
              situacao_romaneio: false,
              classificacao: false,
              modalidade_referencia: true,
              classificacao_viagem: true
            })
            break;
          case '/alertas-carga/painel-alertas-carga':
          case '/alertas-descarga/painel-alertas-descarga':
            Object.assign(this.show, {
              grid: true,
              segmento: true,
              cliente: true,
              ccg: true,
              transit_time: false,
              tempo_permitido: true,
              tipo_alerta: true,
              situacao_romaneio: false,
              classificacao: false,
              modalidade_referencia: false,
              classificacao_viagem: false
            })
            break;
          case '/alertas-destinado/painel-alertas-destinado':
          case '/alertas-viagem/painel-alertas-viagem':
            Object.assign(this.show, {
              grid: true,
              segmento: true,
              cliente: true,
              ccg: true,
              transit_time: false,
              tempo_permitido: true,
              tipo_alerta: true,
              situacao_romaneio: false,
              classificacao: false,
              modalidade_referencia: false,
              classificacao_viagem: false
            })
            break;
        }
      }
    });

    this.socketIo = io(environment.socket_end_point_vm + '/filtro');
    this.socketFiltro = {
      base: this.user.ref.toLowerCase(),
      usuario: this.user.usuario
    };
    this.socket().then(() => { });
  }

  montaForm() {
    this.form = this.fb.group({
      grid: null,
      segmento: null,
      cliente: null,
      ccg: null,
      transit_time: null,
      tempo_permitido: null,
      tipo_alerta: null,
      situacao_romaneio: null,
      classificacao: null,
      modalidade_referencia: null,
      classificacao_viagem: null
    });

    this.show = {
      grid: true,
      segmento: true,
      cliente: true,
      ccg: true,
      transit_time: true,
      tempo_permitido: true,
      tipo_alerta: false,
      situacao_romaneio: false,
      classificacao: false,
      modalidade_referencia: false,
      classificacao_viagem: false
    }
  }

  ngOnInit(): void {

    const filtroGeral = JSON.parse(localStorage.getItem('filtro-geral'));
    if (filtroGeral) {
      this.form.setValue(filtroGeral)
      this.sliderVal = this.form.get('tempo_permitido').value;
    }
  }

  async socket() {
    try {
      // console.log('enviando o filtro:', this.socketFiltro);
      this.socketIo.emit('getFiltro', this.socketFiltro);
      this.socketIo.on('filtro', (data) => {
        console.log('retorno do socket getFiltro:', data);
        this.gridOpt = data.grid;
        this.segOpt = data.segmento;
        this.cliOpt = data.cliente;
        this.ttOpt = data.transit_time;
        this.ccgOpt = data.ccg;
        this.tipoAlertaOpt = data.tipo_alerta;
        this.situRomaneioOpt = data.situacao_romaneio
        this.classificacaoOpt = data.classificacao;
        this.classificacaoViagemOpt = data.classificacao_viagem;
        this.modalidadeReferenciaOpt = data.modalidade_referencia;
      });
    } catch (error) {
      console.log('error => ', error);
    }
  }

  toggle() {
    this.isShown = !this.isShown;
  }

  aplicarFiltro() {
    localStorage.setItem('filtro-geral', JSON.stringify(this.form.value));
    this.filtroAtivo.setValue(this.form.value);
    this.isShown = false;
  }

  limparFiltro() {
    localStorage.removeItem('filtro-geral');
    this.form.reset();
    this.sliderVal = 0;
    this.filtroAtivo.setValue(this.form.value);
    this.isShown = false;
  }

  atualizaTempo(e) {
    this.form.get('tempo_permitido').setValue(e.value);
  }

}
