import { Component, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Inject } from '@angular/core';
import { Workbook } from 'exceljs';
import { saveAs } from 'file-saver';
import { exportDataGrid } from 'devextreme/excel_exporter';
@Component({
  selector: 'app-preview-lista-export',
  templateUrl: './preview-lista-export.component.html',
  styleUrls: ['./preview-lista-export.component.scss']
})
export class PreviewListaExportComponent implements OnInit {
  columns = [];
  lista = [];
  constructor(@Inject(MAT_DIALOG_DATA) public dados: any) { }

  ngOnInit() {
    this.dados.lista.map(dado => {
      if (dado.TEMPO_CARGA && typeof (dado.TEMPO_CARGA) === 'number') {
        dado.TEMPO_CARGA = this.hhmmss(dado.TEMPO_CARGA);
      }

      if (dado.TEMPO_DESCARGA && typeof (dado.TEMPO_DESCARGA) === 'number') {
        dado.TEMPO_DESCARGA = this.hhmmss(dado.TEMPO_DESCARGA);
      }

      if (dado.TEMPO_DESTINADO && typeof (dado.TEMPO_DESTINADO) === 'number') {
        dado.TEMPO_DESTINADO = this.hhmmss(dado.TEMPO_DESTINADO);
      }

      if (dado.TEMPO_PARA_DESTINAR && typeof (dado.TEMPO_PARA_DESTINAR) === 'number') {
        dado.TEMPO_PARA_DESTINAR = this.hhmmss(dado.TEMPO_PARA_DESTINAR);
      }
    });
    this.lista = this.dados.lista;

    if(this.dados.columns && this.dados.columns.length > 0){
      this.columns = this.dados.columns
    }

    if (this.columns.length === 0) {
      this.columns = [
        { dataField: 'CCG', caption: 'CCG' },
        { dataField: 'CLASSIFICACAO', caption: 'Classificação' },
        { dataField: 'GRUPO_NEGOCIADOR', caption: 'Grupo Negociador' },
        { dataField: 'MODALIDADE_CONTROLE', caption: 'Modalidade Controle' },
        { dataField: 'MODALIDADE_REFERENCIA', caption: 'Modalidade Referência' },
        { dataField: 'NUM_ROMANEIO', caption: 'Nª Romaneio' },
        { dataField: 'PLACA_CONTROLE', caption: 'Placa Controle' },
        { dataField: 'REFERENCIA', caption: 'Referência' },
        { dataField: 'SEGMENTO', caption: 'Segmento' },
        { dataField: 'GRID', caption: 'Grid' },
      ]
    }

    if (this.dados.origem === 'tempo-carga') {
      this.columns.push({ dataField: 'TEMPO_CARGA', caption: 'Tempo Carga' })
    }
    if (this.dados.origem === 'tempo-descarga') {
      this.columns.push({ dataField: 'TEMPO_DESCARGA', caption: 'Tempo Descarga' })
    }
    if (this.dados.origem === 'tempo-destinado') {
      this.columns = [
        { dataField: 'CCG', caption: 'CCG' },
        { dataField: 'GRID', caption: 'Grid' },
        { dataField: 'GRUPO_NEGOCIADOR', caption: 'Grupo Negociador' },
        { dataField: 'MODALIDADE_CONTROLE', caption: 'Modalidade Controle' },
        { dataField: 'MODALIDADE_REFERENCIA', caption: 'Modalidade Referência' },
        { dataField: 'NOME_MOTORISTA', caption: 'Motorista' },
        { dataField: 'NUM_ROMANEIO', caption: 'Nª Romaneio' },
        { dataField: 'PLACA_CONTROLE', caption: 'Placa Controle' },
        { dataField: 'PLACA_REFERENCIA', caption: 'Placa Referencia' },
        { dataField: 'REFERENCIA', caption: 'Referência' },
        { dataField: 'ROMANEIO_ANTERIOR', caption: 'Romaneio Anterior' },
        { dataField: 'SEGMENTO', caption: 'Segmento' },
        { dataField: 'TEMPO_DESTINADO', caption: 'Tempo Destinado' },
        { dataField: 'TEMPO_PARA_DESTINAR', caption: 'Tempo para Destinar' },
      ]
    }

  }

  onExporting(e) {
    const workbook = new Workbook();
    const worksheet = workbook.addWorksheet('DadosExportados');

    exportDataGrid({
      component: e.component,
      worksheet: worksheet,
      autoFilterEnabled: true
    }).then(() => {
      workbook.xlsx.writeBuffer().then((buffer) => {
        saveAs(new Blob([buffer], { type: 'application/octet-stream' }), 'torre_de_controle.xlsx');
      });
    });

    e.cancel = true;
  }

  pad(num) {
    return ("0" + num).slice(-2);
  }

  hhmmss(secs) {
    let minutes = Math.floor(secs / 60);
    secs = secs % 60;
    const hours = Math.floor(minutes / 60)
    minutes = minutes % 60;
    return `${hours}:${this.pad(minutes)}:${this.pad(secs)}`;
  }

}
