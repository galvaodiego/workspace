import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PreviewListaExportComponent } from './preview-lista-export.component';

describe('PreviewListaExportComponent', () => {
  let component: PreviewListaExportComponent;
  let fixture: ComponentFixture<PreviewListaExportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PreviewListaExportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PreviewListaExportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
