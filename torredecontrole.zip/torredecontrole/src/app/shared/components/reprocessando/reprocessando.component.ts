import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-reprocessando',
  templateUrl: './reprocessando.component.html',
  styleUrls: ['./reprocessando.component.scss']
})
export class ReprocessandoComponent implements OnInit {
  @Output() resposta = new EventEmitter();
  countDownConfig = {
    leftTime: environment.tempoReprocess,
    // format: 'mm:ss',
    format: 'ss',
  };
  constructor() { }

  ngOnInit() {
  }

  handleEvent(e) {
    if (e.action === 'done') {
      this.resposta.emit({ reprocessar: true })
    }
  }
}
