import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReprocessandoComponent } from './reprocessando.component';

describe('ReprocessandoComponent', () => {
  let component: ReprocessandoComponent;
  let fixture: ComponentFixture<ReprocessandoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReprocessandoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReprocessandoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
