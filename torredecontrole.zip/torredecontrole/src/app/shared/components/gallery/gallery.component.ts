import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-gallery',
  templateUrl: './gallery.component.html',
  styleUrls: ['./gallery.component.scss']
})
export class GalleryComponent implements OnInit {
  @Input() datasource;
  @Input() porPagina = 5;
  @Input() delay = 2000;
  @Input() barColor = '#20A7DF';

  views;
  pages;
  ordem = 1;
  constructor() { }

  ngOnInit() {
    this.prepara(this.datasource);
  }

  prepara(dados) {
    this.views = [];
    this.pages = Math.ceil(dados.length / this.porPagina);
    for (let index = 0; index < this.pages; index++) {
      this.views.push(this.paginate(dados, this.porPagina, index + 1));
    }
  }

  paginate(array, pageSize, pageNumber) {
    --pageNumber;
    return array.slice(pageNumber * pageSize, (pageNumber + 1) * pageSize);
  }

  toggle() {
    if (this.ordem == 1) {
      this.ordem = -1
    } else {
      this.ordem = 1
    }

    this.ordernar(this.ordem);
  }

  ordernar(ord) {
    this.datasource.sort(function (a, b) {
      if (ord === 1) {
        return a.valor - b.valor;
      }
      if (ord === -1) {
        return b.valor - a.valor;
      }
    });
    this.prepara(this.datasource);
  }

}
