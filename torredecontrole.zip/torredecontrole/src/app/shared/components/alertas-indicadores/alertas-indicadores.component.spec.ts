import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AlertasIndicadoresComponent } from './alertas-indicadores.component';

describe('AlertasIndicadoresComponent', () => {
  let component: AlertasIndicadoresComponent;
  let fixture: ComponentFixture<AlertasIndicadoresComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AlertasIndicadoresComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AlertasIndicadoresComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
