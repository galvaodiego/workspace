import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-alertas-indicadores',
  templateUrl: './alertas-indicadores.component.html',
  styleUrls: ['./alertas-indicadores.component.scss']
})
export class AlertasIndicadoresComponent implements OnInit {
  @Input() blocoSuperiorEsquerdo: any;
  @Input() blocoInferiorEsquerdo: any;
  @Input() blocoCentral: any;
  @Input() blocoSuperiorDireito: any;
  @Input() blocoInferiorDireito: any;
  constructor() { }
  ngOnInit() {
  }

}
