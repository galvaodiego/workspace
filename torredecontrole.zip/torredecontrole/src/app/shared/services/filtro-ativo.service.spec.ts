import { TestBed } from '@angular/core/testing';

import { FiltroAtivoService } from './filtro-ativo.service';

describe('FiltroAtivoService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: FiltroAtivoService = TestBed.get(FiltroAtivoService);
    expect(service).toBeTruthy();
  });
});
