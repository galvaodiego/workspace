import { Injectable } from '@angular/core';
import { LocalStorageService } from 'ngx-webstorage';

import { EstruturaOrganizacional } from '../models/organizacional.model';
import { ClienteService } from './cliente.service';

@Injectable({ providedIn: 'root' })
export class EstruturaOrganizacionalService {

    private org: EstruturaOrganizacional = EstruturaOrganizacional.instance;

    constructor(
        private storage: LocalStorageService,
        private clienteS: ClienteService
    ) { }

    /*
    * Inicia o objeto Usuario na aplicação.
    * Caso exista algum registro do usuário no storage, este método o retorna.
    * Caso contrário, o método formata um objeto para o usuário.
    */
    public init(): Promise<any> {
        return new Promise((resolve, reject) => {
            const data = this.storage.retrieve(this.clienteS.discover() + '-organizacional');
            if (data == null) {
                this.org.base = '';
                this.org.usuario = {
                    usuario: '',
                    usuarioBiId: null
                };
                this.org.configOrgUsuario = [];
                this.org.configOrgUsuario.push({
                    listConfigOrg: [],
                    configOrgId: null,
                    configOrg: '',
                    modulo: '',
                    moduloId: null,
                    niveis: [],
                    numModulo: '',
                    dashs: []
                });
                this.org.niveis = {
                    usuario: this.org.usuario,
                    codNivelOrganizacional: '',
                    nivel: null,
                    organizacional: '',
                    organizacionalId: null,
                    tipoOrganizacionalId: null,
                };
                this.org.dashs = [];
                this.org.dashs.push({
                    id: null,
                    descricao: '',
                    path: ''
                });
                this.org.permissoes = [];
                this.org.permissoes.push({
                    ativo: false,
                    codNivelOrganizacional: null,
                    ordem: null,
                    organizacional: '',
                    organizacionalId: null,
                    organizacionalIdCorp: null,
                    organizacionalIdPai: null,
                    tipoOrganizacional: '',
                    tipoOrganizacionalId: null,
                    usuario: this.org.usuario
                });
            } else {
                this.org.base = data.base;
                this.org.usuario = data.usuario;
                this.org.configOrgUsuario = data.configOrgUsuario;
                this.org.permissoes = data.permissoes;
                this.org.niveis = data.niveis;
                this.org.dashs = data.dashs;
            }
            this.save();
            resolve(this.org);
            return data;
        });
    }

    /**
     * Salva os dados da Estrutura Organizacional no storage.
     */
    public save() {

       const data = {
          base: this.org.base,
          usuario: this.org.usuario,
          configOrgUsuario: this.org.configOrgUsuario,
          permissoes: this.org.permissoes,
          niveis: this.org.niveis,
          dashs: this.org.dashs
         };
       this.storage.store(this.clienteS.discover() + '-organizacional', data);
    }

    /*
    * Limpa os dados da Estrutura Organizacional no storage.
    */
    public logout() {
        localStorage.clear();
    }


    /*
     * Objetivo::
     *  Resgatar o organizacional_id do Nivel Empresa
     */
    public getOrgEmpresa() {
        let organizacionalId: number;

        organizacionalId = this.org.permissoes[0].organizacionalId;

        // tslint:disable-next-line: prefer-for-of
        for (let i = 0; i < this.org.permissoes.length; i++) {
            const el = this.org.permissoes[i];
            if (el.codNivelOrganizacional.toUpperCase() !== this.clienteS.discover().toUpperCase()) {
                organizacionalId = el.organizacionalId;
            }
        }

        return 175;
        return organizacionalId;
    }

}
