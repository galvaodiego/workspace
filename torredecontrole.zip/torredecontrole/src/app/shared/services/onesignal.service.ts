import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Usuario } from '../models/usuario.model';
import { EstruturaOrganizacional } from '../models/organizacional.model';

@Injectable()
export class OneSignalService {
   oneSignalId: any;
   private user: Usuario = Usuario.instance;
   private org: EstruturaOrganizacional = EstruturaOrganizacional.instance;

   constructor(

   ) {
   }

   init() {
      // tslint:disable-next-line: no-string-literal
      const OneSignal = window['OneSignal'] || [];
      OneSignal.push(() => {
         OneSignal.sendTags({
            usuario: this.user.usuario.toUpperCase(),
            base: this.org.base,
            grupo_organizacional: 'pendente-backend'
         }).then((tagsSent) => {
            console.log('OneSignal Tags Sent', tagsSent);
         });
      });
      console.log('Init OneSignal');
      OneSignal.push(['init', {
         appId: environment.oneSignal.appId,
         // requiresUserPrivacyConsent: true,
         autoRegister: true,
         allowLocalhostAsSecureOrigin: true,
         notifyButton: {
            enable: false
         }
      }]);
      console.log('OneSignal Initialized');
      this.checkIfSubscribed(OneSignal);

   }

   checkIfSubscribed(OneSignal) {
      OneSignal.push(() => {
         /* These examples are all valid */
         OneSignal.isPushNotificationsEnabled((isEnabled) => {
            if (isEnabled) {
               console.log('Push notifications are enabled!');
               this.getUserID(OneSignal);
            } else {
               console.log('Push notifications are not enabled yet.');
               this.subscribe(OneSignal);
            }
         }, (error) => {
            console.log('Push permission not granted');
         });
      });
   }

   subscribe(OneSignal) {
      OneSignal.push(() => {
         console.log('Register For Push');
         OneSignal.push(['registerForPushNotifications']);
         OneSignal.on('subscriptionChange', (isSubscribed) => {
            console.log('The user\'s subscription state is now:', isSubscribed);
            this.listenForNotification(OneSignal);
            OneSignal.getUserId().then((userId) => {
               console.log('User ID is', userId);
               this.oneSignalId = userId;
            });
         });
      });
   }

   getUserID(OneSignal) {
      OneSignal.getUserId().then((userId) => {
         console.log('User ID is', userId);
         this.oneSignalId = userId;
      });
   }

   listenForNotification(OneSignal) {
      console.log('Initalize Listener');
      OneSignal.on('notificationDisplay', (event) => {
         console.log('OneSignal notification displayed:', event);
         this.listenForNotification(OneSignal);
      });
   }

}
