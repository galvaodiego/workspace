import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

const clientes = [
   { ref: 'sulista', nome: 'Sulista', logo: 'assets/images/clientes/sulista.png', url: 'https://kmm.sulista.com.br' },
   { ref: 'bblog', nome: 'BBLOG', logo: 'assets/images/clientes/bblog.png', url: 'https://bblog.kmm.com.br' },
   { ref: 'diamante', nome: 'Diamante', logo: 'assets/images/clientes/diamante.png', url: 'https://diamante.kmm.com.br' },
   { ref: 'otdbrasil', nome: 'OTDBrasil', logo: 'assets/images/clientes/otd.png', url: 'https://kmm.otdbrasil.com.br' },
   { ref: 'pizzatto', nome: 'Pizzato Log', logo: 'assets/images/clientes/pizzatto.png', url: 'https://kmm.pizzattolog.com.br' },
   { ref: 'axon', nome: 'Axon', logo: 'assets/images/clientes/axon.png', url: 'https://kmm.axontransportes.com.br' },
   { ref: 'cjlog', nome: 'CJ Log', logo: 'assets/images/clientes/cjlog.png', url: 'https://cjlog.kmm.com.br' },
   { ref: 'transgires', nome: 'Transgires', logo: 'assets/images/clientes/transgires.png', url: 'https://kmm.transgires.com.br' },
   { ref: 'ritmo', nome: 'Ritmo', logo: 'assets/images/clientes/ritmo.png', url: 'https://kmm.ritmolog.com.br' },
   { ref: 'panorama', nome: 'Transpanorama', logo: 'assets/images/clientes/panorama.png', url: 'https://kmm.transpanorama.com.br' },
   { ref: 'cargosoft', nome: 'Cargosoft', logo: 'assets/images/clientes/cargosoft.png', url: 'https://cargosoft.kmm.com.br' },
   { ref: 'budel', nome: 'Budel', logo: 'assets/images/clientes/budel.png', url: 'https://kmm.budel.com.br' },
   { ref: 'rodoleve', nome: 'Rodoleve', logo: 'assets/images/clientes/kmm.png', url: 'https://rodoleve.kmm.com.br' },
   { ref: 'levolog', nome: 'Levolog', logo: 'assets/images/clientes/levolog.png', url: 'https://levolog.kmm.com.br' },
   { ref: 'delpozo', nome: 'Del Pozo', logo: 'assets/images/clientes/kmm.png', url: 'https://delpozo-app.kmm.com.br' },
   { ref: 'movc', nome: 'MOVC', logo: 'assets/images/clientes/kmm.png', url: 'https://movc.kmm.com.br' }
];

@Injectable({ providedIn: 'root' })
export class ClienteService {
   /* VARIAVEIS PARA USO EM MODO DEV */

   private defaultCliente = 'KMM'; // KMM;
   private defaultUrl = 'http://o01b03.kmm.com.br:8000';
   private default = { ref: 'kmm', nome: this.defaultCliente, logo: 'assets/images/clientes/kmm.png', url: this.defaultUrl };

   /* FIM - VARIAVEIS PARA USO EM MODO DEV */


   public clienteAtivo: string;
   clienteSelecionado: any;

   constructor(
   ) {
      const clienteSelecionado = JSON.parse(localStorage.getItem('cliente-selecionado'));
      if (clienteSelecionado) {
         this.clienteSelecionado = clienteSelecionado;
      }
   }

   /**
    * Descobre qual o Cliente que esta acessando
    *  através do login
    */
   public discover(url?) {
      let host = '';

      if (url) {
         host = url.toUpperCase();
      } else if (this.clienteSelecionado) {
         host = this.clienteSelecionado.url.toUpperCase();
      }

      for (const cliente of clientes) {
         if (host.indexOf(cliente.ref) !== -1) {
            this.clienteAtivo = cliente.nome;
            break;
         } else {
            this.clienteAtivo = this.defaultCliente;
         }
      }

      return this.clienteAtivo.toUpperCase();
   }

   validaCliente(url) {
      url = url.toUpperCase();
      let flag = false;
      let cli = this.default;
      for (const cliente of clientes) {
         const el = cliente.ref.toUpperCase();
         if (url.indexOf(el) !== -1) {
            flag = true;
            cli = cliente;
         }
      }

      if (environment.production) {
         if (!flag) {
            return flag;
         } else {
            return cli;
         }
      } else {
         return cli;
      }

   }
}
