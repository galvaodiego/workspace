import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AlertasService {
  colunas = [
    { dataField: 'PLACA_CONTROLE', caption: 'Placa', dataType: 'string' },
    { dataField: 'NUM_ROMANEIO', caption: 'Romaneio', dataType: 'string' },
    { dataField: 'ALERTA_TIPO', caption: 'Tipo de Alerta', dataType: 'string' },
    { dataField: 'TEMPO_ABERTO_SEGUNDOS', caption: "Tempo Aberto", alignment: 'center', dataType: 'string' },
    { dataField: 'DATA', caption: 'Data', dataType: 'datetime', format: "HH:mm:ss", visible: false },
    { dataField: 'NOME_MOTORISTA', caption: 'Motorista', dataType: 'string', visible: false },
    { dataField: 'REFERENCIA', caption: 'Ref.', dataType: 'string', visible: false },
    { dataField: 'CCG', caption: 'CCG', dataType: 'string', visible: false },
    { dataField: 'CLIENTE', caption: 'Cliente', dataType: 'string', visible: false },
    { dataField: 'GRID', caption: 'Grid', dataType: 'string', visible: false },
    { dataField: 'GRUPO_NEGOCIADOR', caption: 'Grupo Negociador', dataType: 'string', visible: false },
    { dataField: 'SEGMENTO', caption: 'Segmento', dataType: 'string', visible: false },
  ];
  constructor() { }
}
