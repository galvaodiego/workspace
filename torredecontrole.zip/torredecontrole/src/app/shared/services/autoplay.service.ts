import { Injectable } from '@angular/core';
import { Usuario } from '../models/usuario.model';

@Injectable({
  providedIn: 'root'
})
export class AutoplayService {
  public user: Usuario = Usuario.instance;
  menuShow = true;
  setVision = true;
  rotas: any;
  atual = 0;
  cliente;
  key: string;
  visao: any;

  constructor() {
    this.init();
    this.cliente = JSON.parse(localStorage.getItem('cliente-selecionado'));
    const visao = JSON.parse(localStorage.getItem('tabs-active-view'));
    if (visao) {
      this.setVisao(visao);
    } else {
      this.visao = null;
    }

    const menuShow = JSON.parse(localStorage.getItem('menu-show'));
    if (menuShow != undefined) {
      this.menuShow = menuShow
    }
  }
  init() {
    this.rotas = [
      { id: 1, controlName: 'dashboard', name: 'Dashboard', icon: 'menu-dashboard.png', path: '/dashboard/painel-dashboard', visible: true },
      { id: 2, controlName: 'carga', name: 'Veículos em Carga', icon: 'menu-carga.png', path: '/carga/painel-carga', visible: true },
      { id: 3, controlName: 'viagens', name: 'Viagens', icon: 'menu-viagens.png', path: '/viagens/painel-viagem', visible: true },
      { id: 4, controlName: 'descarga', name: 'Veículos em Descarga', icon: 'menu-carga.png', path: '/descarga/painel-descarga', visible: true },
      { id: 5, controlName: 'tempoCarga', name: 'Tempo em Carga', icon: 'new_tempoCarga_icon.png', path: '/tempo-carga/painel-tempo-carga', visible: false },
      { id: 6, controlName: 'tempoDescarga', name: 'Tempo em Descarga', icon: 'new_tempoDescarga_icon.png', path: '/tempo-descarga/painel-tempo-descarga', visible: false },
      { id: 7, controlName: 'tempoViagem', name: 'Tempo em Viagem', icon: 'new_tempoViagem_icon.png', path: '/tempo-viagem/painel-tempo-viagem', visible: false },
      { id: 8, controlName: 'tempoDestinado', name: 'Tempo Destinado', icon: 'new_tempoDestinado_icon.png', path: '/tempo-destinado/painel-tempo-destinado', visible: false },
      { id: 9, controlName: 'alertas', name: 'Alertas', icon: 'menu-alertas.png', path: '/alertas/painel-alerta', visible: true },
      { id: 10, controlName: 'alertasCarga', name: 'Alertas Carga', icon: 'menu-alertas-carga.png', path: '/alertas-carga/painel-alertas-carga', visible: false },
      { id: 11, controlName: 'alertasDescarga', name: 'Alertas Descarga', icon: 'menu-alertas-descarga.png', path: '/alertas-descarga/painel-alertas-descarga', visible: false },
      { id: 12, controlName: 'alertasViagem', name: 'Alertas Viagem', icon: 'menu-alertas-viagem.png', path: '/alertas-viagem/painel-alertas-viagem', visible: false },
      { id: 13, controlName: 'alertasDestinado', name: 'Alertas Destinado', icon: 'menu-alertas-destinado.png', path: '/alertas-destinado/painel-alertas-destinado', visible: false },
      { id: 14, controlName: 'veiculosInoperantes', name: 'Veículos Inoperantes', icon: 'menu-alertas-destinado.png', path: '/veiculos-inoperantes/painel-veiculos-inoperantes', visible: false },
      { id: 15, controlName: 'veiculosVazios', name: 'Veículos Vazios', icon: 'menu-alertas-destinado.png', path: '/veiculos-vazios/painel-veiculos-vazios', visible: false },
    ];
  }

  setVisao(dados) {
    this.rotas.map(rota => {
      rota.visible = dados[rota.controlName]
    })
    this.visao = dados;
    localStorage.setItem('tabs-active-view', JSON.stringify(dados));
  }

  setViewRegras() {
    const usuariosComRegras = ['torre01', 'torre02', 'torre03', 'torre04', 'torre05', 'torre06']
    if (usuariosComRegras.indexOf(this.user.usuario) === -1) {
      return false;
    }

    const view = {}
    switch (this.user.usuario) {
      case 'torre01':
        Object.assign(view, {
          dashboard: false,
          carga: false,
          viagens: false,
          descarga: false,
          tempoCarga: false,
          tempoDescarga: false,
          tempoViagem: true,
          tempoDestinado: false,
          alertas: false,
          alertasCarga: false,
          alertasDescarga: false,
          alertasViagem: false,
          alertasDestinado: false,
          veiculosInoperantes: false,
          veiculosVazios: false,
        })
        break;
      case 'torre02':
        Object.assign(view, {
          dashboard: false,
          carga: false,
          viagens: false,
          descarga: false,
          tempoCarga: false,
          tempoDescarga: true,
          tempoViagem: false,
          tempoDestinado: false,
          alertas: false,
          alertasCarga: false,
          alertasDescarga: false,
          alertasViagem: false,
          alertasDestinado: false,
          veiculosInoperantes: false,
          veiculosVazios: false,
        })
        break;
      case 'torre03':
        Object.assign(view, {
          dashboard: false,
          carga: false,
          viagens: false,
          descarga: false,
          tempoCarga: false,
          tempoDescarga: false,
          tempoViagem: false,
          tempoDestinado: false,
          alertas: false,
          alertasCarga: false,
          alertasDescarga: true,
          alertasViagem: true,
          alertasDestinado: false,
          veiculosInoperantes: false,
          veiculosVazios: false,
        })
        break;
      case 'torre04':
        Object.assign(view, {
          dashboard: false,
          carga: false,
          viagens: false,
          descarga: false,
          tempoCarga: false,
          tempoDescarga: false,
          tempoViagem: false,
          tempoDestinado: true,
          alertas: false,
          alertasCarga: false,
          alertasDescarga: false,
          alertasViagem: false,
          alertasDestinado: false,
          veiculosInoperantes: false,
          veiculosVazios: false,
        })
        break;
      case 'torre05':
        Object.assign(view, {
          dashboard: false,
          carga: false,
          viagens: false,
          descarga: false,
          tempoCarga: true,
          tempoDescarga: false,
          tempoViagem: false,
          tempoDestinado: false,
          alertas: false,
          alertasCarga: false,
          alertasDescarga: false,
          alertasViagem: false,
          alertasDestinado: false,
          veiculosInoperantes: false,
          veiculosVazios: false,
        })
        break;
      case 'torre06':
        Object.assign(view, {
          dashboard: false,
          carga: false,
          viagens: false,
          descarga: false,
          tempoCarga: false,
          tempoDescarga: false,
          tempoViagem: false,
          tempoDestinado: false,
          alertas: false,
          alertasCarga: true,
          alertasDescarga: false,
          alertasViagem: false,
          alertasDestinado: true,
          veiculosInoperantes: false,
          veiculosVazios: false,
        })
        break;

      default:
        Object.assign(view, {
          dashboard: true,
          carga: true,
          viagens: true,
          descarga: true,
          tempoCarga: false,
          tempoDescarga: false,
          tempoViagem: false,
          tempoDestinado: false,
          alertas: true,
          alertasCarga: false,
          alertasDescarga: false,
          alertasViagem: false,
          alertasDestinado: false,
          veiculosInoperantes: false,
          veiculosVazios: false,
        })
        break;
    }
    this.setVisao(view);
  }
}
