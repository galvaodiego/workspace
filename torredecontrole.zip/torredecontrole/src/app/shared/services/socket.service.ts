import { Injectable } from '@angular/core';
import io from 'socket.io-client';

@Injectable({
   providedIn: 'root'
})
export class SocketService {

   constructor(
      // private socketIo: any
   ) {
   }

   // async start(path: string, on: string, emit: string, filtro) {
   //    this.socketIo = io(path);
   //    try {
   //       if (path) {
   //          this.socketIo.emit(emit, filtro);
   //          this.socketIo.on(on, (data) => {
   //             console.log('---- SOCKET SERVICE START ----- ', path);
   //             console.log('on', on);
   //             console.log('emit', emit);
   //             console.log('filtro', filtro);
   //             console.log('data', data);
   //             console.log('---- SOCKET SERVICE end ----- ');
   //             return data;
   //          });
   //       } else {
   //          console.log('SET A PATH');
   //       }
   //    } catch (error) {
   //       console.log('error => ', error);
   //    }
   // }
}
