import { Injectable, OnChanges, SimpleChanges } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FiltroAtivoService {
  private filtroAtivo: BehaviorSubject<any>;
  constructor() {
    this.filtroAtivo = new BehaviorSubject<any>(null);
  }

  setValue(newValue): void {
    this.filtroAtivo.next(newValue);
  }

  getValue(): Observable<any> {
    return this.filtroAtivo.asObservable();
  }


}
