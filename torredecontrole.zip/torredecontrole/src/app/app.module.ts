import { BrowserModule } from '@angular/platform-browser';
import { NgModule, LOCALE_ID } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';

// Módulos
import { AutenticacaoModule } from './modulos/autenticacao/autenticacao.module';
import { SharedModule } from './shared/shared.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgxWebstorageModule } from 'ngx-webstorage';
import { HttpModule } from '@angular/http';
import { RouterModule } from '@angular/router';
import { LoadingBarHttpModule } from '@ngx-loading-bar/http';
import { HomeModule } from './modulos/home/home.module';


@NgModule({
   declarations: [
      AppComponent
   ],
   imports: [
      BrowserModule,
      AppRoutingModule,
      SharedModule,
      AutenticacaoModule,
      NgxWebstorageModule,
      NgxWebstorageModule.forRoot({ prefix: 'kmm_bi-app', separator: '|', caseSensitive: true }),
      HttpModule,
      RouterModule,
      LoadingBarHttpModule,
      ServiceWorkerModule.register('OneSignalSDKWorker.js', { enabled: environment.production }),
      // tslint:disable-next-line: deprecation
      BrowserAnimationsModule,
      HomeModule
   ],
   providers: [
      { provide: LOCALE_ID, useValue: 'pt' },
   ],
   bootstrap: [AppComponent]
})
export class AppModule { }
