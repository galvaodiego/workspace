import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GuardaRotas } from 'src/app/shared/guards/guarda-rotas.guard';
import { ViagensComponent } from './viagens/viagens.component';



const routes: Routes = [
   { path: '', redirectTo: 'painel-viagem', pathMatch: 'full' },
   {
      path: 'painel-viagem',
      component: ViagensComponent,
      canActivate: [GuardaRotas],
      data: {
         modulo: 'free'
      }
   },

];

@NgModule({
   imports: [RouterModule.forChild(routes)],
   exports: [RouterModule]
})
export class ViagensRoutingModule { }
