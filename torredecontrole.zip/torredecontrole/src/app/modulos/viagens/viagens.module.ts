import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ViagensComponent } from './viagens/viagens.component';
import { ViagensRoutingModule } from './viagens-routing.module';
import { SharedModule } from 'src/app/shared/shared.module';



@NgModule({
  declarations: [ViagensComponent],
  imports: [
    CommonModule,
    ViagensRoutingModule,
    SharedModule
  ]
})
export class ViagensModule { }
