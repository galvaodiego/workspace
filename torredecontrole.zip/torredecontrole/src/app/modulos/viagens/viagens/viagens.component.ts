import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import io from 'socket.io-client';
import { Usuario } from 'src/app/shared/models/usuario.model';
import { FiltroAtivoService } from 'src/app/shared/services/filtro-ativo.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-viagens',
  templateUrl: './viagens.component.html',
  styleUrls: ['./viagens.component.scss']
})
export class ViagensComponent implements OnInit, OnDestroy {
  public user: Usuario = Usuario.instance;
  socketIo: any;
  socketFiltro: any;
  socketRota = 'viagem';
  socketMetodo = 'getViagem';
  loadVisible = false;
  subs: Subscription;
  // datasources:
  lista: any = {};
  indicadores: any = {};
  barList: Array<any> = [];
  mapa: any = {};
  filtroContent: any = {};
  ultimaAtu: any = null;
  // datasources-fim
  imgCustomStyle = { 'background-color': '#20A7DF' }
  constructor(private filtroAtivo: FiltroAtivoService) {

    this.socketIo = io(environment.socket_end_point_vm + '/' + this.socketRota);
    this.socketFiltro = {
      base: this.user.ref.toLowerCase(),
      usuario: this.user.usuario
    };
    const filtroGeral = JSON.parse(localStorage.getItem('filtro-geral'));
    if (filtroGeral) {
      Object.assign(this.socketFiltro, filtroGeral);
    }
    this.socket().then(() => { });
  }

  ngOnInit() {

    this.subs = this.filtroAtivo.getValue().subscribe((value) => {
      if (value) {
        this.loadVisible = true;
        Object.assign(this.socketFiltro, value);
        this.socketIo.emit(this.socketMetodo, this.socketFiltro);
      }
    });

    this.barList = [
      { chave: 'Arcelor Mittal', valor: 7 },
      { chave: 'BIOSEV', valor: 6 },
      { chave: 'Bunge', valor: 3 },
      { chave: 'Usiminas', valor: 3 },
      { chave: 'FS Agrosol', valor: 3 }
    ];
    const max = Math.max.apply(Math, this.barList.map((o) => o.valor));

    this.barList.map(e => {
      e.perc = Number(((e.valor * 100) / max).toFixed(0));
    });
  }

  ngOnDestroy(): void {
    this.socketIo.disconnect();
    this.subs.unsubscribe();
  }

  async socket() {
    try {
      this.socketManut();
      this.loadVisible = true;
      this.socketIo.emit(this.socketMetodo, this.socketFiltro);
      this.socketIo.on(this.socketRota, (data) => {
        if (data.atualizacao !== null) {
          this.reprocessar = false;
          clearTimeout(this.socketIo._connectTimer);
          if (environment.activeLogs) {
            console.log('retorno:viagem', data, 'FILTRO:', this.socketFiltro);
          }
          // monta lista
          Object.assign(this.lista, {
            datasource: data.lista.alerta,
            columns: [
              { dataField: 'PLACA', caption: 'Placa', dataType: 'string' },
              { dataField: 'NOME_MOTORISTA', caption: 'Motorista', dataType: 'string' },
              { dataField: 'REFERENCIA', caption: 'Ref.', dataType: 'string' },
              { dataField: 'ALERTA_TIPO', caption: 'Alerta', dataType: 'string' },
              { dataField: 'DATA', caption: 'Data', dataType: 'date' },
              { dataField: 'TEMPO_ABERTO', caption: 'Tempo Aberto', dataType: 'string' },
              { dataField: 'GRID', caption: 'GRID', dataType: 'string', visible: false },
              { dataField: 'CLIENTE', caption: 'Cliente', dataType: 'string', visible: false },
              { dataField: 'SEGMENTO', caption: 'Segmento', dataType: 'string', visible: false },
              { dataField: 'STATUS', caption: 'Status', dataType: 'string', visible: false },
            ]
          });
          this.indicadores = data.indicadores;
          this.barList = data.grafico.performance_cliente;
          const max = Math.max.apply(Math, this.barList.map((o) => o.valor));

          this.barList.map(e => {
            e.perc = Number(((e.valor * 100) / max).toFixed(0));
          });

          this.mapa = data.mapa;
          this.filtroContent = data.filtro;
          this.ultimaAtu = data.atualizacao;
          this.loadVisible = false;
        }
      });
    } catch (error) {
      this.loadVisible = false;
      console.log('error => ', error);
    }
  }

  markerClick(e) {
    this.loadVisible = true;
    Object.assign(this.socketFiltro, { placa: e.placa });
    // console.log('(markerClick) enviando o filtro:', this.socketFiltro);
    this.socketIo.emit('getViagem', this.socketFiltro);
  }

  reprocessar = false;
  socketManut() {
    this.socketIo._connectTimer = setTimeout(() => {
      this.socketIo.disconnect();
      this.loadVisible = false;
      this.reprocessar = true;
    }, environment.tempoEsperaSocket);
  }

  reprocessamento(e) {
    if (e.reprocessar) {
      this.reprocessar = false;
      this.socketIo.connect();
      this.socketManut();
      this.loadVisible = true;
      this.socketIo.emit(this.socketMetodo, this.socketFiltro);
    }
  }

}
