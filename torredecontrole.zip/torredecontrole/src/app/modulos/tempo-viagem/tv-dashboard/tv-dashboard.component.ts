import { Component, OnInit, ViewChild } from '@angular/core';
import { DxMultiViewComponent } from 'devextreme-angular';
import { Subscription } from 'rxjs/internal/Subscription';
import { Usuario } from 'src/app/shared/models/usuario.model';
import { FiltroAtivoService } from 'src/app/shared/services/filtro-ativo.service';
import { environment } from 'src/environments/environment';
import io from 'socket.io-client';
import { MatDialog } from '@angular/material/dialog';
import { PreviewListaExportComponent } from 'src/app/shared/components/preview-lista-export/preview-lista-export.component';
@Component({
  selector: 'app-tv-dashboard',
  templateUrl: './tv-dashboard.component.html',
  styleUrls: ['./tv-dashboard.component.scss']
})
export class TvDashboardComponent implements OnInit {
  @ViewChild('multiview', { static: false }) multiview: DxMultiViewComponent;
  public user: Usuario = Usuario.instance;
  socketIo: any;
  socketFiltro: any;
  socketRota = 'tempoViagem';
  socketMetodo = 'getTempoViagem';
  loadVisible = false;
  subs: Subscription;
  ultimaAtu: any = null;
  views: Array<any>;
  porPagina: number;
  pages = 0;
  listaBoxes = [];
  lista = [];
  Arr = Array
  constructor(
    private filtroAtivo: FiltroAtivoService,
    public dialog: MatDialog
  ) {
    this.socketIo = io(environment.socket_end_point_vm + '/' + this.socketRota);
    this.socketFiltro = {
      base: this.user.ref.toLowerCase(),
      usuario: this.user.usuario
    };
    const filtroGeral = JSON.parse(localStorage.getItem('filtro-geral'));
    if (filtroGeral) {
      Object.assign(this.socketFiltro, filtroGeral);
    }
    this.socket().then(() => { });
  }

  ngOnInit() {
    this.subs = this.filtroAtivo.getValue().subscribe((value) => {
      if (value) {
        this.loadVisible = true;
        Object.assign(this.socketFiltro, value);
        this.socketIo.emit(this.socketMetodo, this.socketFiltro);
      }
    });
  }

  async socket() {
    try {
      this.socketManut();
      this.loadVisible = true;
      this.socketIo.emit(this.socketMetodo, this.socketFiltro);
      this.socketIo.on(this.socketRota, (data) => {
        if (data.atualizacao !== null) {
          this.reprocessar = false;
          clearTimeout(this.socketIo._connectTimer);
          if (environment.activeLogs) {
            console.log('retorno:tempoViagem', data, 'FILTRO:', this.socketFiltro);
          }
          this.lista = data.listas.tabelaViagens
          this.listaBoxes = data.dados;
          this.ultimaAtu = data.atualizacao;
          this.multiView();
          this.loadVisible = false;
        }
      });

    } catch (error) {
      this.loadVisible = false;
      console.log('error => ', error);
    }
  }

  multiView() {
    this.views = [];
    this.pages = Math.ceil(this.listaBoxes.length / 3);
    for (let index = 0; index < this.pages; index++) {
      this.views.push(this.paginate(this.listaBoxes, 3, index + 1));
    }
    setInterval(() => {
      this.trocaView(this.pages);
    }, 60000)

  }

  paginate(array, page_size, page_number) {
    --page_number; // because pages logically start with 1, but technically with 0
    return array.slice(page_number * page_size, (page_number + 1) * page_size);
  }

  trocaView(paginas) {
    if (this.multiview) {
      if (this.multiview.selectedIndex === paginas - 1) {
        this.multiview.selectedIndex = 0;
      } else {
        this.multiview.selectedIndex = this.multiview.selectedIndex + 1;
      }
    }
  }

  exportar() {
    const dialogRef = this.dialog.open(PreviewListaExportComponent, {
      data: {
        lista: this.lista,
        columns: [
          { dataField: 'CCG', caption: 'CCG' },
          { dataField: 'CLASSIFICACAO_VIAGEM', caption: 'Classificação Viagem' },
          { dataField: 'DATA_CARGA', caption: 'Data Carga' },
          { dataField: 'GRID', caption: 'Grid' },
          { dataField: 'GRUPO_NEGOCIADOR', caption: 'Grupo Negociador' },
          { dataField: 'MODALIDADE_CONTROLE', caption: 'Modalidade Controle' },
          { dataField: 'MODALIDADE_REFERENCIA', caption: 'Modalidade Ref.' },
          { dataField: 'NOME_MOTORISTA', caption: 'Nome Motorista' },
          { dataField: 'NUM_ROMANEIO', caption: 'Num. Romaneio' },
          { dataField: 'PLACA_CONTROLE', caption: 'Placa Controle' },
          { dataField: 'PLACA_REFERENCIA', caption: 'Placa Ref.' },
          { dataField: 'REFERENCIA', caption: 'Ref.' },
          { dataField: 'SEGMENTO', caption: 'Segmento' },
          { dataField: 'TEMPO_PREVISTO', caption: 'Tempo Previsto' },
          { dataField: 'TEMPO_VIAGEM', caption: 'Tempo Viagem' },
          { dataField: 'TOTAL_VIAGENS', caption: 'Total Viagens' }

        ],
        origem: 'tempo-viagem'
      }
    });
  }

  reprocessar = false;
  socketManut() {
    this.socketIo._connectTimer = setTimeout(() => {
      this.socketIo.disconnect();
      this.loadVisible = false;
      this.reprocessar = true;
    }, environment.tempoEsperaSocket);
  }

  reprocessamento(e) {
    if (e.reprocessar) {
      this.reprocessar = false;
      this.socketIo.connect();
      this.socketManut();
      this.loadVisible = true;
      this.socketIo.emit(this.socketMetodo, this.socketFiltro);
    }
  }
}
