import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BoxSegmentoComponent } from './box-segmento.component';

describe('BoxSegmentoComponent', () => {
  let component: BoxSegmentoComponent;
  let fixture: ComponentFixture<BoxSegmentoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BoxSegmentoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BoxSegmentoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
