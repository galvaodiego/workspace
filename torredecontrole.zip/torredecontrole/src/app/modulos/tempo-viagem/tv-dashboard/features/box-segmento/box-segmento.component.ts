import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-box-segmento',
  templateUrl: './box-segmento.component.html',
  styleUrls: ['./box-segmento.component.scss']
})
export class BoxSegmentoComponent implements OnInit {
  @Input() content: any;
  constructor() { }

  ngOnInit() {
    // console.log('chegou content', this.content);

  }

  customizeTextLabelAxis(e) {
    return "<p class='axisLabelTxt'>" + e.valueText + '</p>';
  }
  customizeLabel = (arg: any) => {
    return {
      visible: true,
      backgroundColor: "transparent",
      fontWeight: "bold"
    };

  }

  customizeTextLabelSerie = (e) => {
    let txt = e.valueText
    txt = this.hhmmss(e.value)
    // return txt;
    return e.argumentText + ': ' + txt;
  }


  pad(num) {
    return ("0" + num).slice(-2);
  }

  hhmmss(secs) {
    let minutes = Math.floor(secs / 60);
    secs = secs % 60;
    const hours = Math.floor(minutes / 60)
    minutes = minutes % 60;
    return `${hours}:${this.pad(minutes)}:${this.pad(secs)}`;
  }

}
