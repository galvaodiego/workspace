import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TempoViagemRoutingModule } from './tempo-viagem-routing.module';
import { TvDashboardComponent } from './tv-dashboard/tv-dashboard.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { BoxSegmentoComponent } from './tv-dashboard/features/box-segmento/box-segmento.component';


@NgModule({
  declarations: [TvDashboardComponent, BoxSegmentoComponent],
  imports: [
    CommonModule,
    SharedModule,
    TempoViagemRoutingModule,
    
  ]
})
export class TempoViagemModule { }
