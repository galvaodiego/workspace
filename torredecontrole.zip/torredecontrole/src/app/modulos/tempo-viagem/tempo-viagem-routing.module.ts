import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GuardaRotas } from 'src/app/shared/guards/guarda-rotas.guard';
import { TvDashboardComponent } from './tv-dashboard/tv-dashboard.component';


const routes: Routes = [
  { path: '', redirectTo: 'painel-tempo-viagem', pathMatch: 'full' },
  {
    path: 'painel-tempo-viagem',
    component: TvDashboardComponent,
    canActivate: [GuardaRotas],
    data: {
      modulo: 'free'
    }
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TempoViagemRoutingModule { }
