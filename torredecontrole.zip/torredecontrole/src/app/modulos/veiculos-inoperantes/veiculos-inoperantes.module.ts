import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { VeiculosInoperantesRoutingModule } from './veiculos-inoperantes-routing.module';
import { VeiculosInoperantesDashboardComponent } from './veiculos-inoperantes-dashboard/veiculos-inoperantes-dashboard.component';
import { CardVeiculoComponent } from './card-veiculo/card-veiculo.component';
import { SharedModule } from 'src/app/shared/shared.module';


@NgModule({
  declarations: [VeiculosInoperantesDashboardComponent, CardVeiculoComponent],
  imports: [
    CommonModule,
    VeiculosInoperantesRoutingModule,
    SharedModule
  ]
})
export class VeiculosInoperantesModule { }
