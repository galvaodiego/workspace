import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CardVeiculoComponent } from './card-veiculo.component';

describe('CardVeiculoComponent', () => {
  let component: CardVeiculoComponent;
  let fixture: ComponentFixture<CardVeiculoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CardVeiculoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CardVeiculoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
