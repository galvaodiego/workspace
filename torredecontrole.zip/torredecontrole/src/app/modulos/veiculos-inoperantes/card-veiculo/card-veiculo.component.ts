import { Component, EventEmitter, Input, OnInit, Output } from "@angular/core";

@Component({
  selector: "app-card-veiculo",
  templateUrl: "./card-veiculo.component.html",
  styleUrls: ["./card-veiculo.component.scss"],
})
export class CardVeiculoComponent implements OnInit {
  @Output() saida = new EventEmitter();
  @Input() titulo: string;
  @Input() valor: string;
  @Input() tituloGrafico: string;
  @Input() dataSourceGrafico: any;
  @Input() detalhamento: any;
  customStyleGraficos = { height: "900px" };
  paletaCores = ["#E7F4FF", "#FFE066", "#FAB005"];
  // paletaCores = ['#FAB005', '#FFE066', '#E7F4FF']

  constructor() {}

  ngOnInit() {
    if (this.dataSourceGrafico) {
      this.dataSourceGrafico.reverse();
    }
  }

  exportar() {
    this.saida.emit({ dados: this.detalhamento });
  }
}
