import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VeiculosInoperantesDashboardComponent } from './veiculos-inoperantes-dashboard.component';

describe('VeiculosInoperantesDashboardComponent', () => {
  let component: VeiculosInoperantesDashboardComponent;
  let fixture: ComponentFixture<VeiculosInoperantesDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VeiculosInoperantesDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VeiculosInoperantesDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
