import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Subscription } from 'rxjs';
import { PreviewListaExportComponent } from 'src/app/shared/components/preview-lista-export/preview-lista-export.component';
import { Usuario } from 'src/app/shared/models/usuario.model';
import { FiltroAtivoService } from 'src/app/shared/services/filtro-ativo.service';
import { environment } from 'src/environments/environment';
import io from 'socket.io-client';

@Component({
  selector: 'app-veiculos-inoperantes-dashboard',
  templateUrl: './veiculos-inoperantes-dashboard.component.html',
  styleUrls: ['./veiculos-inoperantes-dashboard.component.scss']
})
export class VeiculosInoperantesDashboardComponent implements OnInit {
  public user: Usuario = Usuario.instance;
  socketIo: any;
  socketFiltro: any;
  socketRota = 'inoperantes';
  socketMetodo = 'getInoperantes';
  loadVisible = false;
  subs: Subscription;
  ultimaAtu: any = null;
  cards: Array<any> = [];
  constructor(
    private filtroAtivo: FiltroAtivoService,
    public dialog: MatDialog
  ) {
    this.socketIo = io(environment.socket_end_point_vm + '/' + this.socketRota);
    this.socketFiltro = {
      base: this.user.ref.toLowerCase(),
      usuario: this.user.usuario
    };
    const filtroGeral = JSON.parse(localStorage.getItem('filtro-geral'));
    if (filtroGeral) {
      Object.assign(this.socketFiltro, filtroGeral);
    }
    this.socket().then(() => { });
  }

  ngOnInit() {
    this.subs = this.filtroAtivo.getValue().subscribe((value) => {
      if (value) {
        this.loadVisible = true;
        Object.assign(this.socketFiltro, value);
        this.socketIo.emit(this.socketMetodo, this.socketFiltro);
      }
    });
  }

  async socket() {
    try {
      this.socketManut();
      this.loadVisible = true;
      this.socketIo.emit(this.socketMetodo, this.socketFiltro);
      this.socketIo.on(this.socketRota, (data) => {
        if (data.atualizacao !== null) {
          this.reprocessar = false;
          clearTimeout(this.socketIo._connectTimer);
          if (environment.activeLogs) {
            console.log('retorno:' + this.socketMetodo, data, 'FILTRO:', this.socketFiltro);
          }
          this.cards = data.dados;
          this.ultimaAtu = data.atualizacao;
          this.loadVisible = false;
        }
      });

    } catch (error) {
      this.loadVisible = false;
      console.log('error => ', error);
    }
  }

  reprocessar = false;
  socketManut() {
    this.socketIo._connectTimer = setTimeout(() => {
      this.socketIo.disconnect();
      this.loadVisible = false;
      this.reprocessar = true;
    }, environment.tempoEsperaSocket);
  }

  reprocessamento(e) {
    if (e.reprocessar) {
      this.reprocessar = false;
      this.socketIo.connect();
      this.socketManut();
      this.loadVisible = true;
      this.socketIo.emit(this.socketMetodo, this.socketFiltro);
    }
  }

  exportar(e) {
    const dialogRef = this.dialog.open(PreviewListaExportComponent, {
      data: {
        lista: e.dados,
        origem: 'veiculos-inoperantes',
        columns: [
          { dataField: 'IMPRODUTIVO', caption: 'Improdutivo' },
          { dataField: 'INOPERANTE', caption: 'Inoperante' },
          { dataField: 'ENCOSTADO', caption: 'Encostado' },
          { dataField: 'FORA_DE_OPERACAO', caption: 'Fora de Operação' },
          { dataField: 'PLACA_CONTROLE', caption: 'Placa' },
          { dataField: 'PLACA_REFERENCIA', caption: 'Placa Ref.' },
          { dataField: 'MODALIDADE_CONTROLE', caption: 'Modalidade' },
          { dataField: 'MODALIDADE_REFERENCIA', caption: 'Modalidade Ref.' },
          { dataField: 'TEMPO_CONTINUO', caption: 'Tempo Continuo' },
          { dataField: 'STATUS', caption: 'Status' },
          { dataField: 'NUM_ROMANEIO', caption: 'Nº Romaneio' },
          { dataField: 'REFERENCIA', caption: 'Re.' },
          { dataField: 'GRID', caption: 'Grid' },
          { dataField: 'SEGMENTO', caption: 'Segmento' },
          { dataField: 'POSSUI_MOTORISTA', caption: 'Possui Motorista' },
          { dataField: 'ENGATADA', caption: 'Engatada' },
          { dataField: 'GRUPO_NEGOCIADOR', caption: 'Grupo' },
          { dataField: 'CCG', caption: 'CCG' },
          { dataField: 'ORDEM_SERVICO_ID', caption: 'OS ID' }
        ]
      }
    });
  }

}
