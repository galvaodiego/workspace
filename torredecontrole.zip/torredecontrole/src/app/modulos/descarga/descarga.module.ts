import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DescargaRoutingModule } from './descarga-routing.module';
import { DescargaComponent } from './descarga/descarga.component';
import { SharedModule } from 'src/app/shared/shared.module';


@NgModule({
  declarations: [DescargaComponent],
  imports: [
    CommonModule,
    DescargaRoutingModule,
    SharedModule
  ]
})
export class DescargaModule { }
