import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MvRoutingModule } from './mv-routing.module';
import { TesteComponent } from './teste/teste.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { TempoCargaModule } from '../tempo-carga/tempo-carga.module';
import { TempoDescargaModule } from '../tempo-descarga/tempo-descarga.module';
import { AlertasViagemModule } from '../alertas-viagem/alertas-viagem.module';
import { AlertasDescargaModule } from '../alertas-descarga/alertas-descarga.module';


@NgModule({
  declarations: [TesteComponent],
  imports: [
    CommonModule,
    SharedModule,
    MvRoutingModule,
    TempoCargaModule,
    TempoDescargaModule,
    AlertasViagemModule,
    AlertasDescargaModule
  ]
})
export class MvModule { }
