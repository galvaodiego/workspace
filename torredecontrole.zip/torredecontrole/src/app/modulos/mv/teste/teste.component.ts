import { Component, OnInit, ViewChild } from '@angular/core';
import { DxMultiViewComponent } from 'devextreme-angular';
import { AutoplayService } from 'src/app/shared/services/autoplay.service';

@Component({
  selector: 'app-teste',
  templateUrl: './teste.component.html',
  styleUrls: ['./teste.component.scss']
})
export class TesteComponent implements OnInit {
  @ViewChild('multiview', { static: false }) multiview: DxMultiViewComponent;
  views: Array<any>;
  Arr = Array
  porPagina: number;
  pages = 0;
  constructor(
    private autoplayServe: AutoplayService
  ) { }

  ngOnInit() {
    this.cancelaTrocaRotas();
    this.views = ['app-av-painel', 'app-ad-painel'];
    this.pages = 2;
    setInterval(() => {
      this.trocaView(this.pages);
    }, 60000)
  }

  cancelaTrocaRotas() {
    this.autoplayServe.menuShow = false;
    this.autoplayServe.setVision = false;
    this.autoplayServe.rotas.map(rota => {
      rota.visible = false;
    })
    console.log(this.autoplayServe.rotas)
    localStorage.removeItem('tabs-active-view');
  }

  paginate(array, page_size, page_number) {
    --page_number; // because pages logically start with 1, but technically with 0
    return array.slice(page_number * page_size, (page_number + 1) * page_size);
  }

  trocaView(paginas) {
    if (this.multiview) {
      if (this.multiview.selectedIndex === paginas - 1) {
        this.multiview.selectedIndex = 0;
      } else {
        this.multiview.selectedIndex = this.multiview.selectedIndex + 1;
      }
    }
  }

}
