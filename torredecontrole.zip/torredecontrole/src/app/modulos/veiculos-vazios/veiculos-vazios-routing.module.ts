import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GuardaRotas } from 'src/app/shared/guards/guarda-rotas.guard';
import { VeiculosVaziosDashboardComponent } from './veiculos-vazios-dashboard/veiculos-vazios-dashboard.component';


const routes: Routes = [
  { path: '', redirectTo: 'painel-veiculos-vazios', pathMatch: 'full' },
  {
    path: 'painel-veiculos-vazios',
    component: VeiculosVaziosDashboardComponent,
    canActivate: [GuardaRotas],
    data: {
      modulo: 'free'
    }
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class VeiculosVaziosRoutingModule { }
