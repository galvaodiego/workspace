import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { VeiculosVaziosRoutingModule } from './veiculos-vazios-routing.module';
import { VeiculosVaziosDashboardComponent } from './veiculos-vazios-dashboard/veiculos-vazios-dashboard.component';
import { IndicadoresComponent } from './veiculos-vazios-dashboard/indicadores/indicadores.component';
import { AnalisePorGridComponent } from './veiculos-vazios-dashboard/analise-por-grid/analise-por-grid.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { BoxGridComponent } from './veiculos-vazios-dashboard/box-grid/box-grid.component';


@NgModule({
  declarations: [VeiculosVaziosDashboardComponent, IndicadoresComponent, AnalisePorGridComponent, BoxGridComponent],
  imports: [
    CommonModule,
    SharedModule,
    VeiculosVaziosRoutingModule,
  ]
})
export class VeiculosVaziosModule { }
