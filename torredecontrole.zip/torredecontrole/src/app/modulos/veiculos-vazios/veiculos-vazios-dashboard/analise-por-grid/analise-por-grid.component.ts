import {
  Component,
  Input,
  OnChanges,
  SimpleChanges,
  ViewChild,
} from "@angular/core";
import { DxMultiViewComponent } from "devextreme-angular";
import { MatDialog } from "@angular/material/dialog";
import { PreviewListaExportComponent } from "src/app/shared/components/preview-lista-export/preview-lista-export.component";
@Component({
  selector: "app-analise-por-grid",
  templateUrl: "./analise-por-grid.component.html",
  styleUrls: ["./analise-por-grid.component.scss"],
})
export class AnalisePorGridComponent implements OnChanges {
  @ViewChild("multiview", { static: false }) multiview: DxMultiViewComponent;
  @Input() listaBoxes: Array<any> = [];
  @Input() detalhamentoExportar: any;
  views: Array<any>;
  Arr = Array;
  porPagina: number;
  pages = 0;
  constructor(private dialog: MatDialog) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (this.listaBoxes.length > 0) {
      this.multiView();
    }
  }

  multiView() {
    this.views = [];
    this.pages = Math.ceil(this.listaBoxes.length / 3);
    for (let index = 0; index < this.pages; index++) {
      this.views.push(this.paginate(this.listaBoxes, 3, index + 1));
    }
    setInterval(() => {
      this.trocaView(this.pages);
    }, 60000);
  }

  paginate(array, page_size, page_number) {
    --page_number; // because pages logically start with 1, but technically with 0
    return array.slice(page_number * page_size, (page_number + 1) * page_size);
  }

  trocaView(paginas) {
    if (this.multiview) {
      if (this.multiview.selectedIndex === paginas - 1) {
        this.multiview.selectedIndex = 0;
      } else {
        this.multiview.selectedIndex = this.multiview.selectedIndex + 1;
      }
    }
  }

  exportar() {
    const dialogRef = this.dialog.open(PreviewListaExportComponent, {
      data: {
        lista: this.detalhamentoExportar,
        columns: [
          { dataField: "CCG", caption: "CCG" },
          { dataField: "EM_LOCAL_CARGA", caption: "Em local de carga" },
          { dataField: "ENGATADA", caption: "Engatada" },
          { dataField: "GRID", caption: "Grid" },
          { dataField: "GRUPO_NEGOCIADOR", caption: "Grupo Negociador" },
          { dataField: "MODALIDADE_CONTROLE", caption: "Modalidade Controle" },
          { dataField: "MODALIDADE_REFERENCIA", caption: "Modalidade Ref." },
          { dataField: "MOV_SEM_VIAGEM", caption: "Mov. sem viagem" },
          { dataField: "NOME_MOTORISTA", caption: "Nome Motorista" },
          { dataField: "NUM_ROMANEIO", caption: "Num. Romaneio" },
          { dataField: "PLACA_CONTROLE", caption: "Placa Controle" },
          { dataField: "PLACA_REFERENCIA", caption: "Placa Ref." },
          { dataField: "POSSUI_MOTORISTA", caption: "Possui Motorista" },
          { dataField: "REFERENCIA", caption: "Ref." },
          { dataField: "SEGMENTO", caption: "Segmento" },
          { dataField: "VEIC_VAZIO", caption: "Veículo Vazio" },
          { dataField: "VELOCIDADE_RASTREADOR", caption: "Velo. Rastreador" },
        ],
        origem: "veiculos-vazios",
      },
    });
  }
}
