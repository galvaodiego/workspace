import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnalisePorGridComponent } from './analise-por-grid.component';

describe('AnalisePorGridComponent', () => {
  let component: AnalisePorGridComponent;
  let fixture: ComponentFixture<AnalisePorGridComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnalisePorGridComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnalisePorGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
