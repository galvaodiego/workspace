import { Component, Input, OnInit } from "@angular/core";

@Component({
  selector: "app-box-grid",
  templateUrl: "./box-grid.component.html",
  styleUrls: ["./box-grid.component.scss"],
})
export class BoxGridComponent implements OnInit {
  @Input() content: any;
  customStyleGraficos = { height: "280px" };
  paletaCores = ["#E7F4FF", "#FFE066", "#FAB005"];
  constructor() {}

  ngOnInit() {
    this.reverse();
  }

  reverse() {
    if (this.content.viagensVazias) {
      this.content.viagensVazias.grafico.reverse();
    }
    if (this.content.vaziasMov) {
      this.content.vaziasMov.grafico.reverse();
    }
    if (this.content.vaziasLocalCarga) {
      this.content.vaziasLocalCarga.grafico.reverse();
    }
  }
}
