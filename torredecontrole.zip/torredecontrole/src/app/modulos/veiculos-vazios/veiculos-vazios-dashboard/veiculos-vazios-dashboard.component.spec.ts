import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VeiculosVaziosDashboardComponent } from './veiculos-vazios-dashboard.component';

describe('VeiculosVaziosDashboardComponent', () => {
  let component: VeiculosVaziosDashboardComponent;
  let fixture: ComponentFixture<VeiculosVaziosDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VeiculosVaziosDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VeiculosVaziosDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
