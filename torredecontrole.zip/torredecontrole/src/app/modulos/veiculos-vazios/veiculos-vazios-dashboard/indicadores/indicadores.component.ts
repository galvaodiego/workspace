import { Component, Input, OnInit } from "@angular/core";
import { MatDialog } from "@angular/material/dialog";
import { PreviewListaExportComponent } from "src/app/shared/components/preview-lista-export/preview-lista-export.component";

@Component({
  selector: "app-indicadores",
  templateUrl: "./indicadores.component.html",
  styleUrls: ["./indicadores.component.scss"],
})
export class IndicadoresComponent implements OnInit {
  @Input() indicadores: any;
  @Input() detalhamentoExportar: number;
  constructor() {}

  ngOnInit() {}
}
