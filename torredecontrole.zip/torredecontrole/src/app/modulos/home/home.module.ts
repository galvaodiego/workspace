import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

import { SharedModule } from 'src/app/shared/shared.module';

import { Page404Component } from './page404/page404.component';




@NgModule({
   declarations: [
      Page404Component,
   ],
   imports: [
      CommonModule,
      RouterModule,
      SharedModule,
   ],
   exports: []
})
export class HomeModule { }
