import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TempoDescargaRoutingModule } from './tempo-descarga-routing.module';
import { TdDashboardComponent } from './td-dashboard/td-dashboard.component';
import { SharedModule } from 'src/app/shared/shared.module';


@NgModule({
  declarations: [TdDashboardComponent],
  imports: [
    CommonModule,
    TempoDescargaRoutingModule,
    SharedModule
  ],
  exports: [TdDashboardComponent]
})
export class TempoDescargaModule { }
