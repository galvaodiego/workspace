import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GuardaRotas } from 'src/app/shared/guards/guarda-rotas.guard';
import { TdDashboardComponent } from './td-dashboard/td-dashboard.component';


const routes: Routes = [
  { path: '', redirectTo: 'painel-tempo-descarga', pathMatch: 'full' },
  {
    path: 'painel-tempo-descarga',
    component: TdDashboardComponent,
    canActivate: [GuardaRotas],
    data: {
      modulo: 'free'
    }
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TempoDescargaRoutingModule { }
