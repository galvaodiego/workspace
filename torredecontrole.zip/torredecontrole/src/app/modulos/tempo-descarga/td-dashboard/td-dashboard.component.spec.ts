import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TdDashboardComponent } from './td-dashboard.component';

describe('TdDashboardComponent', () => {
  let component: TdDashboardComponent;
  let fixture: ComponentFixture<TdDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TdDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TdDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
