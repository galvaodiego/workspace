import { Component, OnInit } from '@angular/core';
import { Usuario } from 'src/app/shared/models/usuario.model';
import { FiltroAtivoService } from 'src/app/shared/services/filtro-ativo.service';
import { environment } from 'src/environments/environment';
import io from 'socket.io-client';
import { Subscription } from 'rxjs';
import { MatDialog } from '@angular/material/dialog';
import { PreviewListaExportComponent } from 'src/app/shared/components/preview-lista-export/preview-lista-export.component';
@Component({
  selector: 'app-td-dashboard',
  templateUrl: './td-dashboard.component.html',
  styleUrls: ['./td-dashboard.component.scss']
})
export class TdDashboardComponent implements OnInit {
  public user: Usuario = Usuario.instance;
  socketIo: any;
  socketFiltro: any;
  socketRota = 'tempoDescarga';
  socketMetodo = 'getTempoDescarga';
  loadVisible = false;
  subs: Subscription;
  // datasources:
  lista: any = {};
  indicadores: any = {};
  graficos: any = {};
  ultimaAtu: any = null;
  // datasources-fim
  paletaCores = ['#FF6000', '#FF8500', '#FFB600'];
  constructor(
    private filtroAtivo: FiltroAtivoService,
    public dialog: MatDialog
  ) {
    this.socketIo = io(environment.socket_end_point_vm + '/' + this.socketRota);
    this.socketFiltro = {
      base: this.user.ref.toLowerCase(),
      usuario: this.user.usuario
    };
    const filtroGeral = JSON.parse(localStorage.getItem('filtro-geral'));
    if (filtroGeral) {
      Object.assign(this.socketFiltro, filtroGeral);
    }
    this.socket().then(() => { });
  }

  ngOnInit() {
    this.subs = this.filtroAtivo.getValue().subscribe((value) => {
      if (value) {
        this.loadVisible = true;
        Object.assign(this.socketFiltro, value);
        // console.log('enviando o filtro:', this.socketFiltro);
        this.socketIo.emit(this.socketMetodo, this.socketFiltro);
      }
    });
  }

  ngOnDestroy(): void {
    this.socketIo.disconnect();
    this.subs.unsubscribe();
  }

  async socket() {
    try {
      this.socketManut();
      this.loadVisible = true;
      this.socketIo.emit(this.socketMetodo, this.socketFiltro);
      this.socketIo.on(this.socketRota, (data) => {
        if (data.atualizacao !== null) {
          this.reprocessar = false;
          clearTimeout(this.socketIo._connectTimer);
          if (environment.activeLogs) {
            console.log('retorno:tempoDescarga', data, 'FILTRO:', this.socketFiltro);
          }
          if (data.graficos.tempoMedioDescargaCliente.length > 0) {
            data.graficos.tempoMedioDescargaCliente.reverse()
          }

          if (data.graficos.tempoMedioDescargaGrid.length > 0) {
            data.graficos.tempoMedioDescargaGrid.reverse()
          }

          if (data.graficos.tempoMedioDescargaSegmento.length > 0) {
            data.graficos.tempoMedioDescargaSegmento.reverse()
          }

          if (data.graficos.veiculosDescargaGrid.length > 0) {
            data.graficos.veiculosDescargaGrid.reverse()
          }

          if (data.graficos.veiculosDescargaSegmento.length > 0) {
            data.graficos.veiculosDescargaSegmento.reverse()
          }
          this.graficos = data.graficos;
          this.indicadores = data.indicadores;
          this.lista = data.listas.ExportarDetalhamento;
          this.ultimaAtu = data.atualizacao;
          this.loadVisible = false;
        }
      });
    } catch (error) {
      this.loadVisible = false;
      console.log('error => ', error);
    }
  }

  markerClick(e) {
    this.loadVisible = true;
    Object.assign(this.socketFiltro, { placa: e.placa });
    this.socketIo.emit('getCarga', this.socketFiltro);
  }


  exportar() {
    const dialogRef = this.dialog.open(PreviewListaExportComponent, {
      data: {
        lista: this.lista,
        origem: 'tempo-descarga'
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      // console.log(`Dialog result: ${result}`);
    });
  }

  reprocessar = false;
  socketManut() {
    this.socketIo._connectTimer = setTimeout(() => {
      this.socketIo.disconnect();
      this.loadVisible = false;
      this.reprocessar = true;
    }, environment.tempoEsperaSocket);
  }

  reprocessamento(e) {
    if (e.reprocessar) {
      this.reprocessar = false;
      this.socketIo.connect();
      this.socketManut();
      this.loadVisible = true;
      this.socketIo.emit(this.socketMetodo, this.socketFiltro);
    }
  }

}
