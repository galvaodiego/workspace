import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CargaRoutingModule } from './carga-routing.module';
import { CargaComponent } from './carga/carga.component';
import { SharedModule } from 'src/app/shared/shared.module';


@NgModule({
  declarations: [CargaComponent],
  imports: [
    CommonModule,
    CargaRoutingModule,
    SharedModule
  ]
})
export class CargaModule { }
