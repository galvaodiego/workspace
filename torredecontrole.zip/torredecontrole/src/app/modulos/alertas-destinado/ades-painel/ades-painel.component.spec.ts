import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdesPainelComponent } from './ades-painel.component';

describe('AdesPainelComponent', () => {
  let component: AdesPainelComponent;
  let fixture: ComponentFixture<AdesPainelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdesPainelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdesPainelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
