import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AlertasDestinadoRoutingModule } from './alertas-destinado-routing.module';
import { AdesPainelComponent } from './ades-painel/ades-painel.component';
import { SharedModule } from 'src/app/shared/shared.module';


@NgModule({
  declarations: [AdesPainelComponent],
  imports: [
    CommonModule,
    AlertasDestinadoRoutingModule,
    SharedModule
  ]
})
export class AlertasDestinadoModule { }
