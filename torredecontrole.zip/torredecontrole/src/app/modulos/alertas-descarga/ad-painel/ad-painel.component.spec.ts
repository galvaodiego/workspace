import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdPainelComponent } from './ad-painel.component';

describe('AdPainelComponent', () => {
  let component: AdPainelComponent;
  let fixture: ComponentFixture<AdPainelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdPainelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdPainelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
