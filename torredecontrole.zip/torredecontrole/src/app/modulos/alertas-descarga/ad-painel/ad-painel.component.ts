import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import io from 'socket.io-client';
import { Usuario } from 'src/app/shared/models/usuario.model';
import { AlertasService } from 'src/app/shared/services/alertas.service';
import { FiltroAtivoService } from 'src/app/shared/services/filtro-ativo.service';
import { environment } from 'src/environments/environment';
import Helper from '../../../shared/helpers/Helper'
@Component({
  selector: 'app-ad-painel',
  templateUrl: './ad-painel.component.html',
  styleUrls: ['./ad-painel.component.scss']
})
export class AdPainelComponent implements OnInit {
  public user: Usuario = Usuario.instance;
  socketIo: any;
  socketFiltro: any;
  socketRota = 'alertaDescarga';
  socketMetodo = 'getAlertaDescarga';
  loadVisible = false;
  subs: Subscription;
  // datasources:
  lista: any = {};
  indicadores: any = {};
  barList: Array<any> = [];
  mapa: any = {};
  graficos: any = {};
  filtroContent: any = {};
  ultimaAtu: any = null;
  // datasources-fim
  OpcoesComponentes = [
    { id: 1, descricao: 'Lista de alerta em aberto' },
    { id: 2, descricao: 'Gráfico de alerta aberto por grid' },
    { id: 3, descricao: 'Gráfico de alerta aberto por grupo do cavalo' },
  ]

  componenteSelecionado = 1;
  paletaCores = ['#FF6000', '#FF8500', '#FFB600']; //escuro ~ claro
  helper = new Helper();
  blocoSuperiorEsquerdo;
  blocoInferiorEsquerdo;
  blocoCentral;
  blocoSuperiorDireito;
  blocoInferiorDireito;
  customStyleGraficos = { height: "620px" }
  constructor(
    private filtroAtivo: FiltroAtivoService,
    private alertasService: AlertasService
  ) {
    this.socketIo = io(environment.socket_end_point_vm + '/' + this.socketRota);
    this.socketFiltro = {
      base: this.user.ref.toLowerCase(),
      usuario: this.user.usuario
    };
    const filtroGeral = JSON.parse(localStorage.getItem('filtro-geral'));
    if (filtroGeral) {
      Object.assign(this.socketFiltro, filtroGeral);
    }
    this.socket().then(() => { });
  }

  ngOnInit() {
    this.subs = this.filtroAtivo.getValue().subscribe((value) => {
      if (value) {
        this.loadVisible = true;
        Object.assign(this.socketFiltro, value);
        // console.log('enviando o filtro:', this.socketFiltro);
        this.socketIo.emit(this.socketMetodo, this.socketFiltro);
      }
    });
  }

  ngOnDestroy(): void {
    this.socketIo.disconnect();
    this.subs.unsubscribe();
  }

  async socket() {
    try {
      this.socketManut();
      this.loadVisible = true;
      this.socketIo.emit(this.socketMetodo, this.socketFiltro);
      this.socketIo.on(this.socketRota, (data) => {
        if (data.atualizacao !== null) {
          this.reprocessar = false;
          clearTimeout(this.socketIo._connectTimer);
          if (environment.activeLogs) {
            console.log('retorno:' + this.socketMetodo, data, 'FILTRO:', this.socketFiltro);
          }
          if (data.listas.tabelaAlertasAbertos.length > 0) {
            data.listas.tabelaAlertasAbertos.map(item => {
              item.DATA = item.DATA.replace('.000Z', '')
              item.DATA_CARGA = item.DATA_CARGA.replace('.000Z', '')
            });
          }

          data.listas.tabelaAlertasAbertos.map(e => {
            e.TEMPO_ABERTO_SEGUNDOS = this.helper.hhmmss(e.TEMPO_ABERTO_SEGUNDOS)
          })
          // monta lista
          Object.assign(this.lista, {
            datasource: data.listas.tabelaAlertasAbertos,
            columns: this.alertasService.colunas
          });
          // this.indicadores = data.indicadores;
          const imgCustomStyle = { 'background-color': '#DE5037' };
          this.blocoSuperiorEsquerdo = {
            titulo: 'Descargas em execução',
            valor: data.indicadores.emExecucao ? data.indicadores.emExecucao : 0,
            imagem: 'assets/images/torre/alertasDescargasEmExecucao.png',
            imgCustomStyle
          }

          this.blocoInferiorEsquerdo = {
            titulo: 'Alertas recebidos',
            valor: data.indicadores.alertasRecebidos ? data.indicadores.alertasRecebidos : 0,
            imagem: 'assets/images/torre/alertasCargasRecebidos.png',
            imgCustomStyle
          }

          this.blocoCentral = {
            titulo: 'Descarga',
            subtitulo: 'Perf. acumulada dia',
            valor: data.indicadores.performanceAlertas ? data.indicadores.performanceAlertas : 0,
            imagem: 'assets/images/torre/Gauge2.png',
            cor: '#DE5037'
          }

          this.blocoSuperiorDireito = {
            titulo: 'Alertas tratados',
            valor: data.indicadores.alertasTratados ? data.indicadores.alertasTratados : 0,
            imagem: 'assets/images/torre/alertas_tratados.png',
            imgCustomStyle
          }

          this.blocoInferiorDireito = {
            titulo: 'Alertas não tratados',
            valor: data.indicadores.alertasNaoTratados ? data.indicadores.alertasNaoTratados : 0,
            imagem: 'assets/images/torre/cargasNaoConforme.png',
            imgCustomStyle
          }
          this.mapa = data.mapa;
          if (data.graficos.alertasAbertosGrid.length > 0) {
            data.graficos.alertasAbertosGrid.reverse();
          }
          if (data.graficos.alertasAbertosGrupoCavalo.length > 0) {
            data.graficos.alertasAbertosGrupoCavalo.reverse();
          }

          this.graficos = data.graficos;
          this.filtroContent = data.filtro;
          this.ultimaAtu = data.atualizacao;
          this.loadVisible = false;
        }
      });
    } catch (error) {
      this.loadVisible = false;
      console.log('error => ', error);
    }
  }

  markerClick(e) {
    this.loadVisible = true;
    Object.assign(this.socketFiltro, { placa: e.placa });
    // console.log('(markerClick) enviando o filtro:', this.socketFiltro);
    this.socketIo.emit(this.socketMetodo, this.socketFiltro);
  }

  selecaoComponente(ev) {
    this.componenteSelecionado = ev.selecao
  }

  reprocessar = false;
  socketManut() {
    this.socketIo._connectTimer = setTimeout(() => {
      this.socketIo.disconnect();
      this.loadVisible = false;
      this.reprocessar = true;
    }, environment.tempoEsperaSocket);
  }

  reprocessamento(e) {
    if (e.reprocessar) {
      this.reprocessar = false;
      this.socketIo.connect();
      this.socketManut();
      this.loadVisible = true;
      this.socketIo.emit(this.socketMetodo, this.socketFiltro);
    }
  }

}
