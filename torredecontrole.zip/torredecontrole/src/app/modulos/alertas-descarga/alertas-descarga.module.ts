import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AlertasDescargaRoutingModule } from './alertas-descarga-routing.module';
import { AdPainelComponent } from './ad-painel/ad-painel.component';
import { SharedModule } from 'src/app/shared/shared.module';


@NgModule({
  declarations: [AdPainelComponent],
  imports: [
    CommonModule,
    AlertasDescargaRoutingModule,
    SharedModule
  ],
  exports: [AdPainelComponent]
})
export class AlertasDescargaModule { }
