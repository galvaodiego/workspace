import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TempoCargaRoutingModule } from './tempo-carga-routing.module';
import { TcDashboardComponent } from './tc-dashboard/tc-dashboard.component';
import { SharedModule } from 'src/app/shared/shared.module';


@NgModule({
  declarations: [TcDashboardComponent],
  imports: [
    CommonModule,
    TempoCargaRoutingModule,
    SharedModule,
  ],
  exports: [TcDashboardComponent]
})
export class TempoCargaModule { }
