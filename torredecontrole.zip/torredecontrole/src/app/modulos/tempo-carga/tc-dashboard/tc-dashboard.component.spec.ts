import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TcDashboardComponent } from './tc-dashboard.component';

describe('TcDashboardComponent', () => {
  let component: TcDashboardComponent;
  let fixture: ComponentFixture<TcDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TcDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TcDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
