import { Component, OnDestroy, OnInit } from '@angular/core';
import { Usuario } from 'src/app/shared/models/usuario.model';
import { environment } from 'src/environments/environment';
import io from 'socket.io-client';
import { Subscription } from 'rxjs';
import { FiltroAtivoService } from 'src/app/shared/services/filtro-ativo.service';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-alertas',
  templateUrl: './alertas.component.html',
  styleUrls: ['./alertas.component.scss']
})
export class AlertasComponent implements OnInit, OnDestroy {
  public user: Usuario = Usuario.instance;
  socketIo: any;
  socketFiltro: any;
  socketRota = 'alerta';
  socketMetodo = 'getAlerta';
  loadVisible = false;
  subs: Subscription;
  // Datasources
  kpiList: any = [];
  lista: any = {};
  listaTemp: any = {};
  ultimaAtu: any = null;
  // Datasources-fim

  pageSizeGrid = 14;
  toggleForm: FormGroup;

  constructor(
    private filtroAtivo: FiltroAtivoService,
    private fb: FormBuilder
  ) {
    this.toggleForm = this.fb.group({
      performance: true,
      produtividade: true,
      monitoramento: true
    })
    this.socketIo = io(environment.socket_end_point_vm + '/' + this.socketRota);
    this.socketFiltro = {
      base: this.user.ref.toLowerCase(),
      usuario: this.user.usuario
    };
    const filtroGeral = JSON.parse(localStorage.getItem('filtro-geral'));
    if (filtroGeral) {
      Object.assign(this.socketFiltro, filtroGeral);
    }
    this.socket().then(() => { });
  }

  ngOnInit() {
    this.corrigeTabela();
    this.subs = this.filtroAtivo.getValue().subscribe((value) => {
      if (value) {
        this.loadVisible = true;
        Object.assign(this.socketFiltro, value);
        // console.log('enviando o filtro:', this.socketFiltro);
        this.socketIo.emit(this.socketMetodo, this.socketFiltro);
      }
    });
  }

  ngOnDestroy(): void {
    this.socketIo.disconnect();
    this.subs.unsubscribe();
  }

  corrigeTabela() {
    const storage = JSON.parse(localStorage.getItem('alertas-storage'));
    if (storage) {
      storage.pageSize = this.pageSizeGrid;
      localStorage.setItem('alertas-storage', JSON.stringify(storage))
    }
  }

  async socket() {
    try {
      this.socketManut();
      this.loadVisible = true;
      this.socketIo.emit(this.socketMetodo, this.socketFiltro);
      this.socketIo.on(this.socketRota, (data) => {
        if (data.atualizacao !== null) {
          this.reprocessar = false;
          clearTimeout(this.socketIo._connectTimer);
          if(environment.activeLogs){
            console.log('retorno do socket alertas:', data, 'filtro:', this.socketFiltro);
          }
          data.lista.map(e => {
            if (e.DATA) {
              e.DATA = e.DATA.slice(0, -5);
            }
          })
          this.listaTemp = data.lista;

          // monta lista
          Object.assign(this.lista, {
            datasource: data.lista,
            columns: [
              { dataField: 'PLACA', caption: 'Placa', dataType: 'string' },
              { dataField: 'SEGMENTO', caption: 'Segmento', dataType: 'string' },
              { dataField: 'COORDENADOR', caption: 'Coordenador', dataType: 'string' },
              { dataField: 'TEMPO_ABERTO', caption: 'Tempo Aberto', dataType: 'string' },
              {
                dataField: 'CLASSIFICACAO', caption: 'Classificação', dataType: 'number', cellTemplate: 'cassificaTemplate',
                alignment: 'center', width: 'auto'
              },
              { dataField: 'MOTORISTA', caption: 'Motorista', dataType: 'string', visible: false },
              { dataField: 'VIAGEM_ITINERARIO_ALERTA_ID', caption: 'Alerta ID', dataType: 'number', visible: false },
              { dataField: 'TIPO_ALERTA', caption: 'Tipo de Alerta', dataType: 'string', visible: false },
              { dataField: 'CLASSIFICACAO_ALERTA', caption: 'Classificação Alerta', dataType: 'string', visible: false },
              { dataField: 'DATA', caption: 'Data', dataType: 'datetime', visible: false, format: "HH:mm:ss" },
              { dataField: 'CLIENTE', caption: 'Cliente', dataType: 'string', visible: false },
              { dataField: 'NUM_ROMANEIO', caption: 'Nº Romaneio', dataType: 'string', visible: false },
              { dataField: 'SITUACAO_ROMANEIO', caption: 'Situ. Romaneio', dataType: 'string', visible: false },
            ]
          });

          if (data.kpiList) {
            data.kpiList.map(e => {
              if (e.type === 'produtividade') {
                e.icon = 'assets/images/torre/kpi-clock.png';
              } else if (e.type === 'nivel_servico') {
                e.icon = 'assets/images/torre/kpi-clock2.png';
              } else if (e.type === 'programacao') {
                e.icon = 'assets/images/torre/kpi-clock3.png';
              } else if (e.type === 'monitoramento') {
                e.icon = 'assets/images/torre/kpi-clock4.png';
              }
            });
            this.kpiList = data.kpiList;
            this.kpiList.map(e => {
              e.visible = true;
            });
            this.toggleFilter();
          } else {
            this.kpiList = [];
          }
          this.ultimaAtu = data.atualizacao;
          this.loadVisible = false;
        }
      });
    } catch (error) {
      this.loadVisible = false;
      console.log('error => ', error);
    }
  }

  clicaToggle(e) {
    const toggle = this.toggleForm.value;
    localStorage.setItem('alertas-toggle', JSON.stringify(toggle));
    this.toggleFilter();
  }

  toggleFilter() {
    // console.log('lista', this.lista);
    const toggle = JSON.parse(localStorage.getItem('alertas-toggle'));
    if (toggle) {
      this.toggleForm.setValue(toggle);
      this.kpiList.map(e => {
        switch (e.type) {
          case 'nivel_servico':
            e.visible = toggle.performance
            break;
          case 'produtividade':
            e.visible = toggle.produtividade
            break;
          case 'monitoramento':
            e.visible = toggle.monitoramento
            break;
        }
      });

      const lista = [... this.listaTemp];
      lista.map(e => {
        switch (e.CLASSIFICACAO) {
          case 'nivel_servico':
            e.VISIBLE = toggle.performance
            break;
          case 'produtividade':
            e.VISIBLE = toggle.produtividade
            break;
          case 'monitoramento':
            e.VISIBLE = toggle.monitoramento
            break;
        }
      });

      this.lista.datasource = lista.filter(f => f.VISIBLE === true);
    }
  }

  reprocessar = false;
  socketManut() {
    this.socketIo._connectTimer = setTimeout(() => {
      this.socketIo.disconnect();
      this.loadVisible = false;
      this.reprocessar = true;
    }, environment.tempoEsperaSocket);
  }

  reprocessamento(e) {
    if (e.reprocessar) {
      this.reprocessar = false;
      this.socketIo.connect();
      this.socketManut();
      this.loadVisible = true;
      this.socketIo.emit(this.socketMetodo, this.socketFiltro);
    }
  }

}
