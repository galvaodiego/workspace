import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GuardaRotas } from 'src/app/shared/guards/guarda-rotas.guard';
import { AlertasComponent } from './alertas/alertas.component';


const routes: Routes = [
  { path: '', redirectTo: 'painel-alerta', pathMatch: 'full' },
  {
    path: 'painel-alerta',
    component: AlertasComponent,
    canActivate: [GuardaRotas],
    data: {
      modulo: 'free'
    }
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AlertasRoutingModule { }
