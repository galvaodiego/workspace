import { Component, OnInit, ViewChild, AfterViewInit, ChangeDetectorRef } from '@angular/core';
import { MatHorizontalStepper } from '@angular/material/stepper';
import { Usuario } from 'src/app/shared/models/usuario.model';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';
import { AutoplayService } from 'src/app/shared/services/autoplay.service';

@Component({
   selector: 'app-autenticacao-login',
   templateUrl: './autenticacao-login.component.html',
   styleUrls: ['./autenticacao-login.component.scss']
})
export class AutenticacaoLoginComponent implements OnInit, AfterViewInit {
   @ViewChild('stepper') stepper: MatHorizontalStepper;

   public user: Usuario = Usuario.instance;
   public version: string;
   step1Status: boolean;
   step2Status: boolean;
   clienteSelecionado = false;
   dadosCliente = {
      ref: '',
      logo: '',
      nome: ''
   };

   selectedIndex = 0;

   constructor(
      private cdRef: ChangeDetectorRef,
      private router: Router,
      private autoPlayService: AutoplayService
   ) {
      this.version = environment.version;
   }

   ngOnInit() {
      if (this.user.isLogged) {
         this.autoPlayService.setViewRegras();
         const go = this.autoPlayService.rotas.find(e=>{
            return e.visible == true
         })
         this.router.navigate([go.path]);
      }
   }

   ngAfterViewInit(): void {
      const cliente = JSON.parse(localStorage.getItem('cliente-selecionado'));
      if (cliente) {
         this.clienteSelecionado = true;
         Object.assign(this.dadosCliente, cliente);
         this.cdRef.detectChanges();
      }
   }

   atualizar() {
      location.reload();
   }


}
