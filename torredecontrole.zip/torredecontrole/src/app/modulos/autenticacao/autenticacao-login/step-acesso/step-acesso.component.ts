import { FormBuilder, Validators, FormControl } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Usuario } from 'src/app/shared/models/usuario.model';
import { UsuarioService } from 'src/app/shared/services/usuario.service';
import { EstruturaOrganizacional, Permissao, ConfigOrgUsuario, Nivel } from 'src/app/shared/models/organizacional.model';
import { ClienteService } from 'src/app/shared/services/cliente.service';
import { GatewayService } from 'src/app/shared/services/gateway.service';
import * as moment from 'moment';
import { NotificacaoService } from 'src/app/shared/services/notificacao.service';
import { Router } from '@angular/router';
import { EstruturaOrganizacionalService } from 'src/app/shared/services/organizacional.service';
import { SocketService } from 'src/app/shared/services/socket.service';

import io from 'socket.io-client';

@Component({
   selector: 'app-step-acesso',
   templateUrl: './step-acesso.component.html',
   styleUrls: ['./step-acesso.component.scss']
})
export class StepAcessoComponent implements OnInit {
   public user: Usuario = Usuario.instance;
   private org: EstruturaOrganizacional = EstruturaOrganizacional.instance;

   public form;
   clienteSelecionado: any;
   showPass = false;
   constructor(
      private formBuilder: FormBuilder,
      private userProvider: UsuarioService,
      private orgProvider: EstruturaOrganizacionalService,
      public clienteS: ClienteService,
      private gateway: GatewayService,
      private notificacao: NotificacaoService,
      private router: Router

   ) {
      // this.form = this.formBuilder.group({
      //    usuario: ['', Validators.required, Validators.email],
      //    senha: ['', Validators.required],
      //    plataforma_tipo: [3],
      // });
      this.form = this.formBuilder.group({
         usuario: new FormControl('', [Validators.required, Validators.email]),
         senha: new FormControl('', [Validators.required]),
         plataforma_tipo: [3],
      });
   }

   ngOnInit() {
   }

   doLogin() {
      const login = this.form.get('usuario').value;

      if (login.indexOf('@') === -1) {
         this.notificacao.openSnackBar('Formato correto de seu usuário: Ex: nome.usuario@seudominio.com.br');
         return false;
      } else {
         const acesso = login.split('@');
         const cliente = this.clienteS.validaCliente(acesso[1]);
         if (!cliente) {
            this.notificacao.openSnackBar('Nenhum cliente encontrado com este domínio');
         } else {
            // encontrou cliente
            this.setCliente(cliente);
            this.user.usuario = acesso[0];
            this.userProvider.save();
            this.user.codGestao = null;
            this.user.filiais = null;
            this.user.token = null;
            this.user.senha = this.form.get('senha').value;
            this.user.plataforma_tipo = 3;
            this.requestLogin();
            console.log('Url de Conexão', this.user.url);
         }

      }

   }

   setCliente(cliente) {
      localStorage.setItem('cliente-selecionado', JSON.stringify(cliente));
      this.user.cliente = cliente.nome;
      this.user.ref = cliente.ref;
      this.user.url = cliente.url;
      this.userProvider.save();
   }

   async requestLogin() {
      const tempGestoes: any = [];

      const parametrosBd = {
         username: this.user.usuario,
         password: this.user.senha,
         cod_gestao: this.user.codGestao,
         filiais: this.user.filiais,
         plataforma_tipo: this.user.plataforma_tipo
      };

      // Chama o Backend
      try {
         const response: any = await this.gateway.backendCall('LOGON', 'LOGON', parametrosBd);
         if (response.token != null && response.token.length) {
            const socketIo = io(environment.socket_end_point_vm + '/login');
            socketIo.emit('getToken', {
               usuario: this.user.usuario,
               base: this.user.ref.toLowerCase(),
               token: response.token
            });
            socketIo.on('getToken', (data) => {
               this.user.tokenSocket = data;
               this.user.token = response.token;
               this.user.ambiente = response.ambiente;
               this.user.isLogged = true;
               this.user.ultimoLogin = moment().format();
               this.userProvider.save();
               // Resgata as Permissoes do Usuario
               this.getPermissoes();
            });

            // socketIo.disconnect();


         } else if (response.gestoes !== null && response.gestoes.length > 0) {
            // console.log('gestoes', response.gestoes);

            // Coleta o COD_PESSOA de todas as Gestões
            //  O Menor COD_PESSOA, é o da Gestão Principal;
            // tslint:disable-next-line: prefer-for-of
            for (let i = 0; i < response.gestoes.length; i++) {
               const el = response.gestoes[i];
               tempGestoes.push(el.cod_pessoa);
            }

            // tslint:disable-next-line: prefer-for-of
            for (let i = 0; i < response.gestoes.length; i++) {
               const el = response.gestoes[i];
               if (el.cod_pessoa === Math.min.apply(null, tempGestoes)) {
                  this.user.codGestao = el.cod_gestao;
                  this.user.codPessoa = el.cod_pessoa;
                  this.user.cliente = el.cliente;
                  this.user.usuario = el.usuario;
                  this.user.identificador = el.identificador;
                  // tslint:disable-next-line:no-shadowed-variable
                  // this.user.filiais = el.filiais.map(el => el.cod_pessoa).join(',');
                  this.user.filiais = '';
                  this.userProvider.save();
               }
            }
            this.requestLogin();
         } else if (response.gestoes.length === 0) {
            this.notificacao.openSnackBar('Usuário Sem Gestão');
         }

      } catch (error) {
         console.log('Erro Login -> ', error);
         return;
      }
   }

   /*
   * Retorna do Banco as Permissões do Usuário Logado, para acesso aos módulos
   */
   public async getPermissoes(): Promise<any> {
      const plataforma = 'WEB';
      const parametrosBd = {
         usuario_bi: this.user.usuario,
         plataforma
      };
      try {
         const response: any = await this.gateway.backendCall('1811-APPGESTOR', 'getUsuarioPermissoes', parametrosBd);
         console.log('getUsuarioPermissoes', response);
         this.user.listaModulos = response.permissoes[0].config_org_usuario;
         this.prepara(response);
         this.user.isLogged = true;
         this.userProvider.save();

         this.router.navigate(['dashboard']);
      } catch (error) {
         console.log('Erro Permissoes -> ', error);
      }
   }

   prepara(response) {
      // Base Acessada
      this.org.base = response.permissoes[0].base ? response.permissoes[0].base : '';

      // Usuario
      this.org.usuario.usuario = response.permissoes[0].usuario;
      this.org.usuario.usuarioBiId = response.permissoes[0].usuario_bi_id;

      // Permissoes do Usuario
      this.org.permissoes = [];
      // tslint:disable-next-line: prefer-for-of
      for (let i = 0; i < response.permissoes[0].permissoes_usuario.length; i++) {
         const element = response.permissoes[0].permissoes_usuario[i];
         const obj: Permissao = new Permissao();
         obj.ativo = element.ativo;
         obj.codNivelOrganizacional = element.cod_nivel_organizacional;
         obj.ordem = element.ordem;
         obj.organizacional = element.organizacional;
         obj.organizacionalId = element.organizacional_id;
         obj.organizacionalIdCorp = element.organizacional_id_corp;
         obj.organizacionalIdPai = element.organizacional_id_pai;
         obj.tipoOrganizacional = element.tipo_organizacional;
         obj.tipoOrganizacionalId = element.tipo_organizacional_id;
         obj.usuario = this.org.usuario;
         this.org.permissoes.push(obj);
      }

      // Configuracao organizacional do Usuario
      this.org.configOrgUsuario = [];

      // tslint:disable-next-line: prefer-for-of
      for (let i = 0; i < response.permissoes[0].config_org_usuario.length; i++) {
         const element = response.permissoes[0].config_org_usuario[i];
         const obj: ConfigOrgUsuario = new ConfigOrgUsuario();
         obj.listConfigOrg = element.config_organizacional;
         obj.configOrgId = element.configuracao_org_id;
         obj.configOrg = element.configuracao_organizacional;
         obj.modulo = element.modulo;
         obj.moduloId = element.modulo_id;
         obj.niveis = this.toNiveis(element.niveis);
         // obj.dashs = this.toDashs(element.permissao_dash);
         obj.numModulo = element.num_modulo;
         this.org.configOrgUsuario.push(obj);
      }

      this.orgProvider.save();
   }
   /*
   * Modela o resultado de Niveis para o AccessConfig
   * @param list :: Niveis
   */
   public toNiveis(list: any) {

      if (!Array.isArray(list)) {
         return new Array<Nivel>();
      }

      if (list.length > 0) {
         list.forEach(
            (item) => {
               this.org.niveis.usuario = this.org.usuario;
               this.org.niveis.codNivelOrganizacional = item.cod_nivel_organizacional;
               this.org.niveis.nivel = item.nivel;
               this.org.niveis.organizacional = item.organizacional;
               this.org.niveis.organizacionalId = item.organizacional_id;
               this.org.niveis.tipoOrganizacionalId = item.tipoOrganizacional_id;
            }
         );
      }
      return list;
   }

   limpaStorage() {
      localStorage.removeItem('kmm_bi-dash|' + this.clienteS.discover() + '-usuario');
      localStorage.removeItem('kmm_bi-dash|' + this.clienteS.discover() + '-organizacional');
   }

}
