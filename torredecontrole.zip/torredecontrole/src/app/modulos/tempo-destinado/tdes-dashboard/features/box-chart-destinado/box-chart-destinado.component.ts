import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-box-chart-destinado',
  templateUrl: './box-chart-destinado.component.html',
  styleUrls: ['./box-chart-destinado.component.scss']
})
export class BoxChartDestinadoComponent implements OnInit {
  @Input() titulo: string;
  @Input() paleta: any;
  @Input() datasource: any;
  @Input() faixaCorteTime: any;
  customStyleGraficos = { height: "440px" }
  constructor() { }

  ngOnInit() {
  }

}
