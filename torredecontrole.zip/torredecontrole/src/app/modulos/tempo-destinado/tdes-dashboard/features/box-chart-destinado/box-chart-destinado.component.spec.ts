import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BoxChartDestinadoComponent } from './box-chart-destinado.component';

describe('BoxChartDestinadoComponent', () => {
  let component: BoxChartDestinadoComponent;
  let fixture: ComponentFixture<BoxChartDestinadoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BoxChartDestinadoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BoxChartDestinadoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
