import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-kpi-destinado',
  templateUrl: './kpi-destinado.component.html',
  styleUrls: ['./kpi-destinado.component.scss']
})
export class KpiDestinadoComponent implements OnInit {
  @Input() valor: any
  @Input() titulo: any
  @Input() className: any
  constructor() { }

  ngOnInit() {
  }

}
