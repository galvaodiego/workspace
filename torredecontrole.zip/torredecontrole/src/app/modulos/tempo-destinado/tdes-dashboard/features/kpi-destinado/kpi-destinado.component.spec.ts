import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KpiDestinadoComponent } from './kpi-destinado.component';

describe('KpiDestinadoComponent', () => {
  let component: KpiDestinadoComponent;
  let fixture: ComponentFixture<KpiDestinadoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KpiDestinadoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KpiDestinadoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
