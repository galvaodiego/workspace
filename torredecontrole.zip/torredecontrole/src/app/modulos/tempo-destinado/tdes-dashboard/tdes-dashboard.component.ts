import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Subscription } from 'rxjs';
import { Usuario } from 'src/app/shared/models/usuario.model';
import { FiltroAtivoService } from 'src/app/shared/services/filtro-ativo.service';
import { environment } from 'src/environments/environment';
import io from 'socket.io-client';
import { PreviewListaExportComponent } from 'src/app/shared/components/preview-lista-export/preview-lista-export.component';

@Component({
  selector: 'app-tdes-dashboard',
  templateUrl: './tdes-dashboard.component.html',
  styleUrls: ['./tdes-dashboard.component.scss']
})
export class TdesDashboardComponent implements OnInit {
  public user: Usuario = Usuario.instance;
  socketIo: any;
  socketFiltro: any;
  socketRota = 'tempoDestinado';
  socketMetodo = 'getTempoDestinado';
  loadVisible = false;
  subs: Subscription;
  // datasources:
  dados: any;
  ultimaAtu: any = null;
  // datasources-fim
  paletaCores = ['#116A19', '#199F26', '#22D334'];
  faixaCorteTime = [10800, 32400]
  constructor(
    private filtroAtivo: FiltroAtivoService,
    public dialog: MatDialog
  ) {
    this.socketIo = io(environment.socket_end_point_vm + '/' + this.socketRota);
    this.socketFiltro = {
      base: this.user.ref.toLowerCase(),
      usuario: this.user.usuario
    };
    const filtroGeral = JSON.parse(localStorage.getItem('filtro-geral'));
    if (filtroGeral) {
      Object.assign(this.socketFiltro, filtroGeral);
    }
    this.socket().then(() => { });
  }
  ngOnDestroy(): void {
    this.socketIo.disconnect();
    this.subs.unsubscribe();
  }
  ngOnInit() {
    this.subs = this.filtroAtivo.getValue().subscribe((value) => {
      if (value) {
        this.loadVisible = true;
        Object.assign(this.socketFiltro, value);
        this.socketIo.emit(this.socketMetodo, this.socketFiltro);
      }
    });
  }

  async socket() {
    try {
      this.socketManut();
      this.loadVisible = true;
      this.socketIo.emit(this.socketMetodo, this.socketFiltro);
      this.socketIo.on(this.socketRota, (data) => {
        if (data.atualizacao !== null) {
          this.reprocessar = false;
          clearTimeout(this.socketIo._connectTimer);
          if(environment.activeLogs){
            console.log('retorno:tempoDestinado', data, 'FILTRO:', this.socketFiltro);
          }
          if (data.graficos) {
            if (data.graficos.tmDestinadoCoordenador.length > 0) {
              data.graficos.tmDestinadoCoordenador.reverse()
            }
            if (data.graficos.tmDestinadoSegmento.length > 0) {
              data.graficos.tmDestinadoSegmento.reverse()
            }
            if (data.graficos.tmDestinarCoordenador.length > 0) {
              data.graficos.tmDestinarCoordenador.reverse()
            }
            if (data.graficos.tmDestinarSegmento.length > 0) {
              data.graficos.tmDestinarSegmento.reverse()
            }
          }
          this.dados = data;
          this.ultimaAtu = data.atualizacao;
          this.loadVisible = false;
        }
      });
    } catch (error) {
      this.loadVisible = false;
      console.log('error => ', error);
    }
  }

  exportar() {
    const dialogRef = this.dialog.open(PreviewListaExportComponent, {
      data: {
        lista: this.dados.listas.ExportarDetalhamento,
        origem: 'tempo-destinado'
      }
    });

    // dialogRef.afterClosed().subscribe(result => {
    //   console.log(`Dialog result: ${result}`);
    // });
  }

  reprocessar = false;
  socketManut() {
    this.socketIo._connectTimer = setTimeout(() => {
      this.socketIo.disconnect();
      this.loadVisible = false;
      this.reprocessar = true;
    }, environment.tempoEsperaSocket);
  }

  reprocessamento(e) {
    if (e.reprocessar) {
      this.reprocessar = false;
      this.socketIo.connect();
      this.socketManut();
      this.loadVisible = true;
      this.socketIo.emit(this.socketMetodo, this.socketFiltro);
    }
  }
}
