import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TdesDashboardComponent } from './tdes-dashboard.component';

describe('TdesDashboardComponent', () => {
  let component: TdesDashboardComponent;
  let fixture: ComponentFixture<TdesDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TdesDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TdesDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
