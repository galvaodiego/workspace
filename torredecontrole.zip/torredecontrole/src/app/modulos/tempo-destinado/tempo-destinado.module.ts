import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TempoDestinadoRoutingModule } from './tempo-destinado-routing.module';
import { TdesDashboardComponent } from './tdes-dashboard/tdes-dashboard.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { KpiDestinadoComponent } from './tdes-dashboard/features/kpi-destinado/kpi-destinado.component';
import { BoxChartDestinadoComponent } from './tdes-dashboard/features/box-chart-destinado/box-chart-destinado.component';


@NgModule({
  declarations: [TdesDashboardComponent, KpiDestinadoComponent, BoxChartDestinadoComponent],
  imports: [
    CommonModule,
    TempoDestinadoRoutingModule,
    SharedModule
  ]
})
export class TempoDestinadoModule { }
