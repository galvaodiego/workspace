import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AlertasViagemRoutingModule } from './alertas-viagem-routing.module';
import { AvPainelComponent } from './av-painel/av-painel.component';
import { SharedModule } from 'src/app/shared/shared.module';


@NgModule({
  declarations: [AvPainelComponent],
  imports: [
    CommonModule,
    AlertasViagemRoutingModule,
    SharedModule
  ],
  exports:[AvPainelComponent]
})
export class AlertasViagemModule { }
