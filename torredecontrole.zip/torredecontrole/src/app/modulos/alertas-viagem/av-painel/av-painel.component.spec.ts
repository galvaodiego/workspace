import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AvPainelComponent } from './av-painel.component';

describe('AvPainelComponent', () => {
  let component: AvPainelComponent;
  let fixture: ComponentFixture<AvPainelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AvPainelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AvPainelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
