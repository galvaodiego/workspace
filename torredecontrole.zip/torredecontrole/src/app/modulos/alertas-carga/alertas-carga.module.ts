import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AlertasCargaRoutingModule } from './alertas-carga-routing.module';
import { AcPainelComponent } from './ac-painel/ac-painel.component';
import { SharedModule } from 'src/app/shared/shared.module';


@NgModule({
  declarations: [AcPainelComponent],
  imports: [
    CommonModule,
    AlertasCargaRoutingModule,
    SharedModule
  ]
})
export class AlertasCargaModule { }
