import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GuardaRotas } from 'src/app/shared/guards/guarda-rotas.guard';
import { AcPainelComponent } from './ac-painel/ac-painel.component';


const routes: Routes = [
  { path: '', redirectTo: 'painel-alertas-carga', pathMatch: 'full' },
  {
    path: 'painel-alertas-carga',
    component: AcPainelComponent,
    canActivate: [GuardaRotas],
    data: {
      modulo: 'free'
    }
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AlertasCargaRoutingModule { }
