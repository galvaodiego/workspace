import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AcPainelComponent } from './ac-painel.component';

describe('AcPainelComponent', () => {
  let component: AcPainelComponent;
  let fixture: ComponentFixture<AcPainelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AcPainelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AcPainelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
