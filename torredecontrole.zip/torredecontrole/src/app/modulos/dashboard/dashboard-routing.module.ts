import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GuardaRotas } from 'src/app/shared/guards/guarda-rotas.guard';
import { DashboardComponent } from './dashboard/dashboard.component';



const routes: Routes = [
   { path: '', redirectTo: 'painel-dashboard', pathMatch: 'full' },
   {
      path: 'painel-dashboard',
      component: DashboardComponent,
      canActivate: [GuardaRotas],
      data: {
         modulo: 'free'
      }
   },

];

@NgModule({
   imports: [RouterModule.forChild(routes)],
   exports: [RouterModule]
})
export class DashboardRoutingModule { }
