import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './dashboard/dashboard.component';
import { DashboardRoutingModule } from './dashboard-routing.module';
import { SharedModule } from 'src/app/shared/shared.module';
import { KpiV1Component } from './features/kpi-v1/kpi-v1.component';
import { KpiTipoComponent } from './features/kpi-tipo/kpi-tipo.component';



@NgModule({
  declarations: [DashboardComponent, KpiV1Component, KpiTipoComponent],
  imports: [
    CommonModule,
    DashboardRoutingModule,
    SharedModule
  ]
})
export class DashboardModule { }
