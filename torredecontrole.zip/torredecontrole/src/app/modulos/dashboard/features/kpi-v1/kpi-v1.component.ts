import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-kpi-v1',
  templateUrl: './kpi-v1.component.html',
  styleUrls: ['./kpi-v1.component.scss']
})
export class KpiV1Component implements OnInit {
  @Input() titulo;
  @Input() subtitulo;
  @Input() valor;
  @Input() lista;
  @Input() nConf;
  @Input() bgColor;
  constructor() { }

  ngOnInit() {
  }

  validaTam(str: string) {
    if (str.length > 12) {
      return true;
    }
  }

}
