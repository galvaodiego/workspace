import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KpiTipoComponent } from './kpi-tipo.component';

describe('KpiTipoComponent', () => {
  let component: KpiTipoComponent;
  let fixture: ComponentFixture<KpiTipoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KpiTipoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KpiTipoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
