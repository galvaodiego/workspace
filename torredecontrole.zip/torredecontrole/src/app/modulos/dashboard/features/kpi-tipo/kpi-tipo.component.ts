import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-kpi-tipo',
  templateUrl: './kpi-tipo.component.html',
  styleUrls: ['./kpi-tipo.component.scss']
})
export class KpiTipoComponent implements OnInit {
  @Input() tipo: number;
  @Input() titulo: string;
  @Input() valor: string;
  @Input() lista1: Lista;
  @Input() lista2: Lista;
  constructor() { }

  ngOnInit() {
  }

}

export class Lista {
  titulo: string;
  itens: Array<any>;
}
