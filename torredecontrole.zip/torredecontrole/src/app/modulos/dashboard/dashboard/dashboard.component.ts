import { Component, OnDestroy, OnInit } from '@angular/core';
import { Usuario } from 'src/app/shared/models/usuario.model';
import { environment } from 'src/environments/environment';
import io from 'socket.io-client';
import { Subscription } from 'rxjs';
import { FiltroAtivoService } from 'src/app/shared/services/filtro-ativo.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit, OnDestroy {
  public user: Usuario = Usuario.instance;
  socketIo: any;
  socketFiltro: any;
  socketRota = 'dashboard';
  socketMetodo = 'getDashboard';
  loadVisible = false;
  subs: Subscription;
  // Datasources
  kpiList: any = {};
  lista: any = {};
  dsNivelServico: any = {};
  dsProdutividade: any = {};
  dsProgramacao: any = {};
  ultimaAtu: any = null;
  // Datasources-fim
  constructor(private filtroAtivo: FiltroAtivoService) {
    this.socketIo = io(environment.socket_end_point_vm + '/' + this.socketRota);
    this.socketFiltro = {
      base: this.user.ref.toLowerCase(),
      usuario: this.user.usuario
    };
    const filtroGeral = JSON.parse(localStorage.getItem('filtro-geral'));
    if (filtroGeral) {
      Object.assign(this.socketFiltro, filtroGeral);
    }

    this.socket().then(() => { });
  }

  ngOnDestroy(): void {
    this.socketIo.disconnect();
    this.subs.unsubscribe();
  }

  ngOnInit() {
    this.subs = this.filtroAtivo.getValue().subscribe((value) => {
      if (value) {
        this.loadVisible = true;
        Object.assign(this.socketFiltro, value);
        // console.log('enviando o filtro:', this.socketFiltro);
        this.socketIo.emit(this.socketMetodo, this.socketFiltro);
      }
    });
  }

  async socket() {
    try {
      this.socketManut()
      this.loadVisible = true;
      this.socketIo.emit(this.socketMetodo, this.socketFiltro);
      this.socketIo.on(this.socketRota, (data) => {
        if (data.atualizacao !== null) {
          this.reprocessar = false;
          clearTimeout(this.socketIo._connectTimer);
          if (environment.activeLogs) {
            console.log('retorno:Dashboard', data, 'FILTRO:', this.socketFiltro);
          }
          Object.assign(this.lista, {
            datasource: data.lista,
            columns: [
              { dataField: 'TIPO_ALERTA', caption: '', dataType: 'string', cellTemplate: 'tipoAlertaIcon' },
              { dataField: 'DESCRICAO', caption: 'Descrição', dataType: 'string' },
              { dataField: 'NUM_ALERTAS', caption: 'Num. Alertas', dataType: 'number', alignment: 'center' }
            ]
          });
          Object.assign(this.dsNivelServico, data.kpiList.nivel_servico);
          Object.assign(this.dsProdutividade, data.kpiList.produtividade);
          Object.assign(this.dsProgramacao, data.kpiList.programacao);
          Object.assign(this.kpiList, data.kpiList);

          if (!environment.production) {
            Object.assign(this.kpiList.produtividade, {
              performance: [
                { chave: 'Perf Carga', valor: '30%' },
                { chave: 'Perf Descarga', valor: '0%' }
              ],
              situacao_veiculo: [
                { chave: 'Com Viagem', valor: 500 },
                { chave: 'Sem Viagem', valor: 500 },
              ]
            });
          }

          this.ultimaAtu = data.atualizacao;
          this.loadVisible = false;
        }
      });
    } catch (error) {
      this.loadVisible = false;
      console.log('error => ', error);
    }
  }

  reprocessar = false;
  socketManut() {
    this.socketIo._connectTimer = setTimeout(() => {
      this.socketIo.disconnect();
      this.loadVisible = false;
      this.reprocessar = true;
    }, environment.tempoEsperaSocket);
  }

  reprocessamento(e) {
    if (e.reprocessar) {
      this.reprocessar = false;
      this.socketIo.connect();
      this.socketManut();
      this.loadVisible = true;
      this.socketIo.emit(this.socketMetodo, this.socketFiltro);
    }
  }

}
