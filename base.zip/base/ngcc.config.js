module.exports = {
  packages: {
    'devextreme-angular':  {
      ignorableDeepImportMatchers: [
        /devextreme\//
      ]
    },
  }
};
