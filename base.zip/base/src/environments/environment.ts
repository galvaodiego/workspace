// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  version: 'DEV',
  socket_end_point: 'https://dash-backend.kmm.com.br',
  // socket_end_point: 'https://kmm-bi.herokuapp.com',
  socket_end_point_base: 'https://base-backend.kmm.com.br',
  // socket_end_point_base: 'https://kmm-base.herokuapp.com',
  oneSignal: {
    appId: 'a0261a18-7362-4b0e-ad7d-100342c404b3',
    apiKey: 'Y2VjNjY2Y2EtMzY3NC00ZTMxLWI3NjctNmRiZWJhY2RiZTEx'
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
