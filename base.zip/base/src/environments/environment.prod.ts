export const environment = {
  production: true,
  version: '2.1.39',
  socket_end_point: 'https://dash-backend.kmm.com.br',
  // socket_end_point: 'https://kmm-bi.herokuapp.com',
  socket_end_point_base: 'https://base-backend.kmm.com.br',
  // socket_end_point_base: 'https://kmm-base.herokuapp.com',
  oneSignal: {
    appId: 'a0261a18-7362-4b0e-ad7d-100342c404b3',
    apiKey: ''
  }
};
