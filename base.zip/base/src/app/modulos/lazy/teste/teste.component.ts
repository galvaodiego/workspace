import { Component, OnInit } from '@angular/core';
import { TSQlik, QSApp } from 'ts-qlik';

@Component({
  selector: 'app-teste',
  templateUrl: './teste.component.html',
  styleUrls: ['./teste.component.scss']
})
export class TesteComponent implements OnInit {
  aba = 1;
  qlik = null;
  active = 'qlik';
  config = {
    host: 'qliksense.kmm.com.br',
    port: '',
    prefix: '/',
    secure: true,
    isSecure: false
  };
  constructor() {
    this.qlik = null;

    TSQlik(this.config).then((q) => {
      this.qlik = q;
      console.log(q);
    });
    QSApp('c3ff7f2b-506f-4ab8-abf6-7fd7d19f763a', this.config).then((q) => {
      console.log(q);
      q.currApp.app.getObject('CurrentSelections', 'CurrentSelections');
      q.currApp.app.getObject('QV01', 'jRNPZJA');
      q.currApp.app.getObject('QV02', '2826efc3-e4ba-4020-a171-e5cbe4ecee98');

      q.currApp.app.getObject('KPI1', '2b2cfcf3-2ad1-4d61-8ec3-3e5c17f1b2b1');
      q.currApp.app.getObject('KPI2', 'a4042a1e-4948-49b2-b5bd-c643e858ec68');

      q.currApp.app.getObject('FT01', '710f3f0d-94d7-4424-9d85-cc8531abc8cf');
      q.currApp.app.getObject('FT02', '61b85bf7-24c1-4a0b-8067-f3b1065fcd82');
      q.currApp.app.getObject('FT03', 'bbc9e873-9343-49c1-8e4c-8908f844326c');

      q.currApp.app.getObject('FT04', '8df6f5fb-1701-49b1-a716-a68648d5b957');
      q.currApp.app.getObject('FT05', 'd6ca8da0-afc2-4cd6-82e0-8c7acc893dd1');
      q.currApp.app.getObject('FT06', 'b04a0af6-ba34-44b7-9293-2386212e8040');

      q.currApp.app.getObject('KPI3', 'MrYAXz');
      q.currApp.app.getObject('KPI4', 'pETBf');
      q.currApp.app.getObject('KPI5', 'MhWEgVn');
      q.currApp.app.getObject('KPI6', '7ad21544-74cd-4ff8-bd26-0c4671d93144');

      q.currApp.app.getObject('QV03', '046ec474-9ff0-46f1-b5e0-34d8831f14cd');
      q.currApp.app.getObject('QV04', 'cb88dd31-c26d-433e-8c75-bb33f5b5d03a');
      q.currApp.app.getObject('QV05', 'a9696828-1ce4-4734-aa21-cb8b1df22669');
      q.currApp.app.getObject('QV06', '38277106-d3cb-4966-94b6-86c70eee646e');


    });
  }

  ngOnInit() {
  }

  changeTab(aba: number) {
    console.log(aba);
    this.aba = aba;
    if (this.aba === 1) {

      QSApp('c3ff7f2b-506f-4ab8-abf6-7fd7d19f763a', this.config).then((q) => {
        console.log(q);
        q.currApp.app.getObject('QV03', '046ec474-9ff0-46f1-b5e0-34d8831f14cd');
      });
    } else if (this.aba === 2) {
      QSApp('c3ff7f2b-506f-4ab8-abf6-7fd7d19f763a', this.config).then((q) => {
        console.log(q);
        q.currApp.app.getObject('QV04', 'cb88dd31-c26d-433e-8c75-bb33f5b5d03a');
      });
    } else if (this.aba === 3) {
      QSApp('c3ff7f2b-506f-4ab8-abf6-7fd7d19f763a', this.config).then((q) => {
        console.log(q);
        q.currApp.app.getObject('QV05', 'a9696828-1ce4-4734-aa21-cb8b1df22669');
      });
    } else if (this.aba === 4) {
      QSApp('c3ff7f2b-506f-4ab8-abf6-7fd7d19f763a', this.config).then((q) => {
        console.log(q);
        q.currApp.app.getObject('QV06', '38277106-d3cb-4966-94b6-86c70eee646e');
      });
    }

  }

}
