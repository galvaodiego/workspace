import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FaturamentoCustomComponent } from './faturamento-custom.component';

describe('FaturamentoCustomComponent', () => {
  let component: FaturamentoCustomComponent;
  let fixture: ComponentFixture<FaturamentoCustomComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FaturamentoCustomComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FaturamentoCustomComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
