import { Component, OnInit } from '@angular/core';

@Component({
   selector: 'app-faturamento-custom',
   templateUrl: './faturamento-custom.component.html',
   styleUrls: ['./faturamento-custom.component.scss']
})
export class FaturamentoCustomComponent implements OnInit {
   componentes = [
      { name: 'kpi', description: 'KPI', icon: '' }
   ];
   constructor() { }

   ngOnInit() {
   }

}
