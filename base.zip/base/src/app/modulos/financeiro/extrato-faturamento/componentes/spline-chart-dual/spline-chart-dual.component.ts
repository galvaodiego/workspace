import { Component, OnInit, Input, Output, EventEmitter, OnDestroy } from '@angular/core';

import * as moment from 'moment';
import io from 'socket.io-client';
import { environment } from 'src/environments/environment';
import { Usuario } from 'src/app/shared/models/usuario.model';


@Component({
  // tslint:disable-next-line:component-selector
  selector: 'extrato-app-spline-chart-dual',
  templateUrl: './spline-chart-dual.component.html',
  styleUrls: ['./spline-chart-dual.component.scss']
})
export class SplineChartDualComponent implements OnInit, OnDestroy {
  public user: Usuario = Usuario.instance;
  // Config Socket
  socketIo: any;
  socketRota = 'base';
  socketFiltro: any;
  /***/
  datasource: any;
  @Input() height;

  dataSerie1 = moment().subtract(1, 'months');
  dataSerie2 = moment();
  constructor() { }

  ngOnInit() {
    this.socketIo = io(environment.socket_end_point_base + '/' + this.socketRota);
    this.socketFiltro = {
      base: this.user.ref.toLowerCase(),
    };
    this.socket();
  }

  ngOnDestroy(): void {
    this.socketIo.disconnect();
  }

  async socket() {
    try {
      this.socketIo.emit('getSplineComponent', this.socketFiltro);
      this.socketIo.on('splineComponent', (data) => {

        console.log('dataSpline FILTRANDO', this.socketFiltro);
        console.log('dataSpline RESPOSTA', data);

        this.datasource = data.faturamento;
      });
    } catch (error) {
      console.log('error => ', error);
    }
  }

  customizeTooltip2 = (info: any) => {
    // console.log('--->', info);
    // tslint:disable-next-line:max-line-length
    let texto = '<div><div class=\'tooltip-header\'>Dia ' + info.argumentText + '</div>' + '<div class=\'tooltip-body\'><div class=\'series-name\'>' + info.points[0].seriesName + ': </div><div class=\'value-text\'>' + info.points[0].valueText + '</div>';

    if (info.points[1]) {
      // const perc = (info.points[1].value / info.points[0].value) * 100;
      const perc = ((info.points[1].value - info.points[0].value) / info.points[0].value) * 100;

      // tslint:disable-next-line:max-line-length
      texto += '<div class=\'series-name\'>' + info.points[1].seriesName + ': </div><div class=\'value-text\'>' + info.points[1].valueText + '</div>';
      texto += '<div class=\'series-name\'>Total: </div><div class=\'value-text\'>' + Math.floor(perc)  + '%</div>';
    }

    texto += '</div></div>';

    return {
      html: texto
    };
  }

  filtrar() {
    Object.assign(this.socketFiltro, {
      data_ac1: moment(this.dataSerie1).format('YYYY-MM-DD'),
      data_ac2: moment(this.dataSerie2).format('YYYY-MM-DD')
    });
    this.socketIo.emit('getSplineComponent', this.socketFiltro);
  }


  onValueChangedDate(e) {
    // PARA CASO PRECISAR FILTRAR A CADA SELEÇÃO DE DATA
  }
}
