import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KpiMobileComponent } from './kpi-mobile.component';

describe('KpiMobileComponent', () => {
  let component: KpiMobileComponent;
  let fixture: ComponentFixture<KpiMobileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KpiMobileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KpiMobileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
