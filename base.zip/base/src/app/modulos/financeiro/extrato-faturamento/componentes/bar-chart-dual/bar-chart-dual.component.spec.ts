import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BarChartDualComponent } from './bar-chart-dual.component';

describe('BarChartDualComponent', () => {
  let component: BarChartDualComponent;
  let fixture: ComponentFixture<BarChartDualComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BarChartDualComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BarChartDualComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
