import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SplineChartDualComponent } from './spline-chart-dual.component';

describe('SplineChartDualComponent', () => {
  let component: SplineChartDualComponent;
  let fixture: ComponentFixture<SplineChartDualComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SplineChartDualComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SplineChartDualComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
