import { Component, OnInit, Input } from '@angular/core';


@Component({
  // tslint:disable-next-line:component-selector
  selector: 'extrato-app-bar-chart-sc',
  templateUrl: './bar-chart-sc.component.html',
  styleUrls: ['./bar-chart-sc.component.scss']
})
export class BarChartScComponent implements OnInit {
  @Input() datasource;
  @Input() rotated;
  @Input() title;
  @Input() name;
  @Input() color;
  @Input() height;
  @Input() legendFontSize;
  constructor() {  }

  ngOnInit() {
  }
  customizeTooltip = (info: any) => {
    return {
      html: '<div class=\'tooltip-box\'><div class=\'tooltip-header\'>' +
        info.argumentText + '</div>' +
        '<div class=\'tooltip-body\'><div class=\'series-name\'>' +
        info.seriesName +
        ': </div><div class=\'value-text\'>' +
        info.totalText +
        '</div></div></div></div>'
    };
  }

}
