import { Component, OnInit, Input } from '@angular/core';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'extrato-app-donut',
  templateUrl: './donut.component.html',
  styleUrls: ['./donut.component.scss']
})
export class DonutComponent implements OnInit {
  paletaCustom = [
    '#F17100',
    '#00B5AD',
    '#146E9C',
    '#6435C9',
    '#7CA5CF',
  ];

  constructor() { }
  @Input() datasource;
  @Input() legendFontSize;
  @Input() legendPosition;
  @Input() height;
  @Input() width;
  ngOnInit() {
  }

  public customizeLegTopN(arg) {
    if (arg.pointName === 'others') {
      return 'Outros';
    } else {
      return arg.pointName;
    }
  }

  public customizeLabel(arg) {
    if (arg.value === 0) {
      return false;
    } else {
      return arg.percentText;
    }
  }

}
