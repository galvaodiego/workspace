import { Component, OnInit, Input } from '@angular/core';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'extrato-app-kpi-mobile',
  templateUrl: './kpi-mobile.component.html',
  styleUrls: ['./kpi-mobile.component.scss']
})
export class KpiMobileComponent implements OnInit {
  @Input() cancelados;
  @Input() emitidos;
  @Input() media;
  @Input() tonelagem;
  constructor() { }

  ngOnInit() {
  }

}
