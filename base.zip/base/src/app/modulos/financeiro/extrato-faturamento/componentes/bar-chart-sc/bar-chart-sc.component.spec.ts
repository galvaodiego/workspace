import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BarChartScComponent } from './bar-chart-sc.component';

describe('BarChartScComponent', () => {
  let component: BarChartScComponent;
  let fixture: ComponentFixture<BarChartScComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BarChartScComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BarChartScComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
