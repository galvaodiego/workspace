import { Component, OnInit, Input } from '@angular/core';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'extrato-app-bar-chart-dual',
  templateUrl: './bar-chart-dual.component.html',
  styleUrls: ['./bar-chart-dual.component.scss']
})
export class BarChartDualComponent implements OnInit {
  @Input() datasource;
  @Input() serie1;
  @Input() serie2;
  @Input() height;
  @Input() rotated;
  @Input() legendFontSize;
  width = 400;


  constructor() { }

  ngOnInit() {
  }

  customizeTooltip2 = (info: any) => {
    // console.log('--->', info);
    return {
      html: '<div class=\'tooltip-box\'><div class=\'tooltip-header\'>' +
        info.argumentText + '</div>' +
        '<div class=\'tooltip-body\'><div class=\'series-name\'>' +
        info.seriesName +
        ': </div><div class=\'value-text\'>' +
        info.value + ' ( ' + info.percentText + ' )' +
        '</div></div></div></div>'
    };
  }


}
