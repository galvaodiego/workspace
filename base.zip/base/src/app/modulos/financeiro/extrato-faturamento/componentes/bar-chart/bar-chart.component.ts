import { Component, OnInit, Input } from '@angular/core';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'extrato-app-bar-chart',
  templateUrl: './bar-chart.component.html',
  styleUrls: ['./bar-chart.component.scss']
})
export class BarChartComponent implements OnInit {
  @Input() datasource;
  @Input() rotated;
  @Input() name;
  @Input() height;
  @Input() alternativo = false;

  paletaCustom = [
    '#F17100',
    '#00B5AD',
    '#146E9C',
    '#6435C9',
    '#7CA5CF',
  ];
  constructor() { }

  ngOnInit() {}

  public customizePointMultiple = (arg: any) => {
    return { color: this.paletaCustom[arg.index] };
  }

  customizeTooltip2 = (info: any) => {
    // console.log('--->', info);
    return {
      html: '<div class=\'tooltip-box\'><div class=\'tooltip-header\'>' +
        info.argumentText + '</div>' +
        '<div class=\'tooltip-body\'>' +
        '<div class=\'value-text\'>' +
        info.totalText +
        '</div></div></div></div>'
    };
  }
}
