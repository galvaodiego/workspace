import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DataGridTopsComponent } from './data-grid-tops.component';

describe('DataGridTopsComponent', () => {
  let component: DataGridTopsComponent;
  let fixture: ComponentFixture<DataGridTopsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DataGridTopsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DataGridTopsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
