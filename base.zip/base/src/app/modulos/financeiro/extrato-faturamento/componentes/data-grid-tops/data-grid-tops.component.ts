import { Component, OnInit, Input } from '@angular/core';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'extrato-app-data-grid-tops',
  templateUrl: './data-grid-tops.component.html',
  styleUrls: ['./data-grid-tops.component.scss']
})
export class DataGridTopsComponent implements OnInit {
  @Input() datasource;
  @Input() origem;

  constructor() { }

  ngOnInit() {
  }

  public onCellPrepared(e: any) {
    if (e.rowType === 'header') {
      e.cellElement.style.paddingTop = '5px';
      e.cellElement.style.paddingBottom = '5px';
      e.cellElement.style.fontSize = '10px';
      e.cellElement.style.fontStyle = 'normal';
      e.cellElement.style.fontWeight = '500';
      e.cellElement.style.lineHeight = '15px';
      e.cellElement.style.color = '#878787';
      e.cellElement.style.border = 'none';
    }

    if (typeof (e.data) !== 'undefined') {
      e.cellElement.style.paddingTop = '8px';
      e.cellElement.style.paddingBottom = '8px';
      e.cellElement.style.fontSize = '12px';
      e.cellElement.style.fontStyle = 'normal';
      e.cellElement.style.fontWeight = '300';
      e.cellElement.style.lineHeight = '16px';
      e.cellElement.style.color = '#070707';
      e.cellElement.style.border = 'none';
    }
  }

}
