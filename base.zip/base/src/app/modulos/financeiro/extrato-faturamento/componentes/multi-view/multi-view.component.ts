import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { DxMultiViewComponent } from 'devextreme-angular';
import { Usuario } from 'src/app/shared/models/usuario.model';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'extrato-app-multi-view',
  templateUrl: './multi-view.component.html',
  styleUrls: ['./multi-view.component.scss']
})
export class MultiViewComponent implements OnInit {
  public user: Usuario = Usuario.instance;

  @ViewChild('multiviewVeiculos') multiviewVeiculos: DxMultiViewComponent;

  @Input() datasource;
  @Input() pagesVeiculos;
  constructor() { }

  ngOnInit() {
  }

  trocaView(direction: string, context: any) {
    let mv = null;
    let pg = 0;
    mv = this.multiviewVeiculos;
    pg = this.pagesVeiculos;

    if (mv) {
      if (mv.selectedIndex === pg - 1) {
        mv.selectedIndex = 0;
      } else {
        if (direction === 'next') {
          mv.selectedIndex = mv.selectedIndex + 1;
        } else {
          mv.selectedIndex = mv.selectedIndex - 1;
        }
      }
    }
  }

}
