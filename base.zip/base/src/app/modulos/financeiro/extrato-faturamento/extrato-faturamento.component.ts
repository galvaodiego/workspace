import { Component, OnInit, OnDestroy, ViewChild, ChangeDetectorRef } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { MatIconRegistry } from '@angular/material/icon';
import { ActivatedRoute } from '@angular/router';
import { MediaMatcher } from '@angular/cdk/layout';

import { DxMultiViewComponent } from 'devextreme-angular';

import { NotificacaoService } from 'src/app/shared/services/notificacao.service';
import { Usuario } from 'src/app/shared/models/usuario.model';
import { environment } from 'src/environments/environment';
import { FeedDataService } from '../../home/feed/feed-data.service';
import { Dados } from './dados';

import io from 'socket.io-client';
import * as _ from 'lodash';
import * as moment from 'moment';

@Component({
   selector: 'app-extrato-faturamento',
   templateUrl: './extrato-faturamento.component.html',
   styleUrls: ['./extrato-faturamento.component.scss'],
   providers: [Dados]
})
export class ExtratoFaturamentoComponent implements OnInit, OnDestroy {
   @ViewChild('multiview') multiview: DxMultiViewComponent;
   @ViewChild('multiviewVeiculos') multiviewVeiculos: DxMultiViewComponent;
   @ViewChild('multiviewTipoFrete') multiviewTipoFrete: DxMultiViewComponent;

   public user: Usuario = Usuario.instance;
   public loadVisible = true;
   mobileQuery: MediaQueryList;
   // tslint:disable-next-line: variable-name
   private _mobileQueryListener: () => void;

   // Multiview
   views: Array<any>;
   viewsTipoFrete: Array<any>;
   viewsVeiculos: Array<any>;
   porPagina: number;
   pages = 0;
   pagesTipoFrete = 0;
   pagesVeiculos = 0;
   // fim Multiview

   // datasources
   datasourceMaster = {
      grafico: {
         fatMes: { dados: [] },
         pesoMes: { dados: [] },
         docMes: { dados: [] },
         fatCarroceria: { dados: [] },
         fatCliente: { dados: [] },
         fatGrupoProduto: { dados: [] },
         fatModalidade: { dados: [] },
         freteMes: { titulo: [], dados: [] }
      },
      indicador: {
         faturamento: 0,
         documento: 0,
         peso: 0,
         emitido: 0,
         cancelado: 0,
         mediaFaturamento: 0,
         mediaCarroceria: 0
      },
      listaIndicador: {
         listaProduto: { dados: [] },
         listaCarroceria: { dados: [] },
         listaTipoFrete: { dados: [] },
      },
      lista: {
         motorista: { dados: [] },
         placa: { dados: [] },
      }
   };
   // -- fim datasources

   chartTonFat = 1;
   showChartDoc = false;
   showChartVeiculos = false;
   showChartFrete = false;
   chartTipoFreteStack = true;
   data: any;

   filtroContent = {
      cliente: [],
      segmento: [],
      placa: [],
      mercadoria: []
   };


   // Config Socket
   socketIo: any;
   socketRota = 'base';
   socketMetodo = 'getBase';
   socketMetodoFiltro = 'getFiltro';
   socketFiltro: any;
   /***/

   origemFeed = false;
   today = moment();
   constructor(
      iconRegistry: MatIconRegistry,
      sanitizer: DomSanitizer,
      private notificacoes: NotificacaoService,
      changeDetectorRef: ChangeDetectorRef,
      media: MediaMatcher,
      private route: ActivatedRoute,
      public feedData: FeedDataService
   ) {
      this.mobileQuery = media.matchMedia('(max-width: 600px)');
      this._mobileQueryListener = () => changeDetectorRef.detectChanges();
      // tslint:disable-next-line: deprecation
      this.mobileQuery.addListener(this._mobileQueryListener);
      iconRegistry.addSvgIcon('ton', sanitizer.bypassSecurityTrustResourceUrl('assets/images/extrato/ton.svg'));
      iconRegistry.addSvgIcon('truck-c', sanitizer.bypassSecurityTrustResourceUrl('assets/images/extrato/truck.svg'));

      this.socketIo = io(environment.socket_end_point_base + '/' + this.socketRota);
      this.socketFiltro = {
         base: this.user.ref.toLowerCase(),
         usuario: this.user.usuario
      };
      this.socket().then(() => { });
   }

   ngOnInit() {
   }
   ngOnDestroy(): void {
      this.socketIo.disconnect();
      // tslint:disable-next-line: deprecation
      this.mobileQuery.removeListener(this._mobileQueryListener);
   }

   async socket() {
      try {
         this.loadVisible = true;
         this.socketIo.emit(this.socketMetodo, this.socketFiltro);
         this.socketIo.emit(this.socketMetodoFiltro, this.socketFiltro);
         this.socketIo.on(this.socketRota, (data) => {
            if (data) {
               console.log('filtrando', this.socketFiltro);
               console.log('retorno data', data);
               if (data.grafico) {
                  if (data.grafico.fatModalidade) {
                     data.grafico.fatModalidade.dados.reverse();
                  }
               }

               if (data.listaIndicador) {
                  if (data.listaIndicador.listaProduto) {
                     this.multiViewGrupos(data.listaIndicador.listaProduto.dados.reverse(), 6);
                  }
                  if (data.listaIndicador.listaCarroceria) {
                     this.multiviewVeiculo(data.listaIndicador.listaCarroceria.dados.reverse(), 3);
                  }
               }

               if (data.grafico) {
                  if (data.grafico.tabelaFrete) {
                     if (data.grafico.tabelaFrete.dados.length > 0) {
                        data.grafico.tabelaFrete.dados = data.grafico.tabelaFrete.dados.filter(e => {
                           return e.valor > 0;
                        });
                     }
                  }
               }
               this.datasourceMaster = data;
               this.loadVisible = false;

            } else {
               this.notificacoes.openSnackBar('Nenhum registro encontrado.');
            }
         });

         this.socketIo.on('filtro', (dataFiltro) => {
            console.log('dataFiltro', dataFiltro);
            this.filtroContent = dataFiltro;
         });
      } catch (error) {
         // this.loadVisible = false;
         console.log('error => ', error);
      }
   }

   respostaFiltro(e: any) {
      if (e.filtro) {
         Object.assign(this.socketFiltro, e.filtro);

         if (this.socketFiltro.data_inicial) {
            this.socketFiltro.data_inicial = moment(this.socketFiltro.data_inicial).utc().format();
         }

         if (this.socketFiltro.data_final) {
            this.socketFiltro.data_final = moment(this.socketFiltro.data_final).utc().format();
         }
         console.log('enviando filtro: (resposta)', this.socketFiltro);
         this.loadVisible = true;
         this.socketIo.emit(this.socketMetodo, this.socketFiltro);
      }
   }

   group(dados: any, by: string, arg: string) {
      const grouped = _(dados)
         .groupBy(by)
         .map((list, id) => ({
            indicador: id,
            total: _.sumBy(list, arg),
         }))
         .sortBy(arg)
         .value();

      return grouped;
   }

   customizeLabelProd(point) {
      return (point.percent * 100).toFixed() + ' %';
   }

   customizeLegTopN(arg) {
      if (arg.pointName === 'others') {
         return 'Outros';
      } else {
         return arg.pointName;
      }

   }

   reset() {
      this.datasourceMaster = {
         grafico: {
            fatMes: { dados: [] },
            pesoMes: { dados: [] },
            docMes: { dados: [] },
            fatCarroceria: { dados: [] },
            fatCliente: { dados: [] },
            fatGrupoProduto: { dados: [] },
            fatModalidade: { dados: [] },
            freteMes: { titulo: [], dados: [] }
         },
         indicador: {
            faturamento: 0,
            documento: 0,
            peso: 0,
            emitido: 0,
            cancelado: 0,
            mediaFaturamento: 0,
            mediaCarroceria: 0
         },
         listaIndicador: {
            listaProduto: { dados: [] },
            listaCarroceria: { dados: [] },
            listaTipoFrete: { dados: [] },
         },
         lista: {
            motorista: { dados: [] },
            placa: { dados: [] },
         }
      };
   }

   getImg(ref) {
      let path = '';
      switch (ref) {
         case 'CAMINHAO 4X2':
            path = 'assets/images/extrato/truck6x2.png';
            break;
         case 'CAMINHAO 6X2':
         case 'CAMINHAO 6X4':
            path = 'assets/images/extrato/truck6x2.png';
            break;

         case 'CAMINHAO TRUCK':
            path = 'assets/images/extrato/truck-truck.png';
            break;
         case 'UTILITARIO':
            path = 'assets/images/extrato/truck6x2.png';
            break;

         default:
            path = 'assets/images/extrato/truck6x2.png';
            break;
      }

      return path;
   }

   multiviewVeiculo(lista, porPagina) {
      lista = lista.reverse();
      this.viewsVeiculos = [];
      this.pagesVeiculos = Math.ceil(lista.length / porPagina);
      for (let index = 0; index < this.pagesVeiculos; index++) {
         this.viewsVeiculos.push(this.paginate(lista, porPagina, index + 1));
      }

   }
   multiViewGrupos(lista, porPagina) {
      lista = lista.reverse();
      this.views = [];
      this.pages = Math.ceil(lista.length / porPagina);
      for (let index = 0; index < this.pages; index++) {
         this.views.push(this.paginate(lista, porPagina, index + 1));
      }

   }

   paginate(array, pageSize, pageNumber) {
      --pageNumber;
      return array.slice(pageNumber * pageSize, (pageNumber + 1) * pageSize);
   }

   trocaView(direction: string, context: any) {
      let mv = null;
      switch (context) {
         case 'multiviewTipoFrete':
            mv = this.multiviewTipoFrete;
            break;
         case 'multiviewGrupoProduto':
            mv = this.multiview;
            break;
         case 'multiviewVeiculos':
            mv = this.multiviewVeiculos;
            break;

      }

      if (mv) {
         if (mv.selectedIndex === this.pages - 1) {
            mv.selectedIndex = 0;
         } else {
            if (direction === 'next') {
               mv.selectedIndex = mv.selectedIndex + 1;
            } else {
               mv.selectedIndex = mv.selectedIndex - 1;
            }
         }
      }
   }



}
