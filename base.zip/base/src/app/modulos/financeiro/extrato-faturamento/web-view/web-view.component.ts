import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { DxMultiViewComponent } from 'devextreme-angular';
import { CommonService } from '../common.service';
import { Usuario } from 'src/app/shared/models/usuario.model';


@Component({
   selector: 'app-web-view',
   templateUrl: './web-view.component.html',
   styleUrls: ['./web-view.component.scss']
})
export class WebViewComponent implements OnInit {
   public user: Usuario = Usuario.instance;
   @ViewChild('multiview') multiview: DxMultiViewComponent;
   @ViewChild('multiviewVeiculos') multiviewVeiculos: DxMultiViewComponent;
   chartTonFat = 1;
   showChartDoc = false;
   showChartVeiculos = false;
   showChartFrete = false;
   chartTipoFreteStack = true;


   // Multiview
   views: Array<any>;
   viewsTipoFrete: Array<any>;
   viewsVeiculos: Array<any>;
   porPagina: number;
   pages = 0;
   pagesTipoFrete = 0;
   pagesVeiculos = 0;
   // fim Multiview

   paletaCustom = [
      '#F17100',
      '#00B5AD',
      '#146E9C',
      '#6435C9',
      '#7CA5CF',
   ];

   datasourceCondicional = [];
   profileEspecial = false;
   constructor(
      public common: CommonService,
   ) {
      if (this.user.ref === 'levolog' || this.user.ref === 'movc') {
         this.profileEspecial = true;
      }
   }

   datasourceMaster: any;
   get value(): any {
      return this.datasourceMaster;
   }

   @Input('datasourceMaster')
   set value(val: any) {
      this.datasourceMaster = val;
      if (this.datasourceMaster.exibir && this.datasourceMaster.exibir.length > 0) {
         this.common.exibir = [... this.datasourceMaster.exibir];
      } else {
         this.common.exibir = this.common.exibirDefault;
      }

      if (this.datasourceMaster.listaIndicador) {
         if (this.datasourceMaster.listaIndicador.listaProduto.dados.length > 0) {
            this.multiViewGrupos(this.datasourceMaster.listaIndicador.listaProduto.dados.reverse(), 20);
         }

         if (this.profileEspecial) {
            if (this.datasourceMaster.listaIndicador.listaCarroceriaControleCarreta.dados.length > 0) {
               this.multiviewVeiculo(this.datasourceMaster.listaIndicador.listaCarroceriaControleCarreta.dados.reverse(), 4);
            }
         } else {
            if (this.datasourceMaster.listaIndicador.listaCarroceria.dados.length > 0) {
               this.multiviewVeiculo(this.datasourceMaster.listaIndicador.listaCarroceria.dados.reverse(), 4);
            }
         }
      }

      if (this.datasourceMaster.grafico) {
         if (this.profileEspecial) {
            this.datasourceCondicional = this.datasourceMaster.grafico.tabelaFrete.dados;
         } else {
            this.datasourceCondicional = this.datasourceMaster.grafico.fatCliente.dados;
         }
      }
   }

   ngOnInit() { }

   public onCellPreparedTops(e: any) {
      if (e.rowType === 'header') {
         e.cellElement.style.paddingTop = '5px';
         e.cellElement.style.paddingBottom = '5px';
         e.cellElement.style.fontSize = '1rem';
      }

      if (typeof (e.data) !== 'undefined') {
         e.cellElement.style.paddingTop = '8px';
         e.cellElement.style.paddingBottom = '8px';
      }
   }

   public customizeLabelProd(point) {
      return (point.percent * 100).toFixed() + ' %';
   }

   public customizeLegTopN(arg) {
      if (arg.pointName === 'others') {
         return 'Outros';
      } else {
         return arg.pointName;
      }
   }

   public customizePointMultiple = (arg: any) => {

      // const palette = getPalette('Material');
      // const index = arg.index % (palette.simpleSet.length - 1);
      // return { color: palette.simpleSet[index] };
      return { color: this.paletaCustom[arg.index] };
   }

   multiviewVeiculo(lista, porPagina) {
      lista = lista.reverse();
      this.viewsVeiculos = [];
      this.pagesVeiculos = Math.ceil(lista.length / porPagina);
      for (let index = 0; index < this.pagesVeiculos; index++) {
         this.viewsVeiculos.push(this.common.paginate(lista, porPagina, index + 1));
      }
   }
   multiViewGrupos(lista, porPagina) {
      lista = lista.reverse();
      this.views = [];
      this.pages = Math.ceil(lista.length / porPagina);
      for (let index = 0; index < this.pages; index++) {
         this.views.push(this.common.paginate(lista, porPagina, index + 1));
      }
   }

   multiViewTipoFrete(lista, porPagina) {
      lista = lista.reverse();
      this.viewsTipoFrete = [];
      this.pagesTipoFrete = Math.ceil(lista.length / porPagina);
      for (let index = 0; index < this.pagesTipoFrete; index++) {
         this.viewsTipoFrete.push(this.common.paginate(lista, porPagina, index + 1));
      }
   }

   paginate(array, pageSize, pageNumber) {
      --pageNumber;
      return array.slice(pageNumber * pageSize, (pageNumber + 1) * pageSize);
   }

   trocaView(direction: string, context: any) {
      let mv = null;
      let pg = 0;
      switch (context) {
         case 'multiviewGrupoProduto':
            mv = this.multiview;
            pg = this.pages;
            break;
         case 'multiviewVeiculos':
            mv = this.multiviewVeiculos;
            pg = this.pagesVeiculos;
            break;
      }

      if (mv) {
         if (mv.selectedIndex === pg - 1) {
            mv.selectedIndex = 0;
         } else {
            if (direction === 'next') {
               mv.selectedIndex = mv.selectedIndex + 1;
            } else {
               mv.selectedIndex = mv.selectedIndex - 1;
            }
         }
      }
   }


   customizeTooltip = (info: any) => {
      // console.log('--->', info);
      return {
         html: '<div class=\'tooltip-box\'><div class=\'tooltip-header\'>' +
            info.argumentText + '</div>' +
            '<div class=\'tooltip-body\'><div class=\'series-name\'>' +
            info.seriesName +
            ': </div><div class=\'value-text\'>' +
            info.totalText +
            '</div></div></div></div>'
      };
   }
   customizeTooltip2 = (info: any) => {
      // console.log('--->', info);
      return {
         html: '<div class=\'tooltip-box\'><div class=\'tooltip-header\'>' +
            info.argumentText + '</div>' +
            '<div class=\'tooltip-body\'><div class=\'series-name\'>' +
            info.seriesName +
            ': </div><div class=\'value-text\'>' +
            info.value + ' ( ' + info.percentText + ' )' +
            '</div></div></div></div>'
      };
   }
   customizeTooltip3 = (info: any) => {
      return {
         html: '<div>' + info.valueText + '</div>'
      };
   }

   respostaFiltroSpline(e) {
      console.log('chegando filtro spline:', e);

   }


}



