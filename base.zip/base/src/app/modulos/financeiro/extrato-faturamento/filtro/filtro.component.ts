import { Component, OnInit, Input, Output, EventEmitter, ViewChild, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { FormGroup, FormControl, FormBuilder } from '@angular/forms';
import * as moment from 'moment';
import { DxoPopupComponent } from 'devextreme-angular/ui/nested';
import { MediaMatcher } from '@angular/cdk/layout';
import { CommonService } from '../common.service';


@Component({
   selector: 'app-filtro',
   templateUrl: './filtro.component.html',
   styleUrls: ['./filtro.component.scss']
})
export class FiltroComponent implements OnInit, OnDestroy {
   @Input() dados: any;
   @Output() filterChange: EventEmitter<any> = new EventEmitter();
   @ViewChild('popFilter') popFilter: DxoPopupComponent;
   public filtroForm: FormGroup;
   popupVisible = false;
   startDateDe = moment().startOf('month').utc().format();
   startDateAte = moment().endOf('month').utc().format();
   public listaPeriodos;

   mobileQuery: MediaQueryList;
   // tslint:disable-next-line: variable-name
   private _mobileQueryListener: () => void;
   today = moment();
   constructor(
      private formBuilder: FormBuilder,
      changeDetectorRef: ChangeDetectorRef,
      media: MediaMatcher,
      public commonService: CommonService

   ) {
      this.mobileQuery = media.matchMedia('(max-width: 600px)');
      this._mobileQueryListener = () => changeDetectorRef.detectChanges();
      // tslint:disable-next-line: deprecation
      this.mobileQuery.addListener(this._mobileQueryListener);

      if (this.mobileQuery.matches) {
         this.listaPeriodos = [
            { id: 0, label: 'Hoje', amount: 0, unit: 'day' },
            { id: 1, label: '7D', amount: 7, unit: 'day' },
            { id: 2, label: '15D', amount: 15, unit: 'day' },
            { id: 3, label: '1M', amount: 1, unit: 'month' },
            { id: 5, label: '6M', amount: 6, unit: 'month' },
            { id: 7, label: '12M', amount: 1, unit: 'year' }
         ];

      } else {
         this.listaPeriodos = [
            { id: 0, label: 'Hoje', amount: 0, unit: 'day' },
            { id: 1, label: '7 dias', amount: 7, unit: 'day' },
            { id: 2, label: '15 dias', amount: 15, unit: 'day' },
            { id: 3, label: '1 mês', amount: 1, unit: 'month' },
            { id: 4, label: '3 meses', amount: 3, unit: 'month' },
            { id: 5, label: '6 meses', amount: 6, unit: 'month' },
            { id: 6, label: '9 meses', amount: 9, unit: 'month' },
            { id: 7, label: '12 meses', amount: 1, unit: 'year' }
         ];
      }
   }

   ngOnInit() {
      this._buildForm();
   }

   ngOnDestroy(): void {
      // tslint:disable-next-line: deprecation
      this.mobileQuery.removeListener(this._mobileQueryListener);
   }


   private _buildForm() {
      this.filtroForm = this.formBuilder.group({
         data_inicial: null,
         data_final: null,
         // cliente_id: new FormControl({ value: null, disabled: false }),
         // segmento_id: new FormControl({ value: null, disabled: false }),
         // placa_id: new FormControl({ value: null, disabled: false }),
         // mercadoria_id: new FormControl({ value: null, disabled: false }),
         cod_pessoa_filial: new FormControl({ value: null, disabled: false }),
         operacao: new FormControl({ value: null, disabled: false }),
         tabela_frete: new FormControl({ value: null, disabled: false })
      });
   }

   filtrar() {
      this.filterChange.emit({ filtro: this.filtroForm.value });
      this.commonService.activeFilter = this.filtroForm.value;
      this.popFilter.instance.hide();
   }

   limparFiltros(event: Event): void {
      event.preventDefault();
      this.filtroForm.reset();
      this.filterChange.emit({ filtro: this.filtroForm.value });
   }

   private _setPeriodo(data) {
      this.filtroForm.get('data_inicial').setValue(data);
      const date = moment().format('YYYY-MM-DDTHH:mm:ssZ');
      this.filtroForm.get('data_final').setValue(date);
      this.filtrar();
   }

   selecionarPeriodo(periodo) {
      moment.locale('pt-br');
      const data = moment()
         .subtract(periodo.amount, periodo.unit)
         .format('YYYY-MM-DDTHH:mm:ssZ');
      this._setPeriodo(data);
   }

   close() {
      if (this.popFilter) {
         this.popFilter.instance.hide();
      }
   }

}
