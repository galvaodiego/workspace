import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

import { SharedModule } from 'src/app/shared/shared.module';

import { ExtratoFaturamentoComponent } from './extrato-faturamento.component';
import { FiltroComponent } from './filtro/filtro.component';
import { MobileViewComponent } from './mobile-view/mobile-view.component';
import { WebViewComponent } from './web-view/web-view.component';
import { DonutComponent } from './componentes/donut/donut.component';
import { DataGridTopsComponent } from './componentes/data-grid-tops/data-grid-tops.component';
import { BarChartComponent } from './componentes/bar-chart/bar-chart.component';
import { MultiViewComponent } from './componentes/multi-view/multi-view.component';
import { KpiMobileComponent } from './componentes/kpi-mobile/kpi-mobile.component';
import { BarChartDualComponent } from './componentes/bar-chart-dual/bar-chart-dual.component';
import { BarChartScComponent } from './componentes/bar-chart-sc/bar-chart-sc.component';
import { SplineChartDualComponent } from './componentes/spline-chart-dual/spline-chart-dual.component';
import { DxDateBoxModule } from 'devextreme-angular';


@NgModule({
   // tslint:disable-next-line: max-line-length
   declarations: [
      ExtratoFaturamentoComponent,
      FiltroComponent,
      MobileViewComponent,
      WebViewComponent,
      DonutComponent,
      DataGridTopsComponent,
      BarChartComponent,
      MultiViewComponent,
      KpiMobileComponent,
      BarChartDualComponent,
      BarChartScComponent,
      SplineChartDualComponent
   ],
   imports: [
      CommonModule,
      SharedModule,
      FormsModule,
      ReactiveFormsModule,
   ]
})
export class ExtratoFaturamentoModule { }
