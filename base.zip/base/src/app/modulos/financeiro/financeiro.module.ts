import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

import { SharedModule } from 'src/app/shared/shared.module';
import { FinanceiroRoutingModule } from './financeiro-routing.module';
import { ExtratoFaturamentoModule } from './extrato-faturamento/extrato-faturamento.module';

// componentes
import { FaturamentoComponent } from './faturamento/faturamento.component';

import { FaturamentoCustomComponent } from './faturamento-custom/faturamento-custom.component';

import { FaturamentoRotaComponent } from './detalhes/faturamento-rota/faturamento-rota.component';
import { KpiListComponent } from './detalhes/faturamento-rota/componentes/kpi-list/kpi-list.component';
import { EvoluRotasComponent } from './detalhes/faturamento-rota/componentes/evolu-rotas/evolu-rotas.component';



@NgModule({
   // tslint:disable-next-line: max-line-length
   declarations: [
      FaturamentoComponent,
      FaturamentoCustomComponent,
      FaturamentoRotaComponent,
      KpiListComponent,
      EvoluRotasComponent,
   ],
   imports: [
      CommonModule,
      SharedModule,
      FormsModule,
      ReactiveFormsModule,
      FinanceiroRoutingModule,
      ExtratoFaturamentoModule
   ]
})
export class FinanceiroModule { }
