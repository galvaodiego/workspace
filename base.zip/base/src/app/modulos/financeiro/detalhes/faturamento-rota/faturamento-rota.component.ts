import { Component, OnInit, OnDestroy } from '@angular/core';
import { FaturamentoRotaService, DataSource } from './faturamento-rota.service';
import { FeedDataService } from 'src/app/modulos/home/feed/feed-data.service';
import io from 'socket.io-client';
import { environment } from 'src/environments/environment';
import { Usuario } from 'src/app/shared/models/usuario.model';
import { Router } from '@angular/router';

@Component({
  templateUrl: './faturamento-rota.component.html',
  styleUrls: ['./faturamento-rota.component.scss']
})
export class FaturamentoRotaComponent implements OnInit, OnDestroy {
  public user: Usuario = Usuario.instance;
  datasourceMaster: DataSource;
  loadVisible = false;
  // Config Socket
  socketIo: any;
  socketFiltro: any;
  /***/
  constructor(
    private faturamentoRotaService: FaturamentoRotaService,
    private feedDataService: FeedDataService,
    private router: Router,
  ) {
    this.socketIo = io(environment.socket_end_point_base + '/faturamento-rotas');
    const fatuRotaDataCard = JSON.parse(localStorage.getItem('fatu-rota-data-card'));
    if (this.feedDataService.dataCard) {
      this.socketFiltro = this.feedDataService.dataCard.filtro;
    } else if (fatuRotaDataCard) {
      this.socketFiltro = fatuRotaDataCard.filtro;
    } else {
      console.log('Nenhum card identificado, redirecionando para home');
      this.goHome();
    }



  }
  ngOnDestroy(): void {
    this.socketIo.disconnect();
  }

  ngOnInit() {
    // this.datasourceMaster = this.faturamentoRotaService.datasource;
    console.log('dataCard', this.feedDataService.dataCard);
    console.log('socketFiltro', this.socketFiltro);
    this.socket().then(() => { });
  }

  goHome() {
    this.loadVisible = true;
    this.router.navigate(['']);
  }

  async socket() {
    try {
      this.loadVisible = true;
      this.socketIo.emit('getFatRotas', this.socketFiltro);
      this.socketIo.on('getFatRotas', (data) => {
        console.log('filtro', this.socketFiltro);
        console.log('data', data);
        this.datasourceMaster = data;
        this.loadVisible = false;
      });
    } catch (error) {
      this.loadVisible = false;
      console.log('error => ', error);
    }
  }

}
