import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EvoluRotasComponent } from './evolu-rotas.component';

describe('EvoluRotasComponent', () => {
  let component: EvoluRotasComponent;
  let fixture: ComponentFixture<EvoluRotasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EvoluRotasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EvoluRotasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
