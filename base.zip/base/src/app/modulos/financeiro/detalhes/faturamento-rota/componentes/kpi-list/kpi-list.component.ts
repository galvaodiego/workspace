import { Component, OnInit, Input } from '@angular/core';
import { element } from 'protractor';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'det-kpi-list',
  templateUrl: './kpi-list.component.html',
  styleUrls: ['./kpi-list.component.scss']
})
export class KpiListComponent implements OnInit {
  graficoKPI = false;

  dsChartKPI = [];
  @Input() datasource;
  @Input() grafico;

  constructor() { }

  ngOnInit() {
  }

  toggle(elemento: number, e) {

    switch (elemento) {
      case 1:
        this.graficoKPI = e.checked;
        break;
      case 2:

        break;

      default:
        console.log('Elemento não rastreado', elemento);

        break;
    }


  }

  getClass(tipo) {
    let classe = '';
    switch (tipo) {
      case 1:
        classe = 'peso';
        break;
      case 2:
        classe = 'cancelados';
        break;
      case 3:
        classe = 'viagens';
        break;
      case 4:
        classe = 'veiculos';
        break;

      default:
        classe = 'indefinida';
        break;
    }

    return classe;
  }

}
