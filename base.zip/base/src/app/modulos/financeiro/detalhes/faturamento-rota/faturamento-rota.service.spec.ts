import { TestBed } from '@angular/core/testing';

import { FaturamentoRotaService } from './faturamento-rota.service';

describe('FaturamentoRotaService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: FaturamentoRotaService = TestBed.get(FaturamentoRotaService);
    expect(service).toBeTruthy();
  });
});
