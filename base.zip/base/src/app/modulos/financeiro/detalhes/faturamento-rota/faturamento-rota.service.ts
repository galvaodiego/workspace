import { Injectable } from '@angular/core';


export interface DataSource {
  descricao: string;
  graficos: any;
  indicadores: any;
  listas: any;
  periodo_final: string;
  periodo_inicial: string;
  titulo: string;
  valor: string;
}

@Injectable({
  providedIn: 'root'
})
export class FaturamentoRotaService {
  datasource = {
    titulo: 'Garuva x Guarulhos',
    valor: 'R$ 49.754,00',
    descricao: 'A rota mostrou uma queda de 26% no período abaixo',
    periodo_inicial: '2020-04-22',
    periodo_final: '2020-04-22',
    indicadores: [
      {
        titulo: 'Peso',
        valor: 260000,
        descricao: '71100 KG a menos',
        tipo: 1
      },
      {
        titulo: 'Doc. Cancelados',
        valor: 10,
        descricao: '3 a mais',
        tipo: 2
      },
      {
        titulo: 'Nº Viagens',
        valor: 160,
        descricao: '20 viagens a menos',
        tipo: 3
      },
      {
        titulo: 'Veículos',
        valor: 100,
        descricao: '20 veículos a menos',
        tipo: 4
      },
    ],
    listas: {
      evolucaoRotas: [
        {
          rota: 'São Paulo x Curitiba',
          valor: 450.00,
          alteracao: '+ 3,23%',
          classe: 'positivo',
          grafico: [
            {
              chave: 'jan',
              valor: 100
            },
            {
              chave: 'fev',
              valor: 50
            },
            {
              chave: 'mar',
              valor: 100
            },
            {
              chave: 'abr',
              valor: 50
            },
            {
              chave: 'mai',
              valor: 100
            },
          ]
        },
        {
          rota: 'São Paulo x Rio de Janeiro',
          valor: 550.00,
          alteracao: '- 2,50%',
          classe: 'negativo',
          grafico: [
            {
              chave: 'jan',
              valor: 200
            },
            {
              chave: 'fev',
              valor: 50
            },
            {
              chave: 'mar',
              valor: 100
            },
            {
              chave: 'abr',
              valor: 350
            },
            {
              chave: 'mai',
              valor: 1000
            },
          ]
        },
      ]
    },
    graficos: {
      geral: [
        {
          chave: 'jan',
          valor: 100
        },
        {
          chave: 'fev',
          valor: 150
        },
        {
          chave: 'mar',
          valor: 200
        },
        {
          chave: 'abr',
          valor: 150
        },
        {
          chave: 'mai',
          valor: 500
        },
        {
          chave: 'jun',
          valor: 100
        },
      ],
      rotasTop: {
        sumario: [
          {
            value: 'rota1',
            name: 'São Paulo x Curitiba'
          },
          {
            value: 'rota2',
            name: 'São Paulo x Rio de Janeiro'
          }
        ],
        dados: [
          {
            chave: 'jan',
            rota1: 100,
            rota2: 200
          },
          {
            chave: 'fev',
            rota1: 150,
            rota2: 20
          },
          {
            chave: 'mar',
            rota1: 1000,
            rota2: 2000
          },
          {
            chave: 'abr',
            rota1: 300,
            rota2: 250
          },
        ]
      }
    }
  };
  constructor() { }
}
