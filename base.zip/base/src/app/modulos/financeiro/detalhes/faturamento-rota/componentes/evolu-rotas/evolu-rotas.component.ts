import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { DxChartComponent } from 'devextreme-angular';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'det-evolu-rotas',
  templateUrl: './evolu-rotas.component.html',
  styleUrls: ['./evolu-rotas.component.scss']
})
export class EvoluRotasComponent implements OnInit {
  @ViewChild('chartRow') chartRow: DxChartComponent;
  @Input() datasource;
  @Input() grafico;
  @Input() de;
  @Input() ate;

  graficoRotas = false;
  constructor() { }

  ngOnInit() {
  }

  toggle(elemento: number, e) {

    switch (elemento) {

      case 2:
        this.graficoRotas = e.checked;
        break;

      default:
        console.log('Elemento não rastreado', elemento);

        break;
    }


  }


}
