import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FaturamentoRotaComponent } from './faturamento-rota.component';

describe('FaturamentoRotaComponent', () => {
  let component: FaturamentoRotaComponent;
  let fixture: ComponentFixture<FaturamentoRotaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FaturamentoRotaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FaturamentoRotaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
