import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GuardaRotas } from 'src/app/shared/guards/guarda-rotas.guard';

import { MapaAbastComponent } from './novo-mapa-abast/mapa-abast/mapa-abast.component';


const routes: Routes = [
   { path: '', redirectTo: 'mapa-abastecimento', pathMatch: 'full' },
   {
      path: 'mapa-abastecimento',
      component: MapaAbastComponent,
      canActivate: [GuardaRotas],
      data: {
         modulo: 'mapa-abastecimento'
      }
   },

];

@NgModule({
   imports: [RouterModule.forChild(routes)],
   exports: [RouterModule]
})
export class SuprimentosRoutingModule { }
