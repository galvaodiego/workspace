import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SuprimentosRoutingModule } from './suprimentos-routing.module';
import { SharedModule } from 'src/app/shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NovoMapaAbastModule } from './novo-mapa-abast/novo-mapa-abast.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    NovoMapaAbastModule,
    SuprimentosRoutingModule
  ]
})
export class SuprimentosModule { }
