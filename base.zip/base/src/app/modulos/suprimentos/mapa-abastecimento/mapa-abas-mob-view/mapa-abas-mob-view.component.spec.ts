import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MapaAbasMobViewComponent } from './mapa-abas-mob-view.component';

describe('MapaAbasMobViewComponent', () => {
  let component: MapaAbasMobViewComponent;
  let fixture: ComponentFixture<MapaAbasMobViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MapaAbasMobViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MapaAbasMobViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
