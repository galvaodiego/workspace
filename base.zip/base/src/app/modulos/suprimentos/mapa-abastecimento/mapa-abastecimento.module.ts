import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from 'src/app/shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MapaAbastecimentoComponent } from './mapa-abastecimento.component';
import { FiltroComponent } from './filtro/filtro.component';
import { MapaAbasMobViewComponent } from './mapa-abas-mob-view/mapa-abas-mob-view.component';
import { MapaAbasWebViewComponent } from './mapa-abas-web-view/mapa-abas-web-view.component';
import { MapaComponent } from './componentes/mapa/mapa.component';



@NgModule({
  declarations: [
      MapaAbastecimentoComponent,
      FiltroComponent,
      MapaAbasMobViewComponent,
      MapaAbasWebViewComponent,
      MapaComponent
    ],
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
  ]
})
export class MapaAbastecimentoModule { }
