import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MapaAbasWebViewComponent } from './mapa-abas-web-view.component';

describe('MapaAbasWebViewComponent', () => {
  let component: MapaAbasWebViewComponent;
  let fixture: ComponentFixture<MapaAbasWebViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MapaAbasWebViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MapaAbasWebViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
