import { Injectable } from '@angular/core';
import { getPalette } from 'devextreme/viz/palette';
import * as moment from 'moment';


@Injectable({
   providedIn: 'root'
})
export class MapaAbastecimentoService {
   mapProvider = 'bing';
   nivel = {
      min1: 100,
      min2: 0.3,
      max1: 4000,
      max2: 4
   };
   markers: any = [
      {
         location: [-29.422, -49.873],
         iconSrc: 'assets/images/mapa-abastecimento/marker-red.png',
         tooltip: {
            isShown: false,
            text: 'AXN-5333'
         }
      },
      {
         location: [-23.514, -46.667],
         iconSrc: 'assets/images/mapa-abastecimento/marker-orange.png',
         tooltip: {
            isShown: false,
            text: 'AMB-3205'
         }
      },
      {
         location: [-26.249, -48.843],
         iconSrc: 'assets/images/mapa-abastecimento/marker-pink.png',

         tooltip: {
            isShown: false,
            text: 'AXN-5051'
         }
      },
      {
         location: [-23.896, -46.302],
         iconSrc: 'assets/images/mapa-abastecimento/marker-yellow.png',

         tooltip: {
            isShown: false,
            text: 'AXN-8J09'
         }
      },
      {
         location: [-23.757, -46.454],
         iconSrc: 'assets/images/mapa-abastecimento/marker-green.png',

         tooltip: {
            isShown: false,
            text: 'AXN-8G00'
         }
      },
   ];

   flag = {
      chart1: true,
      chart2: true,
      chart3: false,
      chart4: false,
      chart5: true
   };

   media = [{
      name: 'percentage',
      position: 'right',
      showZero: true,
      constantLines: [{
         value: 80,
         color: '#fc3535',
         dashStyle: 'dash',
         width: 2,
         label: { visible: false }
      }],
      tickInterval: 20,
      valueMarginsEnabled: false
   }];


   datasourceMaster: {
      'lista': {
         'abast_total_posto': {
            'dados': []
         },
         'acomp_valor_produto': {
            'dados': []
         },
         'qtde_posto_estado': {
            'dados': []
         },
         'arla_combustivel': {
            'dados': []
         },
         'combustivel_fat': {
            'dados': []
         }
      },
      'grafico': {
         'abast_total_posto': {
            'dados': []
         },
         'acomp_valor_produto': {
            'dados': []
         },
         'qtde_posto_estado': {
            'dados': []
         },
         'arla_combustivel': {
            'dados': []
         },
         'combustivel_fat': {
            'dados': []
         }
      },
      'indicador': {
         'media_disel': 0,
         'qtde_abastecimentos': 0,
         'qtde_postos': 0,
         'qtde_arla': 0,
         'combustivel_fat': 0
      },
      'mapa': {
         'distribuicao_volume': {
            'dados': []
         },
         'distribuicao_valor_uni': {
            'dados': []
         }
      }
   };
   filroAtivoMapa1 = false;
   activeFilter: ActiveFilter;
   today = moment();

   constructor() { }


   getImg(chart) {
      let path = '';
      if (chart) {
         path = 'assets/images/mapa-abastecimento/to-table-view.png';
      } else {
         path = 'assets/images/mapa-abastecimento/to-chart-view.png';
      }

      return path;
   }

   public customizePointMultiple = (arg: any) => {
      const tipo = 'Soft';

      const palette = getPalette(tipo);
      const index = arg.index % (palette.simpleSet.length - 1);
      return { color: palette.simpleSet[index] };
   }
}

export interface ActiveFilter {
   base: string;
   data_inicial: string;
   data_final: string;
   posto_id: number;
   placa_id: Array<any>;
   estado: Array<any>;
}
