import { Component, OnInit, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { Usuario } from 'src/app/shared/models/usuario.model';
import { MediaMatcher } from '@angular/cdk/layout';
import io from 'socket.io-client';
import { environment } from 'src/environments/environment';
import { NotificacaoService } from 'src/app/shared/services/notificacao.service';
import { MapaAbastecimentoService } from './mapa-abastecimento.service';
import * as moment from 'moment';
import { throwError } from 'rxjs';


@Component({
   selector: 'app-mapa-abastecimento',
   templateUrl: './mapa-abastecimento.component.html',
   styleUrls: ['./mapa-abastecimento.component.scss']
})
export class MapaAbastecimentoComponent implements OnInit, OnDestroy {
   public user: Usuario = Usuario.instance;
   loadVisible = true;
   mobileQuery: MediaQueryList;
   // tslint:disable-next-line: variable-name
   private _mobileQueryListener: () => void;

   datasourceMaster: any;

   // Config Socket
   socketIo: any;
   socketRota = 'abastecimento';
   socketMetodo = 'getAbastecimento';
   socketMetodoFiltro = 'getFiltro';
   socketFiltro: any;
   /***/
   filtroContent = {
      placa: [],
      estado: []
   };

   markersVolume = [];
   markersValor = [];


   constructor(
      media: MediaMatcher,
      changeDetectorRef: ChangeDetectorRef,
      private notificacoes: NotificacaoService,
      public mabService: MapaAbastecimentoService

   ) {
      this.mobileQuery = media.matchMedia('(max-width: 600px)');
      this._mobileQueryListener = () => changeDetectorRef.detectChanges();
      // tslint:disable-next-line: deprecation
      this.mobileQuery.addListener(this._mobileQueryListener);
      this.socketIo = io(environment.socket_end_point + '/' + this.socketRota);
      this.socketFiltro = {
         base: this.user.ref.toLowerCase(),
         usuario: this.user.usuario
      };
      this.datasourceMaster = mabService.datasourceMaster;
      this.socket().then(() => { });
   }

   ngOnInit() {
   }

   ngOnDestroy(): void {
      this.socketIo.disconnect();
      // tslint:disable-next-line: deprecation
      this.mobileQuery.removeListener(this._mobileQueryListener);
   }

   async socket() {
      // this.route.data.subscribe(v => {
      //    if (this.feedData.dataCard) {
      //       if (v.tipo && v.tipo === 'card' && this.feedData.dataCard.filtro) {
      //          this.origemFeed = true;
      //          this.socketFiltro = this.feedData.dataCard.filtro;
      //       } else {
      //          this.origemFeed = false;
      //       }
      //    }
      // });

      try {
         this.loadVisible = true;
         this.socketIo.emit(this.socketMetodo, this.socketFiltro);
         this.socketIo.emit(this.socketMetodoFiltro, this.socketFiltro);
         this.mabService.activeFilter = this.socketFiltro;
         this.socketIo.on(this.socketRota, (data) => {
            if (data) {
               console.log('filtro -->', this.socketFiltro);
               console.log('data -->', (data));
               if (data.grafico) {

               }
               this.datasourceMaster = data;

               if (this.datasourceMaster.mapa) {
                  this.markersVolume = [];
                  const mapa = this.datasourceMaster.mapa;
                  if (mapa.distribuicao_volume && mapa.distribuicao_volume.dados.length > 0) {

                     mapa.distribuicao_volume.dados.forEach(element => {
                        const location = [];
                        location.push(element.lat);
                        location.push(element.lng);
                        this.markersVolume.push({
                           location,
                           iconSrc: this.getPath('distribuicao_volume', element.status),
                           tooltip: {
                              isShown: false,
                              text: element.chave + ': ' + element.valor.toFixed(2)
                           }
                        });

                     });

                  }

                  if (mapa.distribuicao_valor_uni && mapa.distribuicao_valor_uni.dados.length > 0) {
                     this.markersValor = [];
                     mapa.distribuicao_valor_uni.dados.forEach(element => {
                        const location = [];
                        location.push(element.lat);
                        location.push(element.lng);
                        this.markersValor.push({
                           location,
                           iconSrc: this.getPath('distribuicao_valor_uni', element.status),
                           // tooltip: {
                           //    isShown: false,
                           //    text: element.chave + ': ' + element.valor.toFixed(2)
                           // },
                           onClick: (args) => {
                              this.filtraMarker(element.posto_id);
                           }
                        });

                     });

                  }
               }
               this.datasourceMaster.markersVolume = this.markersVolume;
               this.datasourceMaster.markersValor = this.markersValor;

               this.loadVisible = false;
               console.log('chegou até o fim');


            } else {
               this.notificacoes.openSnackBar('Nenhum registro encontrado.');
            }
         });

         this.socketIo.on('filtro', (dataFiltro) => {
            console.log('dataFiltro', dataFiltro);
            this.filtroContent = dataFiltro;
         });
      } catch (error) {
         this.loadVisible = false;
         console.log('error => ', error);
      }
   }

   respostaFiltro(e: any) {
      if (e.filtro) {
         Object.assign(this.socketFiltro, e.filtro);

         if (this.socketFiltro.data_inicial) {
            this.socketFiltro.data_inicial = moment(this.socketFiltro.data_inicial).utc().format();
         }

         if (this.socketFiltro.data_final) {
            this.socketFiltro.data_final = moment(this.socketFiltro.data_final).utc().format();
         }

         this.socket().then(() => { });
      }
   }


   getPath(tipo: string, status: number) {
      // const distVolume = ['marker-red', 'marker-orange', 'marker-pink', 'marker-yellow', 'marker-green'];
      const distVolume = ['volume-1', 'volume-2', 'volume-3', 'volume-4', 'volume-5'];
      const distValor = ['marker-green', 'marker-yellow', 'marker-pink', 'marker-orange', 'marker-red'];
      let path = 'assets/images/mapa-abastecimento/';
      if (tipo === 'distribuicao_volume') {
         path += distVolume[status] + '.png';
      }

      if (tipo === 'distribuicao_valor_uni') {
         path += distValor[status] + '.png';
      }

      return path;
   }

   filtraMarker(e: number) {
      if (e) {
         Object.assign(this.socketFiltro, {
            posto_id: e
         });
         this.socket();
         this.mabService.filroAtivoMapa1 = true;
      } else {
         throwError('O Parametro POSTO_ID NÃO EXISTE');
         console.log(e);
      }
   }


}
