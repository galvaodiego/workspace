import { Component, OnInit, Input, OnDestroy, ViewChild } from '@angular/core';
import io from 'socket.io-client';
import { Usuario } from 'src/app/shared/models/usuario.model';
import { environment } from 'src/environments/environment';
import { NovoMapaAbastService } from '../../../novo-mapa-abast.service';
import { GeometryService } from './geometry.service';
import 'leaflet/dist/images/marker-shadow.png';
import 'leaflet/dist/images/marker-icon.png';


import * as L from 'leaflet';


@Component({
  // tslint:disable-next-line:component-selector
  selector: 'mab-app-mapa',
  templateUrl: './mapa.component.html',
  styleUrls: ['./mapa.component.scss']
})
export class MapaComponent implements OnInit, OnDestroy {
  @ViewChild('Map') map: L.Map;
  public user: Usuario = Usuario.instance;
  datasource: any;
  socketIo;
  socketFiltro;
  filtroContent;
  loadVisible = false;
  // postosCadastradosIcon = 'assets/images/mapa-abastecimento/marker-icon.png';
  // postosOutrosIcon = 'assets/images/mapa-abastecimento/marker-icon-sec.png';
  // icon1 = L.icon({
  //   iconUrl: 'assets/images/mapa-abastecimento/marker-icon.png',
  //   shadowUrl: 'assets/images/mapa-abastecimento/marker-shadow.png',
  //   iconSize: [25, 41],
  //   iconAnchor: [9, 40],
  //   popupAnchor: [-3, -76],
  // });
  // icon2 = L.icon({
  //   iconUrl: 'assets/images/mapa-abastecimento/marker-icon-sec.png',
  //   shadowUrl: 'assets/images/mapa-abastecimento/marker-shadow.png',
  //   iconSize: [25, 41],
  //   iconAnchor: [9, 40],
  //   popupAnchor: [-3, -76],
  // });
  postosCadastradosIcon = 'assets/images/mapa-abastecimento/blueMarkerLit.png';
  postosOutrosIcon = 'assets/images/mapa-abastecimento/orangeMarkerLit.png';
  icon1 = L.icon({
    iconUrl: 'assets/images/mapa-abastecimento/blueMarkerBig.png',
    // shadowUrl: 'assets/images/mapa-abastecimento/marker-shadow.png',
    iconSize: [30, 38],
    iconAnchor: [9, 40],
    popupAnchor: [-3, -76],
  });
  icon2 = L.icon({
    iconUrl: 'assets/images/mapa-abastecimento/orangeMarkerBig.png',
    // shadowUrl: 'assets/images/mapa-abastecimento/marker-shadow.png',
    iconSize: [30, 38],
    iconAnchor: [9, 40],
    popupAnchor: [-3, -76],
  });
  markers = new L.FeatureGroup();
  mapa: L.Map;
  constructor(
    private novoMapaAbastService: NovoMapaAbastService,
    private geometryService: GeometryService
  ) {
    this.socketIo = io(environment.socket_end_point_base + '/abastecimento');
    this.socketFiltro = {
      base: this.user.ref.toLowerCase(),
      usuario: this.user.usuario
    };
  }

  ngOnDestroy(): void {
    this.socketIo.disconnect();
  }

  ngOnInit() {
    this.socket();
    this.initMapa();

  }

  initMapa() {
    // Creating map options
    const mapOptions = {
      layers: [
        L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token={accessToken}', {
          // tslint:disable-next-line:max-line-length
          attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
          maxZoom: 18,
          id: 'mapbox/streets-v11',
          tileSize: 512,
          zoomOffset: -1,
          accessToken: 'pk.eyJ1Ijoicm9kcmlnby1ldiIsImEiOiJja2FyN3VqajQwaXByMnhxbG5pZWFxb29zIn0.4jEbhTwy8YdBemsRfZbFVg'
        })
      ],
      zoom: 7,
      center: L.latLng(-26.77503938699959, -53.7001895748848)
    };
    // Creating a map object
    this.mapa = L.map('map', mapOptions);

    this.mapa.on('contextmenu', event => {
      console.log('right click info: ', event);
    });
  }

  changeRotas(e) {
    if (e.value) {
      Object.assign(this.socketFiltro, {
        rota_id: e.value
      });
      this.socketIo.emit('getRota', this.socketFiltro);
    } else {
      delete this.socketFiltro.rota_id;
      this.markers.clearLayers();
      this.socketIo.emit('getRota', this.socketFiltro);
    }
  }

  paint(posto) {
    let pos = L.latLng(-26.77503938699959, -53.7001895748848);
    if (posto.posto_base.length > 0) {
      pos = posto.posto_base[0].posicao;
      posto.posto_base.forEach(element => {
        if (this.mapa) {
          const marker = L.marker(element.posicao, {
            icon: this.icon1,
            title: element.posto + '\n' + element.endereco + '\n' + 'Valor Médio: R$ ' + element.valor_medio.toFixed(2)
          });
          this.markers.addLayer(marker);
        }
      });
    }
    if (posto.posto_outros.length > 0) {
      pos = posto.posto_outros[0].posicao;
      posto.posto_outros.forEach(element => {
        if (this.mapa) {
          const marker = L.marker(element.posicao, {
            icon: this.icon2,
            title: element.posto + '\n' + element.endereco + '\n' + 'Valor Médio: R$ ' + element.valor_medio.toFixed(2)
          });
          this.markers.addLayer(marker);
        }
      });
    }

    this.mapa.flyTo(pos, 8);

    this.mapa.addLayer(this.markers);
  }

  async socket() {
    try {
      this.loadVisible = true;
      console.log('enviando o filtro:', this.socketFiltro);
      this.socketIo.emit('getRota', this.socketFiltro);
      this.socketIo.on('getRota', (dataR) => {
        this.datasource = dataR;
        console.log('retorno do socket mapa:', (dataR));
        if (this.datasource) {
          const ds = this.datasource;
          if (ds.rota) {
            if (ds.rota.rota_resumo.polilinha) {
              this.markers.clearLayers();
              const rota = this.geometryService.decode(ds.rota.rota_resumo.polilinha);
              const polyline = L.polyline(rota, { color: 'red' });
              console.log('poly', polyline);

              this.markers.addLayer(polyline);
              // this.mapa.fitBounds(polyline.getBounds(), {
              //   padding: L.point(24, 24),
              //   maxZoom: 12,
              //   animate: true
              // });
            }
            this.paint(ds.posto);
          }
        }
      });
      this.loadVisible = false;
      // this.socketIo.on('filtro', (dataFiltro) => {
      //   console.log('dataFiltro MAPA', dataFiltro);
      //   this.filtroContent = dataFiltro;
      // });

    } catch (error) {
      this.loadVisible = false;
      console.log('error => ', error);
    }
  }
}
