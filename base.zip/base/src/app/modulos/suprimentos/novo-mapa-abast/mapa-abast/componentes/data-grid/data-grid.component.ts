import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { NovoMapaAbastService } from '../../../novo-mapa-abast.service';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'mab-data-grid',
  templateUrl: './data-grid.component.html',
  styleUrls: ['./data-grid.component.scss']
})
export class DataGridComponent implements OnInit {
  @Input() datasource;
  @Output() resposta: EventEmitter<any> = new EventEmitter();
  constructor(public novoMapaAbastService: NovoMapaAbastService) { }

  ngOnInit() {
  }


  contentReady = (e) => {
    if (!e.component.isNotFirstLoad) {
      e.component.isNotFirstLoad = true;
      e.component.expandRow(e.component.getKeyByRowIndex(0));
    }
  }


  customizeMedia(data) {
    return data.value.toFixed(2);
  }

  public onCellPrepared(e: any) {
    e.cellElement.style.fontFamily = 'Fira Sans';

    if (e.rowType === 'header') {
      e.cellElement.style.paddingTop = '5px';
      e.cellElement.style.paddingBottom = '5px';
      e.cellElement.style.fontWeight = 500;
      e.cellElement.style.fontSize = '14px';
    }
    if (e.rowType === 'totalFooter') {
      e.cellElement.style.paddingTop = '5px';
      e.cellElement.style.paddingBottom = '5px';
      e.cellElement.style.backgroundColor = '#E1E1E1';
      e.cellElement.style.color = '#070707';
    }

    // if (e.rowType === 'group') {
    //   if (typeof (e.data) !== 'undefined') {
    //     console.log(e.data);
    //     e.cellElement.style.color = '#CBCBCB';
    //   }
    // }

    if (typeof (e.data) !== 'undefined') {
      e.cellElement.style.paddingTop = '5px';
      e.cellElement.style.paddingBottom = '5px';
      e.cellElement.style.color = '#070707';

    }
  }

  onCellClick(e) {
    if (e.rowType === 'data') {
      if (e.column.dataField === 'placa') {
        this.resposta.emit({ valor: e.value });
      }
    }
  }

  removeFiltro() {
    this.resposta.emit({ valor: null });
  }
}
