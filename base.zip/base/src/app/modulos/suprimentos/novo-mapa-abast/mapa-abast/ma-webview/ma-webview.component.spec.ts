import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MaWebviewComponent } from './ma-webview.component';

describe('MaWebviewComponent', () => {
  let component: MaWebviewComponent;
  let fixture: ComponentFixture<MaWebviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MaWebviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MaWebviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
