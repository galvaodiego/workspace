import { Injectable } from '@angular/core';
import { PolyUtil } from 'node-geometry-library';
@Injectable({
  providedIn: 'root'
})
export class GeometryService {

  constructor() { }

  decode(polyline) {
    const response = PolyUtil.decode(polyline);
    return response;
  }
}
