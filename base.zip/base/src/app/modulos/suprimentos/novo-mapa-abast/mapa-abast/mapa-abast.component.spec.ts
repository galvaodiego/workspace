import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MapaAbastComponent } from './mapa-abast.component';

describe('MapaAbastComponent', () => {
  let component: MapaAbastComponent;
  let fixture: ComponentFixture<MapaAbastComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MapaAbastComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MapaAbastComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
