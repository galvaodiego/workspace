import { Component, OnInit, OnDestroy } from '@angular/core';
import { NovoMapaAbastService } from '../novo-mapa-abast.service';
import { environment } from 'src/environments/environment';
import { Usuario } from 'src/app/shared/models/usuario.model';
import io from 'socket.io-client';
import * as moment from 'moment';

@Component({
  selector: 'app-mapa-abast',
  templateUrl: './mapa-abast.component.html',
  styleUrls: ['./mapa-abast.component.scss']
})
export class MapaAbastComponent implements OnInit, OnDestroy {
  public user: Usuario = Usuario.instance;
  loadVisible = false;
  socketIo: any;
  socketFiltro: any;
  filtroContent = {
    placa: [],
    estado: []
  };
  constructor(private novoMapaAbastService: NovoMapaAbastService) {
    this.socketIo = io(environment.socket_end_point_base + '/abastecimento');
    this.socketFiltro = {
      base: this.user.ref.toLowerCase(),
      usuario: this.user.usuario
    };
    // this.datasourceMaster = mabService.datasourceMaster;
    this.socket().then(() => { });
  }
  datasourceMaster;
  ngOnInit() {
    // this.datasourceMaster = this.novoMapaAbastService.dummy;
  }

  ngOnDestroy(): void {
    this.socketIo.disconnect();
  }

  async socket() {
    try {
      this.loadVisible = true;
      console.log('enviando o filtro:', this.socketFiltro);
      this.socketIo.emit('getAbastecimento', this.socketFiltro);
      this.socketIo.emit('getFiltro', this.socketFiltro);
      this.novoMapaAbastService.activeFilter = this.socketFiltro;
      this.socketIo.on('abastecimento', (data) => {
        console.log('retorno do socket abastecimento:', data);
        this.datasourceMaster = data;
        this.loadVisible = false;
      });

      this.socketIo.on('filtro', (dataFiltro) => {
        console.log('dataFiltro', (dataFiltro));
        this.filtroContent = dataFiltro;
      });

    } catch (error) {
      this.loadVisible = false;
      console.log('error => ', error);
    }
  }

  respostaFiltro(e: any) {
    if (e.filtro) {
      Object.assign(this.socketFiltro, e.filtro);

      if (this.socketFiltro.data_inicial) {
        this.socketFiltro.data_inicial = moment(this.socketFiltro.data_inicial).utc().format();
      }

      if (this.socketFiltro.data_final) {
        this.socketFiltro.data_final = moment(this.socketFiltro.data_final).utc().format();
      }

      this.loadVisible = true;
      console.log('enviando o filtro:', this.socketFiltro);
      this.socketIo.emit('getAbastecimento', this.socketFiltro);
    }

  }

  retornoFiltroInterno(e) {
    switch (e.componente) {
      case 'chart':
        this.novoMapaAbastService.activeFilter.posto = [];
        if (e.valor !== null) {
          this.novoMapaAbastService.activeFilter.posto.push(e.valor);
        }
        break;
      case 'grid':
        this.novoMapaAbastService.activeFilter.placa = [];
        if (e.valor !== null) {
          this.novoMapaAbastService.activeFilter.placa.push(e.valor);
        }
        break;
    }

    Object.assign(this.socketFiltro, this.novoMapaAbastService.activeFilter);
    this.loadVisible = true;
    console.log('enviando o filtro:', this.socketFiltro);
    this.socketIo.emit('getAbastecimento', this.socketFiltro);


  }

}
