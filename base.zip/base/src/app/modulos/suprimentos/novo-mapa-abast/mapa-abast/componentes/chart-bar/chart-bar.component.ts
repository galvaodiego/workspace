import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { NovoMapaAbastService } from '../../../novo-mapa-abast.service';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'mab-chart-bar',
  templateUrl: './chart-bar.component.html',
  styleUrls: ['./chart-bar.component.scss']
})
export class ChartBarComponent implements OnInit {

  constructor(public novoMapaAbastService: NovoMapaAbastService) { }
  @Input() datasource;
  @Input() title;
  @Input() cor;
  @Input() dadosHeader;
  @Output() resposta: EventEmitter<any> = new EventEmitter();
  ngOnInit() {
  }


  removeFiltro() {
    this.resposta.emit({ valor: null });
  }

  onPointClick(e) {
    this.resposta.emit({ valor: e.target.originalArgument });
  }

}
