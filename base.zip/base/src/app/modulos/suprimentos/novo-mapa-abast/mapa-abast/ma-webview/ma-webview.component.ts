import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-ma-webview',
  templateUrl: './ma-webview.component.html',
  styleUrls: ['./ma-webview.component.scss']
})
export class MaWebviewComponent implements OnInit {
  @Output() retornoFiltroInterno: EventEmitter<any> = new EventEmitter();
  constructor() { }
  datasourceMaster: any;
  get value(): any {
    return this.datasourceMaster;
  }

  @Input('datasourceMaster')
  set value(val: any) {
    this.datasourceMaster = val;
    if (this.datasourceMaster) {
      // console.log('chegou na view', this.datasourceMaster);
    }

  }
  ngOnInit() {
  }

  respostaChart(e) {
    this.retornoFiltroInterno.emit({ componente: 'chart', valor: e.valor });
  }
  respostaGrid(e) {
    this.retornoFiltroInterno.emit({ componente: 'grid', valor: e.valor });
  }

}
