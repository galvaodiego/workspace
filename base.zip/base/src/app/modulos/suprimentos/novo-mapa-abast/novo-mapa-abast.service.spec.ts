import { TestBed } from '@angular/core/testing';

import { NovoMapaAbastService } from './novo-mapa-abast.service';

describe('NovoMapaAbastService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: NovoMapaAbastService = TestBed.get(NovoMapaAbastService);
    expect(service).toBeTruthy();
  });
});
