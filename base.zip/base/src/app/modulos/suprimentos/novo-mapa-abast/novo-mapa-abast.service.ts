import { Injectable } from '@angular/core';
import * as  moment from 'moment';
@Injectable({
    providedIn: 'root'
})
export class NovoMapaAbastService {
    // today = moment();
    inicio = moment().subtract(1, 'month');
    fim = moment();
    activeFilter: ActiveFilter = {
        base: '',
        data_inicial: '',
        data_final: '',
        posto: [],
        placa: [],
        estado: []
    };
    dummy = {
        graficos: {
            unitario: {
                unit_hoje: 1357,
                unit_medio: 7638,
                dados: [
                    { chave: 'Auto Posto 44k', valor: 100 },
                    { chave: 'Posto Túlio', valor: 200 },
                    { chave: 'Marajo Centralina', valor: 300 }
                ]
            },
            gasto: {
                hoje: 3000000,
                total: 53000000,
                dados: [
                    { chave: 'Auto Posto 44k', valor: 1000 },
                    { chave: 'Posto Túlio', valor: 2000 },
                    { chave: 'Marajo Centralina', valor: 3000 }
                ]
            }
        },
        tabelas: {
            geral: [
                {
                    uf: 'PR',
                    posto: 'Posto Mirandinha',
                    placa: 'ABX1314',
                    valor: 774350,
                    litros: 2230,
                    menor_valor: 2.90,
                    maior_valor: 3.50,
                    valor_medio: 3.20
                },
                {
                    uf: 'PR',
                    posto: 'Posto Mirandinha',
                    placa: 'ABX0012',
                    valor: 125000,
                    litros: 1500,
                    menor_valor: 2.90,
                    maior_valor: 3.50,
                    valor_medio: 3.20
                },
                {
                    uf: 'PR',
                    posto: 'Posto Mirandinha',
                    placa: 'AOO0013',
                    valor: 250000,
                    litros: 4500,
                    menor_valor: 2.90,
                    maior_valor: 3.50,
                    valor_medio: 3.20
                },
                {
                    uf: 'PR',
                    posto: 'Posto Mirandinha II',
                    placa: 'ABX1222',
                    valor: 5000,
                    litros: 300,
                    menor_valor: 3.90,
                    maior_valor: 4.50,
                    valor_medio: 3.20
                },
                {
                    uf: 'SP',
                    posto: 'Posto Ipiranga',
                    placa: 'ABC2345',
                    valor: 15000,
                    litros: 1300,
                    menor_valor: 13.90,
                    maior_valor: 14.50,
                    valor_medio: 13.20
                },
            ]
        }
    };
    constructor() {}
}


export interface ActiveFilter {
    base: string;
    data_inicial: string;
    data_final: string;
    posto: Array<any>;
    placa: Array<any>;
    estado: Array<any>;
}
