import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MapaAbastComponent } from './mapa-abast/mapa-abast.component';
import { MaWebviewComponent } from './mapa-abast/ma-webview/ma-webview.component';
import { DataGridComponent } from './mapa-abast/componentes/data-grid/data-grid.component';
import { DxDataGridModule, DxChartModule, DxPopupModule, DxLoadPanelModule, DxSelectBoxModule } from 'devextreme-angular';
import { ChartBarComponent } from './mapa-abast/componentes/chart-bar/chart-bar.component';
import { MaterialModule } from 'src/app/shared/modules/material/material.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { FiltroComponent } from './mapa-abast/filtro/filtro.component';
import { MapaComponent } from './mapa-abast/componentes/mapa/mapa.component';
import { LeafletModule } from '@asymmetrik/ngx-leaflet';

@NgModule({
  declarations: [MapaAbastComponent, MaWebviewComponent, DataGridComponent, ChartBarComponent, FiltroComponent, MapaComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    MaterialModule,
    DxDataGridModule,
    DxChartModule,
    DxPopupModule,
    DxLoadPanelModule,
    LeafletModule,
    DxSelectBoxModule
  ]
})
export class NovoMapaAbastModule { }
