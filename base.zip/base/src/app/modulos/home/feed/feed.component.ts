import { Component, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import io from 'socket.io-client';
import { environment } from 'src/environments/environment';
import { Usuario } from 'src/app/shared/models/usuario.model';
import { FeedDataService } from './feed-data.service';
import { MediaMatcher } from '@angular/cdk/layout';
@Component({
   selector: 'app-feed',
   templateUrl: './feed.component.html',
   styleUrls: ['./feed.component.scss']
})
export class FeedComponent implements OnInit, OnDestroy {
   public user: Usuario = Usuario.instance;
   // Config Socket
   socketIo: any;
   socketRota = 'base';
   socketMetodo = 'getFeed';
   socketFiltro: any;
   /***/
   datasourceMaster;
   loadVisible = false;
   mobileQuery: MediaQueryList;
   // tslint:disable-next-line: variable-name
   private _mobileQueryListener: () => void;

   constructor(
      private feedData: FeedDataService,
      changeDetectorRef: ChangeDetectorRef,
      media: MediaMatcher,
   ) {

      this.mobileQuery = media.matchMedia('(max-width: 600px)');
      this._mobileQueryListener = () => changeDetectorRef.detectChanges();
      // tslint:disable-next-line: deprecation
      this.mobileQuery.addListener(this._mobileQueryListener);
      this.socketIo = io(environment.socket_end_point_base + '/' + this.socketRota);
      this.socketFiltro = {
         base: this.user.ref.toLowerCase(),
         usuario: this.user.usuario
      };
      this.socket().then(() => { });
   }

   ngOnInit() {
   }

   ngOnDestroy(): void {
      this.socketIo.disconnect();
      this.feedData.desconectar();
      // tslint:disable-next-line: deprecation
      this.mobileQuery.removeListener(this._mobileQueryListener);
   }

   async socket() {
      this.loadVisible = true;
      try {
         this.socketIo.emit(this.socketMetodo, this.socketFiltro);
         this.socketIo.on('feed', (data) => {
            this.datasourceMaster = data;
            console.log('filtro', this.socketFiltro, 'data', data);
            this.loadVisible = false;
         });
      } catch (error) {
         console.log('error => ', error);
      }
   }

}
