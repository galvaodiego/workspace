import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { SharedModule } from 'src/app/shared/shared.module';

import { FeedComponent } from './feed.component';
import { FeedItemComponent } from './componentes/feed-item/feed-item.component';
import { ElementoComponent } from './componentes/elemento/elemento.component';
import { StoriesComponent } from './componentes/stories/stories.component';
import { StoriesResumoComponent } from './componentes/stories/stories-resumo/stories-resumo.component';
import { StoriesClienteComponent } from './componentes/stories/stories-cliente/stories-cliente.component';
import { CardFaturamentoComponent } from './componentes/feed-item/componentes/card-faturamento/card-faturamento.component';
import { MobileViewComponent } from './mobile-view/mobile-view.component';
import { WebViewComponent } from './web-view/web-view.component';
import { FeedCardComponent } from './componentes/feed-card/feed-card.component';



@NgModule({
   declarations: [
      FeedComponent,
      FeedItemComponent,
      ElementoComponent,
      CardFaturamentoComponent,
      StoriesComponent,
      StoriesResumoComponent,
      StoriesClienteComponent,
      MobileViewComponent,
      WebViewComponent,
      FeedCardComponent
   ],
   imports: [
      CommonModule,
      RouterModule,
      SharedModule
   ],
   exports: [
    FeedComponent
   ]
})
export class FeedModule { }
