import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StoriesClienteComponent } from './stories-cliente.component';

describe('StoriesClienteComponent', () => {
  let component: StoriesClienteComponent;
  let fixture: ComponentFixture<StoriesClienteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StoriesClienteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StoriesClienteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
