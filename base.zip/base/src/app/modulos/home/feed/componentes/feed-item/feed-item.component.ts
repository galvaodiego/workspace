import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { FeedDataService } from '../../feed-data.service';

@Component({
   selector: 'app-feed-item',
   templateUrl: './feed-item.component.html',
   styleUrls: ['./feed-item.component.scss']
})
export class FeedItemComponent implements OnInit {
   dadosCliente: any;
   constructor(
      private router: Router,
      private feedData: FeedDataService
   ) {
      const dadosCliente = JSON.parse(localStorage.getItem('cliente-selecionado'));
      if (dadosCliente) {
         this.dadosCliente = dadosCliente;
      }
   }

   conteudo: any;
   get value(): any {
      return this.conteudo;
   }

   @Input('conteudo')
   set value(val: any) {
      this.conteudo = val;
      // console.log('conteudo::', this.conteudo);
   }

   ngOnInit() {
   }

   vaiParaExtrato() {
      this.feedData.dataCard = this.conteudo;
      this.router.navigate(['/financeiro/extrato-faturamento/card/']);
   }

   vaiParaMapa() {
      this.router.navigate(['/logistico/mapa-rastreamento/']);
   }

   getFlag(uf: string) {
      const path = 'assets/images/feed/flags/flag-' + uf.toLowerCase() + '.png';
      return path;
   }

   enviaFeedBack(chave: string, valor: number) {
      if (chave) {
         const parametro = {
            chave,
            valor
         };
         console.log('parametros', parametro);
         this.feedData.enviaFeedBack(parametro);
      }
   }

   go(classe: number, subclasse: number) {
      switch (classe) {
         case 1: // Faturamento
            switch (subclasse) {
               case 1: // Rota
                  this.feedData.dataCard = this.conteudo;
                  localStorage.setItem('fatu-rota-data-card', JSON.stringify(this.conteudo));
                  this.router.navigate(['/financeiro/faturamento/detalhes/rota']);
                  break;
            }
            break;
      }
   }

}
