import { Component, OnInit, OnDestroy } from '@angular/core';
import io from 'socket.io-client';
import { Usuario } from 'src/app/shared/models/usuario.model';
import { environment } from 'src/environments/environment';

@Component({
   selector: 'app-stories',
   templateUrl: './stories.component.html',
   styleUrls: ['./stories.component.scss']
})
export class StoriesComponent implements OnInit, OnDestroy {
   public user: Usuario = Usuario.instance;

   // Config Socket
   socketIo: any;
   socketRota = 'base';
   socketMetodo = 'getStories';
   socketFiltro: any;
   /***/

   datasource = {
      cliente: {
         dados: []
      },
      resumo: {

      }
   };
   loadVisible = false;

   showResumo = false;
   showCliente = false;

   public iconResumo = 'btn-resumo.png';
   public iconCliente = 'btn-cliente.png';

   constructor() {
      this.socketIo = io(environment.socket_end_point_base + '/' + this.socketRota);
      this.socketFiltro = {
         base: this.user.ref.toLowerCase(),
         usuario: this.user.usuario
      };
      this.socket().then(() => { });
   }

   ngOnInit() {
   }

   ngOnDestroy(): void {
      this.socketIo.disconnect();
   }

   async socket() {
      this.loadVisible = true;
      try {
         this.socketIo.emit(this.socketMetodo, this.socketFiltro);
         this.socketIo.on('stories', (data) => {
            console.log('STORIES:: enviando', this.socketFiltro, 'recebendo', data);
            this.datasource = data;
            this.loadVisible = false;
         });
      } catch (error) {
         console.log('error => ', error);
      }
   }

   show(classe: string) {
      if (classe === 'resumo') {
         if (this.showResumo === true) {
            this.showResumo = false;
            this.iconResumo = 'btn-resumo.png';
            this.iconCliente = 'btn-cliente.png';

         } else {
            this.showResumo = true;
            this.showCliente = false;
            this.iconCliente = 'btn-cliente-inactive.png';
            this.iconResumo = 'btn-resumo.png';
         }

      }

      if (classe === 'cliente') {
         if (this.showCliente === true) {
            this.iconResumo = 'btn-resumo.png';
            this.iconCliente = 'btn-cliente.png';
            this.showCliente = false;
         } else {
            this.showResumo = false;
            this.showCliente = true;
            this.iconResumo = 'btn-resumo-inactive.png';
            this.iconCliente = 'btn-cliente.png';

         }

      }
   }

}
