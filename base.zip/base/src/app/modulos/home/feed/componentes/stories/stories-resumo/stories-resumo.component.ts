import { Component, OnInit, Input } from '@angular/core';

@Component({
   selector: 'app-stories-resumo',
   templateUrl: './stories-resumo.component.html',
   styleUrls: ['./stories-resumo.component.scss']
})
export class StoriesResumoComponent implements OnInit {

   constructor() { }
   datasource: any;
   get value(): any {
      return this.datasource;
   }

   @Input('datasource')
   set value(val: any) {
      this.datasource = val;
      if (this.datasource) {
         // CODE HERE
      }
   }

   ngOnInit() {
   }

}
