import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StoriesResumoComponent } from './stories-resumo.component';

describe('StoriesResumoComponent', () => {
  let component: StoriesResumoComponent;
  let fixture: ComponentFixture<StoriesResumoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StoriesResumoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StoriesResumoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
