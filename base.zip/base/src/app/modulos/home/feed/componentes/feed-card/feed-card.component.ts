import { Component, OnInit, Input } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { MatIconRegistry } from '@angular/material/icon';
import { FeedDataService } from '../../feed-data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-feed-card',
  templateUrl: './feed-card.component.html',
  styleUrls: ['./feed-card.component.scss']
})
export class FeedCardComponent implements OnInit {

  constructor(
    iconRegistry: MatIconRegistry,
    sanitizer: DomSanitizer,
    private feedData: FeedDataService,
    private router: Router,
  ) {
    iconRegistry.addSvgIcon('thumb-up-alt', sanitizer.bypassSecurityTrustResourceUrl('assets/images/feed/thumb_up_alt.svg'));
    iconRegistry.addSvgIcon('thumb-down-alt', sanitizer.bypassSecurityTrustResourceUrl('assets/images/feed/thumb_down_alt.svg'));
  }

  conteudo: any;
  get value(): any {
    return this.conteudo;
  }

  @Input('conteudo')
  set value(val: any) {
    this.conteudo = val;
  }

  ngOnInit() {
  }

  enviaFeedBack(chave: string, valor: number) {
    if (chave) {
      const parametro = {
        chave,
        valor
      };
      console.log('parametros', parametro);
      this.feedData.enviaFeedBack(parametro);
    }
  }

  getClass(subclasse) {
    let classe = '';
    switch (subclasse) {
      case 1:
        classe = 'faturamento-veiculo';
        break;
      case 2:
        classe = 'indefinido';
        break;
      case 3:
        classe = 'indefinido';
        break;
    }

    return classe;
  }

  go(classe: number, subclasse: number) {
    console.log('classe:', classe, 'subclasse:', subclasse);

    // switch (classe) {
    //   case 1: // Faturamento
    //     switch (subclasse) {
    //       case 1: // Rota
    //         this.feedData.dataCard = this.conteudo;
    //         localStorage.setItem('fatu-rota-data-card', JSON.stringify(this.conteudo));
    //         this.router.navigate(['/financeiro/faturamento/detalhes/rota']);
    //         break;
    //     }
    //     break;
    // }
  }

}
