import { Component, OnInit, Input } from '@angular/core';

@Component({
  // tslint:disable-next-line: component-selector
  selector: 'fi-card-faturamento',
  templateUrl: './card-faturamento.component.html',
  styleUrls: ['./card-faturamento.component.scss']
})
export class CardFaturamentoComponent implements OnInit {
  @Input() subclasse: number;
  @Input() conteudo: string;
  constructor() { }

  ngOnInit() {
  }

}
