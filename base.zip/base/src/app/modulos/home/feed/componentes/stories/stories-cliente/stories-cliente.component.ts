import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-stories-cliente',
  templateUrl: './stories-cliente.component.html',
  styleUrls: ['./stories-cliente.component.scss']
})
export class StoriesClienteComponent implements OnInit {

  constructor() { }
  datasource: any;
  get value(): any {
     return this.datasource;
  }

  @Input('datasource')
  set value(val: any) {
     this.datasource = val;
     if (this.datasource) {
        // CODE HERE
     }
  }
  ngOnInit() {
  }

}
