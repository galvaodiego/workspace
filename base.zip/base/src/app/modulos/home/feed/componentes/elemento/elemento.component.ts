import { Component, OnInit, Input } from '@angular/core';

@Component({
   selector: 'app-elemento',
   templateUrl: './elemento.component.html',
   styleUrls: ['./elemento.component.scss']
})
export class ElementoComponent implements OnInit {
   /**
    * @Param tipo
    * 1 - tabela
    * 2 - graf. pizza
    * 3 - graf. barra
    * 4 - graf. linha
    * 5 - kpi
    * 6 - lista
    */
   @Input() tipo: number;
   @Input() conteudo: any;
   @Input() colunas: Array<any>;
   constructor() { }

   ngOnInit() {
   }

   onCellPrepared(e: any) {
      if (e.rowType === 'header') {
         e.cellElement.style.paddingTop = '5px';
         e.cellElement.style.paddingBottom = '5px';
         e.cellElement.style.border = '0px';
      }

      if (typeof (e.data) !== 'undefined') {
         e.cellElement.style.paddingTop = '5px';
         e.cellElement.style.paddingBottom = '5px';
         e.cellElement.style.fontSize = '10px';
         e.cellElement.style.border = '0px';
      }

   }

}
