import { Component, OnInit, Input } from '@angular/core';
// import * as _ from 'lodash';
import * as _ from 'underscore';

@Component({
  selector: 'app-web-view',
  templateUrl: './web-view.component.html',
  styleUrls: ['./web-view.component.scss']
})
export class WebViewComponent implements OnInit {
  datasourceMaster: any;
  get value(): any {
    return this.datasourceMaster;
  }

  @Input('datasourceMaster')
  set value(val: any) {
    const cards = _.groupBy(val, 'classe');
    const lista = [];
    Object.keys(cards).forEach(element => {
      if (element !== 'undefined') {
        lista.push({ titulo: element, dados: cards[element] });
      }
    });
    this.datasourceMaster = lista;
    // console.log('webview-', this.datasourceMaster);
  }
  constructor() { }

  ngOnInit() {
  }

}
