import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-mobile-view',
  templateUrl: './mobile-view.component.html',
  styleUrls: ['./mobile-view.component.scss']
})
export class MobileViewComponent implements OnInit {
  constructor() { }
  datasourceMaster: any;
  get value(): any {
    return this.datasourceMaster;
  }

  @Input('datasourceMaster')
  set value(val: any) {
    this.datasourceMaster = val;
  }

  ngOnInit() {
  }

}
