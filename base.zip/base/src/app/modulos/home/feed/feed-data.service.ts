import { Injectable } from '@angular/core';
import io from 'socket.io-client';
import { environment } from 'src/environments/environment';
import { Usuario } from 'src/app/shared/models/usuario.model';
import { Observable } from 'rxjs';
@Injectable({
   providedIn: 'root'
})
export class FeedDataService {
   public user: Usuario = Usuario.instance;

   dataCard: any;
   socket: any;
   socketFiltro: any;
   constructor() {
      this.socket = io(environment.socket_end_point_base + '/base');
   }

   enviaFeedBack(parametro) {
      this.socket.emit('set_configuracao', {
         base: this.user.ref.toLowerCase(),
         usuario: this.user.usuario,
         metodo: 'set_relevancia',
         parametro
      });
      this.socket.on('set_relevancia', (data) => {
         console.log('ONSetRelevancia', data);
      });
      return true;
   }


   desconectar() {
      this.socket.disconnect();
   }
}
