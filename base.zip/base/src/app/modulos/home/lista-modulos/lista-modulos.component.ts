import { Component, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { MatIconRegistry } from '@angular/material/icon';
import { EstruturaOrganizacional } from 'src/app/shared/models/organizacional.model';
import { Router } from '@angular/router';
import { NotificacaoService } from 'src/app/shared/services/notificacao.service';
import { Usuario } from 'src/app/shared/models/usuario.model';

@Component({
   selector: 'app-lista-modulos',
   templateUrl: './lista-modulos.component.html',
   styleUrls: ['./lista-modulos.component.scss']
})
export class ListaModulosComponent implements OnInit {
   public org: EstruturaOrganizacional = EstruturaOrganizacional.instance;
   public user: Usuario = Usuario.instance;
   modulos: any;
   // listaModulos = [
   //    { nome: 'Acompanhamento Diário', path: '/logistico/acompanhamento-diario', icon: 'acomp-diario' },
   //    { nome: 'Controle de Frete', path: '/logistico/controle-frete', icon: 'controle-frete' },
   //    { nome: 'Extrato de Faturamento', path: '/financeiro/extrato-faturamento', icon: 'extrato-faturamento' },
   //    { nome: 'Mapa de Abastecimento', path: '/suprimentos/mapa-abastecimento', icon: 'mapa-abastecimento' },
   // ];
   constructor(
      private router: Router,
      private notificacao: NotificacaoService,
      iconRegistry: MatIconRegistry,
      sanitizer: DomSanitizer
   ) {
      // tslint:disable-next-line:max-line-length
      // iconRegistry.addSvgIcon('acomp-diario', sanitizer.bypassSecurityTrustResourceUrl('assets/images/modulos/nav-bar-acomp-diario.svg'));

      iconRegistry.addSvgIcon('controle-frete', sanitizer.bypassSecurityTrustResourceUrl('assets/images/modulos/icone-controle-frete.svg'));
      // tslint:disable-next-line: max-line-length
      iconRegistry.addSvgIcon('extrato-faturamento', sanitizer.bypassSecurityTrustResourceUrl('assets/images/modulos/icone-extrato-faturamento.svg'));
      // tslint:disable-next-line: max-line-length
      iconRegistry.addSvgIcon('mapa-abastecimento', sanitizer.bypassSecurityTrustResourceUrl('assets/images/modulos/icone-mapa-abastecimento.svg'));
      // tslint:disable-next-line: max-line-length
      iconRegistry.addSvgIcon('app_blocking', sanitizer.bypassSecurityTrustResourceUrl('assets/images/modulos/app_blocking.svg'));
      this.modulos = this.org.configOrgUsuario;

      this.modulos = this.modulos.filter(e => {
         return e.modulo !== 'Monitoramento';
      });


      const clienteSelecionado = JSON.parse(localStorage.getItem('cliente-selecionado'));
      if (clienteSelecionado) {
         // if (clienteSelecionado.ref === 'delpozo') {
         //    this.listaModulos = this.listaModulos.filter(e => {
         //       return e.nome === 'Acompanhamento Diário';
         //    });
         // }
         // if (clienteSelecionado.ref === 'levolog') {
         //    this.listaModulos = this.listaModulos.filter(e => {
         //       return e.nome === 'Extrato de Faturamento';
         //    });
         // }

      }

   }

   ngOnInit() {
   }

   navegacao(destino) {
      switch (destino.toLowerCase()) {
         case 'faturamento':
            this.router.navigate(['financeiro/faturamento']);
            break;
         case 'indicador logístico':
            this.router.navigate(['logistico/indicadores']);
            break;
         case 'dre':
            this.router.navigate(['contabil/dre']);
            break;

         default:
            this.notificacao.openSnackBar('O módulo ' + destino + ' está indisponível, contate o suporte para a liberação');
            break;
      }
   }


   getDetalhesMenu(modulo) {
      const obj = {
         nome: '',
         path: '',
         icon: '',
         mat_icon: ''
      };
      switch (modulo) {
         case 'extrato-faturamento':
            Object.assign(obj, {
               nome: 'Extrato de Faturamento',
               path: '/financeiro/extrato-faturamento',
               icon: 'extrato-faturamento', mat_icon: 'attach_money'
            });
            break;
         case 'acompanhamento-diario':
            Object.assign(obj, {
               nome: 'Acompanhamento Diário',
               path: '/logistico/acompanhamento-diario',
               icon: 'acomp-diario',
               mat_icon: 'date_range'
            });
            break;
         case 'controle-frete':
            Object.assign(obj, {
               nome: 'Controle de Frete',
               path: '/logistico/controle-frete',
               icon: 'controle-frete',
               mat_icon: 'local_shipping'
            });
            break;
         case 'mapa-abastecimento':
            Object.assign(obj, {
               nome: 'Mapa de Abastecimento',
               path: '/suprimentos/mapa-abastecimento',
               icon: 'mapa-abastecimento',
               mat_icon: 'local_gas_station'
            });
            break;

         default:
            Object.assign(obj, {
               nome: 'Permissão Pendente de Módulo: Contate o suporte!',
               path: '/',
               icon: 'app_blocking',
               mat_icon: 'app_blocking'
            });
            break;
      }

      return obj;
   }



}
