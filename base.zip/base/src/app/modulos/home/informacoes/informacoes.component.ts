import { Component, OnInit } from '@angular/core';

@Component({
   selector: 'app-informacoes',
   templateUrl: './informacoes.component.html',
   styleUrls: ['./informacoes.component.scss']
})
export class InformacoesComponent implements OnInit {
   popupVisible = false;
   path = '';
   constructor() { }

   ngOnInit() {
   }


   showModal(origem) {
      this.popupVisible = true;

      switch (origem) {
         case 'safari-add-home':
            this.path = 'assets/images/info/safari-add-home.jpg';
            break;
         case 'chrome-add-home':
            this.path = 'assets/images/info/chrome-add-home.jpg';
            break;
         case 'pergunta-notificacao':
            this.path = 'assets/images/info/pergunta-notificacao.jpg';
            break;
         case 'ativar-notificacao':
            this.path = 'assets/images/info/ativar-notificacao.jpg';
            break;
      }
   }

}
