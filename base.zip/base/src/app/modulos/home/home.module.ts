import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

import { SharedModule } from 'src/app/shared/shared.module';
import { FeedModule } from './feed/feed.module';


import { HomeComponent } from './home/home.component';
import { ListaModulosComponent } from './lista-modulos/lista-modulos.component';
import { NotificacoesComponent } from './notificacoes/notificacoes.component';
import { ConfiguracoesComponent } from './configuracoes/configuracoes.component';
import { Page404Component } from './page404/page404.component';
import { InformacoesComponent } from './informacoes/informacoes.component';




@NgModule({
   declarations: [
      HomeComponent,
      ListaModulosComponent,
      NotificacoesComponent,
      ConfiguracoesComponent,
      Page404Component,
      InformacoesComponent,
   ],
   imports: [
      CommonModule,
      RouterModule,
      SharedModule,
      FeedModule
   ],
   exports: []
})
export class HomeModule { }
