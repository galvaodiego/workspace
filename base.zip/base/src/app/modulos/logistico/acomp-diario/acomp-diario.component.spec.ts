import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AcompDiarioComponent } from './acomp-diario.component';

describe('AcompDiarioComponent', () => {
  let component: AcompDiarioComponent;
  let fixture: ComponentFixture<AcompDiarioComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AcompDiarioComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AcompDiarioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
