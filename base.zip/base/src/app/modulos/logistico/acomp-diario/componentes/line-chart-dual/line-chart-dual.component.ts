import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-line-chart-dual',
  templateUrl: './line-chart-dual.component.html',
  styleUrls: ['./line-chart-dual.component.scss']
})
export class LineChartDualComponent implements OnInit {
  @Input() datasource;

  constructor() { }

  ngOnInit() {
  }

}
