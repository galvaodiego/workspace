import { Component, OnInit, Input, OnChanges, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-single-bar',
  templateUrl: './single-bar.component.html',
  styleUrls: ['./single-bar.component.scss']
})
export class SingleBarComponent implements OnChanges {
  @Input() datasource;

  constructor() { }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.datasource.currentValue.length > 0) {
      changes.datasource.currentValue.map(e => {
        e.total = e.frota + e.agregado;
      });
      // console.log('total', changes.datasource.currentValue);

    }
  }

  customizeTooltip(arg: any) {
    return {
      text: arg.seriesName + ': ' + arg.valueText
    };
  }

}
