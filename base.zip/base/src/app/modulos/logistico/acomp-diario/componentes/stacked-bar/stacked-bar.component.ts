import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-stacked-bar',
  templateUrl: './stacked-bar.component.html',
  styleUrls: ['./stacked-bar.component.scss']
})
export class StackedBarComponent implements OnInit {
  @Input() datasource;

  constructor() { }

  ngOnInit() {
  }
  customizeTooltip(arg: any) {
    return {
      text: arg.seriesName + ': ' + arg.valueText
    };
  }
}
