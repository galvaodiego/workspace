import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-data-grid-resumo',
  templateUrl: './data-grid-resumo.component.html',
  styleUrls: ['./data-grid-resumo.component.scss']
})
export class DataGridResumoComponent implements OnInit {
  collapsed = false;
  datasource;
  constructor() { }

  ngOnInit() {
  }

  get value(): any {
    return this.datasource;
  }

  @Input('datasource')
  set value(val: any) {
    this.datasource = val;
    if (this.datasource) {
      // CODE HERE
      this.datasource.map(e => {
        e.fat_custo_perc = e.fat_custo_perc / 100;
        e.custo_perc = e.custo_perc / 100;
      });
      // console.log(this.datasource);

    }

  }
  contentReady = (e) => {
    if (!e.component.isNotFirstLoad) {
      e.component.isNotFirstLoad = true;
      e.component.expandRow(e.component.getKeyByRowIndex(0));
    }
  }

  public onCellPrepared(e: any) {
    if (e.rowType === 'header') {
      if (e.column.dataField === 'divisor') {
        e.cellElement.style.borderRight = '3px solid #333333';
        e.cellElement.style.borderLeft = '3px solid #333333';
      }
      e.cellElement.style.padding = '5px';

    }

    if (typeof (e.data) !== 'undefined') {
      if (e.column.dataField === 'divisor') {
        e.cellElement.style.borderRight = '3px solid #333333';
        e.cellElement.style.borderLeft = '3px solid #333333';
      }

      e.cellElement.style.padding = '5px';
      e.cellElement.style.fontSize = '11px';

    }
  }
}
