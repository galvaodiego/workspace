import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LineChartDualComponent } from './line-chart-dual.component';

describe('LineChartDualComponent', () => {
  let component: LineChartDualComponent;
  let fixture: ComponentFixture<LineChartDualComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LineChartDualComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LineChartDualComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
