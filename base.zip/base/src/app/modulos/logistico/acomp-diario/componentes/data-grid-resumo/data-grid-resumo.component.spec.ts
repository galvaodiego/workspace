import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DataGridResumoComponent } from './data-grid-resumo.component';

describe('DataGridResumoComponent', () => {
  let component: DataGridResumoComponent;
  let fixture: ComponentFixture<DataGridResumoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DataGridResumoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DataGridResumoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
