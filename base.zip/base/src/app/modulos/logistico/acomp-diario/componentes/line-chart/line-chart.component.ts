import { Component, OnInit, Input, OnChanges, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-line-chart',
  templateUrl: './line-chart.component.html',
  styleUrls: ['./line-chart.component.scss']
})
export class LineChartComponent implements OnInit, OnChanges {
  @Input() datasource;
  @Input() titulo;
  @Input() formato;
  @Input() color = '#1862AB';

  constructor() { }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.formato) {
      if (changes.formato.currentValue === 'percent') {
        if (changes.datasource.currentValue && changes.datasource.currentValue.length > 0) {
          changes.datasource.currentValue.map(e => {
            e.valor = e.valor / 100;
          });
        }
      }
    }
  }

  ngOnInit() {
  }

}
