import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-web-view',
  templateUrl: './web-view.component.html',
  styleUrls: ['./web-view.component.scss']
})
export class WebViewComponent implements OnInit {

  constructor() { }
  datasourceMaster: any;
  get value(): any {
     return this.datasourceMaster;
  }

  @Input('datasourceMaster')
  set value(val: any) {
     this.datasourceMaster = val;
     if (this.datasourceMaster) {
        // CODE HERE
     }

  }
  
  ngOnInit() {
  }


}

