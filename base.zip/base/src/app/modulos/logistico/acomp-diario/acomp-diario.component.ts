import { Component, OnInit, OnDestroy } from '@angular/core';
import { Usuario } from 'src/app/shared/models/usuario.model';
import io from 'socket.io-client';
import { environment } from 'src/environments/environment';
import * as moment from 'moment';


@Component({
  selector: 'app-acomp-diario',
  templateUrl: './acomp-diario.component.html',
  styleUrls: ['./acomp-diario.component.scss']
})
export class AcompDiarioComponent implements OnInit, OnDestroy {
  public user: Usuario = Usuario.instance;

  loadVisible = false;
  filtroContent;
  datasourceMaster;
  // Config Socket
  socketIo: any;
  socketFiltro: any;
  /***/
  constructor() {
    this.socketIo = io(environment.socket_end_point_base + '/acompanhamento-diario');
    this.socketFiltro = {
      base: this.user.ref.toLowerCase(),
    };
  }
  ngOnDestroy(): void {
    this.socketIo.disconnect();
  }
  ngOnInit() {
    this.socket();
  }

  async socket() {
    try {
      this.loadVisible = true;
      this.socketIo.emit('getAcompanhamento', this.socketFiltro);
      // this.socketIo.emit('getFiltro', this.socketFiltro);
      //  this.controleFreteService.activeFilter = this.socketFiltro;
      console.log('enviando o filtro:', this.socketFiltro);
      this.socketIo.on('getAcompanhamento', (data) => {
        this.datasourceMaster = data;
        console.log('filtro:', this.socketFiltro);
        console.log('retorno do socket:', data);
        this.loadVisible = false;
      });

      // this.socketIo.on('filtro', (dataFiltro) => {
      //   console.log('dataFiltro', dataFiltro);
      //   this.filtroContent = dataFiltro;
      // });
    } catch (error) {
      this.loadVisible = false;
      console.log('error => ', error);
    }
  }


  respostaFiltro(e: any) {
    if (e.filtro) {
      Object.assign(this.socketFiltro, e.filtro);

      if (this.socketFiltro.data_inicial) {
        this.socketFiltro.data_inicial = moment(this.socketFiltro.data_inicial).utc().format();
      }

      if (this.socketFiltro.data_final) {
        this.socketFiltro.data_final = moment(this.socketFiltro.data_final).utc().format();
      }

      this.socketIo.emit('getAcompanhamento', this.socketFiltro);
    }

  }
}
