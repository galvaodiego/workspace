import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from 'src/app/shared/shared.module';

import { AcompDiarioComponent } from './acomp-diario.component';
import { WebViewComponent } from './web-view/web-view.component';
import { DataGridComponent } from './componentes/data-grid/data-grid.component' ;
import { FiltroComponent } from './filtro/filtro.component';
import { ReactiveFormsModule } from '@angular/forms';
import { StackedBarComponent } from './componentes/stacked-bar/stacked-bar.component';
import { LineChartComponent } from './componentes/line-chart/line-chart.component';
import { DataGridResumoComponent } from './componentes/data-grid-resumo/data-grid-resumo.component';
import { LineChartDualComponent } from './componentes/line-chart-dual/line-chart-dual.component';
import { SingleBarComponent } from './componentes/single-bar/single-bar.component';

@NgModule({
    declarations: [
        AcompDiarioComponent,
        WebViewComponent,
        DataGridComponent,
        FiltroComponent,
        StackedBarComponent,
        LineChartComponent,
        DataGridResumoComponent,
        LineChartDualComponent,
        SingleBarComponent,
        
    ],
    imports: [
        CommonModule,
        SharedModule,
        ReactiveFormsModule
    ]
})
export class AcompDiarioModule { }