import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GuardaRotas } from 'src/app/shared/guards/guarda-rotas.guard';
import { IndicadoresComponent } from './indicadores/indicadores.component';
import { IndicadoresDetalhesComponent } from './indicadores/indicadores-detalhes/indicadores-detalhes.component';
import { MapaRastreamentoComponent } from './mapa-rastreamento/mapa-rastreamento.component';
import { ControleFreteComponent } from './controle-frete/controle-frete.component';
import { AcompDiarioComponent } from './acomp-diario/acomp-diario.component';


const routes: Routes = [
   { path: '', redirectTo: 'indicadores', pathMatch: 'full' },
   { path: 'indicadores', component: IndicadoresComponent, canActivate: [GuardaRotas] },
   { path: 'indicadores/detalhes', component: IndicadoresDetalhesComponent, canActivate: [GuardaRotas] },
   { path: 'mapa-rastreamento', component: MapaRastreamentoComponent, canActivate: [GuardaRotas] },
   {
      path: 'controle-frete',
      component: ControleFreteComponent,
      canActivate: [GuardaRotas],
      data: {
         modulo: 'controle-frete'
      }
   },
   {
      path: 'acompanhamento-diario',
      component: AcompDiarioComponent,
      canActivate: [GuardaRotas],
      data: {
         modulo: 'acompanhamento-diario'
      }
   },
];

@NgModule({
   imports: [RouterModule.forChild(routes)],
   exports: [RouterModule]
})
export class LogisticoRoutingModule { }
