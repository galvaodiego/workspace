import { TestBed } from '@angular/core/testing';

import { ControleFreteService } from './controle-frete.service';

describe('ControleFreteService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ControleFreteService = TestBed.get(ControleFreteService);
    expect(service).toBeTruthy();
  });
});
