import { Component, OnInit, Input, Output, EventEmitter, ViewChild, ChangeDetectorRef } from '@angular/core';
import { FormGroup, FormControl, FormBuilder } from '@angular/forms';
import * as moment from 'moment';
import { DxoPopupComponent } from 'devextreme-angular/ui/nested';
import { ControleFreteService } from '../controle-frete.service';
import { MediaMatcher } from '@angular/cdk/layout';

@Component({
   // tslint:disable-next-line: component-selector
   selector: 'cf-filtro',
   templateUrl: './filtro.component.html',
   styleUrls: ['./filtro.component.scss']
})
export class FiltroComponent implements OnInit {
   @Input() dados: any;
   @Output() filterChange: EventEmitter<any> = new EventEmitter();
   @ViewChild('popFilter') popFilter: DxoPopupComponent;
   public filtroForm: FormGroup;
   popupVisible = false;
   startDateDe = moment().startOf('month').utc().format();
   startDateAte = moment().endOf('month').utc().format();
   public listaPeriodos = [
      { id: 1, label: '7 dias', amount: 7, unit: 'day' },
      { id: 2, label: '15 dias', amount: 15, unit: 'day' },
      { id: 3, label: '1 mês', amount: 1, unit: 'month' },
      { id: 4, label: '3 meses', amount: 3, unit: 'month' },
      { id: 5, label: '6 meses', amount: 6, unit: 'month' },
      { id: 6, label: '9 meses', amount: 9, unit: 'month' },
      { id: 7, label: '12 meses', amount: 1, unit: 'year' }
   ];
   mobileQuery: MediaQueryList;
   // tslint:disable-next-line: variable-name
   private _mobileQueryListener: () => void;
   constructor(
      private formBuilder: FormBuilder,
      public controleFreteService: ControleFreteService,
      media: MediaMatcher,
      changeDetectorRef: ChangeDetectorRef,

   ) {
      this.mobileQuery = media.matchMedia('(max-width: 600px)');
      this._mobileQueryListener = () => changeDetectorRef.detectChanges();
      // tslint:disable-next-line: deprecation
      this.mobileQuery.addListener(this._mobileQueryListener);
   }

   ngOnInit() {
      console.log('activeFilter', this.controleFreteService.activeFilter);
      this._buildForm();
   }

   private _buildForm() {
      this.filtroForm = this.formBuilder.group({
         data_inicial: null,
         data_final: null,
         veiculo_id: new FormControl({ value: null, disabled: false }),
         origem_id: new FormControl({ value: null, disabled: false }),
         destino_id: new FormControl({ value: null, disabled: false }),
         estado: new FormControl({ value: null, disabled: false })
      });
   }

   filtrar() {
      this.filterChange.emit({ filtro: this.filtroForm.value });
   }

   limparFiltros(event: Event): void {
      event.preventDefault();
      this.filtroForm.reset();
      this.filterChange.emit({ filtro: this.filtroForm.value });
   }

   private _setPeriodo(data) {
      this.filtroForm.get('data_inicial').setValue(data);
      const date = moment().format('YYYY-MM-DDTHH:mm:ssZ');
      this.filtroForm.get('data_final').setValue(date);
      this.filtrar();
   }

   selecionarPeriodo(periodo) {
      moment.locale('pt-br');
      const data = moment()
         .subtract(periodo.amount, periodo.unit)
         .format('YYYY-MM-DDTHH:mm:ssZ');
      this._setPeriodo(data);
   }

   close() {
      if (this.popFilter) {
         this.popFilter.instance.hide();
      }
   }

   selectChange(e) {
      console.log('select', e);
      this.filtrar();

   }

}
