import { Injectable } from '@angular/core';
import * as  moment from 'moment';
@Injectable({
   providedIn: 'root'
})
export class ControleFreteService {
   activeFilter: ActiveFilter;

   datasourceDummy = {
      lista: {
         custoFretePorEstado: {
            dados: [
               { chave: 'SP', valor: 150 },
               { chave: 'PR', valor: 200 },
               { chave: 'SC', valor: 300 },
               { chave: 'RJ', valor: 1000 },
               { chave: 'RR', valor: 50 },
               { chave: 'MT', valor: 125 },
               { chave: 'MG', valor: 333 },
               { chave: 'SE', valor: 666 },

               { chave: 'PI', valor: 1050 },
               { chave: 'BA', valor: 550 },
               { chave: 'PE', valor: 950 },
               { chave: 'RO', valor: 123 },
               { chave: 'TO', valor: 178 }
            ]
         },
         volumeTransportadoPorEstado: {
            dados: [
               { chave: 'SP', valor: 150 },
               { chave: 'PR', valor: 200 },
               { chave: 'SC', valor: 300 },
               { chave: 'RJ', valor: 1000 },
               { chave: 'RR', valor: 50 },
               { chave: 'MT', valor: 125 },
               { chave: 'MG', valor: 333 },
               { chave: 'SE', valor: 666 },

               { chave: 'PI', valor: 1050 },
               { chave: 'BA', valor: 550 },
               { chave: 'PE', valor: 950 },
               { chave: 'RO', valor: 123 },
               { chave: 'TO', valor: 178 }
            ]
         },
         custoFretePorMes: {
            dados: [
               { chave: 'SP', valor: 150 },
               { chave: 'PR', valor: 200 },
               { chave: 'SC', valor: 300 },
               { chave: 'RJ', valor: 1000 },
               { chave: 'RR', valor: 50 },
               { chave: 'MT', valor: 125 },
               { chave: 'MG', valor: 333 },
               { chave: 'SE', valor: 666 },

               { chave: 'PI', valor: 1050 },
               { chave: 'BA', valor: 550 },
               { chave: 'PE', valor: 950 },
               { chave: 'RO', valor: 123 },
               { chave: 'TO', valor: 178 }
            ]
         },
         acompDiferencaFrete: {
            dados: [
               { chave: 'JAN', valor: 500, valor2: 400 },
               { chave: 'FEV', valor: 1500, valor2: 2400 },
               { chave: 'MAR', valor: 2500, valor2: 1400 },
               { chave: 'ABR', valor: 3500, valor2: 2400 },
               { chave: 'MAI', valor: 4500, valor2: 1400 },
               { chave: 'JUN', valor: 5500, valor2: 2400 },
            ]
         },
         valorMedioPorEstado: {
            dados: [
               { chave: 'SP', valor: 150 },
               { chave: 'PR', valor: 200 },
               { chave: 'SC', valor: 300 },
               { chave: 'RJ', valor: 1000 },
               { chave: 'RR', valor: 50 },
               { chave: 'MT', valor: 125 },
               { chave: 'MG', valor: 333 },
               { chave: 'SE', valor: 666 },

               { chave: 'PI', valor: 1050 },
               { chave: 'BA', valor: 550 },
               { chave: 'PE', valor: 950 },
               { chave: 'RO', valor: 123 },
               { chave: 'TO', valor: 178 }
            ]
         }
      },
      graficos: {
         custoFretePorEstado: {
            dados: [
               { chave: 'SP', valor: 150 },
               { chave: 'PR', valor: 200 },
               { chave: 'SC', valor: 300 },
               { chave: 'RJ', valor: 1000 },
               { chave: 'RR', valor: 50 },
               { chave: 'MT', valor: 125 },
               { chave: 'MG', valor: 333 },
               { chave: 'SE', valor: 666 },

               { chave: 'PI', valor: 1050 },
               { chave: 'BA', valor: 550 },
               { chave: 'PE', valor: 950 },
               { chave: 'RO', valor: 123 },
               { chave: 'TO', valor: 178 }
            ]
         },
         volumeTransportadoPorEstado: {
            dados: [
               { chave: 'SP', valor: 150 },
               { chave: 'PR', valor: 200 },
               { chave: 'SC', valor: 300 },
               { chave: 'RJ', valor: 1000 },
               { chave: 'RR', valor: 50 },
               { chave: 'MT', valor: 125 },
               { chave: 'MG', valor: 333 },
               { chave: 'SE', valor: 666 },

               { chave: 'PI', valor: 1050 },
               { chave: 'BA', valor: 550 },
               { chave: 'PE', valor: 950 },
               { chave: 'RO', valor: 123 },
               { chave: 'TO', valor: 178 }
            ]
         },
         custoFretePorMes: {
            dados: [
               { chave: 'SP', valor: 150 },
               { chave: 'PR', valor: 200 },
               { chave: 'SC', valor: 300 },
               { chave: 'RJ', valor: 1000 },
               { chave: 'RR', valor: 50 },
               { chave: 'MT', valor: 125 },
               { chave: 'MG', valor: 333 },
               { chave: 'SE', valor: 666 },

               { chave: 'PI', valor: 1050 },
               { chave: 'BA', valor: 550 },
               { chave: 'PE', valor: 950 },
               { chave: 'RO', valor: 123 },
               { chave: 'TO', valor: 178 }
            ]
         },
         acompDiferencaFrete: {
            dados: [
               { chave: 'JAN', valor: 500, valor2: 400 },
               { chave: 'FEV', valor: 1500, valor2: 2400 },
               { chave: 'MAR', valor: 2500, valor2: 1400 },
               { chave: 'ABR', valor: 3500, valor2: 2400 },
               { chave: 'MAI', valor: 4500, valor2: 1400 },
               { chave: 'JUN', valor: 5500, valor2: 2400 },
            ]
         },
         valorMedioPorEstado: {
            dados: [
               { chave: 'SP', valor: 150 },
               { chave: 'PR', valor: 200 },
               { chave: 'SC', valor: 300 },
               { chave: 'RJ', valor: 1000 },
               { chave: 'RR', valor: 50 },
               { chave: 'MT', valor: 125 },
               { chave: 'MG', valor: 333 },
               { chave: 'SE', valor: 666 },

               { chave: 'PI', valor: 1050 },
               { chave: 'BA', valor: 550 },
               { chave: 'PE', valor: 950 },
               { chave: 'RO', valor: 123 },
               { chave: 'TO', valor: 178 }
            ]
         },
         qtdeViagemPorEstado: {
            dados: [
               { chave: 'SP', valor: 150 },
               { chave: 'PR', valor: 200 },
               { chave: 'SC', valor: 300 },
               { chave: 'RJ', valor: 1000 },
               { chave: 'RR', valor: 50 },
               { chave: 'MT', valor: 125 },
               { chave: 'MG', valor: 333 },
               { chave: 'SE', valor: 666 },

               { chave: 'PI', valor: 1050 },
               { chave: 'BA', valor: 550 },
               { chave: 'PE', valor: 950 },
               { chave: 'RO', valor: 123 },
               { chave: 'TO', valor: 178 }
            ]
         }
      }
   };
   today = moment();
   constructor() { }
}

export interface ActiveFilter {
   base: string;
   data_inicial: string;
   data_final: string;
   veiculo_id: Array<number>;
   origem_id: Array<number>;
   destino_id: Array<number>;
   estado: Array<string>;
}
