import { Component, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { Usuario } from 'src/app/shared/models/usuario.model';
import { MediaMatcher } from '@angular/cdk/layout';
import { environment } from 'src/environments/environment';
import * as moment from 'moment';
import io from 'socket.io-client';
import { ControleFreteService } from './controle-frete.service';


@Component({
   selector: 'app-controle-frete',
   templateUrl: './controle-frete.component.html',
   styleUrls: ['./controle-frete.component.scss']
})
export class ControleFreteComponent implements OnInit, OnDestroy {
   public user: Usuario = Usuario.instance;
   loadVisible = true;
   mobileQuery: MediaQueryList;
   // tslint:disable-next-line: variable-name
   private _mobileQueryListener: () => void;

   datasourceMaster: any;
   // Config Socket
   socketIo: any;
   socketRota = 'itinerario';
   socketMetodo = 'getItinerario';
   socketMetodoFiltro = 'getFiltro';
   socketFiltro: any;
   /***/
   filtroContent = {
      placa: [],
      estado: []
   };
   constructor(
      media: MediaMatcher,
      changeDetectorRef: ChangeDetectorRef,
      public controleFreteService: ControleFreteService
   ) {
      this.mobileQuery = media.matchMedia('(max-width: 600px)');
      this._mobileQueryListener = () => changeDetectorRef.detectChanges();
      // tslint:disable-next-line: deprecation
      this.mobileQuery.addListener(this._mobileQueryListener);
      this.socketIo = io(environment.socket_end_point_base + '/' + this.socketRota);
      this.socketFiltro = {
         base: this.user.ref.toLowerCase(),
      };
      // this.datasourceMaster = mabService.datasourceMaster;
      this.socket().then(() => { });
   }

   ngOnInit() {
   }
   ngOnDestroy(): void {
      this.socketIo.disconnect();
      // tslint:disable-next-line: deprecation
      this.mobileQuery.removeListener(this._mobileQueryListener);
   }

   async socket() {
      try {
         this.loadVisible = true;
         this.socketIo.emit(this.socketMetodo, this.socketFiltro);
         this.socketIo.emit(this.socketMetodoFiltro, this.socketFiltro);
         this.controleFreteService.activeFilter = this.socketFiltro;
         console.log('enviando o filtro:', this.socketFiltro);
         this.socketIo.on(this.socketRota, (data) => {
            this.datasourceMaster = data;
            // console.log('retorno do socket:', this.socketRota, data);
            // this.datasourceMaster = this.controleFreteService.datasourceDummy;
            this.loadVisible = false;
         });

         this.socketIo.on('filtro', (dataFiltro) => {
            console.log('dataFiltro', dataFiltro);
            this.filtroContent = dataFiltro;
         });
      } catch (error) {
         this.loadVisible = false;
         console.log('error => ', error);
      }
   }

   respostaFiltro(e: any) {
      if (e.filtro) {
         Object.assign(this.socketFiltro, e.filtro);

         if (this.socketFiltro.data_inicial) {
            this.socketFiltro.data_inicial = moment(this.socketFiltro.data_inicial).utc().format();
         }

         if (this.socketFiltro.data_final) {
            this.socketFiltro.data_final = moment(this.socketFiltro.data_final).utc().format();
         }

         this.socket().then(() => { });
      }
   }

}
