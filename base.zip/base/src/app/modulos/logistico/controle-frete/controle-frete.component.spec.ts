import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ControleFreteComponent } from './controle-frete.component';

describe('ControleFreteComponent', () => {
  let component: ControleFreteComponent;
  let fixture: ComponentFixture<ControleFreteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ControleFreteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ControleFreteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
