import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChartBarVComponent } from './chart-bar-v.component';

describe('ChartBarVComponent', () => {
  let component: ChartBarVComponent;
  let fixture: ComponentFixture<ChartBarVComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChartBarVComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChartBarVComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
