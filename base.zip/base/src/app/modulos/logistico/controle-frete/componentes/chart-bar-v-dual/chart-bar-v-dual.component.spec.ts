import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChartBarVDualComponent } from './chart-bar-v-dual.component';

describe('ChartBarVDualComponent', () => {
  let component: ChartBarVDualComponent;
  let fixture: ComponentFixture<ChartBarVDualComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChartBarVDualComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChartBarVDualComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
