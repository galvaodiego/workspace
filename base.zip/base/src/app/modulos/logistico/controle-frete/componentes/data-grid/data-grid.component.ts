import { Component, OnInit, Input } from '@angular/core';

@Component({
   // tslint:disable-next-line: component-selector
   selector: 'cf-data-grid',
   templateUrl: './data-grid.component.html',
   styleUrls: ['./data-grid.component.scss']
})
export class DataGridComponent implements OnInit {

   constructor() { }
   datasource: any;
   get value(): any {
      return this.datasource;
   }

   @Input('datasource')
   set value(val: any) {
      this.datasource = val;
      if (this.datasource) {
         // CODE HERE

      }

   }

   ngOnInit() {
   }

}
