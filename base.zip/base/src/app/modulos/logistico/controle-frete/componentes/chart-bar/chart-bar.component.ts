import { Component, OnInit, Input } from '@angular/core';

import { getPalette } from 'devextreme/viz/palette';
import * as _ from 'underscore';

@Component({
   // tslint:disable-next-line: component-selector
   selector: 'cf-chart-bar',
   templateUrl: './chart-bar.component.html',
   styleUrls: ['./chart-bar.component.scss']
})
export class ChartBarComponent implements OnInit {

   constructor() { }
   datasource: any;
   get value(): any {
      return this.datasource;
   }

   @Input('datasource')
   set value(val: any) {
      this.datasource = val;
      if (this.datasource) {
         // CODE HERE
         this.datasource = _.sortBy(this.datasource, 'valor');
      }

   }
   ngOnInit() {
   }

   customizePointMultiple = (arg: any) => {
      const tipo = 'Soft';

      const palette = getPalette(tipo);
      const index = arg.index % (palette.simpleSet.length - 1);
      return { color: palette.simpleSet[index] };
   }

}
