import { Component, OnInit, Input } from '@angular/core';

@Component({
   selector: 'app-mobile-view',
   templateUrl: './mobile-view.component.html',
   styleUrls: ['./mobile-view.component.scss']
})
export class MobileViewComponent implements OnInit {

   constructor() { }
   datasourceMaster: any;
   trigger = {
      custoFrete: false,
      volumeEstado: false,
      custoFreteMes: false,
      acompFrete: false,
      valorMedioEstado: false,
   };
   get value(): any {
      return this.datasourceMaster;
   }

   @Input('datasourceMaster')
   set value(val: any) {
      this.datasourceMaster = val;
      if (this.datasourceMaster) {
         // CODE HERE
      }

   }
   ngOnInit() {
   }

   trocaView(e) {
      console.log('slide', e);
      switch (e.source.name) {
         case 'custoFrete':
            this.trigger.custoFrete = e.checked;
            break;
         case 'volumeEstado':
            this.trigger.volumeEstado = e.checked;
            break;
         case 'custoFreteMes':
            this.trigger.custoFreteMes = e.checked;
            break;
         case 'acompFrete':
            this.trigger.acompFrete = e.checked;
            break;
         case 'valorMedioEstado':
            this.trigger.valorMedioEstado = e.checked;
            break;

      }
   }

}
