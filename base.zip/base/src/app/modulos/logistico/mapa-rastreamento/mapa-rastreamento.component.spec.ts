import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MapaRastreamentoComponent } from './mapa-rastreamento.component';

describe('MapaRastreamentoComponent', () => {
  let component: MapaRastreamentoComponent;
  let fixture: ComponentFixture<MapaRastreamentoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MapaRastreamentoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MapaRastreamentoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
