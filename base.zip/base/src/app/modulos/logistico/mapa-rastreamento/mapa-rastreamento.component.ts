import { Component, OnInit } from '@angular/core';

@Component({
   selector: 'app-mapa-rastreamento',
   templateUrl: './mapa-rastreamento.component.html',
   styleUrls: ['./mapa-rastreamento.component.scss']
})
export class MapaRastreamentoComponent implements OnInit {
   // mapMarkerUrl = 'https://js.devexpress.com/Demos/RealtorApp/images/map-marker.png';
   mapMarkerUrl = 'assets/images/mapa/truckMarkerBlue.png';
   datasource = [
      {placa: 'AXN-5333', motorista: 'João da Silva', tempo: '00:35:00'},
      {placa: 'AMB-3205', motorista: 'João da Silva 2', tempo: '00:35:00'},
      {placa: 'AXN-5051', motorista: 'João da Silva 3', tempo: '00:35:00'},
      {placa: 'AXN-8J09', motorista: 'João da Silva 4', tempo: '00:35:00'},
      {placa: 'AXN-8G00', motorista: 'João da Silva 5', tempo: '00:35:00'}
   ];

   /*
   : placa AXN-5333 lat:-29.422 long:-49.873
     placa AMB-3205 lat:-23.514 long:-46.667
     placa AXN-5051 lat:-26.249 long:-48.843
     placa:AXN-8J09 lat:-23.896 long:-46.302
     placa:AXN-8G00 lat:-23.757 long:-46.454
   */

   markers: any = [
      {
         location: [-29.422, -49.873],
         iconSrc: 'assets/images/mapa/truckMarkerRed.png',
         tooltip: {
            isShown: false,
            text: 'AXN-5333'
         }
      },
      {
         location: [-23.514, -46.667],
         iconSrc: 'assets/images/mapa/truckMarkerRed.png',
         tooltip: {
            isShown: false,
            text: 'AMB-3205'
         }
      },
      {
         location: [-26.249, -48.843],
         tooltip: {
            isShown: false,
            text: 'AXN-5051'
         }
      },
      {
         location: [-23.896, -46.302],
         tooltip: {
            isShown: false,
            text: 'AXN-8J09'
         }
      },
      {
         location: [-23.757, -46.454],

         tooltip: {
            isShown: false,
            text: 'AXN-8G00'
         }
      },
   ];
   constructor() { }

   ngOnInit() {
   }

}
