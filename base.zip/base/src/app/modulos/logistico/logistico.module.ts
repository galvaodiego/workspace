import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IndicadoresComponent } from './indicadores/indicadores.component';
import { HttpClientModule } from '@angular/common/http';

// components
import { LogisticoCardComponent } from './indicadores/logistico-card/logistico-card.component';
import { IndicadoresDetalhesComponent } from './indicadores/indicadores-detalhes/indicadores-detalhes.component';
import { IndicadoresService } from './indicadores/indicadores.service';
import { SharedModule } from 'src/app/shared/shared.module';
import { MapaRastreamentoComponent } from './mapa-rastreamento/mapa-rastreamento.component';

import { LogisticoRoutingModule } from './logistico-routing.module';
import { ControleFreteComponent } from './controle-frete/controle-frete.component';
import { WebViewComponent } from './controle-frete/web-view/web-view.component';
import { ChartBarComponent } from './controle-frete/componentes/chart-bar/chart-bar.component';
import { DataGridComponent } from './controle-frete/componentes/data-grid/data-grid.component';
import { ChartLineComponent } from './controle-frete/componentes/chart-line/chart-line.component';
import { ChartBarVDualComponent } from './controle-frete/componentes/chart-bar-v-dual/chart-bar-v-dual.component';
import { ChartBarVComponent } from './controle-frete/componentes/chart-bar-v/chart-bar-v.component';
import { FiltroComponent } from './controle-frete/filtro/filtro.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MobileViewComponent } from './controle-frete/mobile-view/mobile-view.component';
import { AcompDiarioModule } from './acomp-diario/acomp-diario.module';



@NgModule({
   declarations: [
      IndicadoresComponent,
      LogisticoCardComponent,
      IndicadoresDetalhesComponent,
      MapaRastreamentoComponent,
      ControleFreteComponent,
      WebViewComponent,
      ChartBarComponent,
      DataGridComponent,
      ChartLineComponent,
      ChartBarVDualComponent,
      ChartBarVComponent,
      FiltroComponent,
      MobileViewComponent,
      WebViewComponent
   ],
   imports: [
      CommonModule,
      HttpClientModule,
      SharedModule,
      LogisticoRoutingModule,
      FormsModule,
      ReactiveFormsModule,
      AcompDiarioModule
   ],
   providers: [IndicadoresService]
})
export class LogisticoModule { }
