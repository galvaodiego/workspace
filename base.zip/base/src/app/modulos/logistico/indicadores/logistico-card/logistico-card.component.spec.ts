import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LogisticoCardComponent } from './logistico-card.component';

describe('LogisticoCardComponent', () => {
  let component: LogisticoCardComponent;
  let fixture: ComponentFixture<LogisticoCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LogisticoCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LogisticoCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
