import { Component, OnInit } from '@angular/core';
import { GatewayService } from 'src/app/shared/services/gateway.service';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
   selector: 'app-indicadores',
   templateUrl: './indicadores.component.html',
   styleUrls: ['./indicadores.component.scss']
})
export class IndicadoresComponent implements OnInit {
   loadVisible = false;
   public infoModulo: any;
   public previsto = 0;
   public atraso = 0;
   public totalVeiculos = 0;
   public totalStatus = 0;
   public percServico = 0;
   public listaStatus: any = [];
   public listaStatusResumo: any = [];
   public listaStatusServico: any = [];
   constructor(
      private gateway: GatewayService,
      private iconRegistry: MatIconRegistry,
      private sanitizer: DomSanitizer
   ) {
      iconRegistry.addSvgIcon('CARGA', sanitizer.bypassSecurityTrustResourceUrl('assets/images/logistico/CARGA.svg'));
      iconRegistry.addSvgIcon('DESCARGA', sanitizer.bypassSecurityTrustResourceUrl('assets/images/logistico/DESCARGA.svg'));
      iconRegistry.addSvgIcon('DESTINADO', sanitizer.bypassSecurityTrustResourceUrl('assets/images/logistico/DESTINADO.svg'));
      iconRegistry.addSvgIcon('FRONTEIRA', sanitizer.bypassSecurityTrustResourceUrl('assets/images/logistico/FRONTEIRA.svg'));
      iconRegistry.addSvgIcon('MANUTENÇÃO', sanitizer.bypassSecurityTrustResourceUrl('assets/images/logistico/MANUTENÇÃO.svg'));
      iconRegistry.addSvgIcon('VAZIO', sanitizer.bypassSecurityTrustResourceUrl('assets/images/logistico/VAZIO.svg'));
      iconRegistry.addSvgIcon('VIAGEM', sanitizer.bypassSecurityTrustResourceUrl('assets/images/logistico/VIAGEM.svg'));
      iconRegistry.addSvgIcon('ADUANA', sanitizer.bypassSecurityTrustResourceUrl('assets/images/logistico/ADUANA.svg'));
   }

   ngOnInit() {
      this.getData();
   }

   async getData() {
      this.loadVisible = true;

      try {
         const response: any = await this.gateway.backendCall('1811-APPGESTOR', 'getIndicadorLogistico');
         console.log('response', response);
         this.listaStatusResumo = response.logistico;
         const temp = [];
         response.logistico.forEach(
            (el) => {
               if (el.status !== 'Vazio' && el.status !== 'Manutenção') {
                  temp.push(el);
               }
            }
         );
         this.listaStatusServico = temp;
         this.sumTotalVeiculos(this.listaStatusResumo); // array completo
         this.sumPrevAtraso(this.listaStatusServico); // array sem o Status VAZIO e MANUTENÇÃO
         this.sumPorcentagemServico(this.listaStatusServico);

         // console.log('root', this.rootItems);
         this.loadVisible = false;
      } catch (error) {
         console.log('Error:', error);
      }
   }

   /*
   * Porcentagem de veiculos por status em relação ao Nº total de veiculos
   * @param dados
   */
   public sumPorcentagem(dados) {
      const temp = [];
      dados.lista.forEach(
         (el) => {
            temp.push(el);
         }
      );
      const tempPrev = temp.map((tupla) => {
         return Number.parseFloat(tupla.previsto);
      }).reduce((anterior, atual) => {
         return (anterior + atual);
      }, 0);

      const tempAtra = temp.map((tupla) => {
         return Number.parseFloat(tupla.atraso);
      }).reduce((anterior, atual) => {
         return (anterior + atual);
      }, 0);

      this.totalStatus = tempPrev + tempAtra;
      const sum = this.totalStatus / this.totalVeiculos * 100;
      return parseFloat(sum.toFixed(0));
   }

   /*
   * Soma o total de veiculos
   */
   public sumTotalVeiculos(dados) {
      const temp = [];
      dados.forEach(
         (el) => {
            el.lista.forEach(
               (it) => {
                  temp.push(it);
               }
            );
         }
      );
      this.previsto = temp.map((tupla) => {
         return Number.parseFloat(tupla.previsto);
      }).reduce((anterior, atual) => {
         return (anterior + atual);
      }, 0);

      this.atraso = temp.map((tupla) => {
         return Number.parseFloat(tupla.atraso);
      }).reduce((anterior, atual) => {
         return (anterior + atual);
      }, 0);

      this.totalVeiculos = this.previsto + this.atraso;

   }


   //////////////////////////////////////////////////////////////////////////
   //                              SERVIÇO                                 //
   //////////////////////////////////////////////////////////////////////////

   /*
   * Porcentagem de veiculos por status em relação ao Nº total de veiculos
   * @param dados
   */
   public sumPorcentagemServico(dados) {
      const temp = [];
      dados.forEach(
         (el) => {
            el.lista.forEach(
               (it) => {
                  temp.push(it);
               }
            );
         }
      );

      const tempPrev = temp.map((tupla) => {
         return Number.parseFloat(tupla.previsto);
      }).reduce((anterior, atual) => {
         return (anterior + atual);
      }, 0);

      // let tempAtra = temp.map((tupla) => {
      //     return Number.parseFloat(tupla['atraso'])
      // }).reduce((anterior, atual) => {
      //     return (anterior + atual);
      // }, 0);

      // let cont = tempPrev + tempAtra;
      const sum = tempPrev / this.totalVeiculos * 100;
      this.percServico = parseFloat(sum.toFixed(0));
   }



   /*
   * Soma os totais por status
   */
   public sumStatus(dados) {
      const temp = [];
      dados.lista.forEach(
         (el) => {
            temp.push(el);
         }
      );
      const tempPrev = temp.map((tupla) => {
         return Number.parseFloat(tupla.previsto);
      }).reduce((anterior, atual) => {
         return (anterior + atual);
      }, 0);

      const tempAtra = temp.map((tupla) => {
         return Number.parseFloat(tupla.atraso);
      }).reduce((anterior, atual) => {
         return (anterior + atual);
      }, 0);

      this.totalStatus = tempPrev + tempAtra;
      return this.totalStatus;
   }

   /*
   * Soma os valores de Previstos e Atrasados da lista de Serviços
   */
   public sumPrevAtraso(dados) {
      const temp = [];
      dados.forEach(
         (el) => {
            el.lista.forEach(
               (it) => {
                  temp.push(it);
               }
            );
         }
      );
      this.previsto = temp.map((tupla) => {
         return Number.parseFloat(tupla.previsto);
      }).reduce((anterior, atual) => {
         return (anterior + atual);
      }, 0);

      this.atraso = temp.map((tupla) => {
         return Number.parseFloat(tupla.atraso);
      }).reduce((anterior, atual) => {
         return (anterior + atual);
      }, 0);
   }



}
