import { Injectable } from '@angular/core';

@Injectable({
   providedIn: 'root'
})
export class IndicadoresService {
   public dados: any;
   public status: string;
   public modo: number;
   constructor() { }

   get() {
      return this;
   }
   set(data) {
      this.dados = data.dados;
      this.status = data.status;
      this.modo = data.modo;

      localStorage.setItem('indicador-detalhes', JSON.stringify(data));
   }
}
