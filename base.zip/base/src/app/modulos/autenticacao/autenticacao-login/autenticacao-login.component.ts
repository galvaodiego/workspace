import { Component, OnInit, ViewChild, AfterViewInit, ChangeDetectorRef } from '@angular/core';
import { MatHorizontalStepper } from '@angular/material/stepper';
import { Usuario } from 'src/app/shared/models/usuario.model';
import { UsuarioService } from 'src/app/shared/services/usuario.service';
import { ClienteService } from 'src/app/shared/services/cliente.service';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';

@Component({
   selector: 'app-autenticacao-login',
   templateUrl: './autenticacao-login.component.html',
   styleUrls: ['./autenticacao-login.component.scss']
})
export class AutenticacaoLoginComponent implements OnInit, AfterViewInit {
   @ViewChild('stepper') stepper: MatHorizontalStepper;

   public user: Usuario = Usuario.instance;
   public version: string;
   step1Status: boolean;
   step2Status: boolean;
   clienteSelecionado = false;
   dadosCliente = {
      ref: '',
      logo: '',
      nome: ''
   };

   selectedIndex = 0;

   constructor(
      private cdRef: ChangeDetectorRef,
      private router: Router
   ) {
      this.version = environment.version;
   }

   ngOnInit() {
      if (this.user.isLogged) {
         this.router.navigate(['/home']);
      }
   }

   ngAfterViewInit(): void {
      const cliente = JSON.parse(localStorage.getItem('cliente-selecionado'));
      if (cliente) {
         this.clienteSelecionado = true;
         Object.assign(this.dadosCliente, cliente);
         this.cdRef.detectChanges();
      }
   }

   atualizar() {
      location.reload();
   }


}
