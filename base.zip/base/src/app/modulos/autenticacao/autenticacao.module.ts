import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AutenticacaoLoginComponent } from './autenticacao-login/autenticacao-login.component';
import { FormsModule, FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { StepClienteComponent } from './autenticacao-login/step-cliente/step-cliente.component';
import { StepAcessoComponent } from './autenticacao-login/step-acesso/step-acesso.component';
import { SharedModule } from 'src/app/shared/shared.module';


@NgModule({
   declarations: [AutenticacaoLoginComponent, StepClienteComponent, StepAcessoComponent],
   imports: [
      CommonModule,
      FormsModule,
      SharedModule,
      ReactiveFormsModule,
   ],
   exports: [
      AutenticacaoLoginComponent
   ],
    providers: [FormBuilder]

})
export class AutenticacaoModule { }
