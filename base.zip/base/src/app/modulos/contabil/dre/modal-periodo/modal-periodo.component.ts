import { Component, OnInit, Inject } from '@angular/core';
import { Location } from '@angular/common';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';


export interface DialogData {
   layoutsPorAno: any;
}

@Component({
   selector: 'app-modal-periodo',
   templateUrl: './modal-periodo.component.html',
   styleUrls: ['./modal-periodo.component.scss']
})

export class ModalPeriodoComponent implements OnInit {
   constructor(
      public dialogRef: MatDialogRef<ModalPeriodoComponent>,
      @Inject(MAT_DIALOG_DATA) public data: DialogData,
      private location: Location
   ) {

   }

   ngOnInit() {
      // console.log(this.data.layoutsPorAno);
   }

   cancel() {
      this.location.back();
   }

   seleciona(layouts) {
      this.dialogRef.close({layouts});
   }

}
