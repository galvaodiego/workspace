import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GuardaRotas } from 'src/app/shared/guards/guarda-rotas.guard';
import { DreComponent } from './dre/dre.component';



const routes: Routes = [
   { path: '', redirectTo: 'dre', pathMatch: 'full' },
   { path: 'dre', component: DreComponent, canActivate: [GuardaRotas] },

];

@NgModule({
   imports: [RouterModule.forChild(routes)],
   exports: [RouterModule]
})
export class ContabilRoutingModule { }
