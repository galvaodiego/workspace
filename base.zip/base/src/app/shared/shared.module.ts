import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

// components
import { NavBarComponent } from './components/nav-bar/nav-bar.component';
import { TreeListComponent } from './components/tree-list/tree-list.component';
import { NavBarMobileComponent } from './components/nav-bar-mobile/nav-bar-mobile.component';
import { DxPopupModule } from 'devextreme-angular';
import { MaterialModule } from './modules/material/material.module';
import { DevextremeModule } from './modules/devextreme/devextreme.module';
import { TopFiltroComponent } from './components/top-filtro/top-filtro.component';
import { LogoutScreenComponent } from './components/logout-screen/logout-screen.component';
import { FloatBoxComponent } from './components/float-box/float-box.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';



@NgModule({
   declarations: [NavBarComponent, TreeListComponent, NavBarMobileComponent, TopFiltroComponent, LogoutScreenComponent, FloatBoxComponent],
   imports: [
      CommonModule,
      RouterModule,
      MaterialModule,
      DevextremeModule,
      DxPopupModule,
      FormsModule,
      ReactiveFormsModule,
   ],
   exports: [
      MaterialModule,
      DevextremeModule,
      NavBarComponent,
      NavBarMobileComponent,
      TreeListComponent
   ],
})
export class SharedModule { }
