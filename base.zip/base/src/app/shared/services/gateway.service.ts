import { Injectable } from '@angular/core';
import { Usuario } from '../models/usuario.model';
import { Headers, Http } from '@angular/http';
import { Router } from '@angular/router';
import notify from 'devextreme/ui/notify';
import { NotificacaoService } from './notificacao.service';


@Injectable({
   providedIn: 'root'
})
export class GatewayService {
   private user: Usuario = Usuario.instance;
   private url: string;
   constructor(
      // tslint:disable-next-line: deprecation
      private http: Http,
      private router: Router,
      private notificacao: NotificacaoService
   ) { }

   public backendCall(module: string, operation: string, parameters?: any) {
      if (this.user.url == null || this.user.url === '') {
         this.user.url = location.protocol + '//' + location.host;
      }
      this.url = this.user.url + '_remote/gateway.php';

      // tslint:disable-next-line: deprecation
      const headers: Headers = new Headers();
      if (parameters == null) {
         parameters = {};
      }

      const requestData: any = {
         module,
         operation,
         parameters
      };

      headers.append('Content-Type', 'application/json');
      if (this.user.token) {
         headers.append('Authorization', 'Bearer ' + this.user.token);
      } else {
         headers.append('Token-Time-Hours', (180 * 24) + ''); // 180 dias
      }
      // if (this.user.isDebug) {
      headers.append('Debug', '1');
      // }
      headers.append('KMM-Platform', 'Web');

      console.log('Requisição ao banco: ', requestData);

      return new Promise((resolvePai, rejectPai) => {
         this.send(this.url, requestData, headers).then(
            (data) => {
               data = data.json();
               if (data.result != null) {
                  resolvePai(data.result);
               } else {
                  resolvePai(data);
               }
            }
         ).catch(
            (dataError) => {
               dataError = dataError.json();
               console.log('dataError', dataError);

               // Não autorizado - Quando o token é inválido ou expirado
               if (dataError.code === 401) {
                  //  notify({
                  //      message: 'Autenticação expirada. Faça novamente o login.',
                  //      type: 'error',
                  //      displayTime: 200000,
                  //      closeOnClick: true,
                  //      width: () => window.innerWidth / 1.8
                  //  });
                  this.notificacao.openSnackBar('Autenticação expirada. Faça novamente o login');
                  this.user.logout();
               } else if (dataError.code === 403) {
                  // notify({
                  //    message: dataError.message,
                  //    type: 'error',
                  //    displayTime: 200000,
                  //    closeOnClick: true,
                  //    width: () => window.innerWidth / 1.8
                  // });
                  console.log('dataError', dataError);
                  this.notificacao.openSnackBar(dataError.message);
                  this.user.logout();
                  this.router.navigate(['']);
                  rejectPai(dataError);
               } else if (dataError.code === 404) {
                  // notify({
                  //    message: 'Não Encontrado',
                  //    type: 'error',
                  //    displayTime: 200000,
                  //    closeOnClick: true,
                  //    width: () => window.innerWidth / 1.8
                  // });
                  this.notificacao.openSnackBar('Não Encontrado');
                  this.user.logout();
               } else {
                  try {
                     // this.errorM = dataError.message;
                     // notify({
                     //    message: dataError.message,
                     //    type: 'error',
                     //    displayTime: 200000,
                     //    closeOnClick: true,
                     //    width: () => window.innerWidth / 1.8
                     // });
                     this.notificacao.openSnackBar(dataError.message);
                     console.log('dataError', dataError);
                  } catch (er) {
                     if (this.user.isDebug) {
                        // this.errorM = JSON.stringify(dataError);
                        // notify({
                        //    message: JSON.stringify(dataError),
                        //    type: 'error',
                        //    displayTime: 200000,
                        //    closeOnClick: true,
                        //    width: () => window.innerWidth / 1.8
                        // });

                        this.notificacao.openSnackBar(JSON.stringify(dataError));

                     }
                  }
                  rejectPai(dataError); // Chama o reject do promise de retorno
               }
            }
         );
      });
   }

   // tslint:disable-next-line: deprecation
   public send(url: string, requestData: any, headers: Headers): Promise<any> {
      return new Promise((resolve, reject) => {
         this.http.post(url, JSON.stringify(requestData), { headers }).subscribe(
            data => resolve(data),
            err => reject(err));
      });

   }
}
