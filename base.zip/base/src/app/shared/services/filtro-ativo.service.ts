import { Injectable } from '@angular/core';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';

@Injectable({
  providedIn: 'root'
})
export class FiltroAtivoService {
  public filtroForm: FormGroup;
  listaPeriodos = [
    { id: 0, label: 'Hoje', shortName: 'Hoje', amount: 0, unit: 'day' },
    { id: 1, label: '7 dias', shortName: '7D', amount: 7, unit: 'day' },
    { id: 2, label: '15 dias', shortName: '15D', amount: 15, unit: 'day' },
    { id: 3, label: '1 mês', shortName: '1M', amount: 1, unit: 'month' },
    { id: 4, label: '3 meses', shortName: '3M', amount: 3, unit: 'month' },
    { id: 5, label: '6 meses', shortName: '6M', amount: 6, unit: 'month' },
    { id: 6, label: '9 meses', shortName: '9M', amount: 9, unit: 'month' },
    { id: 7, label: '12 meses', shortName: '12M', amount: 1, unit: 'year' }
  ];
  constructor(private formBuilder: FormBuilder) {
    this._buildForm();
  }

  private _buildForm() {
    this.filtroForm = this.formBuilder.group({
      data_inicial: null,
      data_final: null,
      cliente_id: new FormControl({ value: null, disabled: false }),
      segmento_id: new FormControl({ value: null, disabled: false }),
      placa_id: new FormControl({ value: null, disabled: false }),
      mercadoria_id: new FormControl({ value: null, disabled: false })
    });
  }

  limparFiltros(event: Event): void {
    event.preventDefault();
    this.filtroForm.reset();
  }
}
