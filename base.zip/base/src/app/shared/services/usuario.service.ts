import { Injectable } from '@angular/core';
import { LocalStorageService } from 'ngx-webstorage';

import { Usuario } from '../models/usuario.model';
import { ClienteService } from './cliente.service';

@Injectable({ providedIn: 'root' })
export class UsuarioService {

   public user: Usuario = Usuario.instance;

   constructor(
      private storage: LocalStorageService,
      private clienteS: ClienteService
   ) { }

   /*
   * Inicia o objeto Usuario na aplicação.
   * Caso exista algum registro do usuário no storage, este método o retorna.
   * Caso contrário, o método formata um objeto para o usuário.
   */
   public init(): Promise<any> {
      return new Promise((resolve, reject) => {
         const data = this.storage.retrieve(this.clienteS.discover() + '-usuario');

         if (data == null) {
            this.user.usuario = '';
            this.user.url = '';
            this.user.ambiente = '';
            this.user.codGestao = null;
            this.user.token = '';
            this.user.tokenSocket = '';
            this.user.isLogged = false;
            this.user.listaModulos = [];
            this.user.selectedModulo = null;
            this.user.tvUsuarioId = null;
            this.user.userType = null;
            this.user.timerTela = null;
            this.user.identificador = null;
            this.user.cliente = '';
            this.user.ref = '';
            this.user.filiais = '';
            this.user.codPessoa = null;
            this.user.ultimoLogin = '';
            this.user.plataforma_tipo = null;
         } else {
            this.user.url = data.url;
            this.user.ambiente = data.ambiente;
            this.user.isLogged = data.isLogged;
            this.user.listaModulos = data.listaModulos;
            this.user.selectedModulo = data.selectedModulo;
            this.user.tvUsuarioId = data.tvUsuarioId;
            this.user.userType = data.userType;
            this.user.timerTela = data.timerTela;
            this.user.identificador = data.identificador;
            this.user.cliente = data.cliente;
            this.user.ref = data.ref;
            this.user.filiais = data.filiais;
            this.user.codPessoa = data.codPessoa;
            this.user.ultimoLogin = data.ultimoLogin;
            this.user.plataforma_tipo = data.plataforma_tipo;
            if (data.token != null) {
               try {
                  const tokenData = JSON.parse(atob(data.token.split('.')[0])).data;
                  this.user.usuario = tokenData.username;
                  this.user.codGestao = tokenData.cod_gestao;
                  this.user.token = data.token;
                  // this.user.tokenSocket = data.tokenSocket;
                  this.user.isLogged = true;
               } catch (error) {

               }
            } else {
               this.user.usuario = data.usuario;
               this.user.senha = data.senha;
               this.user.codGestao = data.codGestao;
               this.user.token = data.token;
               // this.user.tokenSocket = data.tokenSocket;
               this.save();
            }
         }
         resolve(this.user);
      });
   }

   /*
   * Salva os dados do usuário do storage.
   */
   public save() {
      const data = {
         usuario: this.user.usuario,
         url: this.user.url,
         ambiente: this.user.ambiente,
         codGestao: this.user.codGestao,
         token: this.user.token,
         tokenSocket: this.user.tokenSocket,
         isLogged: this.user.isLogged,
         filiais: this.user.filiais,
         listaModulos: this.user.listaModulos,
         selectedModulo: this.user.selectedModulo,
         tvUsuarioId: this.user.tvUsuarioId,
         userType: this.user.userType,
         timerTela: this.user.timerTela,
         identificador: this.user.identificador,
         cliente: this.user.cliente,
         ref: this.user.ref,
         codPessoa: this.user.codPessoa,
         ultimoLogin: this.user.ultimoLogin,
         plataforma_tipo: this.user.plataforma_tipo
      };
      this.storage.store(this.clienteS.discover() + '-usuario', data);
   }

}
