import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FloatBoxComponent } from './float-box.component';

describe('FloatBoxComponent', () => {
  let component: FloatBoxComponent;
  let fixture: ComponentFixture<FloatBoxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FloatBoxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FloatBoxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
