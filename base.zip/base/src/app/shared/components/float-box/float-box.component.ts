import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-float-box',
  templateUrl: './float-box.component.html',
  styleUrls: ['./float-box.component.scss']
})
export class FloatBoxComponent implements OnInit {
  isShown = false;
  constructor() { }

  ngOnInit() {
  }


  toggle() {
    this.isShown = !this.isShown;
  }

}
