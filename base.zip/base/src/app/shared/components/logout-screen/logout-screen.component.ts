import { Component, OnInit } from '@angular/core';
import { Usuario } from '../../models/usuario.model';
import { Router } from '@angular/router';

import { confirm } from 'devextreme/ui/dialog';
import { environment } from 'src/environments/environment';
import { Http } from '@angular/http';


@Component({
  selector: 'app-logout-screen',
  templateUrl: './logout-screen.component.html',
  styleUrls: ['./logout-screen.component.scss']
})
export class LogoutScreenComponent implements OnInit {
  public user: Usuario = Usuario.instance;
  version: string;
  constructor(
    private http: Http,
    private router: Router
  ) {
    this.version = environment.version;
  }

  ngOnInit() {
  }

  public logout() {
    const result = confirm(`Você tem certeza que deseja encerrar a sessão?`, 'Sair');
    result.then((dialogResult) => {
      if (dialogResult) {
        this.http.post(environment.socket_end_point_base + '/logout',
          {
            base: this.user.ref.toLowerCase(),
            usuario: this.user.usuario
          }
        ).subscribe(data => {
          // console.log('-->', data);
          if (data.ok) {
            this.user.logout();
            localStorage.clear();
            this.router.navigate(['']);
          } else {
            alert('Ocorreu um problema ao deslogar, consulte nosso suporte!');
          }

        });

      }
    });
  }
}
