import { Component, OnInit, Input } from '@angular/core';
import { trigger, style, transition, animate } from '@angular/animations';

@Component({
   selector: 'app-tree-list',
   templateUrl: './tree-list.component.html',
   styleUrls: ['./tree-list.component.scss'],
   animations: [
      trigger(
         'enterAnimation', [
         transition(':enter', [
            style({ height: '0', opacity: 0 }),
            animate('130ms', style({ height: '*', opacity: 1 }))
         ]),
         transition(':leave', [
            style({ height: '*', opacity: 1 }),
            animate('300ms', style({ height: 0, opacity: 0 }))
         ])
      ]
      )
   ]
})
export class TreeListComponent implements OnInit {
   @Input() item: any;
   @Input() nivel: number;
   @Input() visibleList: boolean;
   constructor() { }

   ngOnInit() {
   }


   public toggleList() {
      this.visibleList = !this.visibleList;
      // console.log('click', this.visibleList);
   }

   public sumChild(lista: Array<any>) {
      lista.forEach(
         (element) => {
            if (this.hasChildLevel(element)) {
               this.sumChild(element.children);
            } else {
               return lista.reduce((initial, next) => {
                  // console.log('soma', initial + next.valor);
                  // tslint:disable-next-line: no-unused-expression
                  return initial + next.valor, 0;
               });
            }
         }
      );
   }


   public hasChildLevel(item: any): boolean {
      if (item.layout) {
         return true;
      } else {
         return false;
      }
   }

   // tslint:disable-next-line: ban-types
   public hasProperty(item: Object, property: string) {
      if (item[property]) {
         return true;
      } else {
         return false;
      }
   }


   canSeeChildrenList(item: any) {
      if (this.hasChildLevel(item)) {
         if (item.layout.length > 0) {
            if (this.hasChildLevel(item.layout[0]) && this.visibleList) {
               return true;
            } else {
               return false;
            }
         }
      } else {
         return false;
      }
   }

   isLastVisibleItem(item) {
      if ((this.hasChildLevel(item)) && (item.layout.length > 0)) {
         // console.log('item.layout', item);
         if ((this.hasProperty(item.layout[0], 'org'))) {
            return true;
         } else {
            return false;
         }
      } else {
         return true;
      }
   }

}
