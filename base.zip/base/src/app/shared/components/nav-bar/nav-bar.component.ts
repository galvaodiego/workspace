import { Component, OnInit, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { MediaMatcher } from '@angular/cdk/layout';
import { DomSanitizer } from '@angular/platform-browser';
import { Platform } from '@angular/cdk/platform';
import { Usuario } from '../../models/usuario.model';
import { environment } from 'src/environments/environment';
import { MatIconRegistry } from '@angular/material/icon';
import { confirm } from 'devextreme/ui/dialog';
import { Router } from '@angular/router';
import { Http } from '@angular/http';


@Component({
   selector: 'app-nav-bar',
   templateUrl: './nav-bar.component.html',
   styleUrls: ['./nav-bar.component.scss']
})
export class NavBarComponent implements OnInit, OnDestroy {
   public user: Usuario = Usuario.instance;
   mobileQuery: MediaQueryList;
   compAtivo = 'logout';
   // tslint:disable-next-line: variable-name
   private _mobileQueryListener: () => void;
   version: string;
   cliente = {
      path: 'assets/images/clientes/kmm.png',
      descricao: 'KMM Engenharia de Software'
   };

   popupVisible = false;
   prod: any;

   constructor(
      private http: Http,
      changeDetectorRef: ChangeDetectorRef,
      media: MediaMatcher,
      public platform: Platform,
      iconRegistry: MatIconRegistry,
      sanitizer: DomSanitizer,
      private router: Router

   ) {
      this.mobileQuery = media.matchMedia('(max-width: 600px)');
      this._mobileQueryListener = () => changeDetectorRef.detectChanges();
      // tslint:disable-next-line: deprecation
      this.mobileQuery.addListener(this._mobileQueryListener);
      this.version = environment.version;
      this.prod = environment.production;
      const clienteSelecionado = JSON.parse(localStorage.getItem('cliente-selecionado'));
      if (clienteSelecionado) {
         this.cliente.path = clienteSelecionado.logo;
         this.cliente.descricao = clienteSelecionado.nome;
      }
   }

   ngOnInit() {
   }

   ngOnDestroy(): void {
      // tslint:disable-next-line: deprecation
      this.mobileQuery.removeListener(this._mobileQueryListener);
   }


   atualizar() {
      location.reload();
   }

   public logout() {
      const result = confirm(`Você tem certeza que deseja encerrar a sessão?`, 'Sair');
      result.then((dialogResult) => {
         if (dialogResult) {
            this.user.logout();
            localStorage.clear();
            this.router.navigate(['']);
         }
      });
   }

   getDetalhesMenu(modulo) {
      const obj = {
         nome: '',
         path: '',
         icon: '',
         mat_icon: ''
      };
      switch (modulo) {
         case 'extrato-faturamento':
            Object.assign(obj, {
               nome: 'Extrato de Faturamento',
               path: '/financeiro/extrato-faturamento',
               icon: 'extrato-faturamento', mat_icon: 'attach_money'
            });
            break;
         case 'acompanhamento-diario':
            Object.assign(obj, {
               nome: 'Acompanhamento Diário',
               path: '/logistico/acompanhamento-diario',
               icon: 'acomp-diario',
               mat_icon: 'date_range'
            });
            break;
         case 'controle-frete':
            Object.assign(obj, {
               nome: 'Controle de Frete',
               path: '/logistico/controle-frete',
               icon: 'controle-frete',
               mat_icon: 'local_shipping'
            });
            break;
         case 'mapa-abastecimento':
            Object.assign(obj, {
               nome: 'Mapa de Abastecimento',
               path: '/suprimentos/mapa-abastecimento',
               icon: 'mapa-abastecimento',
               mat_icon: 'local_gas_station'
            });
            break;

         default:
            Object.assign(obj, {
               nome: 'Permissão Pendente de Módulo: Contate o suporte!',
               path: '/',
               icon: 'app_blocking',
               mat_icon: 'app_blocking'
            });
            break;
      }

      return obj;
   }

}
