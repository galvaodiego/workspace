import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { Platform } from '@angular/cdk/platform';
import { MediaMatcher } from '@angular/cdk/layout';

@Component({
   selector: 'app-nav-bar-mobile',
   templateUrl: './nav-bar-mobile.component.html',
   styleUrls: ['./nav-bar-mobile.component.scss']
})
export class NavBarMobileComponent implements OnInit {
   mobileQuery: MediaQueryList;
   // tslint:disable-next-line: variable-name
   private _mobileQueryListener: () => void;
   constructor(
      public platform: Platform,
      changeDetectorRef: ChangeDetectorRef,
      media: MediaMatcher,
   ) {
      this.mobileQuery = media.matchMedia('(max-width: 600px)');
      this._mobileQueryListener = () => changeDetectorRef.detectChanges();
      // tslint:disable-next-line: deprecation
      this.mobileQuery.addListener(this._mobileQueryListener);
   }

   ngOnInit() {
   }

}
