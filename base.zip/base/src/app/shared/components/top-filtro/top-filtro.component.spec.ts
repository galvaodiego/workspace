import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TopFiltroComponent } from './top-filtro.component';

describe('TopFiltroComponent', () => {
  let component: TopFiltroComponent;
  let fixture: ComponentFixture<TopFiltroComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TopFiltroComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TopFiltroComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
