import { Component, OnInit } from '@angular/core';
import { FiltroAtivoService } from '../../services/filtro-ativo.service';

@Component({
  selector: 'app-top-filtro',
  templateUrl: './top-filtro.component.html',
  styleUrls: ['./top-filtro.component.scss']
})
export class TopFiltroComponent implements OnInit {

  constructor(
    public filtroAtivoService: FiltroAtivoService
  ) { }

  ngOnInit() {
  }

}
