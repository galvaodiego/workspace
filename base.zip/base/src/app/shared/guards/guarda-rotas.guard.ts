import { CanActivate, ActivatedRouteSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

import { Usuario } from '../models/usuario.model';
import { Http } from '@angular/http';
import { environment } from 'src/environments/environment';


@Injectable({ providedIn: 'root' })
export class GuardaRotas implements CanActivate {

    private user: Usuario = Usuario.instance;

    constructor(
        private http: Http,
        private router: Router,
    ) { }

    /**
     * Protege as Rotas dos Módulos
     */
    canActivate(route: ActivatedRouteSnapshot) {
        if (this.user.isLogged) {
            this.http.post(environment.socket_end_point_base + '/validate_route',
                {
                    base: this.user.ref.toLowerCase(),
                    usuario: this.user.usuario,
                    rota: route.routeConfig.path
                }
            ).subscribe(data => {
                // console.log('-->', data);
            });

            if (route.data.modulo === 'free') {
                return true;
            } else {
                if (this.user.listaModulos && this.user.listaModulos.length > 0) {
                    const lm: any = [... this.user.listaModulos];
                    let flag = false;
                    lm.forEach(element => {
                        if (element.modulo === route.data.modulo) {
                            flag = true;
                        }
                    });

                    if (flag) {
                        return true;
                    } else {
                        this.router.navigate(['']);
                        return false;
                    }

                } else {
                    this.router.navigate(['']);
                    return false;
                }
            }
        } else {
            this.router.navigate(['']);
            return false;
        }
    }


}