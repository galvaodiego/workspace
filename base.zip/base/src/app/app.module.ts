import { BrowserModule } from '@angular/platform-browser';
import { NgModule, LOCALE_ID } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';

// Módulos
import { AutenticacaoModule } from './modulos/autenticacao/autenticacao.module';
import { SharedModule } from './shared/shared.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgxWebstorageModule } from 'ngx-webstorage';
import { HttpModule } from '@angular/http';
import { HomeModule } from './modulos/home/home.module';
import { FinanceiroModule } from './modulos/financeiro/financeiro.module';
import { RouterModule } from '@angular/router';
import { LoadingBarHttpModule } from '@ngx-loading-bar/http';
import { LogisticoModule } from './modulos/logistico/logistico.module';
import { ContabilModule } from './modulos/contabil/contabil.module';


@NgModule({
   declarations: [
      AppComponent
   ],
   imports: [
      BrowserModule,
      AppRoutingModule,
      SharedModule,
      AutenticacaoModule,
      NgxWebstorageModule,
      NgxWebstorageModule.forRoot({ prefix: 'kmm_bi-app', separator: '|', caseSensitive: true }),
      HttpModule,
      RouterModule,
      LoadingBarHttpModule,
      // ServiceWorkerModule.register('ngsw-worker.js', { enabled: environment.production }),
      ServiceWorkerModule.register('OneSignalSDKWorker.js', { enabled: environment.production }),
      // tslint:disable-next-line: deprecation
      BrowserAnimationsModule,
      HomeModule,
      FinanceiroModule,
      LogisticoModule,
      ContabilModule
   ],
   providers: [
      { provide: LOCALE_ID, useValue: 'pt' },
   ],
   bootstrap: [AppComponent]
})
export class AppModule { }
