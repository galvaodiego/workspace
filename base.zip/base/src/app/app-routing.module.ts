import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './modulos/home/home/home.component';
import { ListaModulosComponent } from './modulos/home/lista-modulos/lista-modulos.component';
import { NotificacoesComponent } from './modulos/home/notificacoes/notificacoes.component';
import { Page404Component } from './modulos/home/page404/page404.component';
import { GuardaRotas } from './shared/guards/guarda-rotas.guard';
import { AutenticacaoLoginComponent } from './modulos/autenticacao/autenticacao-login/autenticacao-login.component';
import { InformacoesComponent } from './modulos/home/informacoes/informacoes.component';


const routes: Routes = [
   { path: '', component: AutenticacaoLoginComponent },
   {
      path: 'home',
      component: HomeComponent,
      canActivate: [GuardaRotas],
      data: {
         modulo: 'free'
      }
   },
   {
      path: 'modulos',
      component: ListaModulosComponent,
      canActivate: [GuardaRotas],
      data: {
         modulo: 'free'
      }
   },
   { path: 'notificacoes', component: NotificacoesComponent, canActivate: [GuardaRotas] },
   {
      path: 'informacoes',
      component: InformacoesComponent,
      canActivate: [GuardaRotas],
      data: {
         modulo: 'free'
      }
   },
   { path: 'financeiro', loadChildren: () => import('./modulos/financeiro/financeiro.module').then(m => m.FinanceiroModule) },
   { path: 'logistico', loadChildren: () => import('./modulos/logistico/logistico.module').then(m => m.LogisticoModule) },
   { path: 'contabil', loadChildren: () => import('./modulos/contabil/contabil.module').then(m => m.ContabilModule) },
   { path: 'suprimentos', loadChildren: () => import('./modulos/suprimentos/suprimentos.module').then(m => m.SuprimentosModule) },
   // { path: 'lazy', loadChildren: () => import('./modulos/lazy/lazy.module').then(m => m.LazyModule) },
   { path: '**', component: Page404Component }
];

@NgModule({
   imports: [RouterModule.forRoot(
      routes,
      { enableTracing: false } // <-- debugging purposes only
   )],
   exports: [RouterModule]
})
export class AppRoutingModule { }
