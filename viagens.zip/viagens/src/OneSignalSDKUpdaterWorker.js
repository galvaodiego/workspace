importScripts('https://kmm-bi-gestor.herokuapp.com/ngsw-worker.js');
importScripts('https://cdn.onesignal.com/sdks/OneSignalSDKWorker.js');
