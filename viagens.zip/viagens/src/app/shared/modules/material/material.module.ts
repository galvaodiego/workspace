import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import {
   MatDatepickerModule,
   MatSidenavModule,
   MatIconModule,
   MatToolbarModule,
   MatListModule,
   MatButtonModule,
   MatTabsModule,
   MatSnackBarModule,
   MatSlideToggleModule,
   MatButtonToggleModule,
   MatDividerModule,
   MatDialogModule,
   MatStepperModule,
   MatTooltipModule,
   MatExpansionModule,
   MatCardModule,
   MatProgressBarModule,
   MatFormFieldModule,
   MatNativeDateModule,
   MatInputModule,
   MatSelectModule,
   MatChipsModule
} from '@angular/material';




@NgModule({
   declarations: [],
   imports: [
      CommonModule,
      MatSidenavModule,
      MatToolbarModule,
      MatListModule,
      MatButtonModule,
      MatTabsModule,
      MatSnackBarModule,
      MatSlideToggleModule,
      MatButtonToggleModule,
      MatDividerModule,
      MatIconModule,
      MatDialogModule,
      MatStepperModule,
      MatTooltipModule,
      MatExpansionModule,
      MatCardModule,
      MatProgressBarModule,
      MatDatepickerModule,
      MatFormFieldModule,
      MatNativeDateModule,
      MatInputModule,
      MatSelectModule,
      MatChipsModule

   ],
   exports: [
      MatSidenavModule,
      MatToolbarModule,
      MatListModule,
      MatButtonModule,
      MatTabsModule,
      MatSnackBarModule,
      MatSlideToggleModule,
      MatButtonToggleModule,
      MatDividerModule,
      MatIconModule,
      MatDialogModule,
      MatStepperModule,
      MatTooltipModule,
      MatExpansionModule,
      MatCardModule,
      MatProgressBarModule,
      MatDatepickerModule,
      MatFormFieldModule,
      MatNativeDateModule,
      MatInputModule,
      MatSelectModule,
      MatChipsModule
   ]
})
export class MaterialModule { }
