import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
   DxMultiViewModule,
   DxLoadPanelModule,
   DxTreeListModule,
   DxDataGridModule,
   DxPopupModule,
   DxScrollViewModule,
   DxCircularGaugeModule,
   DxChartModule,
   DxPieChartModule,
   DxMapModule,
   DxSelectBoxModule,
   DxGalleryModule,
} from 'devextreme-angular';



@NgModule({
   declarations: [],
   imports: [
      CommonModule,
      DxMultiViewModule,
      DxLoadPanelModule,
      DxTreeListModule,
      DxDataGridModule,
      DxPopupModule,
      DxScrollViewModule,
      DxCircularGaugeModule,
      DxChartModule,
      DxPieChartModule,
      DxMapModule,
      DxSelectBoxModule,
      DxGalleryModule
   ],
   exports: [
      DxMultiViewModule,
      DxLoadPanelModule,
      DxTreeListModule,
      DxDataGridModule,
      DxPopupModule,
      DxScrollViewModule,
      DxCircularGaugeModule,
      DxChartModule,
      DxPieChartModule,
      DxMapModule,
      DxSelectBoxModule,
      DxGalleryModule

   ]
})
export class DevextremeModule { }
