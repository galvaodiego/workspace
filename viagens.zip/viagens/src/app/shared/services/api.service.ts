import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { environment } from 'src/environments/environment';
// import { AuthenticationService } from './authentication.service';
@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(
    private http: HttpClient,
  ) { }
  request(verbo: string, rota: string, parameters?: any) {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      // 'Authorization': `Bearer ${this.authService.token}`
    })
    const options = {
      headers: headers
    }

    return new Promise((resolvePai, rejectPai) => {
      this.send(verbo, environment.socket_end_point + rota, options, parameters)
        .then(async (data) => await resolvePai(data))
        .catch(async (dataError) => {
          rejectPai(dataError);
        })
    });

  }

  public send(verbo: string, url, options, parameters?): Promise<any> {
    return new Promise((resolve, reject) => {
      switch (verbo) {
        case 'get':
          this.http.get(url, options).subscribe(
            data => resolve(data),
            err => reject(err)
          );
          break;
        case 'post':
          this.http.post(url, parameters, options).subscribe(
            data => resolve(data),
            err => reject(err)
          );
          break;
        case 'put':
          this.http.put(url, parameters, options).subscribe(
            data => resolve(data),
            err => reject(err)
          );
          break;
        case 'patch':
          this.http.patch(url, parameters, options).subscribe(
            data => resolve(data),
            err => reject(err)
          );
          break;
        case 'delete':
          this.http.delete(url, options).subscribe(
            data => resolve(data),
            err => reject(err)
          );
          break;
      }
    });

  }
}
