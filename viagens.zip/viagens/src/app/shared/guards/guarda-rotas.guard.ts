import { CanActivate } from '@angular/router';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

import { Usuario } from '../models/usuario.model';


@Injectable({ providedIn: 'root' })
export class GuardaRotas implements CanActivate {

    private user: Usuario = Usuario.instance;

    constructor(
        private router: Router
    ) { }

    /**
     * Protege as Rotas dos Módulos
     */
    canActivate() {
        if (this.user.isLogged) {
            return true;
        } else {
            this.router.navigate(['']);
            return false;
        }
    }
}