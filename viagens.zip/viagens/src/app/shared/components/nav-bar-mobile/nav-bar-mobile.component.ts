import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { MediaMatcher } from '@angular/cdk/layout';
import { Platform } from '@angular/cdk/platform';

@Component({
   selector: 'app-nav-bar-mobile',
   templateUrl: './nav-bar-mobile.component.html',
   styleUrls: ['./nav-bar-mobile.component.scss']
})
export class NavBarMobileComponent implements OnInit {
   mobileQuery: MediaQueryList;
   // tslint:disable-next-line: variable-name
   private _mobileQueryListener: () => void;
   modulos;
   constructor(
      public platform: Platform,
      changeDetectorRef: ChangeDetectorRef,
      media: MediaMatcher,
   ) {
      this.mobileQuery = media.matchMedia('(max-width: 600px)');
      this._mobileQueryListener = () => changeDetectorRef.detectChanges();
      // tslint:disable-next-line: deprecation
      this.mobileQuery.addListener(this._mobileQueryListener);
      const modulos = localStorage.getItem('modulos');
      if (modulos) {
         this.modulos = JSON.parse(modulos);
         // console.log('chegou os mod', this.modulos);

      }
   }

   ngOnInit() {
   }



}
