import { Component, OnInit, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { MediaMatcher } from '@angular/cdk/layout';
import { Platform } from '@angular/cdk/platform';
import { confirm } from 'devextreme/ui/dialog';
import { Usuario } from '../../models/usuario.model';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';

@Component({
   selector: 'app-nav-bar',
   templateUrl: './nav-bar.component.html',
   styleUrls: ['./nav-bar.component.scss']
})
export class NavBarComponent implements OnInit, OnDestroy {
   public user: Usuario = Usuario.instance;
   mobileQuery: MediaQueryList;
   // tslint:disable-next-line: variable-name
   private _mobileQueryListener: () => void;
   version: string;
   cliente = {
      path: 'assets/images/clientes/kmm.png',
      descricao: 'KMM Engenharia de Software'
   };

   popupVisible = false;
   prod: any;
   constructor(
      changeDetectorRef: ChangeDetectorRef,
      media: MediaMatcher,
      public platform: Platform,
      private router: Router
   ) {
      this.mobileQuery = media.matchMedia('(max-width: 600px)');
      this._mobileQueryListener = () => changeDetectorRef.detectChanges();
      // tslint:disable-next-line: deprecation
      this.mobileQuery.addListener(this._mobileQueryListener);
      this.version = environment.version;
      this.prod = environment.production;
      // console.log('plataforma', this.platform);
      // console.log('user', this.user);

      const clienteSelecionado = JSON.parse(localStorage.getItem('cliente-selecionado'));
      if (clienteSelecionado) {
         this.cliente.path = clienteSelecionado.logo;
         this.cliente.descricao = clienteSelecionado.nome;
      }

   }

   ngOnInit() {
   }

   ngOnDestroy(): void {
      // tslint:disable-next-line: deprecation
      this.mobileQuery.removeListener(this._mobileQueryListener);
   }


   public logout() {
      const result = confirm(`Você tem certeza que deseja encerrar a sessão?`, 'Sair');
      result.then((dialogResult) => {
         if (dialogResult) {
            this.user.logout();
            localStorage.clear();
            this.router.navigate(['']);
         }
      });
   }

   atualizar() {
      location.reload();
   }

}
