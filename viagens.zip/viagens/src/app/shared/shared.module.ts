import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

// components
import { NavBarComponent } from './components/nav-bar/nav-bar.component';
import { TreeListComponent } from './components/tree-list/tree-list.component';
import { NavBarMobileComponent } from './components/nav-bar-mobile/nav-bar-mobile.component';
import { DxPopupModule } from 'devextreme-angular';
import { MaterialModule } from './modules/material/material.module';
import { DevextremeModule } from './modules/devextreme/devextreme.module';
import { ProgressBarComponent } from './components/progress-bar/progress-bar';



@NgModule({
   declarations: [NavBarComponent, TreeListComponent, NavBarMobileComponent, ProgressBarComponent],
   imports: [
      CommonModule,
      RouterModule,
      MaterialModule,
      DevextremeModule,
      DxPopupModule
   ],
   exports: [
      MaterialModule,
      DevextremeModule,
      NavBarComponent,
      NavBarMobileComponent,
      TreeListComponent,
      ProgressBarComponent
   ],
})
export class SharedModule { }
