export class UsuarioBi {
    usuario: string;
    usuarioBiId: number;
}

export class ConfigOrganizacional {
    configuracaoOrgId: number;
    descricao: string;
    ordem: number;
    tipoOrganizacionalId: number;
}

export class ConfigOrgUsuario {
    listConfigOrg: Array<ConfigOrganizacional>;
    configOrgId: number;
    configOrg: string;
    modulo: string;
    moduloId: number;
    numModulo: string;
    niveis: Array<Nivel>;
    dashs: Array<Dash>;

    constructor() {
        // this.niveis = [];
        // this.dashs = [];
    }
}

export class Permissao {
    usuario: UsuarioBi;
    ativo: boolean;
    organizacional: string;
    tipoOrganizacionalId: number;
    tipoOrganizacional: string;
    organizacionalId: number;
    organizacionalIdPai: number;
    organizacionalIdCorp: number;
    codNivelOrganizacional: string;
    ordem: number;
}

export class Nivel {
    usuario: UsuarioBi;
    codNivelOrganizacional: string;
    nivel: number;
    organizacional: string;
    organizacionalId: number;
    tipoOrganizacionalId: number;
}

export class Dash {
    id: number;
    descricao: string;
    path: string;
}

export class EstruturaOrganizacional {

    private _usuario: UsuarioBi;
    private _base: string;
    private _configOrgUsuario: Array<ConfigOrgUsuario>;
    private _permissoes: Array<Permissao>;
    private _niveis: Nivel;
    private _dashs: Array<Dash>;


    private static _instance: EstruturaOrganizacional;

    public storage: Storage;

    public static get instance(): EstruturaOrganizacional {
        if (this._instance == null) {
            this._instance = new EstruturaOrganizacional();
        }
        return this._instance;
    }

    constructor() { }

    /**
    *  getters e setters
    */

    public get usuario(): UsuarioBi {
        return this._usuario;
    }

    public set usuario(value: UsuarioBi) {
        if (value == null) {
            value = new UsuarioBi();
        }
        this._usuario = value;
    }

    public get base(): string {
        return this._base;
    }

    public set base(value: string) {
        this._base = value != null ? value.toUpperCase() : value;
    }

    public get configOrgUsuario(): Array<ConfigOrgUsuario> {
        return this._configOrgUsuario;
    }

    public set configOrgUsuario(value: Array<ConfigOrgUsuario>) {
        if (value == null) {
            value = [];
        }
        this._configOrgUsuario = value;
    }

    public get permissoes(): Array<Permissao> {
        return this._permissoes;
    }

    public set permissoes(value: Array<Permissao>) {
        if (value == null) {
            value = [];
        }
        this._permissoes = value;
    }

    public get niveis(): Nivel {
        return this._niveis;
    }

    public set niveis(value: Nivel) {
        if (value == null) {
            value = new Nivel();
        }
        this._niveis = value;
    }

    public get dashs(): Array<Dash> {
        return this._dashs;
    }

    public set dashs(value: Array<Dash>) {
        if (value == null) {
            value = new Array<Dash>();
        }
        this._dashs = value;
    }

    public logout() {
        this.usuario = null;
        this.configOrgUsuario = null;
        this.permissoes = null;
        this.niveis = null;
        this.dashs = null;
    }

}