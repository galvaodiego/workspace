import { Component, OnInit } from '@angular/core';
import { UsuarioService } from './shared/services/usuario.service';
import { EstruturaOrganizacionalService } from './shared/services/organizacional.service';
import { Usuario } from './shared/models/usuario.model';
import { ActivatedRoute, Router, NavigationEnd } from '@angular/router';
import { filter, map, switchMap } from 'rxjs/operators';
import { Meta } from '@angular/platform-browser';
import { environment } from 'src/environments/environment.prod';
import { UpdateService } from './shared/services/update.service';

@Component({
   selector: 'app-root',
   templateUrl: './app.component.html',
   styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
   private user: Usuario = Usuario.instance;
   title = 'VIAGENS';

   constructor(
      private router: Router,
      private acRoute: ActivatedRoute,
      private userProvider: UsuarioService,
      private orgProvider: EstruturaOrganizacionalService,
      private meta: Meta,
      private sw: UpdateService
   ) {

      if (environment.production) {
         meta.addTag({ httpEquiv: 'Content-Security-Policy', content: 'upgrade-insecure-requests' });
      }

      // check the service worker for updates
      this.sw.checkForUpdates();

      // Inicia o Storage do Usuário
      this.userProvider.init().then(
         (user) => {

            // Inicia o Storage do Organizacional
            this.orgProvider.init().then(
               (org) => {
                  if (!this.user.isLogged) {
                     this.router.navigate(['']);
                  }
                  // else {
                  //    this.router.navigate([(this.router.url === '/' ? '/home' : this.router.url)]);
                  // }
               }
            );
         }
      );
   }

   ngOnInit(): void {
      this.router.events
         .pipe(filter(event => event instanceof NavigationEnd))
         .pipe(map(() => this.acRoute))
         .pipe(map(route => {
            while (route.firstChild) { route = route.firstChild; }
            return route;
         }))
         .pipe(switchMap(route => route.data))
         .subscribe((event => {
         }));

   }

   public isAuthenticated() {
      // return false;
      return this.user.isLogged;
   }
}
