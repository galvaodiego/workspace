import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeComponent } from './home/home.component';
import { FeedComponent } from './feed/feed.component';
import { FeedItemComponent } from './feed/feed-item/feed-item.component';
import { ElementoComponent } from './feed/elemento/elemento.component';
import { ListaModulosComponent } from './lista-modulos/lista-modulos.component';
import { NotificacoesComponent } from './notificacoes/notificacoes.component';
import { RouterModule } from '@angular/router';
import { ConfiguracoesComponent } from './configuracoes/configuracoes.component';
import { Page404Component } from './page404/page404.component';
import { InformacoesComponent } from './informacoes/informacoes.component';
import { SharedModule } from 'src/app/shared/shared.module';



@NgModule({
   declarations: [
      HomeComponent,
      FeedComponent,
      FeedItemComponent,
      ElementoComponent,
      ListaModulosComponent,
      NotificacoesComponent,
      ConfiguracoesComponent,
      Page404Component,
      InformacoesComponent],
   imports: [
      CommonModule,
      RouterModule,
      SharedModule
   ],
   exports: [
      FeedComponent,
      FeedItemComponent
   ]
})
export class HomeModule { }
