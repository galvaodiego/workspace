import { Component, OnInit } from '@angular/core';
import { Usuario } from 'src/app/shared/models/usuario.model';

@Component({
   selector: 'app-home',
   templateUrl: './home.component.html',
   styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
   public user: Usuario = Usuario.instance;
   clienteSelecionado: any;
   listaModulos;

   constructor() {
      const cliente = JSON.parse(localStorage.getItem('cliente-selecionado'));
      if (cliente) {
         this.clienteSelecionado = cliente;
      }
   }

   ngOnInit() {
      const modulos = JSON.parse(localStorage.getItem('modulos'));
      if (modulos) {
         console.log('tem módulos', modulos);
         this.listaModulos = modulos;
      } else {
         this.listaModulos = [];
      }
   }

   getBanner(ref) {
      switch (ref) {
         case 'sulista':
            return 'assets/images/clientes/banner/sulista.jpg';
            break;

         case 'ritmo':
            return 'assets/images/clientes/banner/ritmo.jpg';
            break;

         case 'diamante':
            return 'assets/images/clientes/banner/diamante.jpg';
            break;

         case 'otdbrasil':
            return 'assets/images/clientes/banner/otdbrasil.jpg';
            break;

         case 'pizzatto':
            return 'assets/images/clientes/banner/pizzatto.jpg';
            break;

         case 'axon':
            return 'assets/images/clientes/banner/axon.jpg';
            break;

         case 'transgires':
            return 'assets/images/clientes/banner/transgires.jpg';
            break;

         case 'panorama':
            return 'assets/images/clientes/banner/panorama.jpg';
            break;

         case 'cargosoft':
            return 'assets/images/clientes/banner/cargosoft.jpg';
            break;

         case 'budel':
            return 'assets/images/clientes/banner/budel.jpg';
            break;

         default:
            return 'assets/images/clientes/banner/kmm.jpg';
            break;
      }
   }

}
