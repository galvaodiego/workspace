import { Component, OnInit, OnDestroy } from '@angular/core';
import io from 'socket.io-client';
import { environment } from 'src/environments/environment';
import { Usuario } from 'src/app/shared/models/usuario.model';
@Component({
   selector: 'app-feed',
   templateUrl: './feed.component.html',
   styleUrls: ['./feed.component.scss']
})
export class FeedComponent implements OnInit, OnDestroy {
   public user: Usuario = Usuario.instance;
   // Config Socket
   socketIo: any;
   socketRota = 'base';
   socketMetodo = 'getFeed';
   socketFiltro: any;
   /***/

   itens = [];
   loadVisible = false;
   dadosCliente: any;
   constructor() {
      const dadosCliente = JSON.parse(localStorage.getItem('cliente-selecionado'));
      if (dadosCliente) {
         this.dadosCliente = dadosCliente;
      }
      // this.socketIo = io(environment.socket_end_point + '/' + this.socketRota);
      this.socketIo = io(environment.socket_end_point_base + '/' + this.socketRota);
      this.socketFiltro = {
         base: this.user.ref.toLowerCase()
      };
      this.socket().then(() => { });
   }

   ngOnInit() {
   }

   ngOnDestroy(): void {
      this.socketIo.disconnect();
   }

   async socket() {
      this.loadVisible = true;
      try {
         this.socketIo.emit(this.socketMetodo, this.socketFiltro);
         this.socketIo.on('feed', (data) => {
            this.itens = data;
            console.log('filtro', this.socketFiltro, 'data', data, this.itens);
            this.loadVisible = false;
         });
      } catch (error) {
         console.log('error => ', error);
      }
   }

}
