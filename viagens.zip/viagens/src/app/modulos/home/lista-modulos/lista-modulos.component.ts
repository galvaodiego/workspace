import { Component, OnInit } from '@angular/core';
import { EstruturaOrganizacional } from 'src/app/shared/models/organizacional.model';
import { Router } from '@angular/router';
import { NotificacaoService } from 'src/app/shared/services/notificacao.service';

@Component({
   selector: 'app-lista-modulos',
   templateUrl: './lista-modulos.component.html',
   styleUrls: ['./lista-modulos.component.scss']
})
export class ListaModulosComponent implements OnInit {
   public org: EstruturaOrganizacional = EstruturaOrganizacional.instance;
   modulos: any;
   constructor(
      private router: Router,
      private notificacao: NotificacaoService
   ) {
      this.modulos = this.org.configOrgUsuario;

      this.modulos = this.modulos.filter(e => {
         return e.modulo !== 'Monitoramento';
      });
   }

   ngOnInit() {
   }

   navegacao(destino) {
      switch (destino.toLowerCase()) {
         case 'faturamento':
            this.router.navigate(['financeiro/faturamento']);
            break;
         case 'indicador logístico':
            this.router.navigate(['logistico/indicadores']);
            break;
         case 'dre':
            this.router.navigate(['contabil/dre']);
            break;

         default:
            this.notificacao.openSnackBar('O módulo ' + destino + ' está indisponível, contate o suporte para a liberação');
            break;
      }
   }



}
