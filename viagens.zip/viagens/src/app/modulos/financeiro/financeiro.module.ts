import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

// componentes
import { FaturamentoComponent } from './faturamento/faturamento.component';
import { FaturamentoCustomComponent } from './faturamento-custom/faturamento-custom.component';
import { ExtratoFaturamentoComponent } from './extrato-faturamento/extrato-faturamento.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { FiltroComponent } from './extrato-faturamento/filtro/filtro.component';
import { MobileViewComponent } from './extrato-faturamento/mobile-view/mobile-view.component';
import { WebViewComponent } from './extrato-faturamento/web-view/web-view.component';
import { FinanceiroRoutingModule } from './financeiro-routing.module';


@NgModule({
   // tslint:disable-next-line: max-line-length
   declarations: [FaturamentoComponent, FaturamentoCustomComponent, ExtratoFaturamentoComponent, FiltroComponent, MobileViewComponent, WebViewComponent],
   imports: [
      CommonModule,
      SharedModule,
      FormsModule,
      ReactiveFormsModule,
      FinanceiroRoutingModule
   ]
})
export class FinanceiroModule { }
