import { Component, OnInit } from '@angular/core';
import { GatewayService } from 'src/app/shared/services/gateway.service';
import { Usuario } from 'src/app/shared/models/usuario.model';
import { EstruturaOrganizacional } from 'src/app/shared/models/organizacional.model';

// Plugins
import * as moment from 'moment';
import 'moment/locale/pt-br';

@Component({
   selector: 'app-faturamento',
   templateUrl: './faturamento.component.html',
   styleUrls: ['./faturamento.component.scss']
})
export class FaturamentoComponent implements OnInit {
   public user: Usuario = Usuario.instance;
   public org: EstruturaOrganizacional = EstruturaOrganizacional.instance;
   loadVisible = false;
   public tipoFiltro: string;
   public parameterList: any;


   // Datas Usadas para busca de Dados
   public dataInicio: string;
   public dataFim: string;
   public showFat = true;
   public showTon = false;
   public showDoc = false;

   public rootItems: any;
   public configuracao: any = {};



   constructor(
      private gateway: GatewayService
   ) {
      this.tipoFiltro = 'diario';
      this.dataInicio = ('01/' + moment().format('MM') + '/' + moment().format('YYYY'));
      this.dataFim = moment().format('DD/MM/YYYY');
      this.parameterList = this.org.configOrgUsuario.filter((e) => {
         return e.modulo === 'Faturamento';
      });

      this.parameterList = this.parameterList.filter(e => {
         return e.configOrg === 'Faturamento';
      });


   }

   ngOnInit() {
      this.getData().then(() => { });
   }

   toggleChange(e) {
      switch (e.source.name) {
         case 'showFat':
            this.showFat = e.checked;
            break;
         case 'showTon':
            this.showTon = e.checked;
            break;
         case 'showDoc':
            this.showDoc = e.checked;
            break;
      }
   }

   tipoFiltroChange(e) {
      this.tipoFiltro = e.value;
   }

   async getData() {
      this.loadVisible = true;
      const parametrosBd = {
         usuario_bi_id: this.org.usuario.usuarioBiId,
         organizacional_id: this.parameterList[0].niveis[0].organizacional_id,
         organizacional_id_pai: -1,
         tipo_organizacional_id: this.parameterList[0].niveis[0].tipo_organizacional,
         configuracao_org_id: this.parameterList[0].configOrgId,
         data_inicio: this.dataInicio,
         data_fim: this.dataFim,
         nivel: this.parameterList[0].niveis[0].nivel,
         lista_menu: 1,
         cod_nivel_organizacional: this.parameterList[0].niveis[0].cod_nivel_organizacional
      };

      try {
         const response: any = await this.gateway.backendCall('1811-APPGESTOR', 'getConteudo', parametrosBd);
         console.log('response', response);
         this.configuracao = response;
         this.rootItems = this.configuracao.layout;
         this.normalizeArrayItems(this.configuracao.layout);
         this.setInitialValues(this.rootItems);
         // console.log('root', this.rootItems);
         this.loadVisible = false;
      } catch (error) {
         console.log('Error:', error);
      }
   }

   /**
    * Processa os itens para que todos contenham valor
    * @param lista Array com o Conteudo
    */
   public normalizeArrayItems(lista: Array<any>) {
      lista.forEach(
         (element) => {
            if (this.hasChild(element)) {
               // Inicializa a Variavel em todos os niveis
               if (typeof (element.fat_hoje || element.peso_hoje || element.num_docs) === 'undefined') {
                  element.fat_hoje = 0;
                  element.fat_hoje_mes_ant = 0;
                  element.fat_hoje_ano_ant = 0;
                  element.fat_mes = 0;
                  element.fat_mes_ant = 0;
                  element.fat_ano_ant = 0;
                  element.peso_hoje = 0;
                  element.peso_hoje_mes_ant = 0;
                  element.peso_hoje_ano_ant = 0;
                  element.peso_mes = 0;
                  element.peso_mes_ant = 0;
                  element.peso_mes_ano_ant = 0;
                  element.num_docs = 0;
                  element.num_docs_hoje_mes_ant = 0;
                  element.num_docs_hoje_ano_ant = 0;
                  element.num_docs_mes = 0;
                  element.num_docs_mes_ant = 0;
                  element.num_docs_mes_ano_ant = 0;
               }
               // passa o caminho do item novamente (layout)
               this.normalizeArrayItems(element.layout);
            } else {
               return;
            }
         }
      );
   }

   /*
* Verifica se item contém lista filha.
* @param item
*/
   public hasChild(item: any) {
      if (typeof (item.layout) !== 'undefined' && item.layout !== []) {
         return true;
      }
      return false;
   }

   /*
   * Recebe a Lista e Soma os campos
   * @param lista Array com os Dados
   */
   public setInitialValues(lista: Array<any>) {
      lista.forEach(element => {
         if (this.hasChild(element)) {
            this.setInitialValues(element.layout);

            // Somando o campo FAT_HOJE
            element.fat_hoje = element.layout
               .map(
                  (fatH) => {
                     // tslint:disable-next-line: no-string-literal
                     return fatH['fat_hoje'];
                  }
               ).reduce((anterior, atual) => {
                  return (anterior + atual);
               }, 0);

            // Somando o campo FAT_HOJE_MES_ANT
            element.fat_hoje_mes_ant = element.layout
               .map(
                  (fatMa) => {
                     // tslint:disable-next-line: no-string-literal
                     return fatMa['fat_hoje_mes_ant'];
                  }
               ).reduce((anterior, atual) => {
                  return (anterior + atual);
               }, 0);

            // Somando o campo  FAT_HOJE_ANO_ANT
            element.fat_hoje_ano_ant = element.layout
               .map(
                  (fatAMa) => {
                     // tslint:disable-next-line: no-string-literal
                     return fatAMa['fat_hoje_ano_ant'];
                  }
               ).reduce((anterior, atual) => {
                  return (anterior + atual);
               }, 0);

            // Somando o campo FAT_MES
            element.fat_mes = element.layout
               .map(
                  (fatM) => {
                     // tslint:disable-next-line: no-string-literal
                     return fatM['fat_mes'];
                  }
               ).reduce((anterior, atual) => {
                  return (anterior + atual);
               }, 0);

            // Somando o campo FAT_MES_ANT
            element.fat_mes_ant = element.layout
               .map(
                  (fatMa) => {
                     // tslint:disable-next-line: no-string-literal
                     return fatMa['fat_mes_ant'];
                  }
               ).reduce((anterior, atual) => {
                  return (anterior + atual);
               }, 0);

            // Somando o campo FAT_ANO_ANT
            element.fat_ano_ant = element.layout
               .map(
                  (fatMaA) => {
                     // tslint:disable-next-line: no-string-literal
                     return fatMaA['fat_ano_ant'];
                  }
               ).reduce((anterior, atual) => {
                  return (anterior + atual);
               }, 0);

            // Somando o campo PESO_HOJE
            element.peso_hoje = element.layout
               .map(
                  (pesoH) => {
                     // tslint:disable-next-line: no-string-literal
                     return pesoH['peso_hoje'];
                  }
               ).reduce((anterior, atual) => {
                  return (anterior + atual);
               }, 0);

            // Somando o campo PESO_HOJE_MES_ANT
            element.peso_hoje_mes_ant = element.layout
               .map(
                  (pesoHMa) => {
                     // tslint:disable-next-line: no-string-literal
                     return pesoHMa['peso_hoje_mes_ant'];
                  }
               ).reduce((anterior, atual) => {
                  return (anterior + atual);
               }, 0);

            // Somando o campo PESO_HOJE_MES_ANT
            element.peso_hoje_ano_ant = element.layout
               .map(
                  (pesoHaA) => {
                     // tslint:disable-next-line: no-string-literal
                     return pesoHaA['peso_hoje_ano_ant'];
                  }
               ).reduce((anterior, atual) => {
                  return (anterior + atual);
               }, 0);

            // Somando o campo PESO_MES
            element.peso_mes = element.layout
               .map(
                  (pesoM) => {
                     // tslint:disable-next-line: no-string-literal
                     return pesoM['peso_mes'];
                  }
               ).reduce((anterior, atual) => {
                  return (anterior + atual);
               }, 0);

            // Somando o campo PESO_MES_ANT
            element.peso_mes_ant = element.layout
               .map(
                  (pesoMa) => {
                     // tslint:disable-next-line: no-string-literal
                     return pesoMa['peso_mes_ant'];
                  }
               ).reduce((anterior, atual) => {
                  return (anterior + atual);
               }, 0);

            // Somando o campo PESO_MES_ANO_ANT
            element.peso_mes_ano_ant = element.layout
               .map(
                  (pesoMaA) => {
                     // tslint:disable-next-line: no-string-literal
                     return pesoMaA['peso_mes_ano_ant'];
                  }
               ).reduce((anterior, atual) => {
                  return (anterior + atual);
               }, 0);

            // Somando o campo NUM_DOCS
            element.num_docs = element.layout
               .map(
                  (numDocs) => {
                     // tslint:disable-next-line: no-string-literal
                     return numDocs['num_docs'];
                  }
               ).reduce((anterior, atual) => {
                  return (anterior + atual);
               }, 0);

            // Somando o campo NUM_DOCS_HOJE_MES_ANT
            element.num_docs_hoje_mes_ant = element.layout
               .map(
                  (numDocsHojeMesAnt) => {
                     // tslint:disable-next-line: no-string-literal
                     return numDocsHojeMesAnt['num_docs_hoje_mes_ant'];
                  }
               ).reduce((anterior, atual) => {
                  return (anterior + atual);
               }, 0);

            // Somando o campo NUM_DOCS_HOJE_ANO_ANT
            element.num_docs_hoje_ano_ant = element.layout
               .map(
                  (numDocsHojeAnoAnt) => {
                     // tslint:disable-next-line: no-string-literal
                     return numDocsHojeAnoAnt['num_docs_hoje_ano_ant'];
                  }
               ).reduce((anterior, atual) => {
                  return (anterior + atual);
               }, 0);

            // Somando o campo NUM_DOCS_MES
            element.num_docs_mes = element.layout
               .map(
                  (numDocsMes) => {
                     // tslint:disable-next-line: no-string-literal
                     return numDocsMes['num_docs_mes'];
                  }
               ).reduce((anterior, atual) => {
                  return (anterior + atual);
               }, 0);

            // Somando o campo NUM_DOCS_MES_ANT
            element.num_docs_mes_ant = element.layout
               .map(
                  (numDocsMesAnt) => {
                     // tslint:disable-next-line: no-string-literal
                     return numDocsMesAnt['num_docs_mes_ant'];
                  }
               ).reduce((anterior, atual) => {
                  return (anterior + atual);
               }, 0);

            // Somando o campo NUM_DOCS_MES_ANO_ANT
            element.num_docs_mes_ano_ant = element.layout
               .map(
                  (numDocsMesAnoAnt) => {
                     // tslint:disable-next-line: no-string-literal
                     return numDocsMesAnoAnt['num_docs_mes_ano_ant'];
                  }
               ).reduce((anterior, atual) => {
                  return (anterior + atual);
               }, 0);

         } else {
            return;
         }
      });
   }

   onCellPrepared(e) {
      // Pinta as Linhas de Cabeçalho e Filtros
      if (e.rowType === 'header') {
         e.cellElement.bgColor = '#007bff';
         e.cellElement.style.color = '#ffffff';
         e.cellElement.style.fontWeight = 'bold';
         e.cellElement.style.padding = '5px';
      }

      // Pinta as Linhas dos Níveis (Empresa, Operação, Cliente)
      if (typeof (e.data) !== 'undefined') {
         if (e.data.nivel === 'Sulista') {
            e.cellElement.style.textTransform = 'uppercase';
            e.cellElement.bgColor = '#b3d7ff';
            e.cellElement.style.color = '#333333';
         } else if (e.data.nivel === 'Operação') {
            e.cellElement.bgColor = '#f5f5f5';
            e.cellElement.style.color = '#000000';
         } else if (e.data.nivel === 'Centro de Custo') {
            e.cellElement.bgColor = '#f8f9fa';
            e.cellElement.style.color = '#000000';
         } else if (e.data.nivel === 'Cliente') {
            e.cellElement.bgColor = '#ffffff';
            e.cellElement.style.color = '#000000';
         } else {
            e.cellElement.bgColor = '#e9eef3';
            e.cellElement.style.color = '#000000';
         }

      }
   }

}
