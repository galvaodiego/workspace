export class Dados {
   constructor() { }

   get() {
      return {
         // documentos: {
         //    totalizadores: { cancelados: 2, aprovados: 42, mediaPorVeiculos: 489987.00, peso: 197998.00, total: 372410.90 },
         //    indicadores_documentos: {
         //       kpi: { total: 264, max_cancelados: 50, min_cancelados: 2 },
         //       chart: [
         //          { periodo: 'jan 2019', emitidos: 100, cancelados: 50, peso: 100, faturamento: 50 },
         //          { periodo: 'fev 2019', emitidos: 50, cancelados: 100, peso: 50, faturamento: 100 },
         //          { periodo: 'mar 2019', emitidos: 100, cancelados: 50, peso: 100, faturamento: 50 },
         //          { periodo: 'abr 2019', emitidos: 50, cancelados: 100, peso: 50, faturamento: 100 },
         //          { periodo: 'mai 2019', emitidos: 100, cancelados: 50, peso: 50, faturamento: 50 },
         //          { periodo: 'jun 2019', emitidos: 50, cancelados: 100, peso: 100, faturamento: 100 },
         //          { periodo: 'jul 2019', emitidos: 100, cancelados: 50, peso: 50, faturamento: 50 },
         //          { periodo: 'ago 2019', emitidos: 50, cancelados: 100, peso: 100, faturamento: 100 },
         //          { periodo: 'set 2019', emitidos: 100, cancelados: 50, peso: 50, faturamento: 50 },
         //          { periodo: 'out 2019', emitidos: 50, cancelados: 100, peso: 100, faturamento: 100 },
         //          { periodo: 'nov 2019', emitidos: 100, cancelados: 50, peso: 50, faturamento: 50 },
         //          { periodo: 'dez 2019', emitidos: 50, cancelados: 100, peso: 100, faturamento: 100 }
         //       ]
         //    }
         // },
         // veiculos: {
         //    totalizadores: { media_carroceria: 372410.091},
         //    tipos: [
         //       { classificacao: 'Caminhão 6x2', valor: 6324474.96 },
         //       { classificacao: 'Caminhão truck', valor: 454261.09 },
         //       { classificacao: 'Caminhão toco', valor: 63831.39 },
         //       { classificacao: 'Caminhão 3/4', valor: 26480.55 },
         //    ]
         // },
         base: {
            grafico: {
               fatMes: {
                  titulo: 'Faturamento',
                  dados: [
                     {
                        chave: '01/2019',
                        valor: 4108775.4407656193
                     },
                     {
                        chave: '02/2019',
                        valor: 3704468.514780998
                     },
                     {
                        chave: '03/2019',
                        valor: 3635859.9246209264
                     },
                     {
                        chave: '04/2019',
                        valor: 3498779.5038319826
                     },
                     {
                        chave: '05/2019',
                        valor: 3438927.6021375656
                     },
                     {
                        chave: '06/2019',
                        valor: 3053856.4412121773
                     },
                     {
                        chave: '07/2019',
                        valor: 3528527.861946583
                     },
                     {
                        chave: '08/2019',
                        valor: 3313687.4150012136
                     },
                     {
                        chave: '09/2019',
                        valor: 3525218.1743493676
                     },
                     {
                        chave: '10/2019',
                        valor: 3506750.4992386997
                     },
                     {
                        chave: '11/2019',
                        valor: 3519698.2096791267
                     },
                     {
                        chave: '12/2019',
                        valor: 3086284.5796457827
                     }
                  ]
               },
               pesoMes: {
                  titulo: 'Tonelagem',
                  dados: [
                     {
                        chave: '01/2019',
                        valor: 13247076.03112793
                     },
                     {
                        chave: '02/2019',
                        valor: 10704149.681488037
                     },
                     {
                        chave: '03/2019',
                        valor: 13359840.42251587
                     },
                     {
                        chave: '04/2019',
                        valor: 13668226.589162827
                     },
                     {
                        chave: '05/2019',
                        valor: 12926801.686523438
                     },
                     {
                        chave: '06/2019',
                        valor: 12112306.183700562
                     },
                     {
                        chave: '07/2019',
                        valor: 14776739.89453125
                     },
                     {
                        chave: '08/2019',
                        valor: 13645945.09826088
                     },
                     {
                        chave: '09/2019',
                        valor: 15059475.392456055
                     },
                     {
                        chave: '10/2019',
                        valor: 15493500.976974487
                     },
                     {
                        chave: '11/2019',
                        valor: 16275053.57891655
                     },
                     {
                        chave: '12/2019',
                        valor: 14061523.11296451
                     }
                  ]
               },
               docMes: {
                  titulo: 'Documentos',
                  dados: [
                     {
                        chave: '01/2019',
                        valor: 1016,
                        valor2: 64
                     },
                     {
                        chave: '02/2019',
                        valor: 877,
                        valor2: 53
                     },
                     {
                        chave: '03/2019',
                        valor: 1005,
                        valor2: 48
                     },
                     {
                        chave: '04/2019',
                        valor: 1063,
                        valor2: 101
                     },
                     {
                        chave: '05/2019',
                        valor: 1053,
                        valor2: 81
                     },
                     {
                        chave: '06/2019',
                        valor: 903,
                        valor2: 75
                     },
                     {
                        chave: '07/2019',
                        valor: 1087,
                        valor2: 76
                     },
                     {
                        chave: '08/2019',
                        valor: 914,
                        valor2: 51
                     },
                     {
                        chave: '09/2019',
                        valor: 917,
                        valor2: 54
                     },
                     {
                        chave: '10/2019',
                        valor: 902,
                        valor2: 57
                     },
                     {
                        chave: '11/2019',
                        valor: 900,
                        valor2: 91
                     },
                     {
                        chave: '12/2019',
                        valor: 805,
                        valor2: 58
                     }
                  ]
               },
               fatCarroceria: {
                  titulo: 'Faturamento por Carroceria',
                  dados: [
                     {
                        chave: 'CAVALO MECANICO 4X2',
                        valor: 24963072.969461158
                     },
                     {
                        chave: 'CAVALO MECANICO 6X2',
                        valor: 11578299.27036725
                     },
                     {
                        chave: 'CAVALO MECANICO TERCEIRO 6x2',
                        valor: 2123511.366663456
                     },
                     {
                        chave: 'CAVALO MECANICO',
                        valor: 1507585.8875451088
                     },
                     {
                        chave: null,
                        valor: 857817.8372497559
                     },
                     {
                        chave: 'CAVALO MECANICO 6X4',
                        valor: 712293.3258099556
                     },
                     {
                        chave: 'TRUCK SIDER',
                        valor: 116163.36973249912
                     },
                     {
                        chave: 'CAMINHAO TRUCK TERCEIRO',
                        valor: 39529.140380859375
                     },
                     {
                        chave: 'UTILITARIO TECEIRO',
                        valor: 22561
                     }
                  ]
               },
               fatCliente: {
                  titulo: 'Clientes',
                  dados: [
                     {
                        chave: 'Ceva Logistics Ltda',
                        valor: 10877389.726468086
                     },
                     {
                        chave: 'Sul Rio Grandense Com Embal e Deriv Pla',
                        valor: 8286708.368673801
                     },
                     {
                        chave: 'Companhia Brasileira de Estireno',
                        valor: 3143777.9304819107
                     },
                     {
                        chave: 'Unilever Brasil - Pouso Alegre - Foods',
                        valor: 2825305.3359092027
                     },
                     {
                        chave: 'Dow Brasil Ind e Com de Prod Quimicos',
                        valor: 1809004.0657043457
                     },
                     {
                        chave: 'Karina Ind.Com.De Plasticos Ltda',
                        valor: 1631315.110961914
                     },
                     {
                        chave: 'Leao',
                        valor: 1335479.4700317383
                     },
                     {
                        chave: 'Mexichem Brasil Industria de Transformac',
                        valor: 1328656.3139648438
                     },
                     {
                        chave: 'Fabrica de Papel Nossa Senhora da Penha',
                        valor: 1057568.62084198
                     },
                     {
                        chave: 'Cervejarias Kaiser Brasil S.A',
                        valor: 1055215.8257827759
                     },
                     {
                        chave: 'Fountain Agua Mineral Ltda',
                        valor: 931222.5227050781
                     }
                  ]
               },
               fatGrupoProduto: {
                  titulo: 'Totalizador por Tipo Produto',
                  dados: [
                     {
                        chave: 'Embalagem',
                        valor: 12710320.263936758
                     },
                     {
                        chave: 'Quimico',
                        valor: 10288376.293732643
                     },
                     {
                        chave: 'Peças',
                        valor: 8607745.971335411
                     },
                     {
                        chave: 'Bebidas',
                        valor: 3423767.044863701
                     },
                     {
                        chave: 'Higiene E Limpeza',
                        valor: 2494594.2960333824
                     },
                     {
                        chave: 'Alimenticio',
                        valor: 1302044.7217376977
                     },
                     {
                        chave: 'Papel E Celulose',
                        valor: 1292280.9012050629
                     },
                     {
                        chave: 'Eletrodomestico',
                        valor: 906961.1250724792
                     },
                     {
                        chave: 'Tecidos',
                        valor: 600360.3077392578
                     },
                     {
                        chave: 'Diversos',
                        valor: 67400.11105285585
                     },
                     {
                        chave: 'Madeira',
                        valor: 53237.91931152344
                     },
                     {
                        chave: 'Eletronicos',
                        valor: 28090.3203125
                     },
                     {
                        chave: 'Alimentícios Industrializados',
                        valor: 24716.5
                     },
                     {
                        chave: 'Maquinas E Equipamentos',
                        valor: 22580.55029296875
                     },
                     {
                        chave: 'Combustivel',
                        valor: 22561
                     },
                     {
                        chave: 'Calçados',
                        valor: 20000
                     },
                     {
                        chave: 'Industrializados',
                        valor: 14823.5400390625
                     },
                     {
                        chave: 'Fertilizantes',
                        valor: 12318.18017578125
                     },
                     {
                        chave: 'Plasticos',
                        valor: 10350
                     },
                     {
                        chave: 'Palete Em Madeira',
                        valor: 10279.400390625
                     },
                     {
                        chave: 'Laticineos',
                        valor: 5283.299980163574
                     },
                     {
                        chave: 'Ceramica',
                        valor: 2742.4199981689453
                     }
                  ]
               },
               fatModalidade: {
                  titulo: 'Gráfico por Modalidade',
                  dados: [
                     {
                        chave: 'FROTA',
                        valor: 25258108.66081965
                     },
                     {
                        chave: 'AGREGADO',
                        valor: 12042400.543793023
                     },
                     {
                        chave: 'TERCEIRO',
                        valor: 3736604.675152302
                     },
                     {
                        chave: null,
                        valor: 883720.2874450684
                     }
                  ]
               }
            },
            indicador: {
               faturamento: 41920834.16721004,
               documento: 11442,
               peso: 165330638.6486224,
               emitido: 11442,
               cancelado: 809
            },
            listaIndicador: {
               listaProduto: {
                  titulo: 'Faturamento por Produto',
                  dados: [
                     {
                        chave: 'Embalagem',
                        valor: 12697817.603788137
                     },
                     {
                        chave: 'Polietileno',
                        valor: 8113741.5173950195
                     },
                     {
                        chave: 'Peças Automotivas',
                        valor: 7418161.983760655
                     },
                     {
                        chave: 'Higiene e Limpeza',
                        valor: 2494594.2960333824
                     },
                     {
                        chave: 'Poliestireno',
                        valor: 2161834.7763376236
                     },
                     {
                        chave: 'Alimenticios',
                        valor: 1302044.7217376977
                     },
                     {
                        chave: 'Bebidas',
                        valor: 1296272.575671196
                     },
                     {
                        chave: 'Partes / Pecas',
                        valor: 1180609.127406299
                     },
                     {
                        chave: 'Caixa de Papelão',
                        valor: 1063563.7209396362
                     },
                     {
                        chave: 'Cerveja',
                        valor: 1050915.4157867432
                     },
                     {
                        chave: 'Agua Mineral',
                        valor: 892837.1323242188
                     },
                     {
                        chave: 'Fio Poliester',
                        valor: 600360.3077392578
                     },
                     {
                        chave: 'Eletrodomésticos',
                        valor: 455625.37757492065
                     },
                     {
                        chave: 'Ar Condicionado',
                        valor: 451335.7474975586
                     },
                     {
                        chave: 'Bobina De Papel',
                        valor: 187658.49048995972
                     },
                     {
                        chave: 'Suco Concentrado',
                        valor: 107798.92108154297
                     },
                     {
                        chave: 'Agua',
                        valor: 75943
                     },
                     {
                        chave: 'Gas Refrigeradores',
                        valor: 67400.11105285585
                     },
                     {
                        chave: 'Moveis',
                        valor: 63877.49951171875
                     },
                     {
                        chave: 'Papel',
                        valor: 30341.68977546692
                     },
                     {
                        chave: 'Equipamentos Eletronicos',
                        valor: 28090.3203125
                     },
                     {
                        chave: 'FIO CABO PP',
                        valor: 22580.55029296875
                     },
                     {
                        chave: 'Combustível',
                        valor: 22561
                     },
                     {
                        chave: 'Ração Animal',
                        valor: 22509
                     },
                     {
                        chave: 'Calçados',
                        valor: 20000
                     },
                     {
                        chave: 'Vasilhame',
                        valor: 12502.660148620605
                     },
                     {
                        chave: 'Adubo',
                        valor: 12318.18017578125
                     },
                     {
                        chave: 'Celulose',
                        valor: 10717
                     },
                     {
                        chave: 'Dutos',
                        valor: 10350
                     },
                     {
                        chave: 'Pallet',
                        valor: 10279.400390625
                     },
                     {
                        chave: 'Peças Diversas',
                        valor: 8179.41015625
                     },
                     {
                        chave: 'Hi-Phase 35P',
                        valor: 7500
                     },
                     {
                        chave: 'Carbonato de Sódio',
                        valor: 5300
                     },
                     {
                        chave: 'Leite',
                        valor: 5283.299980163574
                     },
                     {
                        chave: 'Mdf',
                        valor: 4183.9598388671875
                     },
                     {
                        chave: 'Ceramica',
                        valor: 2742.4199981689453
                     },
                     {
                        chave: 'LEITE EM PO',
                        valor: 2207.5
                     },
                     {
                        chave: 'Vidro',
                        valor: 795.4500122070312
                     }
                  ]
               }
            },
            lista: {
               motorista: [
                  {
                     motorista: null,
                     faturamento: 844394.7874450684,
                     documento: 164
                  },
                  {
                     motorista: 'Francisco Bernardino Honorio de Oliveira',
                     faturamento: 610624.7909545898,
                     documento: 127
                  },
                  {
                     motorista: 'Eliseu Vanderlei de Assis',
                     faturamento: 584302.8854751587,
                     documento: 130
                  },
                  {
                     motorista: 'Rodrigo Scrocaro',
                     faturamento: 544318.1041674614,
                     documento: 83
                  },
                  {
                     motorista: 'Ismael da Silva Cardoso',
                     faturamento: 538509.403945446,
                     documento: 104
                  },
                  {
                     motorista: 'Ricardo Baltazar da Silva Quadros',
                     faturamento: 522065.4925994873,
                     documento: 89
                  },
                  {
                     motorista: 'Cesario Gomes dos Santos Neto',
                     faturamento: 506551.3805322647,
                     documento: 136
                  },
                  {
                     motorista: 'Alexandre Jonas Talheimer',
                     faturamento: 498210.53186798096,
                     documento: 120
                  },
                  {
                     motorista: 'Paulo Gracindo de Oliveira',
                     faturamento: 497835.8598937988,
                     documento: 117
                  },
                  {
                     motorista: 'Wagner Luis Cardozo',
                     faturamento: 493693.23988866806,
                     documento: 114
                  },
                  {
                     motorista: 'Zenildo Figueiredo de Freitas Filho',
                     faturamento: 493580.3119621277,
                     documento: 120
                  }
               ],
               placa: [
                  {
                     placa: null,
                     faturamento: 857817.8372497559,
                     documento: 166
                  },
                  {
                     placa: 'DBC7339',
                     faturamento: 759119.8062977791,
                     documento: 114
                  },
                  {
                     placa: 'AMY4C50',
                     faturamento: 620903.6754393578,
                     documento: 98
                  },
                  {
                     placa: 'AXN7686',
                     faturamento: 600390.8503875732,
                     documento: 114
                  },
                  {
                     placa: 'AXN5088',
                     faturamento: 585916.1550598145,
                     documento: 139
                  },
                  {
                     placa: 'AXN5998',
                     faturamento: 572517.3308048248,
                     documento: 99
                  },
                  {
                     placa: 'AXN5100',
                     faturamento: 552185.1447110176,
                     documento: 108
                  },
                  {
                     placa: 'AXN7744',
                     faturamento: 547410.5401391983,
                     documento: 141
                  },
                  {
                     placa: 'AXN7711',
                     faturamento: 536922.7403030396,
                     documento: 127
                  },
                  {
                     placa: 'AXN7878',
                     faturamento: 524147.2487792969,
                     documento: 114
                  },
                  {
                     placa: 'AXN6001',
                     faturamento: 523455.7758998871,
                     documento: 109
                  }
               ]
            }
         }
      };
   }
}
