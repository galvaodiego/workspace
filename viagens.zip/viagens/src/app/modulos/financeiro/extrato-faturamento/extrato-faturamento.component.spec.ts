import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExtratoFaturamentoComponent } from './extrato-faturamento.component';

describe('ExtratoFaturamentoComponent', () => {
  let component: ExtratoFaturamentoComponent;
  let fixture: ComponentFixture<ExtratoFaturamentoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExtratoFaturamentoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExtratoFaturamentoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
