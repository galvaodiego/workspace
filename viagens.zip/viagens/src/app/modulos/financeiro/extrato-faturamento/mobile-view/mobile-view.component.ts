import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { DxMultiViewComponent } from 'devextreme-angular';
import { CommonService } from '../common.service';
import { getPalette } from 'devextreme/viz/palette';


@Component({
   selector: 'app-mobile-view',
   templateUrl: './mobile-view.component.html',
   styleUrls: ['./mobile-view.component.scss']
})
export class MobileViewComponent implements OnInit {
   @ViewChild('multiview', { static: false }) multiview: DxMultiViewComponent;
   @ViewChild('multiviewVeiculos', { static: false }) multiviewVeiculos: DxMultiViewComponent;
   @ViewChild('multiviewTipoFrete', { static: false }) multiviewTipoFrete: DxMultiViewComponent;

   chartTonFat = 1;
   showChartDoc = false;
   showChartVeiculos = false;
   showChartFrete = false;
   chartTipoFreteStack = true;

   // Multiview
   views: Array<any>;
   viewsTipoFrete: Array<any>;
   viewsVeiculos: Array<any>;
   porPagina: number;
   pages = 0;
   pagesTipoFrete = 0;
   pagesVeiculos = 0;
   // fim Multiview

   constructor(
      public common: CommonService
   ) { }
   datasourceMaster: any;
   get value(): any {
      return this.datasourceMaster;
   }

   @Input('datasourceMaster')
   set value(val: any) {
      this.datasourceMaster = val;
      if (this.datasourceMaster.exibir && this.datasourceMaster.exibir.length > 0) {
         this.common.exibir = [... this.datasourceMaster.exibir];
      } else {
         this.common.exibir = this.common.exibirDefault;
      }
      if (this.datasourceMaster.grafico) {
         if (this.datasourceMaster.grafico.docMes.dados.length > 0) {
            this.datasourceMaster.grafico.docMes.dados.reverse();
         }

         if (this.datasourceMaster.grafico.fatMes.dados.length > 0) {
            this.datasourceMaster.grafico.fatMes.dados.reverse();
         }

         if (this.datasourceMaster.grafico.pesoMes.dados.length > 0) {
            this.datasourceMaster.grafico.pesoMes.dados.reverse();
         }

         if (this.datasourceMaster.grafico.fatCarroceria.dados.length > 0) {
            this.datasourceMaster.grafico.fatCarroceria.dados.reverse();
         }
      }


      if (this.datasourceMaster.listaIndicador) {
         if (this.datasourceMaster.listaIndicador.listaProduto.dados.length > 0) {
            this.multiViewGrupos(this.datasourceMaster.listaIndicador.listaProduto.dados.reverse(), 1);
         }
         if (this.datasourceMaster.listaIndicador.listaTipoFrete.dados.length > 0) {
            this.multiViewTipoFrete(this.datasourceMaster.listaIndicador.listaTipoFrete.dados.reverse(), 1);
         }
         if (this.datasourceMaster.listaIndicador.listaCarroceria.dados.length > 0) {
            this.multiviewVeiculo(this.datasourceMaster.listaIndicador.listaCarroceria.dados.reverse(), 1);
         }
      }
   }
   ngOnInit() {
   }

   public onCellPreparedTops(e: any) {
      if (e.rowType === 'header') {
         e.cellElement.style.paddingTop = '5px';
         e.cellElement.style.paddingBottom = '5px';
         e.cellElement.style.fontSize = '1rem';
      }

      if (typeof (e.data) !== 'undefined') {
         e.cellElement.style.paddingTop = '8px';
         e.cellElement.style.paddingBottom = '8px';
      }
   }

   public customizeLabelProd(point) {
      return (point.percent * 100).toFixed() + ' %';
   }

   public customizeLegTopN(arg) {
      if (arg.pointName === 'others') {
         return 'Outros';
      } else {
         return arg.pointName;
      }
   }

   public customizePointMultiple = (arg: any) => {
      const palette = getPalette('Material');
      const index = arg.index % (palette.simpleSet.length - 1);
      return { color: palette.simpleSet[index] };
   }

   multiviewVeiculo(lista, porPagina) {
      lista = lista.reverse();
      this.viewsVeiculos = [];
      this.pagesVeiculos = Math.ceil(lista.length / porPagina);
      for (let index = 0; index < this.pagesVeiculos; index++) {
         this.viewsVeiculos.push(this.common.paginate(lista, porPagina, index + 1));
      }

   }
   multiViewGrupos(lista, porPagina) {
      lista = lista.reverse();
      this.views = [];
      this.pages = Math.ceil(lista.length / porPagina);
      for (let index = 0; index < this.pages; index++) {
         this.views.push(this.common.paginate(lista, porPagina, index + 1));
      }
   }

   multiViewTipoFrete(lista, porPagina) {
      lista = lista.reverse();
      this.viewsTipoFrete = [];
      this.pagesTipoFrete = Math.ceil(lista.length / porPagina);
      for (let index = 0; index < this.pagesTipoFrete; index++) {
         this.viewsTipoFrete.push(this.common.paginate(lista, porPagina, index + 1));
      }
   }

   paginate(array, pageSize, pageNumber) {
      --pageNumber;
      return array.slice(pageNumber * pageSize, (pageNumber + 1) * pageSize);
   }

   trocaView(direction: string, context: any) {
      let mv = null;
      let pg = 0;
      switch (context) {
         case 'multiviewTipoFrete':
            mv = this.multiviewTipoFrete;
            pg = this.pagesTipoFrete;
            break;
         case 'multiviewGrupoProduto':
            mv = this.multiview;
            pg = this.pages;
            break;
         case 'multiviewVeiculos':
            mv = this.multiviewVeiculos;
            pg = this.pagesVeiculos;
            break;

      }

      if (mv) {
         if (mv.selectedIndex === pg - 1) {
            mv.selectedIndex = 0;
         } else {
            if (direction === 'next') {
               mv.selectedIndex = mv.selectedIndex + 1;
            } else {
               mv.selectedIndex = mv.selectedIndex - 1;
            }
         }
      }
   }

}
