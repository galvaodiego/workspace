import { Injectable } from '@angular/core';


@Injectable({
   providedIn: 'root'
})
export class CommonService {
   pagesVeiculos = 0;
   pages = 0;
   pagesTipoFrete = 0;
   exibir = [];

   exibirDefault = [
      { nome: 'totalizadores_documentos', exibe: 1 },
      { nome: 'totalizadores_veiculos', exibe: 1 },
      { nome: 'grafico_modalidade', exibe: 1 },
      { nome: 'clientes', exibe: 1 },
      { nome: 'tipo_frete', exibe: 1 },
      { nome: 'totalizadores_tipo_produto', exibe: 1 },
      { nome: 'lista_motoristas', exibe: 1 },
      { nome: 'lista_veiculos', exibe: 1 },
   ];

   constructor() { }



   reset() {
      const ds = {
         grafico: {
            fatMes: { dados: [] },
            pesoMes: { dados: [] },
            docMes: { dados: [] },
            fatCarroceria: { dados: [] },
            fatCliente: { dados: [] },
            fatGrupoProduto: { dados: [] },
            fatModalidade: { dados: [] },
            freteMes: { titulo: [], dados: [] }
         },
         indicador: {
            faturamento: 0,
            documento: 0,
            peso: 0,
            emitido: 0,
            cancelado: 0,
            mediaFaturamento: 0,
            mediaCarroceria: 0
         },
         listaIndicador: {
            listaProduto: { dados: [] },
            listaCarroceria: { dados: [] },
            listaTipoFrete: { dados: [] },
         },
         lista: {
            motorista: { dados: [] },
            placa: { dados: [] },
         }
      };

      return ds;
   }

   getImg(ref) {
      let path = '';
      switch (ref) {
         case 'CAMINHAO 4X2':
            path = 'assets/images/extrato/truck6x2.png';
            break;
         case 'CAMINHAO 6X2':
         case 'CAMINHAO 6X4':
            path = 'assets/images/extrato/truck6x2.png';
            break;

         case 'CAMINHAO TRUCK':
            path = 'assets/images/extrato/truck-truck.png';
            break;
         case 'UTILITARIO':
            path = 'assets/images/extrato/truck6x2.png';
            break;

         default:
            path = 'assets/images/extrato/truck6x2.png';
            break;
      }

      return path;
   }

   paginate(array, pageSize, pageNumber) {
      --pageNumber;
      return array.slice(pageNumber * pageSize, (pageNumber + 1) * pageSize);
   }

   visibilidade(elemento: string) {
      const array = this.exibir.filter(e => {
         return e.nome === elemento;
      });
      if (array[0].exibe === 1) {
         return false;
      } else {
         return true;
      }
   }

}
