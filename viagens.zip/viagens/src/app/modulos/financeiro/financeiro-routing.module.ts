import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FaturamentoComponent } from './faturamento/faturamento.component';
import { GuardaRotas } from 'src/app/shared/guards/guarda-rotas.guard';
import { ExtratoFaturamentoComponent } from './extrato-faturamento/extrato-faturamento.component';


const routes: Routes = [
   { path: '', redirectTo: 'extrato-faturamento', pathMatch: 'full' },
   { path: 'faturamento', component: FaturamentoComponent, canActivate: [GuardaRotas] },
   { path: 'extrato-faturamento', component: ExtratoFaturamentoComponent, canActivate: [GuardaRotas] },
   { path: 'extrato-faturamento/card', component: ExtratoFaturamentoComponent, canActivate: [GuardaRotas], data: { tipo: 'card' } },

];

@NgModule({
   imports: [RouterModule.forChild(routes)],
   exports: [RouterModule]
})
export class FinanceiroRoutingModule { }
