import { Component, OnInit, Input } from '@angular/core';

@Component({
   selector: 'app-mapa-abas-mob-view',
   templateUrl: './mapa-abas-mob-view.component.html',
   styleUrls: ['./mapa-abas-mob-view.component.scss']
})
export class MapaAbasMobViewComponent implements OnInit {
   @Input() datasourceMaster: any;
   constructor() { }

   ngOnInit() {
   }

}
