import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MapaAbastecimentoComponent } from './mapa-abastecimento.component';

describe('MapaAbastecimentoComponent', () => {
  let component: MapaAbastecimentoComponent;
  let fixture: ComponentFixture<MapaAbastecimentoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MapaAbastecimentoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MapaAbastecimentoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
