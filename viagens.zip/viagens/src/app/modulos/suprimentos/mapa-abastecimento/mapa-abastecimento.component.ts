import { Component, OnInit, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { Usuario } from 'src/app/shared/models/usuario.model';
import { MediaMatcher } from '@angular/cdk/layout';

@Component({
   selector: 'app-mapa-abastecimento',
   templateUrl: './mapa-abastecimento.component.html',
   styleUrls: ['./mapa-abastecimento.component.scss']
})
export class MapaAbastecimentoComponent implements OnInit, OnDestroy {
   public user: Usuario = Usuario.instance;
   loadVisible = true;
   mobileQuery: MediaQueryList;
   // tslint:disable-next-line: variable-name
   private _mobileQueryListener: () => void;

   datasourceMaster: any;
   constructor(
      media: MediaMatcher,
      changeDetectorRef: ChangeDetectorRef,
   ) {
      this.mobileQuery = media.matchMedia('(max-width: 600px)');
      this._mobileQueryListener = () => changeDetectorRef.detectChanges();
      // tslint:disable-next-line: deprecation
      this.mobileQuery.addListener(this._mobileQueryListener);
   }

   ngOnInit() {
   }

   ngOnDestroy(): void {
      // this.socketIo.disconnect();
      // tslint:disable-next-line: deprecation
      this.mobileQuery.removeListener(this._mobileQueryListener);
   }

}
