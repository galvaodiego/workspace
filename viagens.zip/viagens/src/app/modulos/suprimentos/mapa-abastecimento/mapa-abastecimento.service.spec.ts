import { TestBed } from '@angular/core/testing';

import { MapaAbastecimentoService } from './mapa-abastecimento.service';

describe('MapaAbastecimentoService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MapaAbastecimentoService = TestBed.get(MapaAbastecimentoService);
    expect(service).toBeTruthy();
  });
});
