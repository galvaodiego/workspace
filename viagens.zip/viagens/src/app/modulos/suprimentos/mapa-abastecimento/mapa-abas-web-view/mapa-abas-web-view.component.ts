import { Component, OnInit, Input } from '@angular/core';
import { MapaAbastecimentoService } from '../mapa-abastecimento.service';

@Component({
   selector: 'app-mapa-abas-web-view',
   templateUrl: './mapa-abas-web-view.component.html',
   styleUrls: ['./mapa-abas-web-view.component.scss']
})
export class MapaAbasWebViewComponent implements OnInit {
   @Input() datasourceMaster: any;
   mapProvider: string;
   nivel: any;
   markers: any;
   flag: any;
   datasource = [];
   constructor(
      public mabService: MapaAbastecimentoService
   ) {
      this.nivel = mabService.nivel;
      this.markers = mabService.markers;
      this.mapProvider = mabService.mapProvider;
      this.flag = mabService.flag;
   }

   ngOnInit() {
   }


}
