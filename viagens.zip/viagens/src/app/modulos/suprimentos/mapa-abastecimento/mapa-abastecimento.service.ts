import { Injectable } from '@angular/core';

@Injectable({
   providedIn: 'root'
})
export class MapaAbastecimentoService {
   mapProvider = 'bing';
   nivel = {
      min1: 0,
      min2: 1.75,
      max1: 5000,
      max2: 3.50
   };
   markers: any = [
      {
         location: [-29.422, -49.873],
         iconSrc: 'assets/images/mapa-abastecimento/marker-red.png',
         tooltip: {
            isShown: false,
            text: 'AXN-5333'
         }
      },
      {
         location: [-23.514, -46.667],
         iconSrc: 'assets/images/mapa-abastecimento/marker-orange.png',
         tooltip: {
            isShown: false,
            text: 'AMB-3205'
         }
      },
      {
         location: [-26.249, -48.843],
         iconSrc: 'assets/images/mapa-abastecimento/marker-pink.png',

         tooltip: {
            isShown: false,
            text: 'AXN-5051'
         }
      },
      {
         location: [-23.896, -46.302],
         iconSrc: 'assets/images/mapa-abastecimento/marker-yellow.png',

         tooltip: {
            isShown: false,
            text: 'AXN-8J09'
         }
      },
      {
         location: [-23.757, -46.454],
         iconSrc: 'assets/images/mapa-abastecimento/marker-green.png',

         tooltip: {
            isShown: false,
            text: 'AXN-8G00'
         }
      },
   ];

   flag = {
      chart1: true,
      chart2: true,
      chart3: false,
      chart4: false,
      chart5: true
   };

   media = [{
      name: 'percentage',
      position: 'right',
      showZero: true,
      constantLines: [{
          value: 80,
          color: '#fc3535',
          dashStyle: 'dash',
          width: 2,
          label: { visible: false }
      }],
      tickInterval: 20,
      valueMarginsEnabled: false
  }];

   constructor() { }


   getImg(chart) {
      let path = '';
      if (chart) {
         path = 'assets/images/mapa-abastecimento/to-table-view.png';
      } else {
         path = 'assets/images/mapa-abastecimento/to-chart-view.png';
      }

      return path;
   }
}
