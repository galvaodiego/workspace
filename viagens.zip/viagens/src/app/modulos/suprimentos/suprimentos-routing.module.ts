import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GuardaRotas } from 'src/app/shared/guards/guarda-rotas.guard';
import { MapaAbastecimentoComponent } from './mapa-abastecimento/mapa-abastecimento.component';


const routes: Routes = [
   { path: '', redirectTo: 'mapa-abastecimento', pathMatch: 'full' },
   { path: 'mapa-abastecimento', component: MapaAbastecimentoComponent, canActivate: [GuardaRotas] },

];

@NgModule({
   imports: [RouterModule.forChild(routes)],
   exports: [RouterModule]
})
export class SuprimentosRoutingModule { }
