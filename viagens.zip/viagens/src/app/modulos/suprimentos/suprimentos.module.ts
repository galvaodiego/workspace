import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MapaAbastecimentoComponent } from './mapa-abastecimento/mapa-abastecimento.component';
import { SuprimentosRoutingModule } from './suprimentos-routing.module';
import { MapaAbasWebViewComponent } from './mapa-abastecimento/mapa-abas-web-view/mapa-abas-web-view.component';
import { MapaAbasMobViewComponent } from './mapa-abastecimento/mapa-abas-mob-view/mapa-abas-mob-view.component';
import { DxDataGridModule, DxMapModule, DxChartModule } from 'devextreme-angular';



@NgModule({
  declarations: [MapaAbastecimentoComponent, MapaAbasWebViewComponent, MapaAbasMobViewComponent],
  imports: [
    CommonModule,
    SuprimentosRoutingModule,
    DxMapModule,
    DxDataGridModule,
    DxChartModule,
  ]
})
export class SuprimentosModule { }
