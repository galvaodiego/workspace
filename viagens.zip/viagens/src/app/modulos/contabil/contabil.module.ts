import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DreComponent } from './dre/dre.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { ContabilRoutingModule } from './contabil-routing.module';
// componentes
import { ModalPeriodoComponent } from './dre/modal-periodo/modal-periodo.component';
import { ModalLayoutComponent } from './dre/modal-layout/modal-layout.component';





@NgModule({
   declarations: [DreComponent, ModalPeriodoComponent, ModalLayoutComponent],
   imports: [
      CommonModule,
      SharedModule,
      ContabilRoutingModule
   ],
   entryComponents: [
      ModalPeriodoComponent,
      ModalLayoutComponent,
   ],
})
export class ContabilModule { }
