import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import * as moment from 'moment';
import 'moment/locale/pt-br';
import * as _ from 'underscore';
import { GatewayService } from 'src/app/shared/services/gateway.service';
import { EstruturaOrganizacional } from 'src/app/shared/models/organizacional.model';
import { Usuario } from 'src/app/shared/models/usuario.model';
import { MatDialog } from '@angular/material/dialog';
import { ModalPeriodoComponent } from './modal-periodo/modal-periodo.component';
import { ModalLayoutComponent } from './modal-layout/modal-layout.component';
import { NotificacaoService } from 'src/app/shared/services/notificacao.service';
import { MatBottomSheet } from '@angular/material/bottom-sheet';
@Component({
   selector: 'app-dre',
   templateUrl: './dre.component.html',
   styleUrls: ['./dre.component.scss']
})
export class DreComponent implements OnInit {
   public user: Usuario = Usuario.instance;
   public org: EstruturaOrganizacional = EstruturaOrganizacional.instance;

   loadVisible = false;
   public tipo: string;
   public demonstrativoId: number;
   public demonstrativoAno: string;
   public dataExibicao: string;
   public numMes: any;

   public listaItens: Array<any> = [];
   public listaFiltros: Array<any> = [];
   public listaFiltrosDisponiveis: Array<any> = [];
   public listaFiltrosSelecionados: Array<any> = [];
   public periodoFilter: any = [];



   // filtro
   public listaMes: Array<any> = [];
   public novaData = '';
   public dataDia = '';
   public dataMes = '';
   public dataAno = '';
   public ativo: any = {};


   showFiltros = false;



   constructor(
      private gateway: GatewayService,
      public dialog: MatDialog,
      private notificacao: NotificacaoService,
      private location: Location,
   ) {
      this.dataExibicao = moment().format();
      this.montaDatas();
      this.tipo = 'GERAL';

      // default
      this.demonstrativoId = 5;
      this.demonstrativoAno = moment(this.dataExibicao).format('YYYY');
      this.periodoFilter.mes = moment(this.dataExibicao).format('MMM');
      this.periodoFilter.ano = moment(this.dataExibicao).format('YYYY');
   }

   ngOnInit() {
      this.getDemonstrativo().then(e => {
         this.getCalendarioDRE();
      });
   }

   abreFiltros(): void {
      this.showFiltros = !this.showFiltros;
   }

   async getCalendarioDRE() {
      try {
         const response: any = await this.gateway.backendCall('M4002', 'getCalendarioDRE');
         this.listaMes = response.calendario_dre;
         this.listaMes.forEach(
            (element) => {
               element.mes = element.mes.toLowerCase();
            }
         );

         console.log('listaMes', this.listaMes);

      } catch (error) {
         console.log('Error:', error);
      }
   }

   public montaDatas() {
      let dados = [];

      if (this.dataExibicao.indexOf('-') > -1) {
         dados = this.dataExibicao.split('-');

         this.dataDia = dados[2].substring(0, 2);
         this.dataMes = dados[1];
         this.dataAno = dados[0];

         this.novaData = this.dataDia + '/' + this.dataMes + '/' + this.dataAno;
      } else {
         dados = this.dataExibicao.split('/');

         this.dataDia = dados[0];
         this.dataMes = dados[1];
         this.dataAno = dados[2];

         this.novaData = this.dataDia + '/' + this.dataMes + '/' + this.dataAno;
      }
   }


   public setNovaData(i, ano) {
      const data = (moment().month(i - 1).format('YYYY') + '-' + moment().month(i - 1).format('MM') + '-01');
      const parametros = JSON.parse(localStorage.getItem('parametros'));
      if (parametros) {
         Object.assign(parametros, {
            data_inicio: ('01/' + moment().month(i - 1).format('MM') + '/' + moment().month(i - 1).format('YYYY'))
         });
         this.periodoFilter.mes = moment(data).format('MMM');
         this.periodoFilter.ano = moment(data).format('YYYY');
         this.getData(parametros);
         this.showFiltros = false;
      } else {
         console.log('Erro nos parametros');
      }
   }

   async getDemonstrativo() {
      this.loadVisible = true;

      try {
         const response: any = await this.gateway.backendCall('M4002', 'getDemonstrativo');
         this.agrupaPorAno(response.layout);
         this.loadVisible = false;
      } catch (error) {
         console.log('Error:', error);
      }
   }
   public agrupaPorAno(layouts: Array<any>) {
      const layoutsPorAno = [];
      layouts.forEach((i) => {
         let diferente = true;
         layoutsPorAno.forEach((j) => {
            if (i.ano === j.ano) {
               diferente = false;
            }
         });
         if (diferente) {
            layoutsPorAno.push({ ano: i.ano });
         }
      });
      layoutsPorAno.forEach((i) => {
         i.layouts = [];
         layouts.forEach((j) => {
            if (i.ano === j.ano) {
               i.layouts.push(j);
            }
         });
      });
      this.mostraAlertaAno(layoutsPorAno);
   }

   public mostraAlertaAno(layoutsPorAno) {
      const dialogRef = this.dialog.open(ModalPeriodoComponent, {
         width: '250px',
         data: { layoutsPorAno }
      });

      dialogRef.afterClosed().subscribe(result => {
         this.mostraAlertaId(result);
      });
   }

   public mostraAlertaId(layouts) {
      const dialogRef = this.dialog.open(ModalLayoutComponent, {
         width: '250px',
         data: { lista: layouts }
      });

      dialogRef.afterClosed().subscribe(result => {
         if (result) {
            const parametros = {
               demonstrativo_id: result.layouts.demonstrativo_id,
               ano_plano: result.layouts.ano,
               usuario_bi_id: this.org.usuario.usuarioBiId,
               organizacional: this.org.permissoes[0].organizacional,
               cod_nivel_organizacional: this.org.permissoes[0].tipoOrganizacional,
               configuracao_org_id: this.org.configOrgUsuario[0].configOrgId,
               data_inicio: moment(this.dataExibicao).format('DD/MM/YYYY'),
               organizacional_id: this.org.permissoes[0].organizacionalId,
            };
            this.getData(parametros);
         }
      });
   }

   async getData(parametros: any) {
      Object.assign(parametros, {
         nivel: 1,
         layout_id_pai: '-1'
      });

      localStorage.setItem('parametros', JSON.stringify(parametros));

      try {
         this.loadVisible = true;

         const result: any = await this.gateway.backendCall('M4002', 'getDRE', parametros);
         if (result.layout.length > 0) {
            // console.log('result', result);
            this.listaItens = [];
            this.listaFiltros = [];
            this.listaFiltrosDisponiveis = [];
            this.listaFiltrosSelecionados = [];

            this.listaItens = result.layout;
            this.listaItens = this.listaItens.sort((a, b) => (+a.ordem > +b.ordem) ? 1 : -1);
            console.log(this.listaItens);

            this.normalizeArrayItems(this.listaItens);
            this.getFilterList(this.listaItens);
            this.processaListaFiltros(this.listaFiltrosDisponiveis);
            this.filterList(this.listaItens, this.listaFiltrosSelecionados);
         } else {
            this.notificacao.openSnackBar('Nenhum registro encontrado', 'Fechar', 3000);
            this.location.back();

         }
         this.loadVisible = false;
      } catch (error) {
         console.log('Error:', error);
      }
   }

   public normalizeArrayItems(lista: Array<any>) {
      lista.forEach(
         (element) => {
            if (this.hasChild(element)) {
               if (typeof (element.valor) === 'undefined') {
                  element.valor = 0;
               }
               // passa o caminho do item(layout)
               this.normalizeArrayItems(element.layout);
            } else {
               return;
            }
         }
      );

   }

   public sum(lista: Array<any>) {
      lista.forEach(element => {
         if (this.hasChild(element)) {
            this.sum(element.layout);
            element.valor = element.layout.map(
               (vlrs) => {
                  // tslint:disable-next-line: no-string-literal
                  return vlrs['valor'];
               }
            ).reduce((anterior, atual) => {
               return (anterior + atual);
            }, 0);
         } else {
            return;
         }
      });
   }

   public hasChild(item: any) {
      if (typeof (item.layout) !== 'undefined') {
         return true;
      }
      return false;
   }

   public getFilterList(lista: Array<any>) {
      lista.forEach(
         (element) => {
            if (this.hasChild(element)) {
               this.getFilterList(element.layout);
            } else {
               if (element.org) {
                  const organizacionalDetalhado: string = element.org;
                  this.listaFiltrosDisponiveis.push(organizacionalDetalhado.split('???'));
               }
               return;
            }
         }
      );
   }

   public processaListaFiltros(filtros: Array<any>) {
      _.unzip(filtros).forEach(element => {
         this.listaFiltros.push(_.uniq(element).sort());
      });
   }

   public setMenuFilterData() {
      let listaFiltrosPorTipoOrganizacional: Array<any> = [];
      switch (this.org.permissoes[0].tipoOrganizacional.toLowerCase()) {
         case 'transpanorama':
            listaFiltrosPorTipoOrganizacional = this.listaFiltros;
            break;
         case 'diretoria':
            listaFiltrosPorTipoOrganizacional.push(this.listaFiltros[1]);
            listaFiltrosPorTipoOrganizacional.push(this.listaFiltros[2]);
            break;
         case 'centro':
            listaFiltrosPorTipoOrganizacional.push(this.listaFiltros[1]);
            listaFiltrosPorTipoOrganizacional.push(this.listaFiltros[2]);
            break;
         case 'segmento':
            listaFiltrosPorTipoOrganizacional.push(this.listaFiltros[2]);
            break;
         default:
      }
      // this.events.publish('listaFiltros:show', {
      //    listaFiltros: listaFiltrosPorTipoOrganizacional
      // });
   }

   public filterList(lista: Array<any>, filtro?: Array<any>) {
      const diretorias: Array<any> = filtro[0] ? filtro[0] : [];
      const segmentos: Array<any> = filtro[1] ? filtro[1] : [];
      const centros: Array<any> = filtro[2] ? filtro[2] : [];
      const grupos: Array<any> = filtro[3] ? filtro[3] : [];

      lista.forEach(element => {
         if (this.hasChild(element)) {
            this.filterList(element.layout, filtro);
            element.valor = element.layout
               .filter(
                  // tslint:disable-next-line: no-string-literal
                  (it) => ((diretorias.length > 0 && it['org']) ? diretorias.some(el =>
                     // tslint:disable-next-line: no-string-literal
                     it['org'].toLowerCase().indexOf(el.toLowerCase()) > -1
                  ) : this)
               )
               .filter(
                  // tslint:disable-next-line: no-string-literal
                  (it) => ((segmentos.length > 0 && it['org']) ? segmentos.some(el =>
                     // tslint:disable-next-line: no-string-literal
                     it['org'].toLowerCase().indexOf(el.toLowerCase()) > -1
                  ) : this)
               )
               .filter(
                  // tslint:disable-next-line: no-string-literal
                  (it) => ((centros.length > 0 && it['org']) ? centros.some(el => it['org'].toLowerCase().indexOf(el.toLowerCase()) > -1
                  ) : this)
               )
               .filter(
                  // tslint:disable-next-line: no-string-literal
                  (it) => ((grupos.length > 0 && it['org']) ? grupos.some(el => it['org'].toLowerCase().indexOf(el.toLowerCase()) > -1
                  ) : this)
               )
               .map(
                  (vlrs) => {
                     // tslint:disable-next-line: no-string-literal
                     return vlrs['valor'];
                  }
               ).reduce((anterior, atual) => {
                  return (anterior + atual);
               }, 0);
         } else {
            return;
         }
      });
   }


   back() {
      this.location.back();
   }

   /*
	 * Navega para a Pagina de Filtro da Data
	 */
   //    public navigate(page: string, container?: FabContainer) {
   //       if (container) {
   //           container.close();
   //       }
   //       switch (page) {
   //           case 'dre-date-filter':
   //               console.log('navigate dataExibicao', this.dataExibicao);
   //               this.navCtrl.push(DreFilterPage, {
   //                   dataInicio: this.dataExibicao
   //               });
   //               break;
   //           default:
   //       }
   //   }

}
