import { Component, OnInit, Inject } from '@angular/core';
import { Location } from '@angular/common';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
export interface DialogData {
   lista: any;
}
@Component({
   selector: 'app-modal-layout',
   templateUrl: './modal-layout.component.html',
   styleUrls: ['./modal-layout.component.scss']
})
export class ModalLayoutComponent implements OnInit {

   constructor(
      public dialogRef: MatDialogRef<ModalLayoutComponent>,
      @Inject(MAT_DIALOG_DATA) public data: DialogData,
      private location: Location
   ) { }

   ngOnInit() {
      // console.log('data', this.data.lista);
   }

   cancel() {
      this.location.back();
   }

   seleciona(layouts) {
      this.dialogRef.close({ layouts });
   }

}
