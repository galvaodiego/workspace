import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IndicadoresComponent } from './indicadores/indicadores.component';
import { HttpClientModule } from '@angular/common/http';

import { LogisticoRoutingModule } from './logistico-routing.module';
import { SharedModule } from 'src/app/shared/shared.module';
import { ColetaDeCargaModule } from './coleta-de-carga/coleta-de-carga.module';

// components
import { LogisticoCardComponent } from './indicadores/logistico-card/logistico-card.component';
import { IndicadoresDetalhesComponent } from './indicadores/indicadores-detalhes/indicadores-detalhes.component';
import { IndicadoresService } from './indicadores/indicadores.service';
import { MapaRastreamentoComponent } from './mapa-rastreamento/mapa-rastreamento.component';




@NgModule({
   declarations: [
      IndicadoresComponent,
      LogisticoCardComponent,
      IndicadoresDetalhesComponent,
      MapaRastreamentoComponent,
   ],
   imports: [
      CommonModule,
      HttpClientModule,
      SharedModule,
      LogisticoRoutingModule,
      ColetaDeCargaModule
   ],
   providers: [IndicadoresService]
})
export class LogisticoModule { }
