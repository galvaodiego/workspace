import { Component, OnInit, OnDestroy } from '@angular/core';
import { PageDetalhesService } from './page-detalhes.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-page-detalhes',
  templateUrl: './page-detalhes.component.html',
  styleUrls: ['./page-detalhes.component.scss']
})
export class PageDetalhesComponent implements OnInit, OnDestroy {
  dsDetalhes;
  origem;
  constructor(
    public pageDetalhesService: PageDetalhesService,
    private router: Router
  ) {
    if (this.pageDetalhesService.dsDetalhes) {
      this.origem = this.pageDetalhesService.origem;
      this.dsDetalhes = this.pageDetalhesService.dsDetalhes;
      localStorage.setItem('coleta-de-carga-detalhes'
        , JSON.stringify({ origem: this.pageDetalhesService.origem, dsDetalhes: this.pageDetalhesService.dsDetalhes })
      );
    } else {
      const storage = JSON.parse(localStorage.getItem('coleta-de-carga-detalhes'));
      if (storage) {
        this.origem = storage.origem;
        this.dsDetalhes = storage.dsDetalhes;
      } else {
        // redireciona pra coleta
        this.router.navigate(['logistico/coleta-de-carga']);
      }
    }
  }

  ngOnDestroy(): void {
    localStorage.removeItem('coleta-de-carga-detalhes');
  }

  ngOnInit() {
  }

  voltar() {
    this.router.navigate(['logistico/coleta-de-carga']);
  }

}
