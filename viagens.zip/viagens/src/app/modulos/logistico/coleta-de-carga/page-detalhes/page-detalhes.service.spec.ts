import { TestBed } from '@angular/core/testing';

import { PageDetalhesService } from './page-detalhes.service';

describe('PageDetalhesService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PageDetalhesService = TestBed.get(PageDetalhesService);
    expect(service).toBeTruthy();
  });
});
