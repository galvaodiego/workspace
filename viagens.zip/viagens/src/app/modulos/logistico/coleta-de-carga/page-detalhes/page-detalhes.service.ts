import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PageDetalhesService {
  origem: string;
  dsDetalhes: any;
  constructor() { }
}
