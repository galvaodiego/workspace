import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ColetaDeCargaComponent } from './coleta-de-carga.component';
import { MobileViewComponent } from './mobile-view/mobile-view.component';
import { DataGridComponent } from './componentes/data-grid/data-grid.component';
import { DevextremeModule } from 'src/app/shared/modules/devextreme/devextreme.module';
import { GaugeComponent } from './componentes/gauge/gauge.component';
import { CardKpiComponent } from './componentes/card-kpi/card-kpi.component';
import { MaterialModule } from 'src/app/shared/modules/material/material.module';
import { ColetasAbertoComponent } from './componentes/coletas-aberto/coletas-aberto.component';
import { ColetasConcluidasComponent } from './componentes/coletas-concluidas/coletas-concluidas.component';
import { CaDetalhesComponent } from './componentes/coletas-aberto/ca-detalhes/ca-detalhes.component';
import { WebViewComponent } from './web-view/web-view.component';
import { CcDetalhesComponent } from './componentes/coletas-concluidas/cc-detalhes/cc-detalhes.component';
import { PageDetalhesComponent } from './page-detalhes/page-detalhes.component';


@NgModule({
   declarations: [
      ColetaDeCargaComponent,
      MobileViewComponent,
      DataGridComponent,
      GaugeComponent,
      CardKpiComponent,
      ColetasAbertoComponent,
      ColetasConcluidasComponent,
      CaDetalhesComponent,
      WebViewComponent,
      CcDetalhesComponent,
      PageDetalhesComponent
   ],
   imports: [
      CommonModule,
      DevextremeModule,
      MaterialModule
   ]
})
export class ColetaDeCargaModule { }
