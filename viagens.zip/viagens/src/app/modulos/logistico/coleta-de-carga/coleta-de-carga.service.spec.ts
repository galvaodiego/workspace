import { TestBed } from '@angular/core/testing';

import { ColetaDeCargaService } from './coleta-de-carga.service';

describe('ColetaDeCargaService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ColetaDeCargaService = TestBed.get(ColetaDeCargaService);
    expect(service).toBeTruthy();
  });
});
