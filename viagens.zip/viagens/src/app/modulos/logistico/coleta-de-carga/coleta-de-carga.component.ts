import { Component, OnInit, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { GatewayService } from 'src/app/shared/services/gateway.service';
import { Usuario } from 'src/app/shared/models/usuario.model';
import { EstruturaOrganizacional } from 'src/app/shared/models/organizacional.model';
import { MediaMatcher } from '@angular/cdk/layout';

@Component({
  selector: 'app-coleta-de-carga',
  templateUrl: './coleta-de-carga.component.html',
  styleUrls: ['./coleta-de-carga.component.scss']
})
export class ColetaDeCargaComponent implements OnInit, OnDestroy {
  private user: Usuario = Usuario.instance;
  public org: EstruturaOrganizacional = EstruturaOrganizacional.instance;
  loadVisible = true;
  dataSourceMaster: any;
  mobileQuery: MediaQueryList;
  // tslint:disable-next-line: variable-name
  private _mobileQueryListener: () => void;

  public opStatus = ['Todos', 'Descarga', 'Viagem'];

  constructor(
    private gateway: GatewayService,
    media: MediaMatcher,
    changeDetectorRef: ChangeDetectorRef,
  ) {
    this.mobileQuery = media.matchMedia('(max-width: 600px)');
    this._mobileQueryListener = () => changeDetectorRef.detectChanges();
    // tslint:disable-next-line: deprecation
    this.mobileQuery.addListener(this._mobileQueryListener);
  }

  ngOnInit() {
    this.getDados();
  }
  ngOnDestroy() {
    this.mobileQuery.removeListener(this._mobileQueryListener);

  }

  async getDados() {
    try {
      const response: any = await this.gateway.backendCall('M4002', 'getSolicRomaneio', { usuario_bi_id: this.org.usuario.usuarioBiId });
      console.log('res', (response));
      if (response) {
        this.dataSourceMaster = response.solicitacoes[0];
    // this.dataSourceMaster = this.coletaDeCargaService.dummy;

        this.loadVisible = false;
      }

    } catch (error) {
      console.log('Erro -> ', error);
      return;
    }
  }

}
