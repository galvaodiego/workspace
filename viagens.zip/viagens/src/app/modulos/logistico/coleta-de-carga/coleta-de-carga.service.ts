import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ColetaDeCargaService {
  public opStatus = ['Todos', 'Descarga', 'Finalizado', 'Viagem'];
  detalhes = {
    romaneio: 284482,
    num_solicitacao: 412820,
    data_carregamento: '13/05/2020',
    data_entrega: '13/05/2020',
    volume: 0,
    placa: 'BBX4E08',
    remetente: 'YORK - SALTO / SP',
    destinatario: 'LEAR - BETIM/MG',
    mercadoria: 'Peças e Partes Automotivas ',
    motorista: 'ELISEU FORTUNATO DE JESUS',
    coletas: [
      {
        coletado: 1,
        remetente: 'Salto-SP/São Bernardo do Campo-SP',
        rota: 'Salto-SP/São Bernardo do Campo-SP',
        data_carga: '13/05/2020 09:13'
      }
    ]
  };
  dummy = {
    solicitacoes: [
      {
        indicadores: {
          solCargaViagem: 1,
          solCargaDia: 1,
          solCargaDiaPerc: 100
        },
        listas: {
          solCargaAberto: [
            {
              solCargaId: 412629,
              notas: '',
              mercadoria: 'Peças e Partes Automotivas ',
              operacao: 'JOINVILLE-SC X ARAQUARI-SC',
              origem: 'Joinville-SC',
              destino: 'Araquari-SC',
              destinatario: 'BMW DO BRASIL - ARAQUARI/SC',
              coleta: 'LEAR - JOINVILLE / SC',
              data: '13/05/2020',
              volume: 1
            },
            {
              solCargaId: 412632,
              notas: '',
              mercadoria: 'Peças e Partes Automotivas ',
              operacao: 'JOINVILLE-SC X ARAQUARI-SC',
              origem: 'Joinville-SC',
              destino: 'Araquari-SC',
              destinatario: 'BMW DO BRASIL - ARAQUARI/SC',
              coleta: 'LEAR - JOINVILLE / SC',
              data: '13/05/2020',
              volume: 1
            }
          ],
          coletasAberto: [
            {
              romaneio: 284482,
              coletados: 1,
              coletas: 1
            }
          ],
          coletasConcluidas: [
            {
              romaneio: 185006,
              status: 'descarga',
              referencia: 'Sulista São José Pinhais'

            }
          ]
        }
      }
    ]
  };
  constructor() { }
}
