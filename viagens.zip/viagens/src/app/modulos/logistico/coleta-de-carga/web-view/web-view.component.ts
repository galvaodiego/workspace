import { Component, OnInit, Input } from '@angular/core';
import { ColetaDeCargaService } from '../coleta-de-carga.service';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'coleta-carga-web-view',
  templateUrl: './web-view.component.html',
  styleUrls: ['./web-view.component.scss']
})
export class WebViewComponent implements OnInit {
  datasourceCC = [];
  opStatus = [];
  constructor(
    private coletaCargaService: ColetaDeCargaService
  ) { }
  datasourceMaster: any;
  get value(): any {
     return this.datasourceMaster;
  }

  @Input('datasourceMaster')
  set value(val: any) {
     this.datasourceMaster = val;
     if (this.datasourceMaster) {
        // CODE HERE
        if (this.datasourceMaster.listas.coletasConcluidas) {
           this.datasourceCC = [... this.datasourceMaster.listas.coletasConcluidas];
        }
     }

  }
  ngOnInit() {
    this.opStatus = this.coletaCargaService.opStatus;
  }

  filtroConcluidas(e) {

    let coletasConcluidas = [... this.datasourceMaster.listas.coletasConcluidas];

    if (e.value !== 'Todos') {
       coletasConcluidas = coletasConcluidas.filter(v => {
          return v.status === e.value.toLowerCase();
       });

       this.datasourceCC = coletasConcluidas;
    } else {
       this.datasourceCC = [... this.datasourceMaster.listas.coletasConcluidas];
    }

 }

}
