import { Component, OnInit, Input } from '@angular/core';
import { ColetaDeCargaService } from '../coleta-de-carga.service';

@Component({
   // tslint:disable-next-line: component-selector
   selector: 'coleta-carga-mobile-view',
   templateUrl: './mobile-view.component.html',
   styleUrls: ['./mobile-view.component.scss']
})
export class MobileViewComponent implements OnInit {
   public views: Array<any> = [];
   public opStatus = [];

   datasourceCC = [];
   constructor(
      private coletaCargaService: ColetaDeCargaService
   ) {
   }
   datasourceMaster: any;
   get value(): any {
      return this.datasourceMaster;
   }

   @Input('datasourceMaster')
   set value(val: any) {
      this.datasourceMaster = val;
      if (this.datasourceMaster) {
         // CODE HERE
         if (this.datasourceMaster.listas.coletasConcluidas) {
            this.datasourceCC = [... this.datasourceMaster.listas.coletasConcluidas];
         }


         this.views.push(
            {
               descricao: 'Solicitações de Carga Atendidas no Dia',
               valor: this.datasourceMaster.indicadores.solCargaDia,
               icon: 'check_circle_outline'
            }
         );

         this.views.push(
            {
               descricao: 'Solicitações de carga atend. com viagem finalizada',
               valor: this.datasourceMaster.indicadores.solCargaViagem,
               icon: 'departure_board'
            }
         );

      }

   }
   ngOnInit() {
      this.opStatus = this.coletaCargaService.opStatus;
   }


   filtroConcluidas(e) {

      let coletasConcluidas = [... this.datasourceMaster.listas.coletasConcluidas];

      if (e.value !== 'Todos') {
         coletasConcluidas = coletasConcluidas.filter(v => {
            return v.status === e.value.toLowerCase();
         });

         this.datasourceCC = coletasConcluidas;
      } else {
         this.datasourceCC = [... this.datasourceMaster.listas.coletasConcluidas];
      }

   }


}
