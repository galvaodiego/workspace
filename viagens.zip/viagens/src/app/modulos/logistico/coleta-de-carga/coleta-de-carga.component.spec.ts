import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ColetaDeCargaComponent } from './coleta-de-carga.component';

describe('ColetaDeCargaComponent', () => {
  let component: ColetaDeCargaComponent;
  let fixture: ComponentFixture<ColetaDeCargaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ColetaDeCargaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ColetaDeCargaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
