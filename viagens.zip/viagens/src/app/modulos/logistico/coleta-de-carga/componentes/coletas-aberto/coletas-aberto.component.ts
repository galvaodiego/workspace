import { Component, OnInit, Input, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { GatewayService } from 'src/app/shared/services/gateway.service';
import { MediaMatcher } from '@angular/cdk/layout';
import { PageDetalhesService } from '../../page-detalhes/page-detalhes.service';
import { Router } from '@angular/router';

@Component({
   // tslint:disable-next-line: component-selector
   selector: 'cdc-coletas-aberto',
   templateUrl: './coletas-aberto.component.html',
   styleUrls: ['./coletas-aberto.component.scss']
})
export class ColetasAbertoComponent implements OnInit, OnDestroy {
   dsDetalhes = [];
   popupVisible = false;
   mobileQuery: MediaQueryList;
   // tslint:disable-next-line: variable-name
   private _mobileQueryListener: () => void;
   constructor(
      private gateway: GatewayService,
      media: MediaMatcher,
      changeDetectorRef: ChangeDetectorRef,
      private pageDetalhesService: PageDetalhesService,
      private router: Router
   ) {
      this.mobileQuery = media.matchMedia('(max-width: 600px)');
      this._mobileQueryListener = () => changeDetectorRef.detectChanges();
      // tslint:disable-next-line: deprecation
      this.mobileQuery.addListener(this._mobileQueryListener);
   }
   @Input() datasource;
   ngOnInit() {

   }

   ngOnDestroy() {
      this.mobileQuery.removeListener(this._mobileQueryListener);
   }

   async openDetalhes(romaneio) {
      try {
         const response: any = await this.gateway.backendCall('M4002', 'getRomaneio', { romaneio });
         if (response) {
            this.pageDetalhesService.dsDetalhes = response.lista;
            this.pageDetalhesService.origem = 'coletas-aberto';
            this.router.navigate(['logistico/coleta-de-carga/detalhes']);
         }

      } catch (error) {
         console.log('Erro -> ', error);
         return;
      }
   }

   getPercent(v1, v2) {
      const numero = 100 / v2;
      return Math.round(v1 * numero);
   }

   onCellPrepared(e) {
      if (e.rowType === 'header') {
         e.cellElement.style.paddingTop = '5px';
         e.cellElement.style.paddingBottom = '5px';
         e.cellElement.style.fontSize = '1rem';
         e.cellElement.style.display = 'none';
      }

      if (typeof (e.data) !== 'undefined') {
         e.cellElement.style.paddingTop = '8px';
         e.cellElement.style.paddingBottom = '8px';
      }
   }

}
