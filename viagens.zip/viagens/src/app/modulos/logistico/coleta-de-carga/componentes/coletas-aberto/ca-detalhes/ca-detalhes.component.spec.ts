import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CaDetalhesComponent } from './ca-detalhes.component';

describe('CaDetalhesComponent', () => {
  let component: CaDetalhesComponent;
  let fixture: ComponentFixture<CaDetalhesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CaDetalhesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CaDetalhesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
