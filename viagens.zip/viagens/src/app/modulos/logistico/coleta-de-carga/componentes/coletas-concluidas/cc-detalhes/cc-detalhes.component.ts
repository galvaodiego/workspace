import { Component, Input, OnChanges, SimpleChanges, OnDestroy } from '@angular/core';

@Component({
   // tslint:disable-next-line:component-selector
   selector: 'coc-cc-detalhes',
   templateUrl: './cc-detalhes.component.html',
   styleUrls: ['./cc-detalhes.component.scss']
})
export class CcDetalhesComponent implements OnChanges, OnDestroy {
   @Input() datasource;
   constructor() { }
   ngOnDestroy(): void {}
   ngOnChanges(changes: SimpleChanges): void {
   }

   onCellPrepared(e) {
      if (e.rowType === 'header') {
         e.cellElement.style.paddingTop = '5px';
         e.cellElement.style.paddingBottom = '5px';
         e.cellElement.style.fontSize = '1rem';
         e.cellElement.style.display = 'none';
      }

      if (typeof (e.data) !== 'undefined') {
         e.cellElement.style.paddingTop = '8px';
         e.cellElement.style.paddingBottom = '8px';
      }
   }

}
