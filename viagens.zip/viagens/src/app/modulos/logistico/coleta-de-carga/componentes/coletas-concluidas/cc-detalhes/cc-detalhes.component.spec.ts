import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CcDetalhesComponent } from './cc-detalhes.component';

describe('CcDetalhesComponent', () => {
  let component: CcDetalhesComponent;
  let fixture: ComponentFixture<CcDetalhesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CcDetalhesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CcDetalhesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
