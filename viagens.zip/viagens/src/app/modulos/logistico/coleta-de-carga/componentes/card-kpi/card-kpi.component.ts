import { Component, OnInit, Input } from '@angular/core';

@Component({
  // tslint:disable-next-line: component-selector
  selector: 'cdc-card-kpi',
  templateUrl: './card-kpi.component.html',
  styleUrls: ['./card-kpi.component.scss']
})
export class CardKpiComponent implements OnInit {

  constructor() { }

  @Input() valor: number;
  @Input() descricao: string;
  @Input() icon: string;

  ngOnInit() {
  }

}
