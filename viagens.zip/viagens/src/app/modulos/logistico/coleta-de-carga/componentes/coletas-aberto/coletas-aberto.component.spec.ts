import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ColetasAbertoComponent } from './coletas-aberto.component';

describe('ColetasAbertoComponent', () => {
  let component: ColetasAbertoComponent;
  let fixture: ComponentFixture<ColetasAbertoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ColetasAbertoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ColetasAbertoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
