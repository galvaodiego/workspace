import { Component, OnInit, Input, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { MediaMatcher } from '@angular/cdk/layout';

@Component({
  // tslint:disable-next-line: component-selector
  selector: 'cdc-gauge',
  templateUrl: './gauge.component.html',
  styleUrls: ['./gauge.component.scss']
})
export class GaugeComponent implements OnInit, OnDestroy {
  mobileQuery: MediaQueryList;
  // tslint:disable-next-line: variable-name
  private _mobileQueryListener: () => void;
  constructor(
    media: MediaMatcher,
    changeDetectorRef: ChangeDetectorRef,
  ) {
    this.mobileQuery = media.matchMedia('(max-width: 600px)');
    this._mobileQueryListener = () => changeDetectorRef.detectChanges();
    // tslint:disable-next-line: deprecation
    this.mobileQuery.addListener(this._mobileQueryListener);
  }
  datasource: any;
  get value(): any {
    return this.datasource;
  }

  @Input('datasource')
  set value(val: any) {
    this.datasource = val;
    if (this.datasource) {
      // CODE HERE

    }

  }
  ngOnInit() {
  }
  ngOnDestroy() {
    this.mobileQuery.removeListener(this._mobileQueryListener);

  }

}
