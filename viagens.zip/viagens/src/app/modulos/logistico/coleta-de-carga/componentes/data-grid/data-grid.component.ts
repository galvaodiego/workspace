import { Component, OnInit, Input } from '@angular/core';

@Component({
   // tslint:disable-next-line: component-selector
   selector: 'cdc-data-grid',
   templateUrl: './data-grid.component.html',
   styleUrls: ['./data-grid.component.scss']
})
export class DataGridComponent implements OnInit {

   constructor() { }
   datasource: any;
   get value(): any {
      return this.datasource;
   }

   @Input('datasource')
   set value(val: any) {
      this.datasource = val;
      if (this.datasource) {
         // CODE HERE

      }

   }
   onCellPrepared(e) {
      if (e.rowType === 'header') {
         e.cellElement.style.paddingTop = '5px';
         e.cellElement.style.paddingBottom = '5px';
         e.cellElement.style.fontSize = '1rem';
         e.cellElement.style.display = 'none';
      }

      if (typeof (e.data) !== 'undefined') {
         e.cellElement.style.paddingTop = '8px';
         e.cellElement.style.paddingBottom = '8px';
      }
   }
   ngOnInit() {
   }

}
