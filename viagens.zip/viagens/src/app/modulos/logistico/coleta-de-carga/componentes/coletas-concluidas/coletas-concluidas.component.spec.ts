import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ColetasConcluidasComponent } from './coletas-concluidas.component';

describe('ColetasConcluidasComponent', () => {
  let component: ColetasConcluidasComponent;
  let fixture: ComponentFixture<ColetasConcluidasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ColetasConcluidasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ColetasConcluidasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
