import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { IndicadoresService } from '../indicadores.service';

@Component({
   selector: 'app-logistico-card',
   templateUrl: './logistico-card.component.html',
   styleUrls: ['./logistico-card.component.scss']
})
export class LogisticoCardComponent implements OnInit {
   @Input() dados: any;
   public showCard = false;
   public list: Array<any> = [];
   constructor(
      private router: Router,
      private indicadoresService: IndicadoresService
   ) { }

   ngOnInit() {
   }

   /*
     * Realiza a soma de Porcentagem do Gauge
     * @param data status escolhido
     */
   public sumGauge(data) {
      let totalPrevisto;
      let totalAtraso;
      let total;

      totalPrevisto = data.map((tupla) => {
         return Number.parseFloat(tupla.previsto);
      }).reduce((anterior, atual) => {
         return (anterior + atual);
      }, 0);

      totalAtraso = data.map((tupla) => {
         return Number.parseFloat(tupla.atraso);
      }).reduce((anterior, atual) => {
         return (anterior + atual);
      }, 0);

      total = totalPrevisto / (totalPrevisto + totalAtraso) * 100;
      return parseFloat(total.toFixed(0));
   }

   /**
    * Soma os valores de Previstos
    */
   public sumPrevisto() {
      return this.dados.lista.map((tupla) => {
         return Number.parseFloat(tupla.previsto);
      }).reduce((anterior, atual) => {
         return (anterior + atual);
      }, 0);

   }

   /**
    * Soma os valores de Atrasados
    */
   public sumAtrasado() {
      return this.dados.lista.map((tupla) => {
         return Number.parseFloat(tupla.atraso);
      }).reduce((anterior, atual) => {
         return (anterior + atual);
      }, 0);

   }


   public explainTables(data) {
      this.list = data;
   }

   public showCardContent(data) {
      this.explainTables(data);
      this.showCard = !this.showCard;
   }

   /*
   * Navega para a pagina de Detalhes
   * @param dados Informações sobre o Item selecionado
   */
   public logisticoDetalhes(dados, status, modo) {
      const d = {
         dados,
         status,
         modo
      };

      this.indicadoresService.set(d);
      this.router.navigate(['logistico/indicadores/detalhes']);
   }

}
