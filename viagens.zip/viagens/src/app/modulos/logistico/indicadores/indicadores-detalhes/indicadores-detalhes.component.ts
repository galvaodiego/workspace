import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { GatewayService } from 'src/app/shared/services/gateway.service';
import { IndicadoresService } from '../indicadores.service';

@Component({
   selector: 'app-indicadores-detalhes',
   templateUrl: './indicadores-detalhes.component.html',
   styleUrls: ['./indicadores-detalhes.component.scss']
})
export class IndicadoresDetalhesComponent implements OnInit {
   dadosRecebidos = {
      dados: { descricao: '' },
      status: '',
      modo: 0
   };
   loadVisible = false;
   // Array com o Resultado
   public dataSource: any; // Array do Devextreme
   public status: any = [];

   public statusSelecionado = '';
   constructor(
      private gateway: GatewayService,
      private indicadoresService: IndicadoresService,
      private location: Location
   ) {
      this.dadosRecebidos = this.indicadoresService.get();
      if (!this.dadosRecebidos.status) {
         const dados = JSON.parse(localStorage.getItem('indicador-detalhes'));
         if (dados) {
            this.dadosRecebidos = dados;
         }
      }

   }

   ngOnInit() {
      this.getData();
   }

   async getData() {
      this.loadVisible = true;

      try {
         const response: any = await this.gateway.backendCall('1811-APPGESTOR', 'getIndicadorLogisticoDetalhes', {
            org: this.dadosRecebidos.dados.descricao,
            atraso: this.dadosRecebidos.modo,
         });
         console.log('response', response);
         const temp = [];
         response.logistico.forEach(
            (el) => {
               if (el.lista.length > 0) {
                  temp.push(el);
               }
            }
         );
         this.status = temp;
         this.statusSelecionado = this.dadosRecebidos.status;
         this.dataSource = this.status.find((el) => el.status === this.statusSelecionado).lista;

         this.loadVisible = false;
      } catch (error) {
         console.log('Error:', error);
      }
   }

   public onCellPrepared(e) {
      if (e.rowType === 'header') {
         e.cellElement.bgColor = '#007bff';
         e.cellElement.style.color = '#ffffff';
      }
      e.cellElement.style.paddingTop = '5px';
      e.cellElement.style.paddingBottom = '5px';
   }

   /*
    * Escolhe os dados do Grid conforme o Status Selecionado
  * @param item Status Selecionado
  *  Objetivo:: Alterar os Dados do Array @var dataSource do Grid de Detalhes
  */
   public selectStatus(item) {
      let temp = [];
      temp = this.status.filter(
         (it) => {
            return it.status == item;
         }
      );
      this.dataSource = temp[0].lista;
      this.statusSelecionado = temp[0].status;
   }


   /*
	*  Define as Cores das Progress Bar conforme Tempo de Espera
	*/
   public setColor(e) {
      if (typeof (e.key) !== 'undefined') {
         let color = '';
         const prazo = Number(e.key.tt_status);
         if (prazo == 0) {
            color = 'is-success';
         } else if (prazo == 2) {
            color = 'is-warning';
         } else if (prazo == 1) {
            color = 'is-danger';
         }
         return color;
      }
   }

   back() {
      this.location.back();
   }
}
