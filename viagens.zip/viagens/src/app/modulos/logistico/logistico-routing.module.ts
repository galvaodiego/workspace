import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GuardaRotas } from 'src/app/shared/guards/guarda-rotas.guard';
import { ColetaDeCargaComponent } from './coleta-de-carga/coleta-de-carga.component';
import { PageDetalhesComponent } from './coleta-de-carga/page-detalhes/page-detalhes.component';


const routes: Routes = [
   { path: '', redirectTo: 'fracionado', pathMatch: 'full' },
   { path: 'coleta-de-carga', component: ColetaDeCargaComponent, canActivate: [GuardaRotas] },
   { path: 'coleta-de-carga/detalhes', component: PageDetalhesComponent, canActivate: [GuardaRotas] },
];

@NgModule({
   imports: [RouterModule.forChild(routes)],
   exports: [RouterModule]
})
export class LogisticoRoutingModule { }
