import { Injectable } from '@angular/core';
import { Usuario } from 'src/app/shared/models/usuario.model';
import { ApiService } from 'src/app/shared/services/api.service';

@Injectable({
  providedIn: 'root'
})
export class HistoricoTemperaturaService {
  public user: Usuario = Usuario.instance;
  constructor(
    private apiService: ApiService
  ) { }

  getLista(p): Promise<any> {
    return this.apiService.request('post', `/viagens_temp/getViagensTemp`, p);
  }

}
