import { TestBed } from '@angular/core/testing';

import { HistoricoTemperaturaService } from './historico-temperatura.service';

describe('HistoricoTemperaturaService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: HistoricoTemperaturaService = TestBed.get(HistoricoTemperaturaService);
    expect(service).toBeTruthy();
  });
});
