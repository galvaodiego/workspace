import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-kpi',
  templateUrl: './kpi.component.html',
  styleUrls: ['./kpi.component.scss']
})
export class KpiComponent implements OnInit {
  @Input() title: string;
  @Input() value: number;
  @Input() icon: string;
  constructor() { }

  ngOnInit() {
  }

  getImage(icon) {
    return `assets/images/hist-temp/${icon}.png`;
  }

}
