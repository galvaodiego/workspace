import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-kpi-romaneio',
  templateUrl: './kpi-romaneio.component.html',
  styleUrls: ['./kpi-romaneio.component.scss']
})
export class KpiRomaneioComponent implements OnInit {
  @Input() imagem: string;
  @Input() titulo: string;
  @Input() conteudo: any;

  constructor() { }

  ngOnInit() {
  }

}
