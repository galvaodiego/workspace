import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KpiRomaneioComponent } from './kpi-romaneio.component';

describe('KpiRomaneioComponent', () => {
  let component: KpiRomaneioComponent;
  let fixture: ComponentFixture<KpiRomaneioComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KpiRomaneioComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KpiRomaneioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
