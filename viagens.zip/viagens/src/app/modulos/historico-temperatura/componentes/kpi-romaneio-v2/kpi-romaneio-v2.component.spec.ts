import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KpiRomaneioV2Component } from './kpi-romaneio-v2.component';

describe('KpiRomaneioV2Component', () => {
  let component: KpiRomaneioV2Component;
  let fixture: ComponentFixture<KpiRomaneioV2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KpiRomaneioV2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KpiRomaneioV2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
