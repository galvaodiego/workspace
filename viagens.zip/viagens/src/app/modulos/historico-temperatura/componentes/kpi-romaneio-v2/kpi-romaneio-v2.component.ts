import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-kpi-romaneio-v2',
  templateUrl: './kpi-romaneio-v2.component.html',
  styleUrls: ['./kpi-romaneio-v2.component.scss']
})
export class KpiRomaneioV2Component implements OnInit {
  @Input() ref: string;
  @Input() dados: any;
  constructor() { }

  ngOnInit() {
  }

}
