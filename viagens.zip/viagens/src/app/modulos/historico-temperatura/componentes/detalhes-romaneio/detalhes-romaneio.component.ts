import { ChangeDetectorRef, Component, Input, OnChanges, SimpleChanges } from '@angular/core';
import { Usuario } from 'src/app/shared/models/usuario.model';
import { MediaMatcher } from '@angular/cdk/layout';
@Component({
  selector: 'app-detalhes-romaneio',
  templateUrl: './detalhes-romaneio.component.html',
  styleUrls: ['./detalhes-romaneio.component.scss']
})
export class DetalhesRomaneioComponent implements OnChanges {
  mobileQuery: MediaQueryList;
  private _mobileQueryListener: () => void;
  public user: Usuario = Usuario.instance;
  @Input() dados;
  @Input() colunas;
  @Input() origem = 1;
  loadVisible = false;
  indicadores;
  lista = [];

  show = {
    status: true,
    documento: true,
    mercadoria: true,
    veiculos: true
  }

  constructor(
    media: MediaMatcher,
    changeDetectorRef: ChangeDetectorRef,
  ) {
    this.mobileQuery = media.matchMedia('(max-width: 600px)');
    // this._mobileQueryListener = () => changeDetectorRef.detectChanges();
    // tslint:disable-next-line: deprecation
    // this.mobileQuery.addListener(this._mobileQueryListener);
  }


  ngOnChanges(changes: SimpleChanges): void {
    if (this.mobileQuery.matches) {
      this.show = {
        status: true,
        documento: false,
        mercadoria: false,
        veiculos: false
      }
    }

    if (this.dados) {
      this.tratarDados();
    } else {
      this.loadVisible = false;
      console.log('NUM ROMANEIO INVÁLIDO', this.dados);
    }
  }

  tratarDados() {
    // console.log('tratar dados', this.dados);
    this.indicadores = this.dados.indicadores;
    this.lista = this.dados.lista;
  }

  public onCellPrepared(e: any) {
    e.cellElement.style.fontFamily = 'Fira Sans';
    e.cellElement.style.lineHeight = '21px';
    e.cellElement.style.fontStyle = 'normal';
    if (e.rowType === 'header') {
      e.cellElement.style.paddingTop = '5px';
      e.cellElement.style.paddingBottom = '5px';
      e.cellElement.style.fontSize = '14px';
      e.cellElement.style.fontWeight = '600';
      e.cellElement.style.color = '#3F7EAC';
      e.cellElement.style.backgroundColor = '#EAEDEE';
    }

    if (typeof (e.data) !== 'undefined') {
      e.cellElement.style.paddingTop = '5px';
      e.cellElement.style.paddingBottom = '5px';
      e.cellElement.style.borderColor = '#e3e3e3';
      e.cellElement.style.color = '#3F7EAC';

    }
  }

  showCard(tipo: string) {
    this.show = {
      status: false,
      documento: false,
      mercadoria: false,
      veiculos: false
    }
    this.show[tipo] = true;
  }

}
