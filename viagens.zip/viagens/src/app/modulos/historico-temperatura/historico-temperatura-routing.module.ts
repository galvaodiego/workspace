import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GuardaRotas } from 'src/app/shared/guards/guarda-rotas.guard';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ViagensEncerradasComponent } from './viagens-encerradas/viagens-encerradas.component';


const routes: Routes = [
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  { path: 'dashboard', component: DashboardComponent, canActivate: [GuardaRotas] },
  { path: 'viagens-encerradas', component: ViagensEncerradasComponent, canActivate: [GuardaRotas] },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HistoricoTemperaturaRoutingModule { }
