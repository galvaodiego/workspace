import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViagensEncerradasComponent } from './viagens-encerradas.component';

describe('ViagensEncerradasComponent', () => {
  let component: ViagensEncerradasComponent;
  let fixture: ComponentFixture<ViagensEncerradasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViagensEncerradasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViagensEncerradasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
