import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { Usuario } from 'src/app/shared/models/usuario.model';
import { environment } from 'src/environments/environment';
import io from 'socket.io-client';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MediaMatcher } from '@angular/cdk/layout';
@Component({
  selector: 'app-viagens-encerradas',
  templateUrl: './viagens-encerradas.component.html',
  styleUrls: ['./viagens-encerradas.component.scss']
})
export class ViagensEncerradasComponent implements OnInit {
  mobileQuery: MediaQueryList;
  private _mobileQueryListener: () => void;
  public user: Usuario = Usuario.instance;
  loadVisible = false;
  // Config Socket
  socketIo: any;
  socketRota = 'viagens_hist';
  socketMetodo = 'getViagensHist';
  socketFiltro: any;
  /***/
  lista: Array<any> = [];
  colunas: any;
  colunasMobile: any;
  colunasPop: any;
  colunasPopMobile: any;
  popupVisible = false;
  popupTitle = '';
  grupo_negociador;
  showBusca = false;
  form: FormGroup;
  dadosDetalhes: any;
  constructor(
    private router: Router,
    private fb: FormBuilder,
    media: MediaMatcher,
    changeDetectorRef: ChangeDetectorRef,
  ) {
    this.mobileQuery = media.matchMedia('(max-width: 600px)');
    this._mobileQueryListener = () => changeDetectorRef.detectChanges();
    // tslint:disable-next-line: deprecation
    this.mobileQuery.addListener(this._mobileQueryListener);
    this.form = this.fb.group({
      romaneio: [null],
      placa: [null],
    });
    this.montaColunas();
    this.socketIo = io(environment.socket_end_point + '/' + this.socketRota);

    this.socketFiltro = {
      base: this.user.ref.toLowerCase(),
    };

    this.grupo_negociador = JSON.parse(localStorage.getItem('grupo_negociador'));
    if (this.grupo_negociador) {
      const grupo = [];
      if (this.grupo_negociador.length > 0) {
        this.grupo_negociador.forEach(element => {
          grupo.push(element.grupo_negociador)
        });
      }

      Object.assign(this.socketFiltro, {
        grupo_negociador: grupo
      })
    }
    this.socket().then(() => { });
  }

  ngOnInit() {
  }

  ngOnDestroy(): void {
    this.socketIo.disconnect();
  }

  montaColunas() {
    this.colunasPop = [
      { caption: 'Data', dataType: 'datetime', dataField: 'data_posicao', alignment: 'center' },
      { caption: 'Landmark', dataField: 'landmark', alignment: 'center' },
      { caption: 'Ignição', dataField: 'ignicao', alignment: 'center' },
      { caption: 'Velocidade (KM/h)', dataField: 'velocidade', alignment: 'center' },
      { caption: 'Temperatura', dataField: 'temperatura', alignment: 'center', cellTemplate: 'templateTemperatura' },
    ];
    this.colunasPopMobile = [
      { caption: 'Data', dataType: 'datetime', dataField: 'data_posicao', alignment: 'center' },
      { caption: 'Temperatura', dataField: 'temperatura', alignment: 'center', cellTemplate: 'templateTemperatura' },
    ];
    this.colunasMobile = [
      { caption: 'Romaneio', dataField: 'num_romaneio', alignment: 'center' },
      { caption: 'Placa', dataField: 'placa', alignment: 'center' },
      {
        caption: 'Ult. Temp.', dataField: 'temperatura', alignment: 'center',
        cellTemplate: 'templateTemperatura', width: 'auto'
      },
      {
        type: 'buttons',
        buttons: [
          {
            icon: 'assets/images/hist-temp/expandir.png',
            hint: 'Detalhes',
            onClick: this.detalhes.bind(this),
          },
        ],
      },

    ]

    this.colunas = [
      { caption: 'Num Romaneio', dataField: 'num_romaneio', alignment: 'center' },
      { caption: 'Data Encerramento', dataField: 'data_termino', dataType: 'datetime', alignment: 'center' },
      { caption: 'Placa', dataField: 'placa', alignment: 'center' },
      { caption: 'Referência', dataField: 'referencia', alignment: 'center' },
      { caption: 'Data Posição', dataField: 'data_posicao', dataType: 'datetime', alignment: 'center' },
      {
        caption: 'Temperatura', dataField: 'temperatura', alignment: 'center',
        cellTemplate: 'templateTemperatura'
      },
      {
        type: 'buttons',
        buttons: [
          {
            icon: 'assets/images/hist-temp/expandir.png',
            hint: 'Detalhes',
            onClick: this.detalhes.bind(this),
          },
        ],
      },

    ]
  }


  async socket() {
    try {
      this.loadVisible = true;
      this.socketIo.emit(this.socketMetodo, this.socketFiltro);

      // console.log('filtro enviado', this.socketFiltro);
      this.socketIo.on(this.socketRota, (data) => {
        this.loadVisible = false;
        console.log('socket retorno', data, this.socketFiltro);
        if (data) {
          if (data.result) {
            this.lista = data.result[0].lista;
          } else {
            // dados popup
            this.dadosDetalhes = data;
            this.popupVisible = true;
          }


        }
      });

    } catch (error) {
      this.loadVisible = false;
      console.log('error => ', error);
    }
  }

  detalhes(dados) {
    this.popupTitle = dados.row.data.num_romaneio;
    const filtro = { ...this.socketFiltro };
    Object.assign(filtro, {
      num_romaneio: Number(dados.row.data.num_romaneio)
    })
    this.loadVisible = true;
    this.socketIo.emit('getHistDetalhes', filtro);
  }

  public onCellPrepared(e: any) {
    e.cellElement.style.fontFamily = 'Fira Sans';
    e.cellElement.style.lineHeight = '21px';
    e.cellElement.style.fontStyle = 'normal';
    if (e.rowType === 'header') {
      e.cellElement.style.fontSize = '14px';
      e.cellElement.style.fontWeight = '600';
      e.cellElement.style.color = '#3F7EAC';
      e.cellElement.style.backgroundColor = '#EAEDEE';
    }

    if (typeof (e.data) !== 'undefined') {
      e.cellElement.style.paddingTop = '5px';
      e.cellElement.style.paddingBottom = '5px';
      e.cellElement.style.borderBottomColor = '#9FBFD5';
      e.cellElement.style.color = '#1C1C27';
      e.cellElement.style.fontWeight = '300';

    }
  }

  getIMG(data) {
    let path = '';
    switch (data.value.toLowerCase()) {
      case 'viagem':
        path = 'assets/images/hist-temp/lista_viagem.png'
        break;
      case 'carga':
        path = 'assets/images/hist-temp/lista_carga.png'
        break;
      case 'descarga':
        path = 'assets/images/hist-temp/lista_descarga.png'
        break;
    }
    return path;

  }

  voltar() {
    this.router.navigate(['/historico-temperatura/dashboard'])
  }

  limpaForm() {
    this.form.reset();
    delete this.socketFiltro.num_romaneio;
    delete this.socketFiltro.placa;
    this.loadVisible = true;
    this.socketIo.emit(this.socketMetodo, this.socketFiltro);
  }

  onSubmit() {
    delete this.socketFiltro.num_romaneio;
    delete this.socketFiltro.placa;
    if (this.form.get('romaneio').value) {
      Object.assign(this.socketFiltro, {
        num_romaneio: Number(this.form.get('romaneio').value)
      })
    }
    if (this.form.get('placa').value) {
      Object.assign(this.socketFiltro, {
        placa: this.form.get('placa').value
      })
    }

    this.loadVisible = true;
    this.socketIo.emit(this.socketMetodo, this.socketFiltro);
  }

}
