import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HistoricoTemperaturaRoutingModule } from './historico-temperatura-routing.module';
import { DashboardComponent } from './dashboard/dashboard.component';
import { DxDataGridModule, DxLoadPanelModule, DxPopupModule, DxScrollViewModule } from 'devextreme-angular';
import { KpiComponent } from './componentes/kpi/kpi.component';
import { DetalhesRomaneioComponent } from './componentes/detalhes-romaneio/detalhes-romaneio.component';
import { KpiRomaneioComponent } from './componentes/kpi-romaneio/kpi-romaneio.component';
import { ViagensEncerradasComponent } from './viagens-encerradas/viagens-encerradas.component';
import { KpiRomaneioV2Component } from './componentes/kpi-romaneio-v2/kpi-romaneio-v2.component';

import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTooltipModule } from '@angular/material/tooltip';
import { HintComponent } from './componentes/hint/hint.component';

@NgModule({
  declarations: [
    DashboardComponent,
    KpiComponent,
    DetalhesRomaneioComponent,
    KpiRomaneioComponent,
    ViagensEncerradasComponent,
    KpiRomaneioV2Component,
    HintComponent,
  ],
  imports: [
    CommonModule,
    HistoricoTemperaturaRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    DxDataGridModule,
    DxPopupModule,
    DxScrollViewModule,
    DxLoadPanelModule,
    MatButtonModule,
    MatIconModule,
    MatInputModule,
    MatTooltipModule
  ]
})
export class HistoricoTemperaturaModule { }
