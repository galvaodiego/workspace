import { ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import io from 'socket.io-client';
import { environment } from 'src/environments/environment';
import { Usuario } from 'src/app/shared/models/usuario.model';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MediaMatcher } from '@angular/cdk/layout';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit, OnDestroy {
  mobileQuery: MediaQueryList;
  private _mobileQueryListener: () => void;
  public user: Usuario = Usuario.instance;
  public loadVisible = true;
  // Config Socket
  socketIo: any;
  socketRota = 'viagens_temp';
  socketMetodo = 'getViagensTemp';
  socketFiltro: any;
  /***/

  indicadores: any;
  lista: Array<any> = [];
  colunas: any;
  colunasMobile: any;
  colunasPop: any;
  colunasPopMobile: any;

  popupVisible = false;
  popupTitle = '';
  grupo_negociador;

  showBusca = false;
  form: FormGroup;
  num_romaneio = 0;


  dadosDetalhes: any;

  constructor(
    private router: Router,
    private fb: FormBuilder,
    media: MediaMatcher,
    changeDetectorRef: ChangeDetectorRef,
  ) {
    this.mobileQuery = media.matchMedia('(max-width: 600px)');
    this._mobileQueryListener = () => changeDetectorRef.detectChanges();
    // tslint:disable-next-line: deprecation
    this.mobileQuery.addListener(this._mobileQueryListener);
    this.form = this.fb.group({
      nota_fiscal: [null, Validators.required]
    });
    this.montaColunas();
    this.socketIo = io(environment.socket_end_point + '/' + this.socketRota);
    this.socketFiltro = {
      base: this.user.ref.toLowerCase(),
    };

    this.grupo_negociador = JSON.parse(localStorage.getItem('grupo_negociador'));
    if (this.grupo_negociador) {
      const grupo = [];
      if (this.grupo_negociador.length > 0) {
        this.grupo_negociador.forEach(element => {
          grupo.push(element.grupo_negociador)
        });
      }

      Object.assign(this.socketFiltro, {
        grupo_negociador: grupo
      })
    }
    this.socket().then(() => { });
  }

  ngOnDestroy(): void {
    this.socketIo.disconnect();
  }

  montaColunas() {
    this.colunasPop = [
      { caption: 'Data', dataType: 'datetime', dataField: 'data_posicao', alignment: 'center' },
      { caption: 'Landmark', dataField: 'landmark', alignment: 'center' },
      { caption: 'Ignição', dataField: 'ignicao', alignment: 'center' },
      { caption: 'Velocidade (KM/h)', dataField: 'velocidade', alignment: 'center' },
      { caption: 'Temperatura', dataField: 'temperatura', alignment: 'center', cellTemplate: 'templateTemperatura' },
    ]
    this.colunasPopMobile = [
      { caption: 'Data', dataType: 'datetime', dataField: 'data_posicao', alignment: 'center' },
      { caption: 'Temperatura', dataField: 'temperatura', alignment: 'center', cellTemplate: 'templateTemperatura' },
    ]
    this.colunasMobile = [
      { caption: 'Romaneio', dataField: 'num_romaneio', alignment: 'center' },
      { caption: 'Placa', dataField: 'placa_referencia', alignment: 'center' },
      {
        caption: 'Ult. Temp.', dataField: 'temperatura_rastreador', alignment: 'center',
        cellTemplate: 'templateTemperatura'
      },
      {
        type: 'buttons',
        buttons: [
          {
            icon: 'assets/images/hist-temp/expandir.png',
            hint: 'Detalhes',
            onClick: this.detalhes.bind(this),
          },
        ],
      },

    ]
    this.colunas = [
      { caption: 'Num Romaneio', dataField: 'num_romaneio', alignment: 'center' },
      {
        caption: 'Status', dataField: 'status', alignment: 'center',
        cellTemplate: 'templateStatus'
      },
      { caption: 'Placa', dataField: 'placa_referencia', alignment: 'center' },
      { caption: 'Referência', dataField: 'referencia', alignment: 'center' },
      { caption: 'Data Posição', dataField: 'data_posicao', dataType: 'datetime', alignment: 'center' },
      {
        caption: 'Ult Temperatura', dataField: 'temperatura_rastreador', alignment: 'center',
        cellTemplate: 'templateTemperatura'
      },
      { caption: 'Previsão de Chegada', dataField: 'data_previsao', dataType: 'datetime', alignment: 'center' },
      {
        type: 'buttons',
        buttons: [
          {
            icon: 'assets/images/hist-temp/expandir.png',
            hint: 'Detalhes',
            onClick: this.detalhes.bind(this),
          },
        ],
      },

    ]

  }

  ngOnInit() { }


  public onCellPrepared(e: any) {
    e.cellElement.style.fontFamily = 'Fira Sans';
    e.cellElement.style.lineHeight = '21px';
    e.cellElement.style.fontStyle = 'normal';
    if (e.rowType === 'header') {
      e.cellElement.style.fontSize = '14px';
      e.cellElement.style.fontWeight = '600';
      e.cellElement.style.color = '#3F7EAC';
      e.cellElement.style.backgroundColor = '#EAEDEE';
    }

    if (typeof (e.data) !== 'undefined') {
      e.cellElement.style.paddingTop = '5px';
      e.cellElement.style.paddingBottom = '5px';
      e.cellElement.style.borderBottomColor = '#9FBFD5';
      e.cellElement.style.color = '#1C1C27';
      e.cellElement.style.fontWeight = '300';

    }
  }

  getIMG(data) {
    let path = '';
    switch (data.value.toLowerCase()) {
      case 'viagem':
        path = 'assets/images/hist-temp/lista_viagem.png'
        break;
      case 'carga':
        path = 'assets/images/hist-temp/lista_carga.png'
        break;
      case 'descarga':
        path = 'assets/images/hist-temp/lista_descarga.png'
        break;
    }
    return path;

  }

  async socket() {
    // teste
    try {
      this.loadVisible = true;
      this.socketIo.emit(this.socketMetodo, this.socketFiltro);
      this.socketIo.on(this.socketRota, (data) => {
        this.loadVisible = false;
        if (data) {
          console.log('socket data', data, this.socketFiltro);
          if (data.result) {
            // tela 1
            this.indicadores = data.result[0].indicadores[0];
            this.lista = data.result[0].lista;
          } else {
            // dados popup
            this.dadosDetalhes = data;
            this.popupVisible = true;
          }
        }
      });

    } catch (error) {
      // this.loadVisible = false;
      console.log('error => ', error);
    }
  }


  detalhes(dados) {
    this.popupTitle = dados.row.data.num_romaneio;
    const filtro = { ...this.socketFiltro };
    Object.assign(filtro, {
      num_romaneio: Number(dados.row.data.num_romaneio)
    })
    this.loadVisible = true;
    this.socketIo.emit('getViagensDetalhes', filtro);
  }

  go(destino) {
    switch (destino) {
      case 'nota':
        //filtrar por nota
        break;
      case 'encerradas':
        this.router.navigate(['/historico-temperatura/viagens-encerradas']);
        break;
    }
  }

  limpaForm() {
    this.form.reset();
    delete this.socketFiltro.nota_fiscal;
    this.loadVisible = true;
    this.socketIo.emit(this.socketMetodo, this.socketFiltro);
  }

  onSubmit() {
    Object.assign(this.socketFiltro, {
      nota_fiscal: this.form.get('nota_fiscal').value
    })

    this.loadVisible = true;
    this.socketIo.emit(this.socketMetodo, this.socketFiltro);
  }

}
