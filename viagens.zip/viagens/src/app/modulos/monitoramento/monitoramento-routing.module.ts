import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GuardaRotas } from 'src/app/shared/guards/guarda-rotas.guard';
import { MapaComponent } from './mapa/mapa.component';


const routes: Routes = [
   { path: '', redirectTo: 'mapa', pathMatch: 'full' },
   { path: 'mapa', component: MapaComponent, canActivate: [GuardaRotas] },
];

@NgModule({
   imports: [RouterModule.forChild(routes)],
   exports: [RouterModule]
})
export class MonitoramentoRoutingModule { }
