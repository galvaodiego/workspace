import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Usuario } from 'src/app/shared/models/usuario.model';
import { GatewayService } from 'src/app/shared/services/gateway.service';
import * as _ from 'underscore';
import * as moment from 'moment';

@Injectable({
   providedIn: 'root'
})
export class MonitoramentoService {
   public user: Usuario = Usuario.instance;
   // Markers Personalizados do Mapa
   public marcadores: Array<any> = [];
   // Markers Personalizados do Mapa - ESPELHO PARA A BUSCA
   public mirrorMarcadores: Array<any> = [];
   public mirrorMarcadoresNotFis: Array<any> = [];
   // FILTROS
   public filtros: Array<any> = [];
   public internacional: Array<any> = [];
   public status: Array<any> = [];
   public operacoes: Array<any> = [];
   public remetentes: Array<any> = [];
   public atrasado: Array<any> = [];
   apiKey: string;
   public veiculoDetalhes: any = [];
   public percExecutado: number;
   public dataInicioViagem: string;
   public dataTerminoViagem: string;
   popDetalhesVisible = false;
   popCTEVisible = false;
   numRomaneio = 0;

   dataSourceCTE = [];



   constructor(
      private gateway: GatewayService
   ) {
      this.apiKey = environment.apiKeyMaps;
   }

   public getMonitoramento() {
      this.getMonitor().then(
         (result) => {

            // Zera os Arrays de Filtros
            this.filtros = [];
            this.status = [];
            this.operacoes = [];
            this.internacional = [];
            this.atrasado = [];

            // Cópia dos Marcadores Originais
            this.mirrorMarcadores = result.location;

            // Prepara o Array conforme Google Maps
            this.initMap(this.mirrorMarcadores);

            // Cria os Filtros
            this.setAvailableFilters();

            // Tranforma o Array de Filtro em Objeto
            this.castToFilterItem();

         }
      );
   }

   public getDataCTE() {
      console.log('entrou');

      this.getRomaneioDetalhe().then(result => {
         console.log('chegou', result);
         if (result) {
            this.dataSourceCTE = result.location;
         } else {
            this.dataSourceCTE = [];
         }
      });
   }

   public initMap(obj) {
      // Zera o Array para receber os dados
      this.marcadores = [];
      console.log('initMapa', this.marcadores);


      // Se o length for 1 significa que veio da BUSCA
      if (obj.length === 1) {
         this.marcadores.push({
            location: [obj[0].lat, obj[0].lng],
            data: obj[0],
            // tslint:disable-next-line: max-line-length
            path: obj[0].status.toLowerCase() + '???' + obj[0].operacao.toLowerCase() + '???' + obj[0].internacional + '???' + obj[0].atrasado,
            iconSrc: 'assets/icon/map-markers/' + obj[0].status.toLowerCase() + '.png',
            onClick: (args) => {
               this.setVeiculoDetalhes({ veiculo: obj[0] });
            }
         });
      } else {
         obj.forEach(
            (el) => {
               this.marcadores.push({
                  location: [el.lat, el.lng],
                  data: el,
                  path: el.status.toLowerCase() + '???' + el.operacao.toLowerCase() + '???' + el.internacional + '???' + el.atrasado,
                  iconSrc: 'assets/icon/map-markers/' + el.status.toLowerCase() + '.png',
                  onClick: (args) => {
                     this.setVeiculoDetalhes({ veiculo: el });
                  }
               });
            }
         );
      }
   }

   setVeiculoDetalhes(veiculo: any) {
      this.popDetalhesVisible = true;
      // this.isFooterShow = true;
      this.veiculoDetalhes = veiculo.veiculo;
      this.status = this.veiculoDetalhes.status.toLowerCase();

      // Limitando o tamanho das strings
      this.veiculoDetalhes.motorista_reduzido = this.veiculoDetalhes.motorista.substring(0, 17);
      this.veiculoDetalhes.status_reduzido = this.veiculoDetalhes.status.substring(0, 7);

      // Validação de Datas
      if (this.veiculoDetalhes.inicio_evento !== '') {
         this.dataInicioViagem = moment(this.veiculoDetalhes.inicio_evento).format('DD/MM/YYYY HH:mm');
      }
      if (this.veiculoDetalhes.prev_term_evento !== '') {
         this.dataTerminoViagem = moment(this.veiculoDetalhes.prev_term_evento).format('DD/MM/YYYY HH:mm');
      }

      // Valida Valor do Transit Time
      if (this.veiculoDetalhes.perc_executado !== null) {
         this.percExecutado = this.veiculoDetalhes.perc_executado;
      } else {
         this.percExecutado = 0;
      }

   }


   public setAvailableFilters() {
      const aux: Array<any> = [];
      // itera sobre todos os itens do array de nivel mais baixo;
      this.marcadores.forEach(
         (el) => {
            aux.push(el.path.split('???').filter(el => el.length > 0));
         }
      );
      // Separa todos os itens de mesmo nivel e remove os repetidos
      _.unzip(aux).forEach(element => {
         this.filtros.push(_.uniq(element).sort());
      });
   }

   public castToFilterItem() {
      this.filtros.forEach(
         (tipoFiltro) => {
            tipoFiltro.forEach(
               (filtro, index, oArray) => {
                  const aux = Object.assign({
                     item: filtro,
                     checked: false
                  });
                  oArray[index] = aux;
               }
            );
         }
      );
   }


   public getMonitor(): Promise<any> {
      return this.gateway.backendCall(
         'M4002',
         'getMapa',
         {
            usuario: this.user.usuario
         },
      );
   }



   public getRomaneioDetalhe(): Promise<any> {
      if (this.numRomaneio > 0) {
         return this.gateway.backendCall(
            'M4002',
            'getRomaneioDetalhe',
            {
               num_romaneio: this.numRomaneio
            },
         );
      } else {
         console.log('ROMANEIO INEXISTENTE', this.numRomaneio);
      }
   }

}
