import { Component, OnInit } from '@angular/core';
import { MonitoramentoService } from '../../monitoramento.service';
import * as moment from 'moment';

@Component({
   selector: 'app-detalhes',
   templateUrl: './detalhes.component.html',
   styleUrls: ['./detalhes.component.scss']
})
export class DetalhesComponent implements OnInit {
   public statusViagem: string;
   public percExecutado: number;
   public ufOrigem = '';
   public ufDestino = '';
   public cidadeOrigem = '';
   public cidadeDestino = '';
   vejamais = false;
   constructor(
      public monitService: MonitoramentoService,
   ) {
      this.statusViagem = this.monitService.veiculoDetalhes.status.toLowerCase();

      // Valida Valor do Transit Time
      if (this.monitService.veiculoDetalhes.perc_executado !== null) {
         this.percExecutado = this.monitService.veiculoDetalhes.perc_executado;
      } else {
         this.percExecutado = 0;
      }

      // Limita os caracteres
      this.monitService.veiculoDetalhes.carregamento = this.monitService.veiculoDetalhes.carregamento.substring(0, 12);
      this.monitService.veiculoDetalhes.destino = this.monitService.veiculoDetalhes.destino.substring(0, 12);

      // Valida as UFS
      if (this.statusViagem === 'destinado') {
         this.ufOrigem = this.monitService.veiculoDetalhes.uf_origem;
         this.ufDestino = this.monitService.veiculoDetalhes.uf_carregamento;
         this.cidadeOrigem = this.monitService.veiculoDetalhes.origem;
         this.cidadeDestino = this.monitService.veiculoDetalhes.carregamento;
      } else if (this.statusViagem === 'viagem') {
         this.ufOrigem = this.monitService.veiculoDetalhes.uf_carregamento;
         this.ufDestino = this.monitService.veiculoDetalhes.uf_destino;
         this.cidadeOrigem = this.monitService.veiculoDetalhes.carregamento;
         this.cidadeDestino = this.monitService.veiculoDetalhes.destino;
      } else {
         this.ufOrigem = this.monitService.veiculoDetalhes.uf_origem;
         this.ufDestino = this.monitService.veiculoDetalhes.uf_destino;
         this.cidadeOrigem = this.monitService.veiculoDetalhes.origem;
         this.cidadeDestino = this.monitService.veiculoDetalhes.destino;
      }
   }

   ngOnInit() {
   }

   // tslint:disable-next-line: variable-name
   public setIcon(number) {
      let icon = '';
      const value = Number(number);
      if (value === 0) {
         icon = 'transit-truck-atrasado';
      } else if (value === 2) {
         icon = 'transit-truck-possibilidade';
      } else if (value === 1) {
         icon = 'transit-truck-ok';
      } else if (value === null) {
         icon = 'transit-truck';
      }
      return icon;
   }

   // tslint:disable-next-line: variable-name
   public setColor(number) {
      let color = '';
      const value = Number(number);
      if (value == 0) {
         color = '#aa2227';
      } else if (value == 2) {
         color = '#ff9800';
      } else if (value == 1) {
         color = '#4caf50';
      } else if (value == null) {
         color = '#f0eeee';
      }
      return color;
   }


   public setTextSaida(status) {
      let tituloStatus = '';
      if (status === 'vazio') {
         tituloStatus = 'Início Evento';
      } else if (status === 'viagem') {
         tituloStatus = 'Término Carga';
      } else if (status === 'destinado') {
         tituloStatus = 'Início Viagem';
      } else if (status === 'carga') {
         tituloStatus = 'Início Carga';
      } else if (status === 'descarga') {
         tituloStatus = 'Início Descarga';
      } else {
         tituloStatus = 'Saída';
      }
      return tituloStatus;
   }

   public setTextChegada(status) {
      let tituloStatus = '';
      if (status === 'vazio') {
         tituloStatus = '';
      } else if (status === 'viagem') {
         tituloStatus = 'Início Descarga';
      } else if (status === 'destinado') {
         tituloStatus = 'Início Carga';
      } else if (status === 'carga') {
         tituloStatus = 'Término Carga';
      } else if (status === 'descarga') {
         tituloStatus = 'Término Descarga';
      } else {
         tituloStatus = 'Chegada';
      }
      return tituloStatus;
   }

   public validDate(data) {
      if (data !== '') {
         return moment(data).format('DD/MM/YYYY HH:mm');
      } else {
         return data;
      }
   }

   public abreModalCTE(numRomaneio: number) {
      this.monitService.numRomaneio = numRomaneio;
      this.monitService.popDetalhesVisible = false;
      this.monitService.popCTEVisible = true;
   }

}
