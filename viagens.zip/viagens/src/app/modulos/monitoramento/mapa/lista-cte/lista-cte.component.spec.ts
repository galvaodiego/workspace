import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListaCteComponent } from './lista-cte.component';

describe('ListaCteComponent', () => {
  let component: ListaCteComponent;
  let fixture: ComponentFixture<ListaCteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListaCteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListaCteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
