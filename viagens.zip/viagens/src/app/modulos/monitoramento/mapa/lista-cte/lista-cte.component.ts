import { Component, OnInit } from '@angular/core';
import { MonitoramentoService } from '../../monitoramento.service';

@Component({
   selector: 'app-lista-cte',
   templateUrl: './lista-cte.component.html',
   styleUrls: ['./lista-cte.component.scss']
})
export class ListaCteComponent implements OnInit {

   constructor(
      public monitService: MonitoramentoService,
   ) { }

   ngOnInit() {
      if (this.monitService.numRomaneio > 0) {
         this.monitService.getDataCTE();
      }
   }

}
