import { Component, OnInit, ViewChild } from '@angular/core';
import { MonitoramentoService } from '../monitoramento.service';
import { DxMapComponent } from 'devextreme-angular';
import { DxoPopupComponent } from 'devextreme-angular/ui/nested';

@Component({
   selector: 'app-mapa',
   templateUrl: './mapa.component.html',
   styleUrls: ['./mapa.component.scss']
})
export class MapaComponent implements OnInit {
   @ViewChild(DxMapComponent, { static: false }) map: DxMapComponent;
   @ViewChild('popGeo', { static: false }) popGeo: DxoPopupComponent;
   @ViewChild('popStatus', { static: false }) popStatus: DxoPopupComponent;


   // Zoom do Mapa
   public isCenter: any;
   // Distancia do Mapa
   public isZoom: any;
   public statusGeo: boolean;
   popGeoVisible = false;
   popStatusVisible = false;

   constructor(
      public monitService: MonitoramentoService,
   ) { }

   ngOnInit() {
      this.monitService.getMonitoramento();
   }

   public zoomMapa(lat, lng) {
      this.isCenter = [lat, lng];
      this.isZoom = 16;
      this.map.instance.option('center', this.isCenter);
      this.map.instance.option('zoom', this.isZoom);
      this.statusGeo = false;
      // console.log('zoomMapa', lat, lng);
   }


   public showQuestionGeolocalizacao() {
      this.getGeolocalizacao();
   }

   public getGeolocalizacao() {
      console.log('@TODO: Pegar GeoLoca');

      // this.platform.ready().then(() => {
      //    this.geo.getCurrentPosition().then(res => {
      //       console.log('coordenadas', res);
      //       this.zoomMapa(res.coords.latitude, res.coords.longitude);
      //    }).catch(() => {
      //       this.monitService.showToast('Erro ao Resgatar sua Localização');
      //    });
      // });
   }

   aplicaStatus(item: any) {
      item.checked = !item.checked;
      console.log('FILTROS:', this.monitService.filtros);
      this.monitService.setAvailableFilters();
      this.popStatusVisible = false;

   }




   public abreModalFiltros() {
      // const modal = this.modalCtrl.create(MonitoramentoModalFiltrosPage, { listaFiltros: this.monitService.filtros });
      // modal.present();
   }

   public abrePopover() {
      this.popStatusVisible = !this.popStatusVisible;
      // const popover = this.popoverCtrl.create(MonitoramentoPopoverFiltrosPage, { listaFiltros: this.monitService.filtros });
      // popover.present();
   }

}
