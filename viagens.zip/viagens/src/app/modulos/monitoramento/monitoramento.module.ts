import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MapaComponent } from './mapa/mapa.component';
import { DxMapModule, DxPopupModule } from 'devextreme-angular';
import { MonitoramentoRoutingModule } from './monitoramento-routing.module';
import { MatInputModule, MatFormFieldModule, MatButtonModule, MatIconModule, MatSlideToggleModule, MatCardModule } from '@angular/material';
import { DetalhesComponent } from './mapa/detalhes/detalhes.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { ListaCteComponent } from './mapa/lista-cte/lista-cte.component';



@NgModule({
  declarations: [MapaComponent, DetalhesComponent, ListaCteComponent],
  imports: [
    CommonModule,
    DxMapModule,
    MonitoramentoRoutingModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    DxPopupModule,
    MatSlideToggleModule,
    SharedModule,
    MatCardModule
  ]
})
export class MonitoramentoModule { }
