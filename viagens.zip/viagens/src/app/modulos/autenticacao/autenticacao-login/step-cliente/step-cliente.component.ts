import { Component, OnInit, ViewChild, Output, EventEmitter, ChangeDetectorRef, OnDestroy, AfterViewInit } from '@angular/core';
import { DxMultiViewComponent } from 'devextreme-angular';

import * as _ from 'underscore';
import { MediaMatcher } from '@angular/cdk/layout';

@Component({
   selector: 'app-step-cliente',
   templateUrl: './step-cliente.component.html',
   styleUrls: ['./step-cliente.component.scss']
})
export class StepClienteComponent implements OnInit, OnDestroy, AfterViewInit {
   @Output() resposta = new EventEmitter();
   @ViewChild('multiview', { static: false }) multiview: DxMultiViewComponent;
   clientes: Array<any>;
   // MULTIVIEW
   views: Array<any>;
   porPagina: number;
   pages = 0;
   subtitle = [];
   tituloAtual: string;
   // FIM - MULTIVIEW


   mobileQuery: MediaQueryList;
   // tslint:disable-next-line: variable-name
   private _mobileQueryListener: () => void;

   constructor(
      private changeDetectorRef: ChangeDetectorRef,
      media: MediaMatcher
   ) {
      this.mobileQuery = media.matchMedia('(max-width: 600px)');
      this._mobileQueryListener = () => changeDetectorRef.detectChanges();
      // tslint:disable-next-line: deprecation
      this.mobileQuery.addListener(this._mobileQueryListener);

      this.clientes = [
         { ref: 'sulista', nome: 'Sulista', logo: 'assets/images/clientes/sulista.png' },
         { ref: 'bblog', nome: 'BBLOG', logo: 'assets/images/clientes/bblog.png' },
         { ref: 'diamante', nome: 'Diamante', logo: 'assets/images/clientes/diamante.png' },
         { ref: 'otdbrasil', nome: 'OTD Brasil', logo: 'assets/images/clientes/otd.png' },
         { ref: 'pizzato', nome: 'Pizzato Log', logo: 'assets/images/clientes/pizzatto.png' },
         { ref: 'axon', nome: 'Axon', logo: 'assets/images/clientes/axon.png' },
         { ref: 'cjlog', nome: 'CJ Log', logo: 'assets/images/clientes/cjlog.png' },
         // { ref: 'bbm', nome: 'BBM', logo: 'assets/images/clientes/bbm.png' },
         // { ref: 'cofco', nome: 'Cofco', logo: 'assets/images/clientes/cofco.png' },
         // { ref: 'repom', nome: 'Repom', logo: 'assets/images/clientes/repom.png' },
         // { ref: 'vialacteos', nome: 'Vialacteos', logo: 'assets/images/clientes/vialacteos.png' },
         { ref: 'transgires', nome: 'Transgires', logo: 'assets/images/clientes/transgires.png' },
         { ref: 'ritmo', nome: 'Ritmo', logo: 'assets/images/clientes/ritmo.png' },
         { ref: 'panorama', nome: 'Transpanorama', logo: 'assets/images/clientes/panorama.png' },
         { ref: 'cargosoft', nome: 'Cargosoft', logo: 'assets/images/clientes/cargosoft.png' },
         { ref: 'budel', nome: 'Budel', logo: 'assets/images/clientes/budel.png' },
         { ref: 'rodoleve', nome: 'Rodoleve', logo: 'assets/images/clientes/kmm.png' },
         { ref: 'levolog', nome: 'Levolog', logo: 'assets/images/clientes/kmm.png' },
      ];

      this.clientes = _.sortBy(this.clientes, 'nome');

   }

   ngOnInit() {
      this.multiView();
   }

   ngAfterViewInit(): void {
      this.changeDetectorRef.detectChanges();
   }

   ngOnDestroy(): void {
      // tslint:disable-next-line: deprecation
      this.mobileQuery.removeListener(this._mobileQueryListener);
   }

   setCliente(obj) {
      console.log('setando cliente :', obj);
      this.resposta.emit({ cliente: obj });
   }

   multiView() {
      this.views = [];
      this.pages = Math.ceil(this.clientes.length / 3);
      for (let index = 0; index < this.pages; index++) {
         this.views.push(this.paginate(this.clientes, 3, index + 1));

      }

   }

   paginate(array, pageSize, pageNumber) {
      --pageNumber;
      return array.slice(pageNumber * pageSize, (pageNumber + 1) * pageSize);
   }

   acao(tipo) {
      const mv = this.multiview.instance;
      const currentIndex = mv.option('selectedIndex');
      switch (tipo) {
         case 'next':
            mv.option('selectedIndex', currentIndex + 1);
            break;
         case 'prev':
            mv.option('selectedIndex', currentIndex - 1);
            break;

      }
   }



}
