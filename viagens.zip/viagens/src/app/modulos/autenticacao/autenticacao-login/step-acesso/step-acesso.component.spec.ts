import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StepAcessoComponent } from './step-acesso.component';

describe('StepAcessoComponent', () => {
  let component: StepAcessoComponent;
  let fixture: ComponentFixture<StepAcessoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StepAcessoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StepAcessoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
