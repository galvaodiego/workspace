import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './modulos/home/home/home.component';
import { ListaModulosComponent } from './modulos/home/lista-modulos/lista-modulos.component';
import { NotificacoesComponent } from './modulos/home/notificacoes/notificacoes.component';
import { Page404Component } from './modulos/home/page404/page404.component';
import { GuardaRotas } from './shared/guards/guarda-rotas.guard';
import { AutenticacaoLoginComponent } from './modulos/autenticacao/autenticacao-login/autenticacao-login.component';
import { InformacoesComponent } from './modulos/home/informacoes/informacoes.component';


const routes: Routes = [
   { path: '', component: AutenticacaoLoginComponent },
   { path: 'home', component: HomeComponent, canActivate: [GuardaRotas] },
   // { path: 'modulos', component: ListaModulosComponent, canActivate: [GuardaRotas] },
   // { path: 'notificacoes', component: NotificacoesComponent, canActivate: [GuardaRotas] },
   { path: 'informacoes', component: InformacoesComponent, canActivate: [GuardaRotas] },
   { path: 'monitoramento', loadChildren: './modulos/monitoramento/monitoramento.module#MonitoramentoModule' },
   { path: 'historico-temperatura', loadChildren: './modulos/historico-temperatura/historico-temperatura.module#HistoricoTemperaturaModule' },
   // { path: 'financeiro', loadChildren: './modulos/financeiro/financeiro.module#FinanceiroModule' },
   { path: 'logistico', loadChildren: './modulos/logistico/logistico.module#LogisticoModule' },
   // { path: 'contabil', loadChildren: './modulos/contabil/contabil.module#ContabilModule' },
   // { path: 'suprimentos', loadChildren: './modulos/suprimentos/suprimentos.module#SuprimentosModule' },
   // { path: 'lazy', loadChildren: './modulos/lazy/lazy.module#LazyModule' },
   { path: '**', component: Page404Component }
];

@NgModule({
   imports: [RouterModule.forRoot(
      routes,
      { enableTracing: false } // <-- debugging purposes only
   )],
   exports: [RouterModule]
})
export class AppRoutingModule { }
