var SftpUpload = require('sftp-upload'),
        fs = require('fs');
 
    var options = {
        host:'base.kmm.com.br',
        port: 9922,
        username:'www',
        path: __dirname + '/dist/kmm-bi',
        remoteDir: '/var/www/html/viagens',
        excludedFolders: ['./.git', 'node_modules'],
        privateKey: fs.readFileSync('privateKey_rsa')
   //  passphrase: fs.readFileSync('privateKey_rsa.passphrase')
    },
    sftp = new SftpUpload(options);
 
    sftp.on('error', function(err) {
        throw err;
    })
    .on('uploading', function(progress) {
        console.log('Uploading', progress.file);
        console.log(progress.percent+'% completed');
    })
    .on('completed', function() {
        console.log('Upload Completed');
    })
    .upload();