import FormularioCadastro from "./FormularioCadastro"
export default FormularioCadastro