import ListaDeCategorias from "./ListaDeCategorias";
export default ListaDeCategorias;