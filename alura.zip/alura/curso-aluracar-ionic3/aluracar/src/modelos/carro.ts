export interface Carro {
    nome: string;
    preco: number;
    fotos: string[];
}