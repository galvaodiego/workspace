export interface Acessorio {
    nome: string;
    preco: number;
}