export interface NavLifecycles {
    ionViewDidLoad?(): void;
}