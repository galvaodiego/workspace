module.exports = {
    base: require('./base'),
    livros: require('./livros')
}