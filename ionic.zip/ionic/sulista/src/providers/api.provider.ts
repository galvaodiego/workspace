import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Usuario } from '../kmm';
import { Observable } from 'rxjs/Observable';
@Injectable()
export class ApiProvider {
    headers: HttpHeaders = new HttpHeaders();
    public user: Usuario = Usuario.instance;
    constructor(
        private http: HttpClient,
    ) {
        this.headers = this.headers.append('Content-Type', 'application/json');
        this.headers = this.headers.append('Authorization', this.user.token);
    }

    getDados(): Observable<any> {
        const url = 'https://dash-backend.kmm.com.br';
        // const url = 'http://localhost:30042';
        return this.http.post(url+'/ionic-app/getDados', null)
    }

    // backendCall(dados, verbo, operacao) {
    //     // const url = 'https://dash-backend.kmm.com.br/ionic-app/' + operacao;
    //     const url = 'http://localhost:30042/ionic-app/' + operacao;
    //     return new Promise((resolvePai, rejectPai) => {
    //         this.send(verbo, url, dados, this.headers).then(
    //             (data) => {
    //                 // data = data.json();
    //                 if (data.result != null) {
    //                     resolvePai(data.result);
    //                 } else {
    //                     resolvePai(data);
    //                 }
    //             }
    //         ).catch(dataError => {
    //             // dataError = dataError.json();
    //             console.log('dataError', dataError);

    //             // Não autorizado - Quando o token é inválido ou expirado
    //             if (dataError.code === 401) {
    //                 // this.user.logout();
    //             } else if (dataError.code === 403) {
    //                 // console.log('dataError', dataError);
    //                 // this.user.logout();
    //                 // this.router.navigate(['']);
    //                 rejectPai(dataError);
    //             } else if (dataError.code === 404) {
    //                 // this.user.logout();
    //             } else {
    //                 try {
    //                     console.log('dataError', dataError);
    //                 } catch (er) { }
    //                 rejectPai(dataError); // Chama o reject do promise de retorno
    //             }
    //         }
    //         );
    //     });
    // }

    // tslint:disable-next-line: deprecation
    // public send(verbo: string, url: string, requestData: any, headers: HttpHeaders): Promise<any> {
    //     return new Promise((resolve, reject) => {
    //         switch (verbo) {
    //             case 'get':
    //                 this.http.get(url, { headers }).subscribe(
    //                     data => resolve(data),
    //                     err => reject(err));
    //                 break;
    //             case 'post':
    //                 this.http.post(url, JSON.stringify(requestData), { headers }).subscribe(
    //                     data => resolve(data),
    //                     err => reject(err));
    //                 break;
    //         }
    //     });
    // }

}