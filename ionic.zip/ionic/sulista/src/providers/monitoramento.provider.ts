import { Injectable } from '@angular/core';
import { KMMGateway, Usuario } from '../kmm';

@Injectable()
export class MonitoramentoProvider {

   public user: Usuario = Usuario.instance;


   constructor(private gateway: KMMGateway) {
   }

   public getMonitor(showloading?): Promise<any> {
      return this.gateway.backendCall(
         'M4002',
         'getMapa',
         {
            usuario: this.user.usuario
         },
         showloading
      );
   }

   public getRomaneioDetalhe(num_romaneio, showloading?): Promise<any> {
      return this.gateway.backendCall(
         'M4002',
         'getRomaneioDetalhe',
         {
            num_romaneio: num_romaneio
         },
         showloading
      );
   }
}
