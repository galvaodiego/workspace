import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule, LOCALE_ID } from '@angular/core';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';
import { registerLocaleData } from '@angular/common';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { IonicStorageModule } from '@ionic/storage';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { Geolocation } from '@ionic-native/geolocation';

// APLICAÇÃO
import { SulistaApp } from './app.component';
import { AuthProvider } from './../providers/auth.provider';
import { KMMGateway } from '../kmm';

//MODULOS
import { LoginPageModule } from '../pages/login/login.module';
import { DrePageModule } from '../pages/dre/dre.module';
import { FaturamentoPageModule } from './../pages/faturamento/faturamento.module';
import { LogisticoPageModule } from './../pages/logistico/logistico.module';
import { LogisticoDetalhesPageModule } from '../pages/logistico/logistico-detalhes/logistico-detalhes.module';
import { MonitoramentoPageModule } from '../pages/monitoramento/monitoramento.module';
import { MonitoramentoModalDetalhesPageModule } from '../pages/monitoramento/monitoramento-modal-detalhes/monitoramento-modal-detalhes.module';
import { MonitoramentoModalRotaPageModule } from '../pages/monitoramento/monitoramento-modal-rota/monitoramento-modal-rota.module';
import { MonitoramentoModalFiltrosPageModule } from '../pages/monitoramento/monitoramento-modal-filtros/monitoramento-modal-filtros.module';
import { MonitoramentoPopoverFiltrosPageModule } from '../pages/monitoramento/monitoramento-popover-filtros/monitoramento-popover-filtros.module';

//PAGINAS
import { SplashPage } from "../pages/splash/splash";
import { LoginPage } from './../pages/login/login';
import { DrePage } from '../pages/dre/dre';
import { HomePage } from './../pages/home/home';
import { FaturamentoPage } from './../pages/faturamento/faturamento';
import { LogisticoPage } from '../pages/logistico/logistico';
import { LogisticoDetalhesPage } from '../pages/logistico/logistico-detalhes/logistico-detalhes';
import { MonitoramentoPage } from './../pages/monitoramento/monitoramento';
import { MonitoramentoModalDetalhesPage } from '../pages/monitoramento/monitoramento-modal-detalhes/monitoramento-modal-detalhes';
import { MonitoramentoModalRotaPage } from '../pages/monitoramento/monitoramento-modal-rota/monitoramento-modal-rota';
import { MonitoramentoModalFiltrosPage } from '../pages/monitoramento/monitoramento-modal-filtros/monitoramento-modal-filtros';
import { MonitoramentoPopoverFiltrosPage } from '../pages/monitoramento/monitoramento-popover-filtros/monitoramento-popover-filtros';

import localePt from '@angular/common/locales/pt';
registerLocaleData(localePt);

@NgModule({
    declarations: [
        SulistaApp,
        SplashPage,
        HomePage,
    ],
    imports: [
        BrowserModule,
        IonicModule.forRoot(SulistaApp, {
            platforms: {
                ios: {
                    backButtonText: ' ',
                }
            }
        }),
        BrowserModule,
        BrowserAnimationsModule,
        IonicStorageModule.forRoot({
            name: 'sulista',
            driverOrder: ['indexeddb', 'sqlite', 'websql']
        }),
        HttpClientModule,
        LoginPageModule,
        FaturamentoPageModule,
        LogisticoPageModule,
        LogisticoDetalhesPageModule,
        MonitoramentoPageModule,
        MonitoramentoModalDetalhesPageModule,
        MonitoramentoModalRotaPageModule,
        MonitoramentoModalFiltrosPageModule,
        MonitoramentoPopoverFiltrosPageModule,
        DrePageModule
    ],
    bootstrap: [
        IonicApp
    ],
    entryComponents: [
        SulistaApp,
        HomePage,
        SplashPage,
        LoginPage,
        FaturamentoPage,
        LogisticoPage,
        LogisticoDetalhesPage,
        MonitoramentoPage,
        MonitoramentoModalDetalhesPage,
        MonitoramentoModalRotaPage,
        MonitoramentoModalFiltrosPage,
        MonitoramentoPopoverFiltrosPage,
        DrePage
    ],
    providers: [
        Geolocation,
        StatusBar,
        SplashScreen,
        { provide: ErrorHandler, useClass: IonicErrorHandler },
        { provide: LOCALE_ID, useValue: 'pt' },
        HttpClient,
        AuthProvider,
        KMMGateway,
    ]
})
export class AppModule { }
