import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController } from 'ionic-angular';

//KMM
import { AccessConfig, Usuario } from '../../kmm';
import { FaturamentoProvider } from './../../providers/faturamento.provider';

//Plugins
import * as moment from 'moment';
import 'moment/locale/pt-br';

@IonicPage()
@Component({
    selector: 'page-faturamento',
    templateUrl: 'faturamento.html',
})
export class FaturamentoPage {

    public user: Usuario = Usuario.instance;
    public config: AccessConfig = AccessConfig.instance;

    ////////////////////////////////////
    //          ESTRUTURA             //
    ////////////////////////////////////
    public rootItems: any;
    public navStack: Array<any> = [];
    public navStackSelected: any = [];
    public configuracao: any = {};

    public infoModulo: any
    public showFat: boolean = true;
    public showTon: boolean = false;
    public showDoc: boolean = false;

    // Datas Usadas para busca de Dados
    public dataInicio: string;
    public dataFim: string;

    public tipoFiltro;

    constructor(
        public navCtrl: NavController,
        public navParams: NavParams,
        public fatProvider: FaturamentoProvider,
        public alertCtrl: AlertController
    ) {
        this.tipoFiltro = 'diario';
        this.infoModulo = this.navParams.get('permissoesUserModulo');
        this.dataInicio = ('01/' + moment().format('MM') + '/' + moment().format('YYYY'));
        this.dataFim = moment().format('DD/MM/YYYY');
    }

    ionViewDidLoad() {
        this.getData(1, this.infoModulo, this.dataInicio, this.dataFim);
    }

    /**
     * Retorna os dados do Banco
     * @param listaMenu  :: Menu a ser mostrado  (1) = FATURAMENTO
     * @param permissoes :: Objeto com Permissoes do Usuário
     */
    public getData(listaMenu: number, permissoes, dataInicio, dataFim) {
        this.fatProvider.getConteudo(listaMenu, permissoes, dataInicio, dataFim).then(
            (result) => {
                this.configuracao = result;
                this.rootItems = this.configuracao.layout;
                this.normalizeArrayItems(this.configuracao.layout);
                this.setInitialValues(this.rootItems);
                console.log('root', this.rootItems);
            }
        );
    }

    ///////////////////////////////////////////////
    //                ESTRUTRA                   //
    ///////////////////////////////////////////////

    /**
    * Verifica se item contém lista filha. 
    * @param item 
    */
    public hasChild(item: any) {
        if (typeof (item.layout) != 'undefined' && item.layout != []) {
            return true;
        }
        return false;
    }

    /**
    * Recebe a Lista e Soma os campos
    * @param lista Array com os Dados
    */
    public setInitialValues(lista: Array<any>) {
        lista.forEach(element => {
            if (this.hasChild(element)) {
                this.setInitialValues(element.layout);

                //Somando o campo FAT_HOJE
                element.fat_hoje = element.layout
                    .map(
                        (fatH) => {
                            return fatH['fat_hoje'];
                        }
                    ).reduce((anterior, atual) => {
                        return (anterior + atual);
                    }, 0);

                //Somando o campo FAT_HOJE_MES_ANT
                element.fat_hoje_mes_ant = element.layout
                    .map(
                        (fatMa) => {
                            return fatMa['fat_hoje_mes_ant'];
                        }
                    ).reduce((anterior, atual) => {
                        return (anterior + atual);
                    }, 0);

                //Somando o campo  FAT_HOJE_ANO_ANT
                element.fat_hoje_ano_ant = element.layout
                    .map(
                        (fatAMa) => {
                            return fatAMa['fat_hoje_ano_ant'];
                        }
                    ).reduce((anterior, atual) => {
                        return (anterior + atual);
                    }, 0);

                //Somando o campo FAT_MES
                element.fat_mes = element.layout
                    .map(
                        (fatM) => {
                            return fatM['fat_mes'];
                        }
                    ).reduce((anterior, atual) => {
                        return (anterior + atual);
                    }, 0);

                //Somando o campo FAT_MES_ANT
                element.fat_mes_ant = element.layout
                    .map(
                        (fatMa) => {
                            return fatMa['fat_mes_ant'];
                        }
                    ).reduce((anterior, atual) => {
                        return (anterior + atual);
                    }, 0);

                //Somando o campo FAT_ANO_ANT
                element.fat_ano_ant = element.layout
                    .map(
                        (fatMaA) => {
                            return fatMaA['fat_ano_ant'];
                        }
                    ).reduce((anterior, atual) => {
                        return (anterior + atual);
                    }, 0);

                //Somando o campo PESO_HOJE
                element.peso_hoje = element.layout
                    .map(
                        (pesoH) => {
                            return pesoH['peso_hoje'];
                        }
                    ).reduce((anterior, atual) => {
                        return (anterior + atual);
                    }, 0);

                //Somando o campo PESO_HOJE_MES_ANT
                element.peso_hoje_mes_ant = element.layout
                    .map(
                        (pesoHMa) => {
                            return pesoHMa['peso_hoje_mes_ant'];
                        }
                    ).reduce((anterior, atual) => {
                        return (anterior + atual);
                    }, 0);

                //Somando o campo PESO_HOJE_MES_ANT
                element.peso_hoje_ano_ant = element.layout
                    .map(
                        (pesoHaA) => {
                            return pesoHaA['peso_hoje_ano_ant'];
                        }
                    ).reduce((anterior, atual) => {
                        return (anterior + atual);
                    }, 0);

                //Somando o campo PESO_MES
                element.peso_mes = element.layout
                    .map(
                        (pesoM) => {
                            return pesoM['peso_mes'];
                        }
                    ).reduce((anterior, atual) => {
                        return (anterior + atual);
                    }, 0);

                //Somando o campo PESO_MES_ANT
                element.peso_mes_ant = element.layout
                    .map(
                        (pesoMa) => {
                            return pesoMa['peso_mes_ant'];
                        }
                    ).reduce((anterior, atual) => {
                        return (anterior + atual);
                    }, 0);

                //Somando o campo PESO_MES_ANO_ANT
                element.peso_mes_ano_ant = element.layout
                    .map(
                        (pesoMaA) => {
                            return pesoMaA['peso_mes_ano_ant'];
                        }
                    ).reduce((anterior, atual) => {
                        return (anterior + atual);
                    }, 0);

                //Somando o campo NUM_DOCS
                element.num_docs = element.layout
                    .map(
                        (numDocs) => {
                            return numDocs['num_docs'];
                        }
                    ).reduce((anterior, atual) => {
                        return (anterior + atual);
                    }, 0);

                //Somando o campo NUM_DOCS_HOJE_MES_ANT
                element.num_docs_hoje_mes_ant = element.layout
                    .map(
                        (numDocsHojeMesAnt) => {
                            return numDocsHojeMesAnt['num_docs_hoje_mes_ant'];
                        }
                    ).reduce((anterior, atual) => {
                        return (anterior + atual);
                    }, 0);

                //Somando o campo NUM_DOCS_HOJE_ANO_ANT
                element.num_docs_hoje_ano_ant = element.layout
                    .map(
                        (numDocsHojeAnoAnt) => {
                            return numDocsHojeAnoAnt['num_docs_hoje_ano_ant'];
                        }
                    ).reduce((anterior, atual) => {
                        return (anterior + atual);
                    }, 0);

                //Somando o campo NUM_DOCS_MES
                element.num_docs_mes = element.layout
                    .map(
                        (numDocsMes) => {
                            return numDocsMes['num_docs_mes'];
                        }
                    ).reduce((anterior, atual) => {
                        return (anterior + atual);
                    }, 0);

                //Somando o campo NUM_DOCS_MES_ANT
                element.num_docs_mes_ant = element.layout
                    .map(
                        (numDocsMesAnt) => {
                            return numDocsMesAnt['num_docs_mes_ant'];
                        }
                    ).reduce((anterior, atual) => {
                        return (anterior + atual);
                    }, 0);

                //Somando o campo NUM_DOCS_MES_ANO_ANT
                element.num_docs_mes_ano_ant = element.layout
                    .map(
                        (numDocsMesAnoAnt) => {
                            return numDocsMesAnoAnt['num_docs_mes_ano_ant'];
                        }
                    ).reduce((anterior, atual) => {
                        return (anterior + atual);
                    }, 0);

            } else {
                return;
            }
        });
    }


    /**
    * Processa os itens para que todos contenham valor
    * @param lista Array com o Conteudo
    */
    public normalizeArrayItems(lista: Array<any>) {
        lista.forEach(
            (element) => {
                if (this.hasChild(element)) {
                    //Inicializa a Variavel em todos os niveis
                    if (typeof (element.fat_hoje || element.peso_hoje || element.num_docs) === 'undefined') {
                        element.fat_hoje = 0;
                        element.fat_hoje_mes_ant = 0;
                        element.fat_hoje_ano_ant = 0;
                        element.fat_mes = 0;
                        element.fat_mes_ant = 0;
                        element.fat_ano_ant = 0;
                        element.peso_hoje = 0;
                        element.peso_hoje_mes_ant = 0;
                        element.peso_hoje_ano_ant = 0;
                        element.peso_mes = 0;
                        element.peso_mes_ant = 0;
                        element.peso_mes_ano_ant = 0;
                        element.num_docs = 0;
                        element.num_docs_hoje_mes_ant = 0;
                        element.num_docs_hoje_ano_ant = 0;
                        element.num_docs_mes = 0;
                        element.num_docs_mes_ant = 0;
                        element.num_docs_mes_ano_ant = 0;
                    }
                    //passa o caminho do item novamente (layout)
                    this.normalizeArrayItems(element.layout)
                }
                else {
                    return;
                }
            }
        );
    }



    // public novaData() {
    //     let alert = this.alertCtrl.create({
    //         title: 'Período',
    //         inputs: [
    //             {
    //                 name: 'inicio',
    //                 placeholder: 'Data Inicio',
    //                 type: 'date'
    //             },
    //             {
    //                 name: 'fim',
    //                 placeholder: 'Data Fim',
    //                 type: 'date'
    //             }
    //         ],
    //         buttons: [
    //             {
    //                 text: 'Cancelar',
    //                 role: 'cancel',
    //                 handler: data => { }
    //             },
    //             {
    //                 text: 'OK',
    //                 handler: data => {
    //                     this.dataInicio = data.inicio;
    //                     this.dataFim = data.fim;
    //                     this.getData(1, this.infoModulo, this.dataInicio, this.dataFim);
    //                 }
    //             }
    //         ]
    //     });
    //     alert.present();
    // }

    /**
    * Função Para Alterar o Estilo do botão da Tabela
    * @param e Evento recebido pelo componente
    */

    onCellPrepared(e) {
        //Pinta as Linhas de Cabeçalho e Filtros
        if (e.rowType == 'header') {
            e.cellElement.bgColor = '#251b40';
            e.cellElement.style.color = '#ffffff';
        }

        // Pinta as Linhas dos Níveis (Empresa, Operação, Cliente)
        if (typeof (e.data) !== 'undefined') {
            if (e.data.nivel == 'Sulista') {
                e.cellElement.style.textTransform = 'uppercase';
                e.cellElement.bgColor = '#505050';
                e.cellElement.style.color = '#ffffff';
            } else if (e.data.nivel == 'Operação') {
                e.cellElement.bgColor = '#a0a0a0';
                e.cellElement.style.color = '#000000';
            } else if (e.data.nivel == 'Centro de Custo') {
                e.cellElement.bgColor = '#d0cece';
                e.cellElement.style.color = '#000000';
            } else if (e.data.nivel == 'Cliente') {
                e.cellElement.bgColor = '#ffffff';
                e.cellElement.style.color = '#000000';
            } else {
                e.cellElement.bgColor = '#e9eef3';
                e.cellElement.style.color = '#000000';
            }

            //Cores antigas (ROXO)
            // if (e.data.nivel == 'Sulista') {
            //     e.cellElement.bgColor = '#3d3061';
            //     e.cellElement.style.color = '#ffffff';
            // } else if (e.data.nivel == 'Operação') {
            //     e.cellElement.bgColor = '#5a488a';
            //     e.cellElement.style.color = '#ffffff';
            // } else if (e.data.nivel == 'Centro de Custo') {
            //     e.cellElement.bgColor = '#725dab';
            //     e.cellElement.style.color = '#ffffff';
            // } else if (e.data.nivel == 'Cliente') {
            //     e.cellElement.bgColor = '#ffffff';
            //     e.cellElement.style.color = '#000000';
            // } else {
            //     e.cellElement.bgColor = '#e9eef3';
            //     e.cellElement.style.color = '#000000';
            // }
        }
    }
}



