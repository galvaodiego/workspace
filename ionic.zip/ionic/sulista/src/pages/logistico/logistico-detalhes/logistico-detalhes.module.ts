import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DxDataGridModule } from 'devextreme-angular';
import { LogisticoDetalhesPage } from './logistico-detalhes';

@NgModule({
    declarations: [
        LogisticoDetalhesPage,
    ],
    imports: [
        IonicPageModule.forChild(LogisticoDetalhesPage),
        DxDataGridModule
    ],
})
export class LogisticoDetalhesPageModule { }
