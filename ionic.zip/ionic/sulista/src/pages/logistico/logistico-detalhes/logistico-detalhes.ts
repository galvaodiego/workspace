import { Component } from '@angular/core';
import { IonicPage, NavParams } from 'ionic-angular';
import { LogisticoProvider } from '../../../providers/logistico.provider';

@IonicPage()
@Component({
    selector: 'page-logistico-detalhes',
    templateUrl: 'logistico-detalhes.html',
})
export class LogisticoDetalhesPage {

    //Dados do Organizacional para as Buscas
    public dados: any = [];

    //Array com o Resultado
    public dataSource: any; //Array do Devextreme
    public status: any = [];

    public statusSelecionado: string = '';

    constructor(
        public navParams: NavParams,
        public logProvider: LogisticoProvider
    ) {
        this.dados = this.navParams.get('info');
    }

    ionViewDidLoad() {
        this.getDados(this.dados);
    }

    /**
    * Retorna os dados do Banco
    * @param dados :: Informações da Operação Selecionada na tela anterior
    */
    public getDados(dados: any): Promise<any> {
        return this.logProvider.getIndicadorLogisticoDetalhes(this.dados[0].dados.organizacional).then(
            (result) => {
                let temp = [];
                result.logistico.forEach(
                    (el) => {
                        if (el.lista.length > 0) {
                            temp.push(el)
                        }
                    }
                );
                this.status = temp;
                this.statusSelecionado = this.dados[0].status
                this.dataSource = this.status.find((el) => el.status == this.statusSelecionado).lista
            }
        );
    }

    /**
     * Escolhe os dados do Grid conforme o Status Selecionado
     * @param item Status Selecionado
     *  Objetivo:: Alterar os Dados do Array @var dataSource do Grid de Detalhes
     */
    public selectStatus(item) {
        let temp = [];
        temp = this.status.filter(
            (it) => {
                return it.status == item
            }
        )
        this.dataSource = temp[0].lista;
        this.statusSelecionado = temp[0].status;
    }

    /**
    * Função Para Alterar o Estilo do botão da Tabela
    * @param e Evento recebido pelo componente
    */

    public onCellPrepared(e) {
        //Pinta as Linhas de Cabeçalho e Filtros
        if (e.rowType == 'header') {
            e.cellElement.bgColor = '#251b40';
            e.cellElement.style.color = '#ffffff';
        }
    }
}