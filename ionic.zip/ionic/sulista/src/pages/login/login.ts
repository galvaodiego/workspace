import { Component } from '@angular/core';
import { IonicPage, NavController, ActionSheetController, AlertController, ToastController } from 'ionic-angular';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';

//KMM
import { AuthProvider } from './../../providers/auth.provider';
import { Usuario } from '../../kmm';

//Paginas
import { HomePage } from '../../pages/home/home';

@IonicPage()
@Component({
    selector: 'page-login',
    templateUrl: 'login.html'
})

export class LoginPage {
    public loginForm: FormGroup;
    public backimg: string;
    public senhaTemp: string;
    public user: Usuario = Usuario.instance;

    constructor(
        public actionSheetCtrl: ActionSheetController,
        public alertCtrl: AlertController,
        public authProvider: AuthProvider,
        public form: FormBuilder,
        public nav: NavController,
        public toastCtrl: ToastController
    ) {
        this.loginForm = this.form.group({
            "username": ["", Validators.required],
            "password": ["", Validators.required]
        });

        this.user.url = "https://kmm.sulista.com.br"
      //   this.user.url = "http://kmm.otdbrasil.com.br"

    }

    ionViewDidLoad() { }

    /**
    * Recebe os Dados do Formulário e chama a função de Login
    */
    public doLogin(ev) {
        this.user.senha = this.senhaTemp;
        this.user.codGestao = null;
        this.user.filiais = null;
        this.user.identificador = null;
        this.user.token = null;
        this.requestLogin();
    }

    /**
     * LOGIN | Função que realiza o Login e traz os Dados do Usuário
     */
    // public requestLogin() {
    //     this.loginProvider.login().then(result => {
    //         if (result.token != null && result.token.length) {
    //             this.user.token = result.token;
    //             this.user.isLogged = true;
    //             this.nav.setRoot(HomePage);
    //         } else if (result.gestoes != null && result.gestoes.length > 0) {
    //             if (result.gestoes.length == 1) {
    //                 this.user.codGestao = result.gestoes[0].cod_gestao;
    //                 this.user.identificador = result.gestoes[0].identificador;
    //                 this.showFiliais(result.gestoes[0].filiais);
    //             } else {
    //                 this.showGestoes(result.gestoes);
    //             }
    //         }
    //     }).catch(err => {
    //         return;
    //     });
    // }

    /**
     * Faz Login sem aparecer POP-UP de Gestões e Filiais
     */
    public requestLogin() {
        this.authProvider.login().then(result => {
            if (result.token != null && result.token.length) {
                this.user.token = result.token;
                this.user.isLogged = true;
                this.nav.setRoot(HomePage);
            } else if (result.gestoes != null && result.gestoes.length > 0) {
                result.gestoes.forEach(
                    (element) => {
                        this.user.codGestao = 1;
                        this.user.filiais = '';
                        this.user.identificador = element.identificador;
                    });
                this.requestLogin();
            }
        }).catch(err => {
            return;
        });
    }

    /**
    *  Mostra as GESTÕES do usuário que o Login retornou
    * @param listaGestoes -- Lista de Gestões para Exibir
    */
    public showGestoes(listaGestoes: Array<any>) {
        let alertGestoes = this.alertCtrl.create();
        alertGestoes.setTitle("Gestões");
        for (let g of listaGestoes) {
            alertGestoes.addInput({
                type: 'radio',
                label: g.cliente,
                value: g.cod_gestao,
                checked: g.cod_gestao == this.user.codGestao
            });
        }
        alertGestoes.addButton({
            text: 'Cancelar'
        });
        alertGestoes.addButton({
            text: 'Selecionar',
            handler: codGestao => {
                if (codGestao != null) {
                    this.user.codGestao = codGestao;
                    this.user.identificador = listaGestoes.find(obj => obj.cod_gestao === codGestao).identificador;
                    this.showFiliais(listaGestoes.find(obj => obj.cod_gestao === codGestao).filiais); // Descomentar para mostras as filiais
                }
            }
        });

        alertGestoes.present(alertGestoes);
    }

    /**
     *  Mostra as FILIAIS do usuário que o Login retornou
     */

    public showFiliais(listaFiliais: Array<any>) {
        if (listaFiliais == null || listaFiliais.length == 0) {
            this.user.filiais = null;
            this.requestLogin();
            return;
        }
        let alert = this.alertCtrl.create();
        alert.setTitle('Filiais');

        for (let filial of listaFiliais) {
            alert.addInput({
                type: 'checkbox',
                label: filial.cliente,
                value: filial.cod_pessoa,
                checked: true
            });
        }

        alert.addButton('Cancelar');
        alert.addButton({
            text: 'Selecionar',
            handler: data => {
                this.user.filiais = data.join(",");
                this.requestLogin();
            }
        });
        alert.present(alert);
    }


    //DEBUG 
    public _countDebug: number = 0;
    public _lastTime: number = 0;
    public onDebugClick($event) {
        if (($event.timeStamp - this._lastTime) <= 250) {
            this._countDebug++;
            if (this._countDebug == 10) {
                this.user.isDebug = !this.user.isDebug;
                this._countDebug = 0;
                let alert = this.alertCtrl.create({
                    message: "Debug " + (this.user.isDebug ? "ativado" : "desativado"),
                    title: "Debug",
                    buttons: [{ text: "OK" }]
                });
                alert.present(alert);
            }
        } else {
            this._countDebug = 0;
        }
        this._lastTime = $event.timeStamp;
    }

    public opcoes() {
        let actionSheet = this.actionSheetCtrl.create({
            title: 'Opções',
            buttons: [{
                text: 'URL',
                handler: () => {
                    this.promptURL();
                }
            }
            ]
        });
        actionSheet.present();
    }

    public promptURL() {
        //debugger;
        let prompt = this.alertCtrl.create({
            title: 'URL',
            message: "Informe a URL para conexão",
            inputs: [
                {
                    name: 'url',
                    placeholder: 'URL',
                    value: this.user.url,
                    type: "url",
                }
            ],
            buttons: [
                {
                    text: 'Cancelar'
                },
                {
                    text: 'Salvar',
                    handler: (data) => {
                        if (!data.url.startsWith("http")) {
                            data.url = "http://" + data.url;
                        }

                        if (!this.isURL(data.url)) {
                            this.toast("URL inválida.", 2000);
                            return false;
                        }
                        this.user.url = data.url;
                        return true;
                    }
                }
            ]
        });
        prompt.present();
    }

    public toast(msg: string, duration?: number) {
        let toast = this.toastCtrl.create({
            message: msg,
            closeButtonText: "OK",
            showCloseButton: true,
            duration: duration
        });
        toast.present();
    }


    public isURL(str: string): boolean {
        var urlRegex = '^(?!mailto:)(?:(?:http|https|ftp)://)(?:\\S+(?::\\S*)?@)?(?:(?:(?:[1-9]\\d?|1\\d\\d|2[01]\\d|22[0-3])(?:\\.(?:1?\\d{1,2}|2[0-4]\\d|25[0-5])){2}(?:\\.(?:[0-9]\\d?|1\\d\\d|2[0-4]\\d|25[0-4]))|(?:(?:[a-z\\u00a1-\\uffff0-9]+-?)*[a-z\\u00a1-\\uffff0-9]+)(?:\\.(?:[a-z\\u00a1-\\uffff0-9]+-?)*[a-z\\u00a1-\\uffff0-9]+)*(?:\\.(?:[a-z\\u00a1-\\uffff]{2,})))|localhost)(?::\\d{2,5})?(?:(/|\\?|#)[^\\s]*)?$';
        var url = new RegExp(urlRegex, 'i');
        return str.length < 2083 && url.test(str);
    }


}
