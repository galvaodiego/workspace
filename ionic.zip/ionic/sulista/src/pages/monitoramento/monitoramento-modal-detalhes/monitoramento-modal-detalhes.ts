import { Component, ChangeDetectorRef } from '@angular/core';
import { IonicPage, NavParams, Platform, Events, ViewController, ModalController } from 'ionic-angular';
import { Screenshot } from '@ionic-native/screenshot';
import { SocialSharing } from '@ionic-native/social-sharing';

import * as moment from 'moment';
import 'moment/locale/pt-br';
import { MonitoramentoModalCtesPage } from '../monitoramento-modal-ctes/monitoramento-modal-ctes';

@IonicPage()
@Component({
   selector: 'page-monitoramento-modal-detalhes',
   templateUrl: 'monitoramento-modal-detalhes.html'
})
export class MonitoramentoModalDetalhesPage {

   public dadosVeicDetalhes: any;
   public statusViagem: string;
   public percExecutado: number;

   //Contagem de Tempo no Status
   public tempoNoStatus: any;
   public intervaloDate: any;
   public valueTime: number;
   public tempoLimite: number;

   constructor(
      public platform: Platform,
      public params: NavParams,
      public viewCtrl: ViewController,
      public events: Events,
      public cd: ChangeDetectorRef,
      private print: Screenshot,
      private social: SocialSharing,
      public modalCtrl: ModalController,
   ) {
      this.dadosVeicDetalhes = this.params.get('veiculo');
      console.log('dadosVeicDetalhes', this.dadosVeicDetalhes);
      this.statusViagem = this.dadosVeicDetalhes.status.toLowerCase();

      //Valida Valor do Transit Time
      if (this.dadosVeicDetalhes.perc_executado !== null) {
         this.percExecutado = this.dadosVeicDetalhes.perc_executado
      } else {
         this.percExecutado = 0;
      }

      //Limita os caracteres
      this.dadosVeicDetalhes.carregamento = this.dadosVeicDetalhes.carregamento.substring(0, 12);
      this.dadosVeicDetalhes.destino = this.dadosVeicDetalhes.destino.substring(0, 12);

      // Se o Caminhão estiver em CARGA ou DESCARGA mostra quanto tempo ele está no Status
      if (this.statusViagem == 'carga' || this.statusViagem == 'descarga') {
         this.countUp(this.dadosVeicDetalhes.inicio_evento)
      }

   }

   ionViewDidLoad() {

   }

	/**
	 * Valida se a Data não é Vazia e retorna Formatada
	 * @param data data desejada
	 */
   public validDate(data) {
      if (data !== '') {
         return moment(data).format('DD/MM/YYYY HH:mm');
      } else {
         return data
      }
   }

	/**
	 * Tira um Print da Tela e envia via rede Social
	 */
   public printTelaAndShare() {
      this.platform.ready().then(() => {
         this.print.URI(80)
            .then((res) => {
               let msg = '[APP Monitoramento Sulista] Placa CV: ' + this.dadosVeicDetalhes.placa_cavalo + ' | Operação: ' + this.dadosVeicDetalhes.operacao;
               let sub = '[APP Monitoramento Sulista]'
               this.social.share(msg, sub, res.URI, null).then();
            }, () => { });
      });
   }

	/**
 	* Seta a Cor da Progressbar do TransitTime
	* @param number Valor de Comparação
	* 0 = Atrasado | 1 = Verde | 2 = Possibilidade de Atraso
	*/
   public setColor(number) {
      let color: string = '';
      let value = Number(number);
      if (value == 0) {
         color = '#aa2227';
      } else if (value == 2) {
         color = '#ff9800';
      } else if (value == 1) {
         color = '#4caf50';
      } else if (value == null) {
         color = '#f0eeee';
      }
      return color;
   }

	/**
	 * Seta o Icone da Progressbar do TransitTime
	 * @param number Valor de Comparação
	 * 0 = Atrasado | 1 = Verde | 2 = Possibilidade de Atraso
	*/
   public setIcon(number) {
      let icon: string = '';
      let value = Number(number);
      if (value == 0) {
         icon = 'transit-truck-atrasado';
      } else if (value == 2) {
         icon = 'transit-truck-possibilidade';
      } else if (value == 1) {
         icon = 'transit-truck-ok';
      } else if (value == null) {
         icon = 'transit-truck';
      }
      return icon;
   }

	/**
 	* Seta o Texto de Saida conforme Status
	* @param valor Valor de Comparação
	*/
   public setTextSaida(status) {
      let tituloStatus: string = '';
      if (status == 'viagem') {
         tituloStatus = 'Janela Carga';
      } else if (status == 'carga') {
         tituloStatus = 'Janela Carga';
      } else if (status == 'descarga') {
         tituloStatus = 'Janela Descarga';
      } else {
         tituloStatus = 'Saída';
      }
      return tituloStatus;
   }

	/**
 	* Seta o Texto de Chegada conforme Status
	* @param valor Valor de Comparação
	*/
   public setTextChegada(status) {
      let tituloStatus: string = '';
      if (status == 'viagem') {
         tituloStatus = 'Janela Descarga';
      } else if (status == 'carga') {
         tituloStatus = 'Prev término Carga';
      } else if (status == 'descarga') {
         tituloStatus = 'Prev Término Descarga';
      } else {
         tituloStatus = 'Chegada';
      }
      return tituloStatus;
   }

	/**
    * Realiza a contagem regressiva com base na data fim.
    */
   public countUp(dataInicio) {


      dataInicio = moment(dataInicio).toISOString();

      //5*3600*1000 -- 5 horas em ms
      const countUpDate = new Date(dataInicio).getTime();

      //Tempo Limite de Carga e Descarga (5 Horas)
      this.tempoLimite = Math.floor(5 * 1000 * 60 * 60);

      // Atualiza a contagem a cada segundo
      this.intervaloDate = setInterval(
         () => {
            // Datetime atual
            const now = new Date().getTime();

            // distância entre a data desejada e a atual
            this.valueTime = now - countUpDate;

            // Calcula dia, hora, minuto e segundo
            const days = Math.floor(this.valueTime / (1000 * 60 * 60 * 24));
            const hours = Math.floor((this.valueTime % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            const minutes = Math.floor((this.valueTime % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((this.valueTime % (1000 * 60)) / 1000);

            if (days > 0) {
               this.tempoNoStatus = days + 'd ' + hours + 'h ' + minutes + 'm ' + seconds + 's ';
            } else if (hours > 0) {
               this.tempoNoStatus = hours + 'h ' + minutes + 'm ' + seconds + 's ';
            } else {
               this.tempoNoStatus = minutes + 'm ' + seconds + 's ';
            }

            this.cd.detectChanges();
            this.cd.detach();
         }, 1000
      );
   }

	/**
	* Fecha o Modal 
	*/
   public fechaModal() {
      clearInterval(this.intervaloDate);
      this.viewCtrl.dismiss();
   }


   public abreModalCTE(num_romaneio) {
      let modal = this.modalCtrl.create(MonitoramentoModalCtesPage, { num_romaneio: num_romaneio });
      modal.present();
   }

}
