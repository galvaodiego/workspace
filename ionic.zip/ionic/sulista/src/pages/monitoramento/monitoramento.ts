import { Component, ViewChild } from '@angular/core';
import { AlertController, Events, IonicPage, Keyboard, ModalController, NavController, NavParams, Platform, PopoverController } from 'ionic-angular';

import { DxMapComponent } from 'devextreme-angular';
import { Geolocation } from '@ionic-native/geolocation';

import { MonitoramentoService } from './monitoramento.service';
import { MonitoramentoModalFiltrosPage } from './monitoramento-modal-filtros/monitoramento-modal-filtros';
import { MonitoramentoPopoverFiltrosPage } from './../monitoramento/monitoramento-popover-filtros/monitoramento-popover-filtros';

@IonicPage()
@Component({
    selector: 'page-monitoramento',
    templateUrl: 'monitoramento.html'
})
export class MonitoramentoPage {

    //////////////////////////////
    //    VARIAVEIS DO MAPA
    /////////////////////////////

    //Zoom do Mapa
    public isCenter: any
    //Distancia do Mapa
    public isZoom: any

    @ViewChild(DxMapComponent) map: DxMapComponent;

    //////////////////////////////
    //    MINHAS VARIAVEIS
    /////////////////////////////

    //Permissoes do usuário no Módulo
    public infoModulo: any;

    //Campo de Busca
    public isSearchShow: boolean = false;
    public searchField: string = '';

    constructor(
        public alertCtrl: AlertController,
        public events: Events,
        public geo: Geolocation,
        public keyboard: Keyboard,
        public modalCtrl: ModalController,
        public monitService: MonitoramentoService,
        public navCtrl: NavController,
        public navParams: NavParams,
        public platform: Platform,
        public popoverCtrl: PopoverController,

    ) {
        this.infoModulo = this.navParams.get('permissoesUserModulo');
    }

    ionViewDidLoad() {
        // Busca os Dados do Mapa no Service
        this.monitService.getMonitoramento(true);
    }

    /**
     * Retrocede para a Página Inicial
     */
    public backPage() {
        this.navCtrl.pop();
    }

    /**
    * Chama o Modal de Filtros
    */
    public abreModalFiltros() {
        let modal = this.modalCtrl.create(MonitoramentoModalFiltrosPage, { listaFiltros: this.monitService.filtros });
        modal.present();
    }

    /**
    * Abre o PopOver de Status
    * @param evento 
    */
    public abrePopover() {
        let popover = this.popoverCtrl.create(MonitoramentoPopoverFiltrosPage, { listaFiltros: this.monitService.filtros });
        popover.present();
    }

    /**
    * Aplica o Zoom no Mapa
    * @param lat latitude
    * @param lng longitude
    */
    public zoomMapa(lat, lng) {
        this.isCenter = [lat, lng];
        this.isZoom = 16;
        this.map.instance.option("center", this.isCenter);
        this.map.instance.option("zoom", this.isZoom);

    }


    /************************************** 
    *  BUSCA DO VEICULO POR PLACA 
    ***************************************/
    /**
    * Mostra/Oculta o Campo de Busca
    */
    public showSearch() {
        this.searchField = '';
        this.isSearchShow = true;
    }

    public hideSearch() {
        this.searchField = '';
        this.isSearchShow = false;
    }

    /**
    * Localiza o veículo por placa e por frota e retorna o objeto.
    * @param busca 
    */
    // public findVeiculoPorPlaca(busca: string) {
        
    //     return this.monitService.mirrorMarcadores.find(
    //         (el) => {
    //             this.keyboard.close();
    //             return el.placa_cavalo === busca.toUpperCase() || el.frota === busca.toUpperCase(); //busca por placa e por frota
    //         }
    //     );

    // }

    /**
    * Realiza a Busca
    * Localiza o veículo por placa e por frota 
    */

    public realizaBusca(veiculo: any) {
        console.log(veiculo);
        
        this.hideSearch();
        let marcadoresBusca = [];
        marcadoresBusca.push(veiculo)
        this.monitService.initMap(marcadoresBusca);
        this.zoomMapa(veiculo.lat, veiculo.lng);
    }

    ///////////////////////////////////////////
    //             GEOLOCALIZAÇÃO            //
    ///////////////////////////////////////////

    /**
    * Pergunta ao Usuário sobre a Geolocalização
    */
    public showQuestionGeolocalizacao() {
        let alert = this.alertCtrl.create({
            title: 'Geolocalização',
            message: 'Deseja ver quais veículos estão ao seu redor?',
            buttons: [
                {
                    text: 'Não',
                    role: 'cancel',
                    handler: () => {
                        console.log('cancelado');
                    }
                },
                {
                    text: 'Sim',
                    handler: () => {
                        this.getGeolocalizacao();
                    }
                }
            ]
        });
        alert.present();
    }


    /**
    * Resgata a localização do Usuário
    */
    public getGeolocalizacao() {
        this.platform.ready().then(() => {
            this.geo.getCurrentPosition().then(res => {
                this.zoomMapa(res.coords.latitude, res.coords.longitude)
            }).catch(() => {
                this.monitService.showToast('Erro ao Resgatar sua Localização')
            })
        })
    }

}
