import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AppModule } from './app.module';

// CONFIGS EM PT-BR DO ANGULAR
import localePt from '@angular/common/locales/pt';
import { registerLocaleData } from '@angular/common';
registerLocaleData(localePt);

/////////////////////////////////
//          DEVEXTREME         //
/////////////////////////////////

import 'devextreme-intl';
import * as messagesPt from '../assets/devextreme/pt.json';
import config from 'devextreme/core/config';
import { loadMessages, locale } from 'devextreme/localization';

config({
    defaultCurrency: 'BRL',
    decimalSeparator: ',',
    thousandsSeparator: '.'
});

loadMessages(messagesPt.default);
locale('pt-BR');

platformBrowserDynamic().bootstrapModule(AppModule);
