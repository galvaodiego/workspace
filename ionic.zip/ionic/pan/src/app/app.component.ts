import { Component } from '@angular/core';
import { Platform } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { Usuario, AccessConfig } from '../kmm';

import { SplashPage } from '../pages/splash/splash';
import { LoginPage } from './../pages/login/login';
import { HomePage } from '../pages/home/home';

@Component({
    templateUrl: 'app.html'
})
export class SulistaApp {
    private user: Usuario = Usuario.instance;
    private accessConfig: AccessConfig = AccessConfig.instance;

    rootPage: any = SplashPage;

    constructor(platform: Platform, statusBar: StatusBar, splashScreen: SplashScreen) {
        platform.ready().then(() => {
            this.user.init().then(
                () => {
                    this.accessConfig.init().then(
                        () => {
                            if (this.user.isLogged == true) {
                                this.rootPage = HomePage;
                            } else {
                                this.rootPage = LoginPage;
                            }
                        }
                    );
                }
            );

            if (platform.is('ios')) {
                statusBar.overlaysWebView(true);
                statusBar.styleBlackTranslucent();
                statusBar.backgroundColorByHexString('#ffffff');
            }

            statusBar.styleBlackTranslucent();
            splashScreen.hide();
        });
    }
}

