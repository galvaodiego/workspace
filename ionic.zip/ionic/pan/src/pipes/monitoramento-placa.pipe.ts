import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'monitoramentoPlacaPipe',
    pure: false
})
export class MonitoramentoPlacaPipe implements PipeTransform {
    transform(items: any[], field: string, terms: string): any[] {
        if (!items) return [];
        if (!terms) return items;
        terms = terms.toUpperCase();
        return items.filter(it => {
            return it.placa_cavalo.toUpperCase().includes(terms);
        });
    }
}
