import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'monitoramentoFrotaPipe',
    pure: false
})
export class MonitoramentoFrotaPipe implements PipeTransform {
    transform(items: any[], field: string, terms: string): any[] {
        if (!items) return [];
        if (!terms) return items;
        terms = terms.toUpperCase();
        return items.filter(it => {
            return it.frota.toUpperCase().includes(terms);
        });
    }
}
