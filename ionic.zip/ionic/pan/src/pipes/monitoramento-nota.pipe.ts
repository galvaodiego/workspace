import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'monitoramentoNotaPipe',
    pure: false
})
export class MonitoramentoNotaPipe implements PipeTransform {
    transform(items: any[], field: string, terms: string): any[] {
        if (!items) return [];
        if (!terms) return items;
        terms = terms.toUpperCase();

        return items.filter(it => {
            return it.num_nota.toUpperCase().includes(terms);
        });

    }
}
