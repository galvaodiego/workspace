import { NgModule } from '@angular/core';
import { MonitoramentoPlacaPipe } from './monitoramento-placa.pipe';
import { MonitoramentoFrotaPipe } from './monitoramento-frota.pipe';
import { MonitoramentoNotaPipe } from './monitoramento-nota.pipe';
@NgModule({
    declarations: [
        MonitoramentoPlacaPipe,
        MonitoramentoFrotaPipe,
        MonitoramentoNotaPipe
    ],
    imports: [],
    exports: [
        MonitoramentoPlacaPipe,
        MonitoramentoFrotaPipe,
        MonitoramentoNotaPipe
    ]
})
export class PipesModule { }
