import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';

//KMM
import { LoginPage } from './login';
import { AuthProvider } from './../../providers/auth.provider';

@NgModule({
    declarations: [
        LoginPage,
    ],
    imports: [
        IonicPageModule.forChild(LoginPage),
    ],
    providers: [AuthProvider]
})
export class LoginPageModule { }
