import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AcompanhamentoLogisticoPage } from './acompanhamento-logistico';
import { LogisticoProvider } from '../../providers/logistico.provider';
import { ComponentsModule } from '../../components/components.module';

@NgModule({
    declarations: [
        AcompanhamentoLogisticoPage,
    ],
    imports: [
        IonicPageModule.forChild(AcompanhamentoLogisticoPage),
        ComponentsModule
    ],
    providers: [LogisticoProvider]
})
export class AcompanhamentoLogisticoPageModule { }
