import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DxDataGridModule } from 'devextreme-angular';
import { AcompanhamentoLogisticoDetalhesPage } from './acompanhamento-logistico-detalhes';

@NgModule({
    declarations: [
      AcompanhamentoLogisticoDetalhesPage,
    ],
    imports: [
        IonicPageModule.forChild(AcompanhamentoLogisticoDetalhesPage),
        DxDataGridModule
    ],
})
export class AcompanhamentoLogisticoDetalhesPageModule { }
