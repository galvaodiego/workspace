import { Component } from '@angular/core';
import { AlertController, NavController } from 'ionic-angular';

import { AccessConfig, ConfigOrgUsuario, Nivel, Permissao, Usuario } from '../../kmm';
import { AuthProvider } from '../../providers/auth.provider';

//Paginas
import { FaturamentoPage } from '../faturamento/faturamento';
import { LoginPage } from '../login/login';
import { LogisticoPage } from '../logistico/logistico';
import { MonitoramentoPage } from '../monitoramento/monitoramento';
import { DrePage } from './../dre/dre';
import { AcompanhamentoLogisticoPage } from '../acompanhamento-logistico/acompanhamento-logistico';

@Component({
    selector: 'page-home',
    templateUrl: 'home.html'
})
export class HomePage {

    public user: Usuario = Usuario.instance;
    public accessConfig: AccessConfig = AccessConfig.instance;

    constructor(
        public auth: AuthProvider,
        public navCtrl: NavController,
        public alertCtrl: AlertController,
    ) {

        // Retorna do Banco as Permissões do Usuário Logado, para acesso aos módulos
        this.auth.getUsuarioPermissoes(this.user.usuario).then(
            (result) => {
                let userPermissoes = result.permissoes[0];
                console.log('Permissões: ', userPermissoes);
                sessionStorage.setItem('dados-login', JSON.stringify({ usuario: this.user.usuario, permissoes: userPermissoes }));

                //Usuario
                this.accessConfig.usuario.usuario = userPermissoes.usuario;
                this.accessConfig.usuario.usuarioBiId = userPermissoes.usuario_bi_id;

                //Permissoes_usuario
                userPermissoes.permissoes_usuario.forEach(element => {
                    let obj: Permissao = new Permissao();
                    obj.ativo = element.ativo;
                    obj.codNivelOrganizacional = element.cod_nivel_organizacional;
                    obj.ordem = element.ordem;
                    obj.organizacional = element.organizacional;
                    obj.organizacionalId = element.organizacional_id;
                    obj.organizacionalIdCorp = element.organizacional_id_corp;
                    obj.organizacionalIdPai = element.organizacional_id_pai;
                    obj.tipoOrganizacional = element.tipo_organizacional;
                    obj.tipoOrganizacionalId = element.tipo_organizacional_id;
                    obj.usuario = this.accessConfig.usuario;
                    this.accessConfig.permissoes.push(obj);
                });

                //Config_org_usuario
                userPermissoes.config_org_usuario.forEach(element => {
                    let obj: ConfigOrgUsuario = new ConfigOrgUsuario();
                    obj.configOrg = element.configuracao_organizacional;
                    obj.configOrgId = element.configuracao_org_id;
                    obj.moduloId = element.modulo_id;
                    obj.modulo = element.modulo;
                    obj.numModulo = element.num_modulo;
                    obj.listConfigOrg = element.config_organizacional;
                    obj.niveis = this.toNiveis(element.niveis);
                    this.accessConfig.configOrgUsuario.push(obj);
                });
                this.accessConfig.save();
            }
        );

    }

    ionViewDidLoad() { }

    /**
    * Modela o resultado de Niveis para o AccessConfig
    * @param list :: Niveis 
    */

    public toNiveis(list) {
        if (!Array.isArray(list)) {
            return new Array<Nivel>();
        }
        list.forEach(
            (item) => {
                this.accessConfig.niveis.usuario = this.accessConfig.usuario;
                this.accessConfig.niveis.codNivelOrganizacional = item.cod_nivel_organizacional;
                this.accessConfig.niveis.nivel = item.nivel;
                this.accessConfig.niveis.organizacional = item.organizacional;
                this.accessConfig.niveis.organizacionalId = item.organizacionalId;
                this.accessConfig.niveis.tipoOrganizacionalId = item.tipoOrganizacionalId;
            }
        );
        return list
    }

    /**
    * Permite Navegação entre Páginas
    * @param {Array} dados :: Contem todos os Dados Sobre o Módulo a ser acessado
    */

    public navigate(dadosModulo: any) {
        switch (dadosModulo.modulo.toLowerCase()) {
            case 'faturamento':
                this.navCtrl.push(FaturamentoPage, {
                    permissoesUserModulo: dadosModulo
                });
                break;
            case 'indicador logístico':
                this.navCtrl.push(LogisticoPage, {
                    permissoesUserModulo: dadosModulo
                });
                break;
            case 'acompanhamento logístico':
                this.navCtrl.push(AcompanhamentoLogisticoPage, {
                    permissoesUserModulo: dadosModulo
                });
                break;
            case 'monitoramento':
                this.navCtrl.push(MonitoramentoPage, {
                    permissoesUserModulo: dadosModulo
                });
                break;
            case 'dre':
                this.navCtrl.push(DrePage, {
                    permissoesUserModulo: dadosModulo
                });
                break;
        }
    }


    //Confirmação do Logout
    public logout() {
        let confirm = this.alertCtrl.create({
            title: 'Sair',
            message: 'Deseja realmente sair?',
            buttons: [
                {
                    text: 'Não'
                },
                {
                    text: 'Sim',
                    handler: () => {
                        this.user.logout();
                        this.accessConfig.logout();
                        this.navCtrl.setRoot(LoginPage);
                    }
                }
            ]
        });
        confirm.present(confirm);
    }

}
