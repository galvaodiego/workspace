import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DreFilterPage } from './dre-filter';

@NgModule({
  declarations: [
    DreFilterPage,
  ],
  imports: [
    IonicPageModule.forChild(DreFilterPage),
  ],
})
export class DreFilterPageModule {}
