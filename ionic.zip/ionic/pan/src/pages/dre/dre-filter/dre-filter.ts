import { Component } from '@angular/core';
import { Events, IonicPage, NavController, NavParams } from 'ionic-angular';

import { DreProvider } from '../../../providers/dre.provider';

import * as moment from 'moment';
import 'moment/locale/pt-br';

@IonicPage()
@Component({
    selector: 'page-dre-filter',
    templateUrl: 'dre-filter.html',
})
export class DreFilterPage {

    public dataExibicao: string = '';
    public novaData: string = '';
    public dataDia: string = '';
    public dataMes: string = '';
    public dataAno: string = '';

    public listaMes: Array<any> = [];
    public ativo: any = {};

    constructor(
        public events: Events,
        public navCtrl: NavController,
        public navParams: NavParams,
        public dreProvider: DreProvider
    ) {
        this.dataExibicao = this.navParams.get('dataInicio');

        this.montaDatas();

        this.ativo = {
            mes: this.dataMes,
            ano: this.dataAno,
            dataInicio: this.novaData,
            numero: this.dataMes
        };

        this.getData();
    }

    ionViewDidLoad() { }


    /**
    *  Resgata as informações de Meses Disponiveis para o Filtro
    */
    public getData() {
        this.dreProvider.getCalendarioDRE().then(
            (result) => {
                this.listaMes = result.calendario_dre
                this.listaMes.forEach(
                    (element) => {
                        element.mes = element.mes.toLowerCase();
                    }
                );
            }
        );
    }

    public setNovaData(i, ano) {
        this.ativo = {
            mes: moment().month(i - 1).format('MMM'),
            ano: ano,
            data: moment().startOf('month').month(i - 1).format('DD/MM/YYYY'),
            dataInicio: ('01/' + moment().month(i - 1).format('MM') + '/' + moment().month(i - 1).format('YYYY')),
            numero: moment().month(i - 1).format('M'),
        };

        if (this.dataExibicao) {
            this.events.publish('date-filter:selected', this.ativo)
            this.navCtrl.pop();
        } else {
            return;
        }
    }



    /**
     * Usa a Data Recebida para Modelar novas strings em formatos diferentes
     */
    public montaDatas() {
        let dados = [];

        if (this.dataExibicao.indexOf('-') > -1) {
            dados = this.dataExibicao.split('-');

            this.dataDia = dados[2].substring(0, 2);
            this.dataMes = dados[1];
            this.dataAno = dados[0];

            this.novaData = this.dataDia + '/' + this.dataMes + '/' + this.dataAno;
        } else {
            dados = this.dataExibicao.split('/');

            this.dataDia = dados[0];
            this.dataMes = dados[1];
            this.dataAno = dados[2];

            this.novaData = this.dataDia + '/' + this.dataMes + '/' + this.dataAno;
        }
    }

}
