import { Component } from '@angular/core';
import { FabContainer, Events, IonicPage, MenuController, NavController, NavParams, AlertController } from 'ionic-angular';

//
import { DreProvider } from '../../providers/dre.provider';
import { AccessConfig } from '../../kmm/access.config';
import { DreFilterPage } from './dre-filter/dre-filter';

//Plugins
import * as moment from 'moment';
import 'moment/locale/pt-br';
import * as _ from 'underscore';

@IonicPage()
@Component({
    selector: 'page-dre',
    templateUrl: 'dre.html',
})
export class DrePage {

    public accessConfig: AccessConfig = AccessConfig.instance;
    public tipo: string;
    public demonstrativoId: number;
    public demonstrativoAno: string;
    public dataExibicao: string;
    public numMes: any;

    public listaItens: Array<any> = [];
    public listaFiltros: Array<any> = [];
    public listaFiltrosDisponiveis: Array<any> = [];
    public listaFiltrosSelecionados: Array<any> = [];
    public periodoFilter: any = [];

    constructor(
        public dreProvider: DreProvider,
        public events: Events,
        public menuCtrl: MenuController,
        public navCtrl: NavController,
        public alertCtrl: AlertController,
        public navParams: NavParams
    ) {
        console.log('orgs', this.accessConfig);

        this.dataExibicao = moment().format();
        this.tipo = 'GERAL';

        // default
        this.demonstrativoId = 5;
        this.demonstrativoAno = moment(this.dataExibicao).format('YYYY');

        this.periodoFilter['mes'] = moment(this.dataExibicao).format('MMM');
        this.periodoFilter['ano'] = moment(this.dataExibicao).format('YYYY');

        console.log('periodoFilter', this.periodoFilter);


        //////////////////////////////////////
        // RECEBE AS MODIFICAÇÕES DO FILTRO //
        /////////////////////////////////////
        this.events.subscribe('filtro:changed', (data) => {
            console.log('filtro:changed', data);

            this.listaFiltrosSelecionados = data.filtros;
            this.filterList(this.listaItens, this.listaFiltrosSelecionados);
        });

        /////////////////////////////////////////////
        // RECEBE AS DATAS SELECIONADAS NO FILTRO //
        ///////////////////////////////////////////
        this.events.subscribe('date-filter:selected', (periodo) => {
            console.log('periodo: ', periodo);
            this.periodoFilter = periodo;

            console.log('evento', this.periodoFilter);

            //Refaz a Chamada
            this.getData(
                this.demonstrativoId,
                this.demonstrativoAno,
                this.accessConfig.usuario.usuarioBiId,
                this.accessConfig.permissoes[0].organizacional,
                this.accessConfig.permissoes[0].tipoOrganizacional,
                this.accessConfig.configOrgUsuario[0].configOrgId,
                periodo.dataInicio,
                this.accessConfig.permissoes[0].organizacionalId,
            );
        });

    }

    ionViewDidLoad() {
        console.log('DreCompletoPage');
        this.getDemonstrativo();
        this.menuCtrl.enable(true, 'menu-dre');
    }

    ionViewWillUnload() {
        this.events.unsubscribe('filtro:changed');
        this.events.unsubscribe('date-filter:selected');
        this.menuCtrl.enable(false, 'menu-dre');
        this.menuCtrl.enable(false, 'menu-dre-date');
    }

    public recarregar() {
        this.periodoFilter['mes'] = moment(this.dataExibicao).format('MMM');
        this.periodoFilter['ano'] = moment(this.dataExibicao).format('YYYY');
        this.getDemonstrativo();
    }

    public getDemonstrativo() {
        this.dreProvider.getDemonstrativo().then(
            (result) => {
                this.agrupaPorAno(result.layout);
            }
        ).catch(
            (erro) => {
                console.log(erro);
            }
        );
    }

    public agrupaPorAno(layouts: Array<any>) {
        let layoutsPorAno = [];
        layouts.forEach((i) => {
            let diferente = true;
            layoutsPorAno.forEach((j) => {
                if(i.ano == j.ano) {
                    diferente = false;
                }
            });
            if(diferente) {
                layoutsPorAno.push({ano: i.ano});
            }
        });
        layoutsPorAno.forEach((i) => {
            i.layouts = [];
            layouts.forEach((j) => {
                if(i.ano == j.ano) {
                    i.layouts.push(j);
                }
            });
        });
        this.mostraAlertaAno(layoutsPorAno);
    }

    public mostraAlertaAno(layoutsPorAno) {
        let alert = this.alertCtrl.create({
            enableBackdropDismiss: false
        });
        alert.setTitle('Selecione o demonstrativo:');

        layoutsPorAno.forEach((layout, index) => {
            alert.addInput({
                type: 'radio',
                label: layout.ano,
                value: layout.layouts,
                checked: index == 0 ? true : false
            });
        });

        alert.addButton({
            text: 'Cancelar',
            handler: () => {
                if(this.listaItens.length == 0) {
                    this.navCtrl.pop();
                }
            }
        });
        alert.addButton({
            text: 'Confirmar',
            handler: data => {
                this.mostraAlertaId(data);
            }
        });
        alert.present();
    }

    public mostraAlertaId(layout) {
        let alert = this.alertCtrl.create({
            enableBackdropDismiss: false
        });
        alert.setTitle('Selecione o demonstrativo:');

        layout.forEach((layout_id, index) => {
            alert.addInput({
                type: 'radio',
                label: layout_id.demonstrativo_id + '. ' + layout_id.descricao,
                value: layout_id,
                checked: index == 0 ? true : false
            });
        });

        alert.addButton({
            text: 'Cancelar',
            handler: data => {
                if(this.listaItens.length == 0) {
                    this.navCtrl.pop();
                }
            }
        });
        alert.addButton({
            text: 'Confirmar',
            handler: data => {
                this.demonstrativoId = data.demonstrativo_id;
                this.demonstrativoAno = data.ano;

                this.getData(
                    data.demonstrativo_id,
                    data.ano,
                    this.accessConfig.usuario.usuarioBiId,
                    this.accessConfig.permissoes[0].organizacional,
                    this.accessConfig.permissoes[0].tipoOrganizacional,
                    this.accessConfig.configOrgUsuario[0].configOrgId,
                    moment(this.dataExibicao).format('DD/MM/YYYY'),
                    this.accessConfig.permissoes[0].organizacionalId,
                );
            }
        });
        alert.present();
    }


	/**
 	*  Resgata as informações 
	*/
    public getData(
        demonstrativoId: number,
        anoPlano: string,
        usuarioBiId: number,
        organizacional: string,
        codNivelOrganizacional: string,
        confOrgId: number,
        dataExibicao: string,
        organizacionalId: number,
    ) {
        this.dreProvider.getDre(
            demonstrativoId,
            anoPlano,
            usuarioBiId,
            organizacional,
            codNivelOrganizacional,
            confOrgId,
            dataExibicao,
            organizacionalId
        ).then(
            (result) => {
                this.listaItens = [];
                this.listaFiltros = [];
                this.listaFiltrosDisponiveis = [];
                this.listaFiltrosSelecionados = [];

                this.listaItens = result.layout;
                console.log(this.listaItens);
                this.listaItens = this.listaItens.sort((a, b) => (+a.ordem > +b.ordem) ? 1 : -1);
                console.log(this.listaItens);  

                this.normalizeArrayItems(this.listaItens);
                this.getFilterList(this.listaItens);
                this.processaListaFiltros(this.listaFiltrosDisponiveis);
                this.filterList(this.listaItens, this.listaFiltrosSelecionados);
            }
        );
    }

	/**
	* Processa os itens para que todos contenham valor
	* @param lista Array com o Conteudo
	*/
    public normalizeArrayItems(lista: Array<any>) {
        lista.forEach(
            (element) => {
                if (this.hasChild(element)) {
                    if (typeof (element.valor) === 'undefined') {
                        element.valor = 0;
                    }
                    //passa o caminho do item(layout)
                    this.normalizeArrayItems(element.layout)
                }
                else {
                    return;
                }
            }
        );

    }

	/**
    * Retorna a soma dos valores para determinado atributo
    * @param atributo
    */
    public sum(lista: Array<any>) {
        lista.forEach(element => {
            if (this.hasChild(element)) {
                this.sum(element.layout);
                element.valor = element.layout.map(
                    (vlrs) => {
                        return vlrs['valor'];
                    }
                ).reduce((anterior, atual) => {
                    return (anterior + atual);
                }, 0);
            } else {
                return;
            }
        });
    }

	/**
    * verifica se item contém array
    * @param item
    */
    public hasChild(item: any) {
        if (typeof (item.layout) != 'undefined') {
            return true;
        }
        return false;
    }


    public getFilterList(lista: Array<any>) {
        lista.forEach(
            (element) => {
                if (this.hasChild(element)) {
                    this.getFilterList(element.layout);
                } else {
                    if (element.org) {
                        let organizacionalDetalhado: string = element.org;
                        this.listaFiltrosDisponiveis.push(organizacionalDetalhado.split('???'));
                    }
                    return;
                }
            }
        );
    }

    public processaListaFiltros(filtros: Array<any>) {
        _.unzip(filtros).forEach(element => {
            this.listaFiltros.push(_.uniq(element).sort());
        });
    }

    public setMenuFilterData() {
        let listaFiltrosPorTipoOrganizacional: Array<any> = [];
        switch (this.accessConfig.permissoes[0].tipoOrganizacional.toLowerCase()) {
            case 'transpanorama':
                listaFiltrosPorTipoOrganizacional = this.listaFiltros;
                break;
            case 'diretoria':
                listaFiltrosPorTipoOrganizacional.push(this.listaFiltros[1]);
                listaFiltrosPorTipoOrganizacional.push(this.listaFiltros[2]);
                break;
            case 'centro':
                listaFiltrosPorTipoOrganizacional.push(this.listaFiltros[1]);
                listaFiltrosPorTipoOrganizacional.push(this.listaFiltros[2]);
                break;
            case 'segmento':
                listaFiltrosPorTipoOrganizacional.push(this.listaFiltros[2]);
                break;
            default:
        }
        this.events.publish('listaFiltros:show', {
            listaFiltros: listaFiltrosPorTipoOrganizacional
        });
    }

    public filterList(lista: Array<any>, filtro?: Array<any>) {
        let diretorias: Array<any> = filtro[0] ? filtro[0] : [];
        let segmentos: Array<any> = filtro[1] ? filtro[1] : [];
        let centros: Array<any> = filtro[2] ? filtro[2] : [];
        let grupos: Array<any> = filtro[3] ? filtro[3] : [];

        lista.forEach(element => {
            if (this.hasChild(element)) {
                this.filterList(element.layout, filtro);
                element.valor = element.layout
                    .filter(
                        (it) => ((diretorias.length > 0 && it['org']) ? diretorias.some(el =>
                            it['org'].toLowerCase().indexOf(el.toLowerCase()) > -1
                        ) : this)
                    )
                    .filter(
                        (it) => ((segmentos.length > 0 && it['org']) ? segmentos.some(el =>
                            it['org'].toLowerCase().indexOf(el.toLowerCase()) > -1
                        ) : this)
                    )
                    .filter(
                        (it) => ((centros.length > 0 && it['org']) ? centros.some(el =>
                            it['org'].toLowerCase().indexOf(el.toLowerCase()) > -1
                        ) : this)
                    )
                    .filter(
                        (it) => ((grupos.length > 0 && it['org']) ? grupos.some(el =>
                            it['org'].toLowerCase().indexOf(el.toLowerCase()) > -1
                        ) : this)
                    )
                    .map(
                        (vlrs) => {
                            return vlrs['valor'];
                        }
                    ).reduce((anterior, atual) => {
                        return (anterior + atual);
                    }, 0);
            } else {
                return;
            }
        });
    }

	/**
	 * Navega para a Pagina de Filtro da Data
	 */
    public navigate(page: string, container?: FabContainer) {
        if (container) {
            container.close();
        }
        switch (page) {
            case 'dre-date-filter':
                console.log('navigate dataExibicao', this.dataExibicao);
                this.navCtrl.push(DreFilterPage, {
                    dataInicio: this.dataExibicao
                });
                break;
            default:
        }
    }

}
