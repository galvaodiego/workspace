import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';

import { DrePage } from './dre';
import { DreFilterPageModule } from './dre-filter/dre-filter.module';

import { ComponentsModule } from '../../components/components.module';
import { DirectivesModule } from './../../directives/directives.module';
import { DreProvider } from './../../providers/dre.provider';

@NgModule({
    declarations: [
        DrePage,
    ],
    imports: [
        IonicPageModule.forChild(DrePage),
        ComponentsModule,
        DirectivesModule,
        DreFilterPageModule
    ],
    providers: [
        DreProvider
    ]
})
export class DrePageModule { }
