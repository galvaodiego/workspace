import {Component} from '@angular/core';
import {NavController} from 'ionic-angular';

@Component({
   templateUrl: 'splash.html',
})
export class SplashPage {
   constructor(public nav: NavController) {
   }
}
