import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FaturamentoPage } from './faturamento';
import { FaturamentoProvider } from './../../providers/faturamento.provider';
import { DxTreeListModule } from 'devextreme-angular';


@NgModule({
  declarations: [
    FaturamentoPage,
  ],
  imports: [
    IonicPageModule.forChild(FaturamentoPage),
    DxTreeListModule
  ],
  providers: [FaturamentoProvider]
})
export class FaturamentoPageModule { }
