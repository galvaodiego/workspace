import { NgModule, ErrorHandler } from '@angular/core';
import { IonicPageModule, IonicErrorHandler } from 'ionic-angular';
import { MonitoramentoModalDetalhesPage } from './monitoramento-modal-detalhes';
import { ComponentsModule } from '../../../components/components.module';
import { Screenshot } from '@ionic-native/screenshot';
import { SocialSharing } from '@ionic-native/social-sharing';
import { MonitoramentoModalCtesPage } from '../monitoramento-modal-ctes/monitoramento-modal-ctes';
import { MonitoramentoModalCtesPageModule } from '../monitoramento-modal-ctes/monitoramento-modal-ctes.module';


@NgModule({
    declarations: [
        MonitoramentoModalDetalhesPage,
    ],
    imports: [
        IonicPageModule.forChild(MonitoramentoModalDetalhesPage),
        ComponentsModule,
        MonitoramentoModalCtesPageModule
    ],
    providers: [
        Screenshot,
        SocialSharing,
        { provide: ErrorHandler, useClass: IonicErrorHandler }
    ],
    entryComponents:[
      MonitoramentoModalCtesPage
    ]
})
export class MonitoramentoModalDetalhesPageModule { }
