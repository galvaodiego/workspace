import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { MonitoramentoPopoverFiltrosPage } from './monitoramento-popover-filtros';

@NgModule({
  declarations: [
    MonitoramentoPopoverFiltrosPage,
  ],
  imports: [
    IonicPageModule.forChild(MonitoramentoPopoverFiltrosPage),
  ],
})
export class MonitoramentoPopoverFiltrosPageModule {}
