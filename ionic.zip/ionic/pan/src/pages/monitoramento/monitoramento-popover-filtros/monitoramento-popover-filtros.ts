import { Component } from '@angular/core';
import { Events, IonicPage, NavController, NavParams, ViewController } from 'ionic-angular';
import { MonitoramentoService } from '../monitoramento.service';

@IonicPage()
@Component({
    selector: 'page-monitoramento-popover-filtros',
    templateUrl: 'monitoramento-popover-filtros.html',
})
export class MonitoramentoPopoverFiltrosPage {

    //Lista de Arrays
    public filtros: Array<any> = [];

    constructor(
        public navCtrl: NavController,
        public params: NavParams,
        public viewCtrl: ViewController,
        public events: Events,
        public monitService: MonitoramentoService
    ) {
        if (this.params.get('listaFiltros') != undefined) {
            this.filtros = this.params.get('listaFiltros');
        } else {
            this.filtros = [];
        }
    }

    ionViewDidLoad() {
    }

    /**
    * Recarrega todos os Markers Novamente
    */
    public reloadAll() {
        this.monitService.initMap(this.monitService.mirrorMarcadores);
        this.filtros.forEach(
            (el) => {
                el.forEach(
                    (it) => {
                        it.checked = false;
                    }
                );
            }
        )
        this.events.publish('listaFiltros:changed', {
            listaFiltros: this.filtros
        });
        this.viewCtrl.dismiss();
    }

    /**
	 * Altera o estado do toggle.
	 * @param item
	 */
    public handleFilter(item: any) {
        item.checked = !item.checked;
        this.events.publish('listaFiltros:changed', {
            listaFiltros: this.filtros
        });
        this.viewCtrl.dismiss();
    }

}
