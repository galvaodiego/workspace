import { Component, ViewChild } from '@angular/core';
import { AlertController, Events, IonicPage, Keyboard, ModalController, NavController, NavParams, Platform, PopoverController } from 'ionic-angular';

import { DxMapComponent } from 'devextreme-angular';
import { Geolocation } from '@ionic-native/geolocation';
import { LoadingController, Loading } from 'ionic-angular';
import { MonitoramentoService } from './monitoramento.service';
import { MonitoramentoModalFiltrosPage } from './monitoramento-modal-filtros/monitoramento-modal-filtros';
import { MonitoramentoPopoverFiltrosPage } from './../monitoramento/monitoramento-popover-filtros/monitoramento-popover-filtros';
import io from 'socket.io-client';

@IonicPage()
@Component({
    selector: 'page-monitoramento',
    templateUrl: 'monitoramento.html'
})
export class MonitoramentoPage {

    //////////////////////////////
    //    VARIAVEIS DO MAPA
    /////////////////////////////

    //Zoom do Mapa
    public isCenter: any
    //Distancia do Mapa
    public isZoom: any

    @ViewChild(DxMapComponent) map: DxMapComponent;

    //////////////////////////////
    //    MINHAS VARIAVEIS
    /////////////////////////////

    //Permissoes do usuário no Módulo
    public infoModulo: any;

    //Campo de Busca
    public isSearchShow: boolean = false;
    public searchField: string = '';
    // Config Socket
    socket_io: any;
    socket_rota = 'monitoramento';
    socket_metodo = 'getMonitoramento';
    socket_filtro: any;
    /***/
    public loading: Loading;
    constructor(
        public alertCtrl: AlertController,
        public events: Events,
        public geo: Geolocation,
        public keyboard: Keyboard,
        public modalCtrl: ModalController,
        public monitService: MonitoramentoService,
        public navCtrl: NavController,
        public navParams: NavParams,
        public platform: Platform,
        public popoverCtrl: PopoverController,
        public loadingCtrl: LoadingController

    ) {
        this.infoModulo = this.navParams.get('permissoesUserModulo');

        this.socket_io = io('https://dash-backend.kmm.com.br/' + this.socket_rota);
        const dadosSessao = JSON.parse(sessionStorage.getItem('dados-login'));
        this.socket_filtro = {
            base: 'panorama',
            // usuario: this.monitProvider.user.usuario
            usuario: dadosSessao.usuario
        };
    }

    public createLoader(message: string = "Carregando...") { // Optional Parameter
        this.loading = this.loadingCtrl.create({
            content: message
        });
    }

    ngOnDestroy() {
        this.socket_io.disconnect();
    }

    ionViewDidLoad() {
        this.getMonitoramento();
    }

    refresh(){
        this.getMonitoramento();
    }

    public getMonitoramento() {

        const alertNotFound = this.alertCtrl.create({
            title: 'Atenção!',
            message: 'Nenhum Registro foi encontrado, tente novamente mais tarde.',
            buttons: ['OK']
        });

        this.createLoader();
        this.loading.present().then(() => {
            this.socket_io.emit(this.socket_metodo, this.socket_filtro);
            this.socket_io.on(this.socket_rota, (result) => {
                console.log('socket parametros', this.socket_filtro, 'data', (result));
                if (result.location.length > 0) {
                    //Zera os Arrays de Filtros 
                    this.monitService.filtros = [];
                    this.monitService.status = [];
                    this.monitService.operacoes = [];
                    this.monitService.remetentes = [];
                    this.monitService.atrasado = [];

                    //Cópia dos Marcadores Originais
                    this.monitService.mirrorMarcadores = result.location;
                    this.monitService.mirrorMarcadoresNotFis = this.monitService.splitNotFis(result.location);

                    //Prepara o Array conforme Google Maps
                    this.monitService.initMap(result.location);

                    //Cria os Filtros
                    this.monitService.setAvailableFilters();

                    //Tranforma o Array de Filtro em Objeto
                    this.monitService.castToFilterItem();
                } else {
                    //Zera os Arrays de Filtros 
                    this.monitService.filtros = [];
                    this.monitService.status = [];
                    this.monitService.operacoes = [];
                    this.monitService.remetentes = [];
                    this.monitService.atrasado = [];
                    this.monitService.mirrorMarcadores = []
                    this.monitService.mirrorMarcadoresNotFis = [];
                    this.monitService.initMap([]);
                    this.monitService.setAvailableFilters();
                    this.monitService.castToFilterItem();
                    alertNotFound.present();
                }

                this.loading.dismiss();
            });
        });
    };

    public backPage() {
        this.navCtrl.pop();
    }

    /**
    * Chama o Modal de Filtros
    */
    public abreModalFiltros() {
        let modal = this.modalCtrl.create(MonitoramentoModalFiltrosPage, { listaFiltros: this.monitService.filtros });
        modal.present();
    }

    /**
    * Abre o PopOver de Status
    * @param evento 
    */
    public abrePopover() {
        let popover = this.popoverCtrl.create(MonitoramentoPopoverFiltrosPage, { listaFiltros: this.monitService.filtros });
        popover.present();
    }

    /**
    * Aplica o Zoom no Mapa
    * @param lat latitude
    * @param lng longitude
    */
    public zoomMapa(lat, lng) {
        this.isCenter = [lat, lng];
        this.isZoom = 16;
        this.map.instance.option("center", this.isCenter);
        this.map.instance.option("zoom", this.isZoom);

    }


    /************************************** 
    *  BUSCA DO VEICULO POR PLACA 
    ***************************************/
    /**
    * Mostra/Oculta o Campo de Busca
    */
    public showSearch() {
        this.searchField = '';
        this.isSearchShow = true;
    }

    public hideSearch() {
        this.searchField = '';
        this.isSearchShow = false;
    }



    /**
    * Realiza a Busca
    * Localiza o veículo por placa e por frota 
    */

    public realizaBusca(veiculo: any) {
        console.log(veiculo);

        this.hideSearch();
        let marcadoresBusca = [];
        marcadoresBusca.push(veiculo)
        this.monitService.initMap(marcadoresBusca);
        this.zoomMapa(veiculo.lat, veiculo.lng);
    }

    ///////////////////////////////////////////
    //             GEOLOCALIZAÇÃO            //
    ///////////////////////////////////////////

    /**
    * Pergunta ao Usuário sobre a Geolocalização
    */
    public showQuestionGeolocalizacao() {
        let alert = this.alertCtrl.create({
            title: 'Geolocalização',
            message: 'Deseja ver quais veículos estão ao seu redor?',
            buttons: [
                {
                    text: 'Não',
                    role: 'cancel',
                    handler: () => {
                        console.log('cancelado');
                    }
                },
                {
                    text: 'Sim',
                    handler: () => {
                        this.getGeolocalizacao();
                    }
                }
            ]
        });
        alert.present();
    }


    /**
    * Resgata a localização do Usuário
    */
    public getGeolocalizacao() {
        this.platform.ready().then(() => {
            this.geo.getCurrentPosition().then(res => {
                this.zoomMapa(res.coords.latitude, res.coords.longitude)
            }).catch(() => {
                this.monitService.showToast('Erro ao Resgatar sua Localização')
            })
        })
    }

}
