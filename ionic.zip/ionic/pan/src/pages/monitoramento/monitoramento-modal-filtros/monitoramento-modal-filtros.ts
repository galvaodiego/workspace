import { Component } from '@angular/core';
import { IonicPage, NavParams, ViewController, Events } from 'ionic-angular';
import { MonitoramentoService } from './../monitoramento.service';

@IonicPage()
@Component({
    selector: 'page-monitoramento-modal-filtros',
    templateUrl: 'monitoramento-modal-filtros.html',
})
export class MonitoramentoModalFiltrosPage {

    //Lista de Arrays
    public filtros: Array<any> = [];

    constructor(
        public params: NavParams,
        public viewCtrl: ViewController,
        public events: Events,
        public monitService: MonitoramentoService
    ) {
        if (this.params.get('listaFiltros') != undefined) {
            this.filtros = this.params.get('listaFiltros');
            console.log('Meus Filtros ', this.filtros);
        } else {
            this.filtros = [];
        }
    }

    ionViewDidLoad() {
    }
    /**
    *  ATRASO 
    *  EM TEMPO, POSSIBILIDADE DE ATRASO, ATRASADO
    */
    public setIconAtraso(item: any) {
        let path: string = '';
        switch (item.item) {
            case "0":
                path = 'assets/icon/atrasado.png';
                break;
            case "1":
                path = 'assets/icon/ok.png';
                break;
            case "2":
                path = 'assets/icon/possibilidade-atraso.png';
                break;
            case "3":
                path = 'assets/icon/configuracao.png';
                break;
            default: path = 'assets/icon/configuracao.png';
        }
        return path
    }

    public setTextAtraso(item: any) {
        let text: string = '';
        switch (item.item) {
            case "0":
                text = 'Atrasado';
                break;
            case "1":
                text = 'Em Tempo';
                break;
            case "2":
                text = 'Possib. de Atraso';
                break;
            case "3":
                text = 'Sem Status';
                break;
            default: text = '';
        }
        return text
    }


    /**
     * 
     * @param item Array de Operação
     */
    public setTextIniciais(item: any) {
        let temp = [];
        let string = '';
        temp = item.item.split(" ");

        if (temp[1]) {
            temp[0] = temp[0].substring(0, 1);
            temp[1] = temp[1].substring(0, 1);
            string = temp[0] + temp[1]
        } else {
            temp[0] = temp[0].substring(0, 2);
            string = temp[0];
        }
        return string
    }


	/**
	 * Altera o estado do toggle.
	 * @param item
	 */
    public handleFilter(item: any) {
        item.checked = !item.checked;
        this.events.publish('listaFiltros:changed', {
            listaFiltros: this.filtros
        });
    }

    /**
    * Limpa os Filtros
    *  - Mata os Eventos 
    */
    public limpaFiltros() {
        this.monitService.initMap(this.monitService.mirrorMarcadores);
        this.filtros.forEach(
            (el) => {
                el.forEach(
                    (it) => {
                        it.checked = false;
                    }
                );
            }
        )
        this.events.publish('listaFiltros:changed', {
            listaFiltros: this.filtros
        });
        this.monitService.showToast('Filtros Zerados!');
        this.fechaModal();
    }

    /**
    * Fecha o Modal 
    */
    public fechaModal() {
        this.viewCtrl.dismiss();
    }



}
