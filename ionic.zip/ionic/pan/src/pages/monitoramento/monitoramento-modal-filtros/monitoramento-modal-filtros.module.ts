import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { MonitoramentoModalFiltrosPage } from './monitoramento-modal-filtros';

@NgModule({
  declarations: [
    MonitoramentoModalFiltrosPage,
  ],
  imports: [
    IonicPageModule.forChild(MonitoramentoModalFiltrosPage),
  ],
})
export class MonitoramentoModalFiltrosPageModule {}
