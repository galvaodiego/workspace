import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';

import { DxMapModule } from 'devextreme-angular';
import { MonitoramentoPage } from './monitoramento';
import { ComponentsModule } from '../../components/components.module';
import { PipesModule } from '../../pipes/pipes.module';

import { MonitoramentoProvider } from '../../providers/monitoramento.provider';
import { MonitoramentoService } from './monitoramento.service';

@NgModule({
    declarations: [
        MonitoramentoPage
    ],
    imports: [
        IonicPageModule.forChild(MonitoramentoPage),
        DxMapModule,
        ComponentsModule,
        PipesModule
    ],
    exports: [

    ],
    providers: [
        MonitoramentoProvider,
        MonitoramentoService
    ]
})
export class MonitoramentoPageModule { }
