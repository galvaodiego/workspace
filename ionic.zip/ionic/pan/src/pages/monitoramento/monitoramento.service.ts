import { Injectable } from '@angular/core';
import { Events, ToastController } from 'ionic-angular';

import { MonitoramentoProvider } from '../../providers/monitoramento.provider';
import * as _ from 'underscore';




@Injectable()
export class MonitoramentoService {

   //////////////////////////////
   //    VARIAVEIS DO MAPA
   /////////////////////////////
   //Markers Personalizados do Mapa
   public marcadores: Array<any> = [];
   //Markers Personalizados do Mapa - ESPELHO PARA A BUSCA
   public mirrorMarcadores: Array<any> = [];
   public mirrorMarcadoresNotFis: Array<any> = [];
   //Chave de Acesso
   public apiKey: string;

   //////////////////////////////
   //    MINHAS VARIAVEIS
   /////////////////////////////

   //FILTROS
   public filtros: Array<any> = [];
   public status: Array<any> = [];
   public operacoes: Array<any> = [];
   public remetentes: Array<any> = [];
   public atrasado: Array<any> = [];


   
   public hasLoading: boolean;

   constructor(
      public events: Events,
      public monitProvider: MonitoramentoProvider,
      public toastCtrl: ToastController     
   ) {
      //Api do Mapa
      this.apiKey = "AIzaSyD3-YFwQBzXxbEn9zfn51dGXp-w2k9w7WI";

      this.events.subscribe('listaFiltros:changed', (data) => {
         this.filtros = data.listaFiltros;
         this.setFilterString();
      });
   }

   public splitNotFis(items: any): Array<any> {
      let notas = [];

      items.forEach(it => {
         if (it.num_notas == undefined) return;
         if (it.num_notas.includes(',')) {
            it.num_notas.split(',').forEach(num_nota => {
               notas.push({ veiculo: it, num_nota });
            });
         }
         else {
            notas.push({ veiculo: it, num_nota: it.num_notas });
         }
      });
      return notas;
   }

   /**
   * Inicializa o Mapa Atribuindo valor ao @var this.marcadores
   * @param obj array para ser preparado
   */
   public initMap(obj) {
      //Zera o Array para receber os dados
      this.marcadores = [];

      //Se o length for 1 significa que veio da BUSCA
      if (obj.length === 1) {
         this.marcadores.push({
            location: [obj[0].lat, obj[0].lng],
            data: obj[0],
            path: obj[0].status.toLowerCase() + '???' + obj[0].operacao.toLowerCase() + '???' + obj[0].remetente + '???' + obj[0].atrasado,
            iconSrc: "assets/icon/map-markers/" + obj[0].status.toLowerCase() + ".png",
            onClick: (args) => {
               this.events.publish("show-veiculo-detalhe", {
                  veiculo: obj[0]
               });
            }
         });
      } else {
         obj.forEach(
            (el) => {
               this.marcadores.push({
                  location: [el.lat, el.lng],
                  data: el,
                  path: el.status.toLowerCase() + '???' + el.operacao.toLowerCase() + '???' + el.remetente + '???' + el.atrasado,
                  iconSrc: "assets/icon/map-markers/" + el.status.toLowerCase() + ".png",
                  onClick: (args) => {
                     this.events.publish("show-veiculo-detalhe", {
                        veiculo: el
                     });
                  }
               });
            }
         );
      }
   }

   /**
   * Cria um array com todos os itens que podem ser usados como filtro.
   */
   public setAvailableFilters() {
      let aux: Array<any> = [];
      //itera sobre todos os itens do array de nivel mais baixo;
      this.marcadores.forEach(
         (el) => {
            aux.push(el.path.split('???').filter(el => el.length > 0));
         }
      );
      //Separa todos os itens de mesmo nivel e remove os repetidos
      _.unzip(aux).forEach(element => {
         this.filtros.push(_.uniq(element).sort());
      });
   }

   /**
    * Transforma itens da lista de filtros em objetos.
    */
   public castToFilterItem() {
      this.filtros.forEach(
         (tipoFiltro) => {
            tipoFiltro.forEach(
               (filtro, index, oArray) => {
                  let aux = Object.assign({
                     item: filtro,
                     checked: false
                  });
                  oArray[index] = aux;
               }
            );
         }
      );
   }

   /**
   * Define o novo Array a ser utilizado na soma dos atributos;
   */
   public setFilterString() {

      //Prepara Novamente o Array antes de Filtrar
      this.initMap(this.mirrorMarcadores);

      let temp = [];
      this.status = this.filtros[0] ? this.filtros[0].filter(el => el.checked == true) : [];
      this.operacoes = this.filtros[1] ? this.filtros[1].filter(el => el.checked == true) : [];
      this.remetentes = this.filtros[2] ? this.filtros[2].filter(el => el.checked == true) : [];
      this.atrasado = this.filtros[3] ? this.filtros[3].filter(el => el.checked == true) : [];

      temp = this.marcadores
         .filter(
            (it) => ((this.status.length > 0) ? this.status.some(el => it.data.status.toLowerCase() == el.item.toLowerCase()) : this)
         )
         .filter(
            (it) => ((this.operacoes.length > 0) ? this.operacoes.some(el => it.data.operacao.toLowerCase() == el.item.toLowerCase()) : this)
         )
         .filter(
            (it) => ((this.remetentes.length > 0) ? this.remetentes.some(el => it.data.remetente.toLowerCase() == el.item.toLowerCase()) : this)
         )
         .filter(
            (it) => ((this.atrasado.length > 0) ? this.atrasado.some(el => it.data.atrasado == el.item) : this)
         );

      this.marcadores = [];
      temp.forEach(
         (el) => {
            this.marcadores.push(el);
         }
      )
   }

   /**
   * Exibe mensagem no toast
   * @param message 
   * @param duration 
   */
   public showToast(message: string, duration?: number) {
      let toast = this.toastCtrl.create({
         message: message,
         duration: duration ? duration : 3000,
         showCloseButton: true,
         closeButtonText: 'OK'
      });
      toast.present();
   }
}
