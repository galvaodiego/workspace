import { Component, ViewChild } from '@angular/core';
import { IonicPage, NavController, NavParams, Platform, ViewController, Events, ModalController } from 'ionic-angular';
import { MonitoramentoProvider } from '../../../providers/monitoramento.provider';
import { DxMapComponent } from 'devextreme-angular';

@IonicPage()
@Component({
    selector: 'page-monitoramento-modal-rota',
    templateUrl: 'monitoramento-modal-rota.html',
    providers: []
})
export class MonitoramentoModalRotaPage {

    //////////////////////////////
    //    VARIAVEIS DO MAPA
    /////////////////////////////

    @ViewChild(DxMapComponent) map: DxMapComponent;

    //Icone do Marker
    public mapMarkerUrl: string;
    //Icone Personalizado do Marker do Mapa
    public customMarkerUrl: string;
    //Rota Definida
    public rota: any = [];
    //Markers Personalizados do Mapa
    public marcadores: any = [];
    //Chave de Acesso 	
    public apiKey: string;
    //Estilo do Mapa
    public mapTypes: Array<any>;
    //Provedor do Mapa
    public mapProviders: Array<any>;


    //////////////////////////////
    //    MINHAS VARIAVEIS
    /////////////////////////////
    public loading: any
    public dadosVeicDetalhes: any;

    constructor(
        public platform: Platform,
        public params: NavParams,
        public viewCtrl: ViewController,
        public events: Events,
        public navCtrl: NavController,
        public navParams: NavParams,
        public monitorProvider: MonitoramentoProvider,
        public modalCtrl: ModalController
    ) {
        this.dadosVeicDetalhes = this.params.get('veiculo');

        //Api do Mapa
        this.apiKey = "AIzaSyD3-YFwQBzXxbEn9zfn51dGXp-w2k9w7WI";
    }

    ionViewDidLoad() {
        // Busca os Dados do Mapa
        this.getRotas();
    }



    /**
     * Monta a Rota do Caminhão conforme o veiculo selecionado
     */
    public getRotas() {
        // let status: string = this.dadosVeicDetalhes.status;

        //Array de Marcadores (Pinos)
        this.marcadores = [

            //Transit Time Real
            // {
            //     location: "Centro, Campo Largo - PR",
            //     iconSrc: "assets/icon/map-markers/" + status.toLowerCase() + ".svg"
            // },

            //Origem
            {
                location: this.dadosVeicDetalhes.origem + '/' + this.dadosVeicDetalhes.uf_origem,
                iconSrc: "assets/icon/map-markers/rota-origem.svg"
            },

            //Destino
            {
                location: this.dadosVeicDetalhes.destino + '/' + this.dadosVeicDetalhes.uf_destino,
                iconSrc: "assets/icon/map-markers/rota-destino.svg"
            }
        ];

        /**
        * ROTA REALIZADA PELO VEICULO
        */
        // this.map.instance.addRoute(
        //     {
        //         weight: 6,
        //         color: "blue",
        //         opacity: 0.5,
        //         mode: "",
        //         locations: [
        //             // [40.782500, -73.966111],
        //             this.dadosVeicDetalhes.origem + '/' + this.dadosVeicDetalhes.uf_origem,
        //             this.dadosVeicDetalhes.destino + '/' + this.dadosVeicDetalhes.uf_destino,
        //         ]
        //     }
        // );

        /**
        * ROTA PREVISTA PARA O VEICULO
        */
        this.map.instance.addRoute(
            {
                color: "red",
                opacity: 0.4,
                locations: [
                    this.dadosVeicDetalhes.origem + '/' + this.dadosVeicDetalhes.uf_origem,
                    this.dadosVeicDetalhes.destino + '/' + this.dadosVeicDetalhes.uf_destino,
                ]
            }
        );
    }

	/**
	* Fecha o Modal 
	*/
    public fechaModal() {
        this.viewCtrl.dismiss();
    }

}
