import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { MonitoramentoModalRotaPage } from './monitoramento-modal-rota';
import { DxMapModule } from 'devextreme-angular';
import { ComponentsModule } from '../../../components/components.module';
import { MonitoramentoProvider } from '../../../providers/monitoramento.provider';

@NgModule({
    declarations: [
        MonitoramentoModalRotaPage,
    ],
    imports: [
        IonicPageModule.forChild(MonitoramentoModalRotaPage),
        DxMapModule,
        ComponentsModule
    ],
    providers: [
        MonitoramentoProvider
    ]
})
export class MonitoramentoModalRotaPageModule { }
