import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { MonitoramentoModalCtesPage } from './monitoramento-modal-ctes';
import { DxDataGridModule } from 'devextreme-angular';

@NgModule({
  declarations: [MonitoramentoModalCtesPage],
  imports: [
    IonicPageModule.forChild(MonitoramentoModalCtesPage),
    DxDataGridModule
  ],
  exports: [
   MonitoramentoModalCtesPage
  ]
})
export class MonitoramentoModalCtesPageModule {}
