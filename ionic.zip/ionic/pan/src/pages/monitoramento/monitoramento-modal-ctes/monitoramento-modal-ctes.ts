import { Component } from '@angular/core';
import { IonicPage, NavParams, ViewController, Events } from 'ionic-angular';
import { MonitoramentoService } from './../monitoramento.service';
import { MonitoramentoProvider } from '../../../providers/monitoramento.provider';

@IonicPage()
@Component({
   selector: 'page-monitoramento-modal-ctes',
   templateUrl: 'monitoramento-modal-ctes.html',
})
export class MonitoramentoModalCtesPage {

   datasource: any = [];
   num_romaneio: any;
   constructor(
      public params: NavParams,
      public viewCtrl: ViewController,
      public events: Events,
      public monitService: MonitoramentoService,
      public monitoramentoProvider: MonitoramentoProvider
   ) {
      this.num_romaneio = this.params.get('num_romaneio');
   }

   ionViewDidLoad() {
      this.getData();
   }

   getData(){
      this.monitoramentoProvider.getRomaneioDetalhe(this.num_romaneio).then(result => {
         console.log('chegou', result);
         this.datasource = result.location;
      })
   }

   /**
   * Fecha o Modal 
   */
   public fechaModal() {
      this.viewCtrl.dismiss();
   }



}
