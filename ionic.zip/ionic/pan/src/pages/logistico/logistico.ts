import { Component } from '@angular/core';
import { IonicPage, NavParams } from 'ionic-angular';
import { LogisticoProvider } from './../../providers/logistico.provider';
import io from 'socket.io-client';
import { LoadingController, Loading } from 'ionic-angular';


@IonicPage()
@Component({
   selector: 'page-logistico',
   templateUrl: 'logistico.html',
})
export class LogisticoPage {

   public infoModulo: any

   public previsto: number = 0;
   public atraso: number = 0;
   public totalVeiculos: number = 0;
   public totalStatus: number = 0;
   public percServico: number = 0;

   //Arrays
   public listaStatus: any = [];
   public listaStatusResumo: any = [];
   public listaStatusServico: any = [];
   // Config Socket
   socket_io: any;
   socket_rota = 'indicador_logistico';
   socket_metodo = 'getIndicadorLogistico';
   socket_filtro: any;
   /***/
   public loading: Loading;
   public hasLoading: boolean;
   constructor(
      public navParams: NavParams,
      public logProvider: LogisticoProvider,
      public loadingCtrl: LoadingController
   ) {
      this.infoModulo = this.navParams.get('permissoesUserModulo');
      this.socket_io = io('https://dash-backend.kmm.com.br/' + this.socket_rota);
      this.socket_filtro = {
         base: 'panorama',
      };
   }

   ionViewDidLoad() {
      this.getData();
   }

   ngOnDestroy(): void {
      this.socket_io.disconnect();
   }

   public setLoading(flag: boolean, loadingText?: string): Promise<any> {
      if (flag) {
         this.loading = this.loadingCtrl.create({
            content: loadingText
         });
         this.hasLoading = true;
         return this.loading.present();
      } else {
         if (this.loading != null && this.loading.isOverlay) {
            return this.loading.dismiss();
         } else {
            return Promise.resolve({});
         }
      }
   }

	/**
	* Retorna os dados do Banco
    */
   public getData() {
      this.setLoading(true).then(() => {
         this.socket_io.emit(this.socket_metodo, this.socket_filtro);
         this.socket_io.on(this.socket_rota, (data) => {
            this.setLoading(false).then(() => {
               console.log('socket parametros', this.socket_filtro, 'data', (data));
               this.listaStatusResumo = data.logistico;
               let temp = [];
               data.logistico.forEach(
                  (el) => {
                     if (el.status !== 'Vazio' && el.status !== 'Manutenção') {
                        temp.push(el)
                     }
                  }
               );
               this.listaStatusServico = temp;
               this.sumTotalVeiculos(this.listaStatusResumo) // array completo
               this.sumPrevAtraso(this.listaStatusServico) // array sem o Status VAZIO e MANUTENÇÃO
               this.sumPorcentagemServico(this.listaStatusServico);
            });
         });
      });



      // return this.logProvider.getIndicadorLogistico().then(
      //    (result) => {
      //       console.log('result', result);

      //       this.listaStatusResumo = result.logistico;
      //       let temp = [];
      //       result.logistico.forEach(
      //          (el) => {
      //             if (el.status !== 'Vazio' && el.status !== 'Manutenção') {
      //                temp.push(el)
      //             }
      //          }
      //       );
      //       this.listaStatusServico = temp;

      //       this.sumTotalVeiculos(this.listaStatusResumo) // array completo
      //       this.sumPrevAtraso(this.listaStatusServico) // array sem o Status VAZIO e MANUTENÇÃO
      //       this.sumPorcentagemServico(this.listaStatusServico);
      //    }
      // );
   }


   //////////////////////////////////////////////////////////////////////////
   //                              RESUMO                                  //
   //////////////////////////////////////////////////////////////////////////

   /**
   * Porcentagem de veiculos por status em relação ao Nº total de veiculos
   * @param dados 
   */
   public sumPorcentagem(dados) {
      let temp = [];
      dados.lista.forEach(
         (el) => {
            temp.push(el);
         }
      );
      let tempPrev = temp.map((tupla) => {
         return Number.parseFloat(tupla['previsto'])
      }).reduce((anterior, atual) => {
         return (anterior + atual);
      }, 0);

      let tempAtra = temp.map((tupla) => {
         return Number.parseFloat(tupla['atraso'])
      }).reduce((anterior, atual) => {
         return (anterior + atual);
      }, 0);

      this.totalStatus = tempPrev + tempAtra;
      let sum = this.totalStatus / this.totalVeiculos * 100;
      return parseFloat(sum.toFixed(0))
   }

   /**
   * Soma o total de veiculos
   */
   public sumTotalVeiculos(dados) {
      let temp = [];
      dados.forEach(
         (el) => {
            el.lista.forEach(
               (it) => {
                  temp.push(it);
               }
            );
         }
      );
      this.previsto = temp.map((tupla) => {
         return Number.parseFloat(tupla['previsto'])
      }).reduce((anterior, atual) => {
         return (anterior + atual);
      }, 0);

      this.atraso = temp.map((tupla) => {
         return Number.parseFloat(tupla['atraso'])
      }).reduce((anterior, atual) => {
         return (anterior + atual);
      }, 0);

      this.totalVeiculos = this.previsto + this.atraso;

   }


   //////////////////////////////////////////////////////////////////////////
   //                              SERVIÇO                                 //
   //////////////////////////////////////////////////////////////////////////

   /**
   * Porcentagem de veiculos por status em relação ao Nº total de veiculos
   * @param dados 
   */
   public sumPorcentagemServico(dados) {
      let temp = [];
      dados.forEach(
         (el) => {
            el.lista.forEach(
               (it) => {
                  temp.push(it);
               }
            );
         }
      );

      let tempPrev = temp.map((tupla) => {
         return Number.parseFloat(tupla['previsto'])
      }).reduce((anterior, atual) => {
         return (anterior + atual);
      }, 0);

      // let tempAtra = temp.map((tupla) => {
      //     return Number.parseFloat(tupla['atraso'])
      // }).reduce((anterior, atual) => {
      //     return (anterior + atual);
      // }, 0);

      // let cont = tempPrev + tempAtra;
      let sum = tempPrev / this.totalVeiculos * 100;
      this.percServico = parseFloat(sum.toFixed(0))
   }



   /**
   * Soma os totais por status
   */
   public sumStatus(dados) {
      let temp = [];
      dados.lista.forEach(
         (el) => {
            temp.push(el);
         }
      );
      let tempPrev = temp.map((tupla) => {
         return Number.parseFloat(tupla['previsto'])
      }).reduce((anterior, atual) => {
         return (anterior + atual);
      }, 0);

      let tempAtra = temp.map((tupla) => {
         return Number.parseFloat(tupla['atraso'])
      }).reduce((anterior, atual) => {
         return (anterior + atual);
      }, 0);

      this.totalStatus = tempPrev + tempAtra;
      return this.totalStatus;
   }

   /**
   * Soma os valores de Previstos e Atrasados da lista de Serviços
   */
   public sumPrevAtraso(dados) {
      let temp = [];
      dados.forEach(
         (el) => {
            el.lista.forEach(
               (it) => {
                  temp.push(it);
               }
            );
         }
      );
      this.previsto = temp.map((tupla) => {
         return Number.parseFloat(tupla['previsto'])
      }).reduce((anterior, atual) => {
         return (anterior + atual);
      }, 0);

      this.atraso = temp.map((tupla) => {
         return Number.parseFloat(tupla['atraso'])
      }).reduce((anterior, atual) => {
         return (anterior + atual);
      }, 0);
   }
}