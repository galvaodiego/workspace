import { Component } from '@angular/core';
import { IonicPage, NavParams } from 'ionic-angular';
import { LogisticoProvider } from '../../../providers/logistico.provider';
import { LoadingController, Loading } from 'ionic-angular';
import io from 'socket.io-client';

@IonicPage()
@Component({
   selector: 'page-logistico-detalhes',
   templateUrl: 'logistico-detalhes.html',
})
export class LogisticoDetalhesPage {

   //Dados do Organizacional para as Buscas
   public dados: any = [];
   public descricao: string = '';

   //Array com o Resultado
   public dataSource: any;
   public status: any = [];

   public statusSelecionado: string = '';
   // Config Socket
   socket_io: any;
   socket_rota = 'indicador_logistico';
   socket_metodo = 'getIndicadorLogistico';
   socket_filtro: any;
   /***/
   public loading: Loading;
   public hasLoading: boolean;
   constructor(
      public navParams: NavParams,
      public logProvider: LogisticoProvider,
      public loadingCtrl: LoadingController
   ) {
      this.dados = this.navParams.get('info');
      this.socket_io = io('https://dash-backend.kmm.com.br/' + this.socket_rota);
      this.socket_filtro = {
         base: 'panorama',
      };
   }

   ionViewDidLoad() {
      this.getData();
   }

   public setLoading(flag: boolean, loadingText?: string): Promise<any> {
      if (flag) {
         this.loading = this.loadingCtrl.create({
            content: loadingText
         });
         this.hasLoading = true;
         return this.loading.present();
      } else {
         if (this.loading != null && this.loading.isOverlay) {
            return this.loading.dismiss();
         } else {
            return Promise.resolve({});
         }
      }
   }

   /**
   * Retorna os dados do Banco
   */
   public getDados(): Promise<any> {
      return this.logProvider.getIndicadorLogisticoDetalhes(this.dados[0].dados.descricao, this.dados[0].modo).then(
         (result) => {
            console.log('>:>', result);

            let temp = [];
            result.logistico.forEach(
               (el) => {
                  if (el.lista.length > 0) {
                     temp.push(el)
                  }
               }
            );
            this.status = temp;
            this.statusSelecionado = this.dados[0].status;
            this.dataSource = this.status.find((el) => el.status == this.statusSelecionado).lista;
            this.descricao = this.dados[0].dados.descricao
            console.log('Stattus', this.status);
         }

      );
   }


   public getData() {
      this.setLoading(true).then(() => {
         Object.assign(this.socket_filtro, { atraso: this.dados[0].modo, cliente: this.dados[0].dados.descricao });
         this.socket_io.emit(this.socket_metodo, this.socket_filtro);
         this.socket_io.on(this.socket_rota, (result) => {
            this.setLoading(false).then(() => {
               console.log('socket parametros detalhes', this.socket_filtro, 'data', (result));
               let temp = [];
               result.result.logistico.forEach(
                  (el) => {
                     temp.push(el)
                  }
               );

               this.status = temp;
               this.statusSelecionado = this.dados[0].status;
               if(this.status.find((el) => el.status == this.statusSelecionado)){
                  this.dataSource = this.status.find((el) => el.status == this.statusSelecionado).lista;
               }
               this.descricao = this.dados[0].dados.descricao
               console.log('Stattus', this.status);

            });
         });
      });
   }


   /**
    * Escolhe os dados do Grid conforme o Status Selecionado
  * @param item Status Selecionado
  *  Objetivo:: Alterar os Dados do Array @var dataSource do Grid de Detalhes
  */
   public selectStatus(item) {
      let temp = [];
      temp = this.status.filter(
         (it) => {
            return it.status == item
         }
      )
      this.dataSource = temp[0].lista;
      this.statusSelecionado = temp[0].status;
   }

	/**
    * Função Para Alterar o Estilo do botão da Tabela
    * @param e Evento recebido pelo componente
    */

   public onCellPrepared(e) {
      //Pinta as Linhas de Cabeçalho e Filtros
      if (e.rowType == 'header') {
         e.cellElement.bgColor = '#952725';
         e.cellElement.style.color = '#ffffff';
      }
   }


	/**
	*  Define as Cores das Progress Bar conforme Tempo de Espera
	*/
   public setColor(e) {
      if (typeof (e.key) !== 'undefined') {
         let color: string = '';
         let prazo = Number(e.key.tt_status);
         if (prazo == 0) {
            color = 'is-success';
         } else if (prazo == 2) {
            color = 'is-warning';
         } else if (prazo == 1) {
            color = 'is-danger';
         }
         return color;
      }
   }
}