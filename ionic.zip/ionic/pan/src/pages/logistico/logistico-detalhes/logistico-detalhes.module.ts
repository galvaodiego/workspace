import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DxDataGridModule,  DxButtonModule } from 'devextreme-angular';
import { LogisticoDetalhesPage } from './logistico-detalhes';
import { ComponentsModule } from './../../../components/components.module';

@NgModule({
    declarations: [
        LogisticoDetalhesPage,
    ],
    imports: [
        IonicPageModule.forChild(LogisticoDetalhesPage),
        DxDataGridModule,
        DxButtonModule,
        ComponentsModule
    ],
})
export class LogisticoDetalhesPageModule { }
