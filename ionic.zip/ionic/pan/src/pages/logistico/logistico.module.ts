import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { LogisticoPage } from './logistico';
import { LogisticoProvider } from '../../providers/logistico.provider';
import { ComponentsModule } from '../../components/components.module';

@NgModule({
    declarations: [
        LogisticoPage,
    ],
    imports: [
        IonicPageModule.forChild(LogisticoPage),
        ComponentsModule
    ],
    providers: [LogisticoProvider]
})
export class LogisticoPageModule { }
