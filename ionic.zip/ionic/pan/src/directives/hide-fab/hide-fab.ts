import { Directive, ElementRef, Renderer } from "@angular/core";
import { Content } from "ionic-angular";
@Directive({
	selector: '[hide-fab]',
	host: {
		'(ionScroll)': 'handleScroll($event)'
	}
})
export class HideFabDirective {
	private fabRef;
	private storedScroll: number = 0;
	private threshold: number = 1;

	constructor(
		public element: ElementRef,
		public renderer: Renderer
	) {
	}

	ngAfterViewInit() {
		this.fabRef = this.element.nativeElement.getElementsByClassName("fab")[0];
		this.renderer.setElementStyle(this.fabRef, "webkitTransition", "opacity 500ms");
	}

	handleScroll(e: Content) {
		if (e.scrollTop - this.storedScroll > this.threshold) {
			this.renderer.setElementStyle(this.fabRef, "opacity", "0");
		} else if (e.scrollTop - this.storedScroll < 0) {
			this.renderer.setElementStyle(this.fabRef, "opacity", "1");
		}
		this.storedScroll = e.scrollTop;
	}
}

