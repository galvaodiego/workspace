import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';

import { ProgressBarComponent } from './progress-bar/progress-bar';
import { FooterMonitoramentoComponent } from './footer-monitoramento/footer-monitoramento';
import { LogisticoCardComponent } from './logistico-card/logistico-card';
import { TreeListComponent } from './tree-list/tree-list';

@NgModule({
	declarations: [
		ProgressBarComponent,
		FooterMonitoramentoComponent,
		LogisticoCardComponent,
		TreeListComponent
	],
	imports: [
		IonicPageModule
	],
	exports: [
		ProgressBarComponent,
		FooterMonitoramentoComponent,
		LogisticoCardComponent,
		TreeListComponent
	]
})
export class ComponentsModule { }
