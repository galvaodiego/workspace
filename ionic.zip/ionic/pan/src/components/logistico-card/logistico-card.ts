import { Component, ViewEncapsulation, Input } from '@angular/core';
import { NavController } from 'ionic-angular';
import { LogisticoDetalhesPage } from '../../pages/logistico/logistico-detalhes/logistico-detalhes';
import { AcompanhamentoLogisticoDetalhesPage } from '../../pages/acompanhamento-logistico/acompanhamento-logistico-detalhes/acompanhamento-logistico-detalhes';

@Component({
   selector: 'logistico-card',
   templateUrl: 'logistico-card.html',
   encapsulation: ViewEncapsulation.None
})
export class LogisticoCardComponent {

   @Input() dados: any = {};
   @Input() origem: string;

   public showCard = false;
   public list: Array<any> = [];

   constructor(
      public navCtrl: NavController
   ) { }

   ngOnInit(): void {
      this.showCardContent(this.dados.lista);
   }

   /**
    * Realiza a soma de Porcentagem do Gauge
    * @param data status escolhido
    */
   public sumGauge(data) {
      let totalPrevisto
      let totalAtraso
      let total

      totalPrevisto = data.map((tupla) => {
         return Number.parseFloat(tupla['previsto'])
      }).reduce((anterior, atual) => {
         return (anterior + atual);
      }, 0);

      totalAtraso = data.map((tupla) => {
         return Number.parseFloat(tupla['atraso'])
      }).reduce((anterior, atual) => {
         return (anterior + atual);
      }, 0);

      total = totalPrevisto / (totalPrevisto + totalAtraso) * 100
      return parseFloat(total.toFixed(0))
   }

   /**
    * Soma os valores de Previstos
    */
   public sumPrevisto() {
      return this.dados.lista.map((tupla) => {
         return Number.parseFloat(tupla['previsto'])
      }).reduce((anterior, atual) => {
         return (anterior + atual);
      }, 0);

   }

   /**
    * Soma os valores de Atrasados
    */
   public sumAtrasado() {
      return this.dados.lista.map((tupla) => {
         return Number.parseFloat(tupla['atraso'])
      }).reduce((anterior, atual) => {
         return (anterior + atual);
      }, 0);

   }


   public explainTables(data) {
      this.list = data;
   }

   public showCardContent(data) {
      this.explainTables(data);
      this.showCard = !this.showCard;
   }

   /**
   * Navega para a pagina de Detalhes
   * @param dados Informações sobre o Item selecionado
   */
   public logisticoDetalhes(valor, dados, status, modo) {
      console.log('origem', this.origem);
      
      if (valor > 0) {
         let temp = [];
         temp = [{
            "status": status,
            "dados": dados,
            "modo": modo

         }];

         if (this.origem === 'indicador-logistico') {
            this.navCtrl.push(LogisticoDetalhesPage, {
               info: temp
            });
         }

         if (this.origem === 'acompanhamento-logistico') {
            this.navCtrl.push(AcompanhamentoLogisticoDetalhesPage, {
               info: temp
            });
         }
      }
   }

}
