import { Component, ChangeDetectorRef, ElementRef, NgZone } from '@angular/core';
import { Events, NavController, NavParams, LoadingController, ModalController } from 'ionic-angular';

import { MonitoramentoModalDetalhesPage } from '../../pages/monitoramento/monitoramento-modal-detalhes/monitoramento-modal-detalhes';
import { MonitoramentoModalRotaPage } from '../../pages/monitoramento/monitoramento-modal-rota/monitoramento-modal-rota';

import * as moment from 'moment';
import 'moment/locale/pt-br';

@Component({
    selector: 'footer-monitoramento',
    templateUrl: 'footer-monitoramento.html'
})
export class FooterMonitoramentoComponent {

    public veiculoDetalhes: any = [];
    public isFooterShow: boolean = false;
    public status: string;
    public percExecutado: number;
    public dataInicioViagem: string;
    public dataTerminoViagem: string;

    constructor(
        public cd: ChangeDetectorRef,
        public element: ElementRef,
        public events: Events,
        public navCtrl: NavController,
        public navParams: NavParams,
        public loadingCtrl: LoadingController,
        public modalCtrl: ModalController,
        public zone: NgZone
    ) {

        /**
        * Evento que pega o Marker (Veiculo) selecionado no Mapa
        * e chama a Função de Detalhes dele
        */
        this.events.subscribe('show-veiculo-detalhe', (veiculo) => {
            this.isFooterShow = true;
            this.veiculoDetalhes = veiculo.veiculo;
            this.status = this.veiculoDetalhes.status.toLowerCase();

            //Limitando o tamanho das strings
            // this.veiculoDetalhes.motorista_reduzido = this.veiculoDetalhes.motorista.substring(0, 15);
            this.veiculoDetalhes.motorista_reduzido = this.veiculoDetalhes.motorista;
            // this.veiculoDetalhes.status_reduzido = this.veiculoDetalhes.status.substring(0, 10);
            this.veiculoDetalhes.status_reduzido = this.veiculoDetalhes.status;
            this.veiculoDetalhes.referencia_reduzida = this.veiculoDetalhes.referencia.substring(0, 30);

            //Validação de Datas
            if (this.status == 'viagem') {
                if (this.veiculoDetalhes.fim_evento_ant !== '') {
                    this.dataInicioViagem = moment(this.veiculoDetalhes.fim_evento_ant).format('DD/MM/YYYY HH:mm');
                }
                if (this.veiculoDetalhes.fim_evento !== '') {
                    this.dataTerminoViagem = moment(this.veiculoDetalhes.fim_evento).format('DD/MM/YYYY HH:mm');
                }
            } else {
                if (this.veiculoDetalhes.inicio_evento !== '') {
                    this.dataInicioViagem = moment(this.veiculoDetalhes.inicio_evento).format('DD/MM/YYYY HH:mm');
                }
                if (this.veiculoDetalhes.prev_inicio_evento !== '') {
                    this.dataTerminoViagem = moment(this.veiculoDetalhes.prev_inicio_evento).format('DD/MM/YYYY HH:mm');
                }
            }

            //Valida Valor do Transit Time
            if (this.veiculoDetalhes.perc_executado !== null) {
                this.percExecutado = this.veiculoDetalhes.perc_executado
            } else {
                this.percExecutado = 0;
            }

            //Destroi o Footer Card
            if (!this.cd['destroyed']) {
                this.cd.detectChanges();
            }
        });
    }


	/**
 	* Seta a Cor da Progressbar do TransitTime
	* @param number Valor de Comparação
	* 0 = Atrasado | 1 = Verde | 2 = Possibilidade de Atraso
	*/
    public setColor(number) {
        let color: string = '';
        let value = Number(number);
        if (value == 0) {
            color = '#aa2227';
        } else if (value == 2) {
            color = '#ff9800';
        } else if (value == 1) {
            color = '#4caf50';
        } else if (value == null) {
            color = '#f0eeee';
        }
        return color;
    }

	/**
	 * Seta o Icone da Progressbar do TransitTime
	 * @param number Valor de Comparação
	 * 0 = Atrasado | 1 = Verde | 2 = Possibilidade de Atraso
	*/
    public setIcon(number) {
        let icon: string = '';
        let value = Number(number);
        if (value == 0) {
            icon = 'transit-truck-atrasado';
        } else if (value == 2) {
            icon = 'transit-truck-possibilidade';
        } else if (value == 1) {
            icon = 'transit-truck-ok';
        } else if (value == null) {
            icon = 'transit-truck';
        }
        return icon;
    }

    /**
 	* Seta o Texto de Saida conforme Status
	* @param valor Valor de Comparação
	*/
    public setTextSaida(status) {
        let tituloStatus: string = '';
        if (status == 'viagem') {
            tituloStatus = 'Início';
        } else if (status == 'carga') {
            tituloStatus = 'Início';
        } else if (status == 'descarga') {
            tituloStatus = 'Início';
        } else {
            tituloStatus = 'Saída';
        }
        return tituloStatus;
    }

	/**
 	* Seta o Texto de Chegada conforme Status
	* @param valor Valor de Comparação
	*/
    public setTextChegada(status) {
        let tituloStatus: string = '';
        if (status == 'viagem') {
            tituloStatus = 'Previsão';
        } else if (status == 'carga') {
            tituloStatus = 'Janela';
        } else if (status == 'descarga') {
            tituloStatus = 'Janela';
        } else {
            tituloStatus = 'Chegada';
        }
        return tituloStatus;
    }


    /**
	 * Modal com os Detalhes do Veiculo
	 */
    public openModalInfo() {
        let modal = this.modalCtrl.create(MonitoramentoModalDetalhesPage, { veiculo: this.veiculoDetalhes });
        modal.present();
    }

	/**
	 * Modal com a Rota do Veiculo Escolhido
	 */
    public openModalRota() {
        let modal = this.modalCtrl.create(MonitoramentoModalRotaPage, { veiculo: this.veiculoDetalhes });
        modal.present();
    }

	/**
	* Fecha o Footer 
	*/
    public ctrlFooterVisibility() {
        if (this.cd['destroyed']) {
            this.cd.detectChanges();
        }
        this.isFooterShow = false;
        this.zone.run(
            () => { }
        );
    }

}
