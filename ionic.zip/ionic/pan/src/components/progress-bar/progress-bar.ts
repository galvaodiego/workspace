import { Component, Input } from '@angular/core';

@Component({
  selector: 'progress-bar',
  templateUrl: 'progress-bar.html'
})
export class ProgressBarComponent {

  @Input('progress') progress;
  @Input('colorOut') colorOut;
  @Input('colorIn') colorIn;
  @Input('iconSrc') iconSrc;
  @Input('iconTransit') iconTransit;

  constructor() {

  }

}