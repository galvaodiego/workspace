import { Injectable } from '@angular/core';
import { AlertController, Loading, LoadingController } from 'ionic-angular';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Usuario } from '../kmm';

@Injectable()
export class KMMGateway {
    protected user: Usuario = Usuario.instance;
    public url: string;
    public loading: Loading;
    public hasLoading: boolean;
    public isConnected: boolean;

    constructor(public _http: HttpClient, public loadingCtrl: LoadingController, public alertCtrl: AlertController) {

    }

    public setLoading(flag: boolean, loadingText?: string): Promise<any> {
        if (flag) {
            this.loading = this.loadingCtrl.create({
                content: loadingText
            });
            this.hasLoading = true;
            return this.loading.present();
        } else {
            if (this.loading != null && this.loading.isOverlay) {
                return this.loading.dismiss();
            } else {
                return Promise.resolve({});
            }
        }
    }

    public isLoading(): boolean {
        return false;
    }

    public backendCall(module: string, operation: string, parameters?: any, showLoading?: boolean): Promise<any> {
        if (this.user.url == null || this.user.url == "") {
            this.user.url = location.protocol + "//" + location.host;
        }
        this.url = this.user.url + "_remote/gateway.php";

        showLoading = showLoading == null ? true : showLoading;
        let loadingText: string = "";


        try {
            if ((<any>navigator).connection.type == 'none') {
                let errorM: string = "Erro de conexão. Verifique a conexão do seu dispositivo.";
                return new Promise((resolve, reject) => {
                    let alert = this.alertCtrl.create({
                        title: "Erro",
                        message: errorM,
                        buttons: [
                            {
                                text: "OK",
                                handler: () => {
                                    // alert.dismiss();.then(() => {
                                    alert.dismiss();
                                        reject({ status: 500, success: false, message: errorM });
                                    // });
                                }
                            }
                        ]
                    });
                    this.setLoading(false).then(() => {
                        alert.present();
                    });
                });
            }
        } catch (er) {
            if ((<any>window).cordova) {
                console.error("Erro ao detectar conexão.", er)
            } else {
                if (!this.isLoading) {
                    console.log("Não foi possível detectar a conexão. Provavelmente sendo utilizado pelo browser", er);
                }
            }
        } // Fim tratamento de conexão


        if (parameters == null) {
            parameters = {};
        }


        let requestData: any = {
            module: module,
            operation: operation,
            parameters: parameters
        };

        let headers: HttpHeaders = new HttpHeaders()
            .set("Content-Type", "application/json; charset=utf-8");
        if (this.user.token) {
            headers = headers.set("Authorization", "Bearer " + this.user.token);
        } else {
            headers = headers.set("Token-Time-Hours", (180 * 24) + ""); // 180 dias
        }
        if (this.user.isDebug) {
            headers = headers.set("Debug", "1");
        }
        headers =  headers.set("KMM-Platform", "Web");


        console.log('Requisição ao banco: ', requestData);

        return new Promise((resolvePai, rejectPai) => {
            this.setLoading(showLoading, loadingText).then(() => {
                this.send(this.url, requestData, headers).then((data: any) => {
                    this.setLoading(false).then(() => {
                        // data = data.json(); // Observable.map não estava funcionando...
                        if (data.result != null) {
                            resolvePai(data.result);
                        } else {
                            resolvePai(data);
                        }
                    });
                }).catch((dataError: any) => {
                    this.setLoading(false).then(data => {
                        // dataError = dataError.json();
                        let errorM = "Erro não identificado. Entre em contato com o suporte.";
                        if (dataError.error.code == 401) {// Não autorizado - Quando o token é inválido ou expirado
                            errorM = "Autenticação expirada. Faça novamente o login.";
                            //this.user.logout();
                            // Se não tiver na tela inicial ou splash, voltar pro login
                        } else if (dataError.error.code === 403) {
                            console.log('aqui que caiu');
                            console.log('dataError', dataError);
                            errorM = dataError.error.message;
                            this.user.logout();
                            // Se não tiver na tela inicial ou splash, voltar pro login
                        } else if (dataError.error.code == 404) {
                            errorM = "Não encontrado";
                            this.user.logout();
                            // Se não tiver na tela inicial ou splash, voltar pro login
                        }
                        else {
                            try {
                                console.log('dataError', dataError);
                                errorM = dataError.error.message;
                            } catch (er) {
                                if (this.user.isDebug) {
                                    errorM = dataError;
                                }
                            }
                            console.log('errorM', errorM);
                        
                        }
                        let alert = this.alertCtrl.create({
                            title: "Erro",
                            message: errorM,
                            buttons: [
                                {
                                    text: "OK",
                                    handler: () => {
                                        // alert.dismiss().then(
                                        //     () => {
                                                // if (rejectPai != null) {
                                        alert.dismiss();
                                                rejectPai(dataError); // Chama o reject do promise de retorno
                                                // }
                                            // });
                                        return false;
                                    }
                                }
                            ]
                        });
                        alert.present();
                    });
                });
            });
        });
    }

    public send(url: string, requestData: any, headers: HttpHeaders): Promise<any> {
        return new Promise((resolve, reject) => {
            this._http.post(url, requestData, { headers: headers } ).subscribe(data => resolve(data), err => reject(err));
        })
    }
}
