import { Storage, StorageConfig } from '@ionic/storage';

export class UsuarioBi {
    usuario: string;
    usuarioBiId: number;
}

export class ConfigOrganizacional {
    configuracaoOrgId: number;
    descricao: string;
    ordem: number;
    tipoOrganizacionalId: number;
}

export class ConfigOrgUsuario {
    listConfigOrg: Array<ConfigOrganizacional>;
    configOrgId: number;
    configOrg: string;
    modulo: string;
    moduloId: number;
    numModulo: string;
    niveis: Array<Nivel>;

    constructor() {
        this.niveis = [];
    }
}

export class Permissao {
    usuario: UsuarioBi;
    ativo: boolean;
    organizacional: string;
    tipoOrganizacionalId: number;
    tipoOrganizacional: string;
    organizacionalId: number;
    organizacionalIdPai: number;
    organizacionalIdCorp: number;
    codNivelOrganizacional: string;
    ordem: number;
}

export class Nivel {
    usuario: UsuarioBi;
    codNivelOrganizacional: string;
    nivel: number;
    organizacional: string;
    organizacionalId: number;
    tipoOrganizacionalId: number;
}

export class AccessConfig {

    private _usuario: UsuarioBi;
    private _configOrgUsuario: Array<ConfigOrgUsuario>;
    private _permissao: Permissao;
    private _permissoes: Array<Permissao>;
    private _niveis: Nivel;
    private static _instance: AccessConfig;

    public storage: Storage;
    public storageConfig: StorageConfig;

    public static get instance(): AccessConfig {
        if (this._instance == null) {
            this._instance = new AccessConfig();
        }
        return this._instance;
    }

    constructor() {
        this.storage = new Storage(this.storageConfig);
        this.configOrgUsuario = [];
        this.permissoes = [];
    }

    /**
    *  getters e setters
    */

    public get usuario(): UsuarioBi {
        return this._usuario;
    }

    public set usuario(value: UsuarioBi) {
        if (value == null) {
            value = new UsuarioBi();
        }
        this._usuario = value;
        this.save();
    }

    public get configOrgUsuario(): Array<ConfigOrgUsuario> {
        return this._configOrgUsuario;
    }

    public set configOrgUsuario(value: Array<ConfigOrgUsuario>) {
        if (value == null) {
            value = [];
        }
        this._configOrgUsuario = value;
        this.save();
    }

    public get permissao(): Permissao {
        return this._permissao;
    }

    public set permissao(value: Permissao) {
        if (value == null) {
            value = new Permissao();
        }
        this._permissao = value;
        this.save();
    }

    public get permissoes(): Array<Permissao> {
        return this._permissoes;
    }

    public set permissoes(value: Array<Permissao>) {
        if (value == null) {
            value = [];
        }
        this._permissoes = value;
        this.save();
    }

    public get niveis(): Nivel {
        return this._niveis;
    }

    public set niveis(value: Nivel) {
        if (value == null) {
            value = new Nivel();
        }
        this._niveis = value;
        this.save();
    }

    /**
    * inicializa as variaveis da classe de acordo com a existencia de dados no storage
    * @returns {Promise<any>}
    */

    public init(): Promise<any> {
        return this.storage.ready().then(
            () => {
                return this.storage.get("access-config").then(
                    (data) => {
                        if (data == null) {
                            this.usuario = {
                                usuario: '',
                                usuarioBiId: null
                            };
                            this.configOrgUsuario.push({
                                listConfigOrg: [],
                                configOrgId: null,
                                configOrg: '',
                                modulo: '',
                                moduloId: null,
                                niveis: [],
                                numModulo: ''
                            });
                            this.niveis = {
                                usuario: this.usuario,
                                codNivelOrganizacional: '',
                                nivel: null,
                                organizacional: '',
                                organizacionalId: null,
                                tipoOrganizacionalId: null,
                            };
                            this.permissao = {
                                ativo: false,
                                codNivelOrganizacional: null,
                                ordem: null,
                                organizacional: '',
                                organizacionalId: null,
                                organizacionalIdCorp: null,
                                organizacionalIdPai: null,
                                tipoOrganizacional: '',
                                tipoOrganizacionalId: null,
                                usuario: this.usuario
                            };
                        } else {
                            this.usuario = data.usuario;
                            this.configOrgUsuario = [];
                            this.permissao = data.permissao;
                            this.niveis = data.niveis;
                        }
                        return data;
                    }
                );
            }
        );
    }

    public save() {
        let data: any = {
            usuario: this._usuario,
            configOrgUsuario: this._configOrgUsuario,
            permissao: this._permissoes,
            niveis: this._niveis
        };
        this.storage.set('access-config', data).then(
            (saves) => {
            }
        ).catch(
            (err) => {
                console.log('access-config com erros');
            }
        );
    }

    public logout() {
        this.usuario = null;
        this.configOrgUsuario = [];
        this.permissao = null;
        this.niveis = null;
    }

}
