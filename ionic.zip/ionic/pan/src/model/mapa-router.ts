/** Classe criada para representar um objeto de previsão para o devextreme */
export class MapRouter {
    weight: number;
    color: string;
    opacity: number;
    mode: string;
    locations: any[]

    constructor(weight: number, color: string, opacity: number, mode: string, locations: Array<any>) {
        this.weight = weight;
        this.color = color;
        this.opacity = opacity;
        this.mode = mode;
        this.locations = locations;
    }
}