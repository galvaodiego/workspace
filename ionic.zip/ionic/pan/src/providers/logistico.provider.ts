import { Injectable } from '@angular/core';
import { KMMGateway } from '../kmm/gateway';

@Injectable()
export class LogisticoProvider {

    constructor(public gateway: KMMGateway) { }

    /**
    * Retorna os dados do módulo Logistico
    * @param tipo :: Operação ou Cliente
    */

    public getIndicadorLogistico(loading?: boolean): Promise<any> {
        return this.gateway.backendCall(
            "1811-APPGESTOR",
            "getIndicadorLogistico",
            {},
            loading
        );
    }

    /**
    * Retorna os dados detalhados do módulo Logistico
    * @param org :: Operação ou Cliente
    */

    public getIndicadorLogisticoDetalhes(organizacional: number, loading?: boolean): Promise<any> {
        return this.gateway.backendCall(
            "1811-APPGESTOR",
            "getIndicadorLogisticoDetalhes",
            {
                org: organizacional,
            },
            loading
        );
    }
}
