import { Injectable } from '@angular/core';
import { AccessConfig, KMMGateway } from '../kmm';

@Injectable()
export class FaturamentoProvider {

    public config: AccessConfig = AccessConfig.instance;

    constructor(
        private gateway: KMMGateway
    ) { }


    /**
     * Get Conteudo
     * @param listaMenu :: Lista a ser acessada
     * @param parameterList :: Configurações do usuário para Esse Módulo 
     * @param dataInicio :: Data de Inicio do Periodo
     * @param dataFim :: Data de Fim do Periodo
     */
    public getConteudo(listaMenu: number, parameterList, dataInicio, dataFim): Promise<any> {
        return this.gateway.backendCall(
            '1811-APPGESTOR',
            'getConteudo',
            {
                usuario_bi_id: this.config.usuario.usuarioBiId,
                organizacional_id: parameterList.niveis[0].organizacional_id,
                organizacional_id_pai: -1,
                tipo_organizacional_id: parameterList.niveis[0].tipo_organizacional,
                configuracao_org_id: parameterList.configOrgId,
                data_inicio: dataInicio,
                data_fim: dataFim,
                nivel: parameterList.niveis[0].nivel,
                lista_menu: listaMenu,
                cod_nivel_organizacional: parameterList.niveis[0].cod_nivel_organizacional
            }
        );
    }
}