import { Injectable } from '@angular/core';
import { Usuario, KMMGateway } from '../kmm';

@Injectable()
export class AuthProvider {

    private user: Usuario = Usuario.instance;

    constructor(
        public gateway: KMMGateway
    ) { }


    /**
     * Realiza a Comunicação e Validação do Usuário
     */
    public login(): Promise<any> {
        return this.gateway.backendCall(
            'LOGON',
            'LOGON',
            {
                username: this.user.usuario,
                password: this.user.senha,
                cod_gestao: this.user.codGestao,
                filiais: this.user.filiais
            }
        );
    }

    /**
     * Resgata os parâmetros de configuração do app;
     * @param {string} usuario - usuario de acesso no app
     * @param {number} usuario_bi_id -- ID do usuario de acesso no app
     * @returns {Promise<any>} - retorno do backendCall
     */

    public getUsuarioPermissoes(usuario: string, usuario_bi_id?: number): Promise<any> {
        return this.gateway.backendCall(
            "1811-APPGESTOR",
            "getUsuarioPermissoes",
            {
                usuario_bi: usuario,
                usuario_bi_id: usuario_bi_id
            }
        );
    }

}
