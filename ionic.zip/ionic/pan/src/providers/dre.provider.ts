import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { KMMGateway } from '../kmm/gateway';

@Injectable()
export class DreProvider {

	constructor(
		public http: HttpClient,
		public gateway: KMMGateway
	) {
	}

	public getFakeData() {
		return this.http.get('https://api.myjson.com/bins/idjhj').toPromise().then(
			(data) => {
				return data;
			}
		);
	}

	public getDre(
		demonstrativoId: number,
		anoPlano: string,
		usuarioBiId: number,
		organizacional: string,
		codNivelOrganizacional: string,
		confOrgId: number,
		dataExibicao: string,
		organizacionalId: number
	): Promise<any> {
		return this.gateway.backendCall(
			"M4002",
			"getDRE",
			{
				demonstrativo_id: demonstrativoId,
				nivel: 1,
				ano_plano: anoPlano,
				layout_id_pai: "-1",
				usuario_bi_id: usuarioBiId,
				organizacional: organizacional,
				cod_nivel_organizacional: codNivelOrganizacional,
				configuracao_org_id: confOrgId,
				data_inicio: dataExibicao,
				organizacional_id: organizacionalId
			},
			true
		);
	}


	/**
	 * Retorna os Meses Disponiveis para Utilização do Filtro
	 */
	public getCalendarioDRE(): Promise<any> {
		return this.gateway.backendCall(
			"M4002",
			"getCalendarioDRE",
			{
			},
			true
		);
	}

	/**
	 * Retorna o leyout e ano para o dre
	 */
	public getDemonstrativo(): Promise<any> {
		return this.gateway.backendCall(
			"M4002",
			"getDemonstrativo",
			{ },
			true
		);
	}
	
}
