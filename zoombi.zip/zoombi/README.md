# ZoomBI

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 9.1.1.

## Development server
* C:\Windows\System32\drivers\etc
* hosts
* 127.0.0.1 zoombi.kmm.com.br
* rodar o servidor com: npm start
