import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NotFoundComponent } from './modulos/pages/not-found/not-found.component';


const routes: Routes = [
  { path: '', redirectTo: 'pages', pathMatch: 'full' },
  { path: 'pages', loadChildren: () => import('./modulos/pages/pages.module').then(m => m.PagesModule) },
  { path: 'gerencial', loadChildren: () => import('./modulos/gerencial/gerencial.module').then(m => m.GerencialModule) },
  { path: 'frota', loadChildren: () => import('./modulos/frota/frota.module').then(m => m.FrotaModule) },
  { path: 'operacao', loadChildren: () => import('./modulos/operacao/operacao.module').then(m => m.OperacaoModule) },
  { path: 'financas', loadChildren: () => import('./modulos/financas/financas.module').then(m => m.FinancasModule) },
  // { path: 'dev', loadChildren: () => import('./modulos/dev/dev.module').then(m => m.DevModule) },
  { path: '**', component: NotFoundComponent },



];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
