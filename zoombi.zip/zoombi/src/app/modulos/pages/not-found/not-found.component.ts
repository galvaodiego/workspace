import { Component, OnInit } from '@angular/core';
import { LoadingService } from 'src/app/shared/services/loading.service';
import { ToolsService } from 'src/app/shared/services/tools.service';

@Component({
  selector: 'app-not-found',
  templateUrl: './not-found.component.html',
  styleUrls: ['./not-found.component.scss']
})
export class NotFoundComponent implements OnInit {

  constructor(
    private loading: LoadingService
  ) {
    this.loading.loadVisible = false
  }

  ngOnInit(): void {
  }

}
