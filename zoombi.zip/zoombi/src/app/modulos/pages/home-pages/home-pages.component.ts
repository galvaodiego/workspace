import { Component, OnInit } from '@angular/core';
import { LoadingService } from 'src/app/shared/services/loading.service';
import { ApiService } from 'src/app/shared/services/api.service';
import { environment } from 'src/environments/environment';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ToolsService } from 'src/app/shared/services/tools.service';
@Component({
  selector: 'app-home-pages',
  templateUrl: './home-pages.component.html',
  styleUrls: ['./home-pages.component.scss']
})
export class HomePagesComponent implements OnInit {
  parameters: any

  constructor(
    private loading: LoadingService,
    private api: ApiService,
    private _snackBar: MatSnackBar,
    public tools: ToolsService
  ) {
    const session = sessionStorage.getItem('usuario');
    let nome_usuario = '';
    if (session) {
      nome_usuario = session;
    }
    this.parameters = {
      usuario: nome_usuario,
      pacote: 'Home',
      assunto: null,
      aba: null
    }
  }

  ngOnInit(): void {
    this.loading.loadVisible = false;
    this.api.backendCall('getComponente', this.parameters).then((res: any) => {
      console.log('getComponente', res);
      if (res.retorno.componentes.length > 0) {
        // this.componentes = res.retorno.componentes;
        // setTimeout(() => {
        //   this.loading.loadVisible = false;
        // }, environment.time_loading);
      } else {
        // this._snackBar.open('Componentes não encontrados', 'OK', {
        //   duration: 2000,
        // });
        this.loading.loadVisible = false;
      }
    }).catch(err => {
      this.loading.loadVisible = false;
      console.error('ERROR', err.error.message, 'PARAM:', this.parameters);
      this._snackBar.open(err.error.message, 'OK', {
        duration: 20000,
      });
    });
  }

}
