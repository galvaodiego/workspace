import { Component, OnInit } from '@angular/core';
import { environment } from 'src/environments/environment';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { ApiService } from 'src/app/shared/services/api.service';
import { LoadingService } from 'src/app/shared/services/loading.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  urlLogin = environment.loginUrl;
  form: FormGroup;
  constructor(
    private api: ApiService,
    private fb: FormBuilder,
    private loading: LoadingService,
    private _snackBar: MatSnackBar,
  ) {
    this.form = this.fb.group({
      usuario: ['', Validators.required],
      senha: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.loading.loadVisible = false;
  }

  onSubmit() {
    this.api.backendCall('zoombi/login', {
      usuario: this.form.get('usuario').value,
      senha: this.form.get('senha').value
    }).then((res: any) => {
      console.log('zoombi/login', res);
      if (res.login) {
        sessionStorage.setItem('usuario', res.login.usuario);
        window.location.replace('https://dash-backend.kmm.com.br/setToken?token=' + res.login.token);
      }
    }).catch(err => {
      this._snackBar.open(err.error.message, 'Fechar', {
        duration: 2000,
      });
    });
  }

}
