import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TestesComponent } from './testes/testes.component';
import { DevRoutingModule } from './dev-routing.module';



@NgModule({
  declarations: [TestesComponent],
  imports: [
    CommonModule,
    DevRoutingModule
  ]
})
export class DevModule { }
