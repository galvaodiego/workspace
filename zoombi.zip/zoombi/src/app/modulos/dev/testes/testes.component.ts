import { Component, OnInit } from '@angular/core';
import { LoadingService } from 'src/app/shared/services/loading.service';

@Component({
  selector: 'app-testes',
  templateUrl: './testes.component.html',
  styleUrls: ['./testes.component.scss']
})
export class TestesComponent implements OnInit {

  constructor(
    private loading: LoadingService
  ) { }

  ngOnInit(): void {
    this.loading.loadVisible = false;
  }

}
