import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FrotaRoutingModule } from './frota-routing.module';
import { HomeMotoristasComponent } from './motoristas/home-motoristas/home-motoristas.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { ViagensComponent } from './motoristas/viagens/viagens.component';
import { AnaliseKmComponent } from './motoristas/analise-km/analise-km.component';
import { JornadaComponent } from './motoristas/jornada/jornada.component';

import {MatButtonModule} from '@angular/material/button';
import { OcorrenciasComponent } from './motoristas/ocorrencias/ocorrencias.component';
import { HorasExtrasComponent } from './motoristas/horas-extras/horas-extras.component';
import { InfracoesComponent } from './motoristas/infracoes/infracoes.component';
import { HomeCombustivelComponent } from './combustivel/home-combustivel/home-combustivel.component';
import { AnaliseDeVolumeComponent } from './combustivel/analise-de-volume/analise-de-volume.component';
import { NegociacaoComponent } from './combustivel/negociacao/negociacao.component';
import { AnaliseDeMediasComponent } from './combustivel/analise-de-medias/analise-de-medias.component';
import { AquisicaoComponent } from './pneus/aquisicao/aquisicao.component';
import { PneusEmEstoqueComponent } from './pneus/pneus-em-estoque/pneus-em-estoque.component';
import { MovimentacoesComponent } from './pneus/movimentacoes/movimentacoes.component';
import { ReformaComponent } from './pneus/reforma/reforma.component';
import { InspecoesComponent } from './pneus/inspecoes/inspecoes.component';
import { DesempenhoComponent } from './pneus/desempenho/desempenho.component';
import { DesempenhoDetalhesComponent } from './pneus/desempenho-detalhes/desempenho-detalhes.component';
import { CpkDetalhesComponent } from './pneus/cpk-detalhes/cpk-detalhes.component';
import { SucateamentoComponent } from './pneus/sucateamento/sucateamento.component';
import { DashboardComponent } from './manutencao/dashboard/dashboard.component';
import { OrdensDeServicoAbertasComponent } from './manutencao/ordens-de-servico-abertas/ordens-de-servico-abertas.component';
import { TempoEmExecucaoComponent } from './manutencao/tempo-em-execucao/tempo-em-execucao.component';
import { DetalhamentoDeItemComponent } from './manutencao/detalhamento-de-item/detalhamento-de-item.component';
import { ComprasHomeComponent } from './compras/compras-home/compras-home.component';
import {MatSnackBarModule} from '@angular/material/snack-bar';
@NgModule({
  declarations: [HomeMotoristasComponent, ViagensComponent, AnaliseKmComponent, JornadaComponent, OcorrenciasComponent, HorasExtrasComponent, InfracoesComponent, HomeCombustivelComponent, AnaliseDeVolumeComponent, NegociacaoComponent, AnaliseDeMediasComponent, AquisicaoComponent, PneusEmEstoqueComponent, MovimentacoesComponent, ReformaComponent, InspecoesComponent, DesempenhoComponent, DesempenhoDetalhesComponent, CpkDetalhesComponent, SucateamentoComponent, DashboardComponent, OrdensDeServicoAbertasComponent, TempoEmExecucaoComponent, DetalhamentoDeItemComponent, ComprasHomeComponent],
  imports: [
    CommonModule,
    FrotaRoutingModule,
    SharedModule,
    MatButtonModule,
    MatSnackBarModule
  ]
})
export class FrotaModule { }
