import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnaliseKmComponent } from './analise-km.component';

describe('AnaliseKmComponent', () => {
  let component: AnaliseKmComponent;
  let fixture: ComponentFixture<AnaliseKmComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnaliseKmComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnaliseKmComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
