import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InfracoesComponent } from './infracoes.component';

describe('InfracoesComponent', () => {
  let component: InfracoesComponent;
  let fixture: ComponentFixture<InfracoesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InfracoesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InfracoesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
