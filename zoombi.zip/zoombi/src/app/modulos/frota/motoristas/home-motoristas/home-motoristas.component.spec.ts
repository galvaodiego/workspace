import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HomeMotoristasComponent } from './home-motoristas.component';

describe('HomeMotoristasComponent', () => {
  let component: HomeMotoristasComponent;
  let fixture: ComponentFixture<HomeMotoristasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HomeMotoristasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeMotoristasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
