import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SucateamentoComponent } from './sucateamento.component';

describe('SucateamentoComponent', () => {
  let component: SucateamentoComponent;
  let fixture: ComponentFixture<SucateamentoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SucateamentoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SucateamentoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
