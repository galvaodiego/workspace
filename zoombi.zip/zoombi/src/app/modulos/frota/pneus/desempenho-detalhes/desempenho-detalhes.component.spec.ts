import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DesempenhoDetalhesComponent } from './desempenho-detalhes.component';

describe('DesempenhoDetalhesComponent', () => {
  let component: DesempenhoDetalhesComponent;
  let fixture: ComponentFixture<DesempenhoDetalhesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DesempenhoDetalhesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DesempenhoDetalhesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
