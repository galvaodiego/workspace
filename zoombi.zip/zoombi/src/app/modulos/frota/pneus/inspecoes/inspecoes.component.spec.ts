import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InspecoesComponent } from './inspecoes.component';

describe('InspecoesComponent', () => {
  let component: InspecoesComponent;
  let fixture: ComponentFixture<InspecoesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InspecoesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InspecoesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
