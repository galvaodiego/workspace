import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CpkDetalhesComponent } from './cpk-detalhes.component';

describe('CpkDetalhesComponent', () => {
  let component: CpkDetalhesComponent;
  let fixture: ComponentFixture<CpkDetalhesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CpkDetalhesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CpkDetalhesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
