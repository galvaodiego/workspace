import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DetalhamentoDeItemComponent } from './detalhamento-de-item.component';

describe('DetalhamentoDeItemComponent', () => {
  let component: DetalhamentoDeItemComponent;
  let fixture: ComponentFixture<DetalhamentoDeItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DetalhamentoDeItemComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DetalhamentoDeItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
