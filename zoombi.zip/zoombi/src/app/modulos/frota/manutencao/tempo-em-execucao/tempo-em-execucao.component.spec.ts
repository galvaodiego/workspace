import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TempoEmExecucaoComponent } from './tempo-em-execucao.component';

describe('TempoEmExecucaoComponent', () => {
  let component: TempoEmExecucaoComponent;
  let fixture: ComponentFixture<TempoEmExecucaoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TempoEmExecucaoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TempoEmExecucaoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
