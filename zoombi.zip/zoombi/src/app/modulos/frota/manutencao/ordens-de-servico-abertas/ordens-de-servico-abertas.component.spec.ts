import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrdensDeServicoAbertasComponent } from './ordens-de-servico-abertas.component';

describe('OrdensDeServicoAbertasComponent', () => {
  let component: OrdensDeServicoAbertasComponent;
  let fixture: ComponentFixture<OrdensDeServicoAbertasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrdensDeServicoAbertasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrdensDeServicoAbertasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
