import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnaliseDeMediasComponent } from './analise-de-medias.component';

describe('AnaliseDeMediasComponent', () => {
  let component: AnaliseDeMediasComponent;
  let fixture: ComponentFixture<AnaliseDeMediasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnaliseDeMediasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnaliseDeMediasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
