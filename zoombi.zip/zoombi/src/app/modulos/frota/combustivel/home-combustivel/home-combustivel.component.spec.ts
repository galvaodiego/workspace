import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HomeCombustivelComponent } from './home-combustivel.component';

describe('HomeCombustivelComponent', () => {
  let component: HomeCombustivelComponent;
  let fixture: ComponentFixture<HomeCombustivelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HomeCombustivelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeCombustivelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
