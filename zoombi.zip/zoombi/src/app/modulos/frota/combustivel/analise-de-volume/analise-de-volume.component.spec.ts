import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnaliseDeVolumeComponent } from './analise-de-volume.component';

describe('AnaliseDeVolumeComponent', () => {
  let component: AnaliseDeVolumeComponent;
  let fixture: ComponentFixture<AnaliseDeVolumeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnaliseDeVolumeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnaliseDeVolumeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
