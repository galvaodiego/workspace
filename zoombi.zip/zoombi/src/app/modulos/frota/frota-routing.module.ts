import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NotFoundComponent } from '../pages/not-found/not-found.component';
import { AnaliseDeMediasComponent } from './combustivel/analise-de-medias/analise-de-medias.component';
import { AnaliseDeVolumeComponent } from './combustivel/analise-de-volume/analise-de-volume.component';
import { HomeCombustivelComponent } from './combustivel/home-combustivel/home-combustivel.component';
import { NegociacaoComponent } from './combustivel/negociacao/negociacao.component';
import { ComprasHomeComponent } from './compras/compras-home/compras-home.component';
import { DashboardComponent } from './manutencao/dashboard/dashboard.component';
import { DetalhamentoDeItemComponent } from './manutencao/detalhamento-de-item/detalhamento-de-item.component';
import { OrdensDeServicoAbertasComponent } from './manutencao/ordens-de-servico-abertas/ordens-de-servico-abertas.component';
import { TempoEmExecucaoComponent } from './manutencao/tempo-em-execucao/tempo-em-execucao.component';
import { AnaliseKmComponent } from './motoristas/analise-km/analise-km.component';
import { HomeMotoristasComponent } from './motoristas/home-motoristas/home-motoristas.component';
import { HorasExtrasComponent } from './motoristas/horas-extras/horas-extras.component';
import { InfracoesComponent } from './motoristas/infracoes/infracoes.component';
import { JornadaComponent } from './motoristas/jornada/jornada.component';
import { OcorrenciasComponent } from './motoristas/ocorrencias/ocorrencias.component';
import { ViagensComponent } from './motoristas/viagens/viagens.component';
import { AquisicaoComponent } from './pneus/aquisicao/aquisicao.component';
import { CpkDetalhesComponent } from './pneus/cpk-detalhes/cpk-detalhes.component';
import { DesempenhoDetalhesComponent } from './pneus/desempenho-detalhes/desempenho-detalhes.component';
import { DesempenhoComponent } from './pneus/desempenho/desempenho.component';
import { InspecoesComponent } from './pneus/inspecoes/inspecoes.component';
import { MovimentacoesComponent } from './pneus/movimentacoes/movimentacoes.component';
import { PneusEmEstoqueComponent } from './pneus/pneus-em-estoque/pneus-em-estoque.component';
import { ReformaComponent } from './pneus/reforma/reforma.component';
import { SucateamentoComponent } from './pneus/sucateamento/sucateamento.component';


const routes: Routes = [
  { path: '', redirectTo: 'motoristas', pathMatch: 'full' },
  {
    path: 'motoristas',
    children: [
      { path: 'principal', component: HomeMotoristasComponent },
      { path: 'viagens', component: ViagensComponent },
      { path: 'analise-sobre-km', component: AnaliseKmComponent },
      { path: 'jornada', component: JornadaComponent },
      { path: 'ocorrencias', component: OcorrenciasComponent },
      { path: 'horas-extras', component: HorasExtrasComponent },
      { path: 'infracoes', component: InfracoesComponent },
      { path: '', redirectTo: 'principal', pathMatch: 'full' },
    ]
  },
  {
    path: 'combustiveis',
    children: [
      { path: 'principal', component: HomeCombustivelComponent },
      { path: 'analise-de-volume', component: AnaliseDeVolumeComponent },
      { path: 'negociacao', component: NegociacaoComponent },
      { path: 'analise-de-medias', component: AnaliseDeMediasComponent },
      { path: '', redirectTo: 'principal', pathMatch: 'full' },
    ]
  },
  {
    path: 'pneus',
    children: [
      { path: 'aquisicao', component: AquisicaoComponent },
      { path: 'pneus-em-estoque', component: PneusEmEstoqueComponent },
      { path: 'movimentacoes', component: MovimentacoesComponent },
      { path: 'reforma', component: ReformaComponent },
      { path: 'inspecoes', component: InspecoesComponent },
      { path: 'desempenho', component: DesempenhoComponent },
      { path: 'desempenho-detalhes', component: DesempenhoDetalhesComponent },
      { path: 'sucateamento', component: SucateamentoComponent },
      { path: 'cpk-detalhes', component: CpkDetalhesComponent },
      { path: '', redirectTo: 'aquisicoes', pathMatch: 'full' },
    ]
  },
  {
    path: 'manutencao',
    children: [
      { path: 'dashboard', component: DashboardComponent },
      { path: 'ordens-de-servico-abertas', component: OrdensDeServicoAbertasComponent },
      { path: 'tempo-em-execucao', component: TempoEmExecucaoComponent },
      { path: 'detalhamento-de-item', component: DetalhamentoDeItemComponent },
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
    ]
  },
  {
    path: 'compras',
    children: [
      { path: 'mashup', component: ComprasHomeComponent },
      { path: '', redirectTo: 'mashup', pathMatch: 'full' },
    ]
  },

  { path: '**', component: NotFoundComponent },


];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FrotaRoutingModule { }
