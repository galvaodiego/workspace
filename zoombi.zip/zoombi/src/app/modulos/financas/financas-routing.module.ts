import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NotFoundComponent } from '../pages/not-found/not-found.component';
import { CcrAnaliseMensalComponent } from './ccr/ccr-analise-mensal/ccr-analise-mensal.component';
import { CcrCicloFinanceiroComponent } from './ccr/ccr-ciclo-financeiro/ccr-ciclo-financeiro.component';
import { CcrDashboardComponent } from './ccr/ccr-dashboard/ccr-dashboard.component';
import { CcrFaturarComponent } from './ccr/ccr-faturar/ccr-faturar.component';
import { CcrInadimplenciaComponent } from './ccr/ccr-inadimplencia/ccr-inadimplencia.component';
import { DreAnaCcgComponent } from './dre/dre-ana-ccg/dre-ana-ccg.component';
import { DreBaseContabilComponent } from './dre/dre-base-contabil/dre-base-contabil.component';
import { DreEvoMensalComponent } from './dre/dre-evo-mensal/dre-evo-mensal.component';
import { DreGestaoComponent } from './dre/dre-gestao/dre-gestao.component';
import { FinContratoComponent } from './financiamentos/fin-contrato/fin-contrato.component';
import { FinDashboardComponent } from './financiamentos/fin-dashboard/fin-dashboard.component';
import { FinFrotaComponent } from './financiamentos/fin-frota/fin-frota.component';
import { FinHistParcelaComponent } from './financiamentos/fin-hist-parcela/fin-hist-parcela.component';
import { FinParcelasComponent } from './financiamentos/fin-parcelas/fin-parcelas.component';
import { FinValorContratoComponent } from './financiamentos/fin-valor-contrato/fin-valor-contrato.component';
import { FdcDashboardComponent } from './fluxo-caixa/fdc-dashboard/fdc-dashboard.component';
import { FdcPagarGrafComponent } from './fluxo-caixa/fdc-pagar-graf/fdc-pagar-graf.component';
import { FdcPagarComponent } from './fluxo-caixa/fdc-pagar/fdc-pagar.component';
import { FdcReceberGrafComponent } from './fluxo-caixa/fdc-receber-graf/fdc-receber-graf.component';
import { FdcReceberComponent } from './fluxo-caixa/fdc-receber/fdc-receber.component';


const routes: Routes = [
  { path: '', redirectTo: 'fluxo-de-caixa', pathMatch: 'full' },
  {
    path: 'fluxo-caixa',
    children: [
      { path: 'principal', component: FdcDashboardComponent },
      { path: 'a-receber', component: FdcReceberComponent },
      { path: 'a-receber-graficos', component: FdcReceberGrafComponent },
      { path: 'a-pagar', component: FdcPagarComponent },
      { path: 'a-pagar-graficos', component: FdcPagarGrafComponent },
      { path: '', redirectTo: 'principal', pathMatch: 'full' },
    ]
  },
  {
    path: 'car',
    children: [
      { path: 'principal', component: CcrDashboardComponent },
      { path: 'ciclo-financeiro', component: CcrCicloFinanceiroComponent },
      { path: 'analise-mensal', component: CcrAnaliseMensalComponent },
      { path: 'inadimplencia', component: CcrInadimplenciaComponent },
      { path: 'a-faturar', component: CcrFaturarComponent },
      { path: '', redirectTo: 'principal', pathMatch: 'full' },
    ]
  },
  {
    path: 'financiamentos',
    children: [
      { path: 'principal', component: FinDashboardComponent },
      { path: 'contratos', component: FinContratoComponent },
      { path: 'parcelas', component: FinParcelasComponent },
      { path: 'arrendadoras', component: FinValorContratoComponent },
      { path: 'endividamento', component: FinHistParcelaComponent },
      { path: 'analise-frota', component: FinFrotaComponent },
      { path: '', redirectTo: 'principal', pathMatch: 'full' },
    ]
  },
  {
    path: 'dre',
    children: [
      { path: 'dre-gestao', component: DreGestaoComponent },
      { path: 'evolucao-mensal', component: DreEvoMensalComponent },
      { path: 'analise-ccg', component: DreAnaCcgComponent },
      { path: 'base-contabil', component: DreBaseContabilComponent },
      { path: '', redirectTo: 'dre-gestao', pathMatch: 'full' },
    ]
  },
  { path: '**', component: NotFoundComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FinancasRoutingModule { }
