import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FinancasRoutingModule } from './financas-routing.module';
import { FdcDashboardComponent } from './fluxo-caixa/fdc-dashboard/fdc-dashboard.component';
import { FdcReceberComponent } from './fluxo-caixa/fdc-receber/fdc-receber.component';
import { FdcReceberGrafComponent } from './fluxo-caixa/fdc-receber-graf/fdc-receber-graf.component';
import { FdcPagarComponent } from './fluxo-caixa/fdc-pagar/fdc-pagar.component';
import { FdcPagarGrafComponent } from './fluxo-caixa/fdc-pagar-graf/fdc-pagar-graf.component';
import { FinDashboardComponent } from './financiamentos/fin-dashboard/fin-dashboard.component';
import { FinContratoComponent } from './financiamentos/fin-contrato/fin-contrato.component';
import { FinParcelasComponent } from './financiamentos/fin-parcelas/fin-parcelas.component';
import { FinValorContratoComponent } from './financiamentos/fin-valor-contrato/fin-valor-contrato.component';
import { FinFatPlacaComponent } from './financiamentos/fin-fat-placa/fin-fat-placa.component';
import { FinHistParcelaComponent } from './financiamentos/fin-hist-parcela/fin-hist-parcela.component';
import { FinFrotaComponent } from './financiamentos/fin-frota/fin-frota.component';
import { CcrDashboardComponent } from './ccr/ccr-dashboard/ccr-dashboard.component';
import { CcrCicloFinanceiroComponent } from './ccr/ccr-ciclo-financeiro/ccr-ciclo-financeiro.component';
import { CcrAnaliseMensalComponent } from './ccr/ccr-analise-mensal/ccr-analise-mensal.component';
import { CcrInadimplenciaComponent } from './ccr/ccr-inadimplencia/ccr-inadimplencia.component';
import { CcrFaturarComponent } from './ccr/ccr-faturar/ccr-faturar.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { MatButtonModule } from '@angular/material/button';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { DreGestaoComponent } from './dre/dre-gestao/dre-gestao.component';
import { DreEvoMensalComponent } from './dre/dre-evo-mensal/dre-evo-mensal.component';
import { DreAnaCcgComponent } from './dre/dre-ana-ccg/dre-ana-ccg.component';
import { DreBaseContabilComponent } from './dre/dre-base-contabil/dre-base-contabil.component';


@NgModule({
  declarations: [FdcDashboardComponent, FdcReceberComponent, FdcReceberGrafComponent, FdcPagarComponent, FdcPagarGrafComponent, FinDashboardComponent, FinContratoComponent, FinParcelasComponent, FinValorContratoComponent, FinFatPlacaComponent, FinHistParcelaComponent, FinFrotaComponent, CcrDashboardComponent, CcrCicloFinanceiroComponent, CcrAnaliseMensalComponent, CcrInadimplenciaComponent, CcrFaturarComponent, DreGestaoComponent, DreEvoMensalComponent, DreAnaCcgComponent, DreBaseContabilComponent],
  imports: [
    CommonModule,
    FinancasRoutingModule,
    SharedModule,
    MatButtonModule,
    MatSnackBarModule
  ]
})
export class FinancasModule { }
