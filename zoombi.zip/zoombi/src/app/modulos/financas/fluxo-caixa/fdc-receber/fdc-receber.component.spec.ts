import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FdcReceberComponent } from './fdc-receber.component';

describe('FdcReceberComponent', () => {
  let component: FdcReceberComponent;
  let fixture: ComponentFixture<FdcReceberComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FdcReceberComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FdcReceberComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
