import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FdcReceberGrafComponent } from './fdc-receber-graf.component';

describe('FdcReceberGrafComponent', () => {
  let component: FdcReceberGrafComponent;
  let fixture: ComponentFixture<FdcReceberGrafComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FdcReceberGrafComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FdcReceberGrafComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
