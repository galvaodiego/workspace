import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FdcPagarComponent } from './fdc-pagar.component';

describe('FdcPagarComponent', () => {
  let component: FdcPagarComponent;
  let fixture: ComponentFixture<FdcPagarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FdcPagarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FdcPagarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
