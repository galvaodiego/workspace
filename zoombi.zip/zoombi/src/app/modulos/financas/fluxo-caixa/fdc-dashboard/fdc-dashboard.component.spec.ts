import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FdcDashboardComponent } from './fdc-dashboard.component';

describe('FdcDashboardComponent', () => {
  let component: FdcDashboardComponent;
  let fixture: ComponentFixture<FdcDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FdcDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FdcDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
