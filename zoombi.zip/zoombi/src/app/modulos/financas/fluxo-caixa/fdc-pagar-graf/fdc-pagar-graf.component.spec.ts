import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FdcPagarGrafComponent } from './fdc-pagar-graf.component';

describe('FdcPagarGrafComponent', () => {
  let component: FdcPagarGrafComponent;
  let fixture: ComponentFixture<FdcPagarGrafComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FdcPagarGrafComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FdcPagarGrafComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
