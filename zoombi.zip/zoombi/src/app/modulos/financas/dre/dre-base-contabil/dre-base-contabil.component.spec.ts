import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DreBaseContabilComponent } from './dre-base-contabil.component';

describe('DreBaseContabilComponent', () => {
  let component: DreBaseContabilComponent;
  let fixture: ComponentFixture<DreBaseContabilComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DreBaseContabilComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DreBaseContabilComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
