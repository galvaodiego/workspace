import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DreEvoMensalComponent } from './dre-evo-mensal.component';

describe('DreEvoMensalComponent', () => {
  let component: DreEvoMensalComponent;
  let fixture: ComponentFixture<DreEvoMensalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DreEvoMensalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DreEvoMensalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
