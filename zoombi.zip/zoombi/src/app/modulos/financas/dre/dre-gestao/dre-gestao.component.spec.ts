import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DreGestaoComponent } from './dre-gestao.component';

describe('DreGestaoComponent', () => {
  let component: DreGestaoComponent;
  let fixture: ComponentFixture<DreGestaoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DreGestaoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DreGestaoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
