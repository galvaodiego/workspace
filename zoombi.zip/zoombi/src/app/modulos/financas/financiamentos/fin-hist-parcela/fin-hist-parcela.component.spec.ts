import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FinHistParcelaComponent } from './fin-hist-parcela.component';

describe('FinHistParcelaComponent', () => {
  let component: FinHistParcelaComponent;
  let fixture: ComponentFixture<FinHistParcelaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FinHistParcelaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FinHistParcelaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
