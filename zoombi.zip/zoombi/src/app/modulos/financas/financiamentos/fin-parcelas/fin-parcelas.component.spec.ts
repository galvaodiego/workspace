import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FinParcelasComponent } from './fin-parcelas.component';

describe('FinParcelasComponent', () => {
  let component: FinParcelasComponent;
  let fixture: ComponentFixture<FinParcelasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FinParcelasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FinParcelasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
