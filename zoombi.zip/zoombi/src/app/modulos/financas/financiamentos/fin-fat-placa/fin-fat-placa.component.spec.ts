import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FinFatPlacaComponent } from './fin-fat-placa.component';

describe('FinFatPlacaComponent', () => {
  let component: FinFatPlacaComponent;
  let fixture: ComponentFixture<FinFatPlacaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FinFatPlacaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FinFatPlacaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
