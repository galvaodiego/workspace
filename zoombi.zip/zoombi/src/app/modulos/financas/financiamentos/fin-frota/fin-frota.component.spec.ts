import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FinFrotaComponent } from './fin-frota.component';

describe('FinFrotaComponent', () => {
  let component: FinFrotaComponent;
  let fixture: ComponentFixture<FinFrotaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FinFrotaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FinFrotaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
