import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FinValorContratoComponent } from './fin-valor-contrato.component';

describe('FinValorContratoComponent', () => {
  let component: FinValorContratoComponent;
  let fixture: ComponentFixture<FinValorContratoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FinValorContratoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FinValorContratoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
