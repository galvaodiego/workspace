import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FinContratoComponent } from './fin-contrato.component';

describe('FinContratoComponent', () => {
  let component: FinContratoComponent;
  let fixture: ComponentFixture<FinContratoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FinContratoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FinContratoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
