import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/shared/services/api.service';
import { LoadingService } from 'src/app/shared/services/loading.service';
import { environment } from 'src/environments/environment';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ToolsService } from 'src/app/shared/services/tools.service';
@Component({
  selector: 'app-ccr-faturar',
  templateUrl: './ccr-faturar.component.html',
  styleUrls: ['./ccr-faturar.component.scss']
})
export class CcrFaturarComponent implements OnInit {
  config = environment.configQlik;
  customStyle = environment.customStyleIframe;
  dados: any;
  parameters: any
  componentes: any;
  filtros = [];
  constructor(
    private loading: LoadingService,
    private api: ApiService,
    private _snackBar: MatSnackBar,
    public tools: ToolsService
  ) {

    const session = sessionStorage.getItem('usuario');
    let nome_usuario = '';
    if (session) {
      nome_usuario = session;
    }
    this.parameters = {
      usuario: nome_usuario,
      pacote: 'Finanças',
      assunto: 'CAR',
      aba: 'A Faturar'
    }
  }

  ngOnInit(): void {
    for (let index = 1; index < 10; index++) {
      this.filtros.push(index)
    }
    this.loading.loadVisible = true;
    this.api.backendCall('getComponente', this.parameters).then((res: any) => {
      console.log('getComponente', res);
      if (res.retorno.componentes.length > 0) {
        this.componentes = res.retorno.componentes;
        setTimeout(() => {
          this.loading.loadVisible = false;
        }, environment.time_loading);
      } else {
        this._snackBar.open('Componentes não encontrados', 'OK', {
          duration: 2000,
        });
        this.loading.loadVisible = false;
      }
    }).catch(err => {
      this.loading.loadVisible = false;
      console.error('ERROR', err.error.message, 'PARAM:', this.parameters);
      this._snackBar.open(err.error.message, 'OK', {
        duration: 20000,
      });
    });
  }

}
