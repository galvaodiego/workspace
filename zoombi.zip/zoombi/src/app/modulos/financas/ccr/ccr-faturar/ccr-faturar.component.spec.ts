import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CcrFaturarComponent } from './ccr-faturar.component';

describe('CcrFaturarComponent', () => {
  let component: CcrFaturarComponent;
  let fixture: ComponentFixture<CcrFaturarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CcrFaturarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CcrFaturarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
