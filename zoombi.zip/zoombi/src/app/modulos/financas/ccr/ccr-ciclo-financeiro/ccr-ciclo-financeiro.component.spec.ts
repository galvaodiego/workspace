import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CcrCicloFinanceiroComponent } from './ccr-ciclo-financeiro.component';

describe('CcrCicloFinanceiroComponent', () => {
  let component: CcrCicloFinanceiroComponent;
  let fixture: ComponentFixture<CcrCicloFinanceiroComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CcrCicloFinanceiroComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CcrCicloFinanceiroComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
