import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CcrInadimplenciaComponent } from './ccr-inadimplencia.component';

describe('CcrInadimplenciaComponent', () => {
  let component: CcrInadimplenciaComponent;
  let fixture: ComponentFixture<CcrInadimplenciaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CcrInadimplenciaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CcrInadimplenciaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
