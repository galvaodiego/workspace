import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CcrDashboardComponent } from './ccr-dashboard.component';

describe('CcrDashboardComponent', () => {
  let component: CcrDashboardComponent;
  let fixture: ComponentFixture<CcrDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CcrDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CcrDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
