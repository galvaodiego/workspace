import { Component, OnInit } from '@angular/core';
import { LoadingService } from 'src/app/shared/services/loading.service';
import { environment } from 'src/environments/environment';
import { TSQlik, QSApp } from 'ts-qlik'

@Component({
  selector: 'app-ind-combustiveis',
  templateUrl: './ind-combustiveis.component.html',
  styleUrls: ['./ind-combustiveis.component.scss']
})
export class IndCombustiveisComponent implements OnInit {

  qlik = null;

  config = environment.configQlik;
  constructor(private loadingService: LoadingService) {

    TSQlik(this.config).then((q) => {
      this.qlik = q;
      console.log('TSQlik', q);
    });
    QSApp('37ed2de4-e3e8-4f16-9476-3dd776428b13', this.config).then((q) => {
      console.log('QSApp', q);
      q.currApp.app.getObject('CurrentSelections', 'CurrentSelections');

      q.currApp.app.getObject('QV01', 'yfVjj');
      q.currApp.app.getObject('QV02', 'AHZnNsA');
      q.currApp.app.getObject('QV03', 'DHDnLB');
      q.currApp.app.getObject('QV04', 'VXfmns');
      q.currApp.app.getObject('QV05', 'LjDpAS');
      q.currApp.app.getObject('FT01', '3adcf379-b720-45a4-8041-907c464bbc92');
      q.currApp.app.getObject('FT02', '76f3164b-471b-47ce-b2f1-a8a06a4f8a51');
      q.currApp.app.getObject('FT03', '5350d46d-3d29-47ab-a5d7-a613857d1751');
      q.currApp.app.getObject('FT04', 'ace12550-a3da-4bf3-9177-428fb936b20a');
      q.currApp.app.getObject('FT05', '3d7b48f2-f212-45db-9ff5-758c1b96c764');
      q.currApp.app.getObject('FT06', 'eac09f2a-b5f1-4104-8a51-9335a903317f');

      q.currApp.app.getObject('EX01', 'bjPDEQ');
      q.currApp.app.getObject('EX02', 'mTaMj');
    });

  }

  ngOnInit(): void {
    this.loadingService.loadVisible = true;
    setTimeout(() => {
      this.loadingService.loadVisible = false;
    }, 3000);
  }
}
