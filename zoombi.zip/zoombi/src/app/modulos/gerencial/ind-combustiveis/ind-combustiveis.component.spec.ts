import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IndCombustiveisComponent } from './ind-combustiveis.component';

describe('IndCombustiveisComponent', () => {
  let component: IndCombustiveisComponent;
  let fixture: ComponentFixture<IndCombustiveisComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IndCombustiveisComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IndCombustiveisComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
