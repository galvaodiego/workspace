import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NotFoundComponent } from '../pages/not-found/not-found.component';
import { FaturamentoComponent } from './faturamento/faturamento.component';
import { IndCombustiveisComponent } from './ind-combustiveis/ind-combustiveis.component';
import { LogisticoComponent } from './logistico/logistico.component';
import { MotoristasComponent } from './motoristas/motoristas.component';
import { PneusComponent } from './pneus/pneus.component';
import { RecebiveisComponent } from './recebiveis/recebiveis.component';


const routes: Routes = [
  { path: '', redirectTo: 'faturamento', pathMatch: 'full' },
  { path: 'faturamento', component: FaturamentoComponent },
  { path: 'ind-combustiveis', component: IndCombustiveisComponent },
  { path: 'logistico', component: LogisticoComponent },
  { path: 'pneus', component: PneusComponent },
  { path: 'recebiveis', component: RecebiveisComponent },
  { path: 'motoristas', component: MotoristasComponent },
  { path: '**', component: NotFoundComponent },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class GerencialRoutingModule { }
