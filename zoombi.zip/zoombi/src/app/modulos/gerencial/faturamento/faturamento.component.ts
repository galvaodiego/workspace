import { Component, OnInit } from '@angular/core';
import { LoadingService } from 'src/app/shared/services/loading.service';
import { environment } from 'src/environments/environment';
import { QSApp } from 'ts-qlik';

@Component({
  selector: 'app-faturamento',
  templateUrl: './faturamento.component.html',
  styleUrls: ['./faturamento.component.scss']
})
export class FaturamentoComponent implements OnInit {
  aba = 1;
  active = 'qlik';
  config = environment.configQlik;
  constructor(
    private loadingService: LoadingService,
  ) {
    QSApp('cad33b5b-a0b3-46d2-880d-af15ed5aee72', this.config).then((q) => {
      console.log('QSApp:', q);
      q.currApp.app.getObject('CurrentSelections', 'CurrentSelections');
      q.currApp.app.getObject('QV01', 'GPHjph');
      q.currApp.app.getObject('QV02', 'GUYAwQZ');

      q.currApp.app.getObject('KPI1', 'tmjWEn');
      q.currApp.app.getObject('KPI2', 'gALJscr');

      q.currApp.app.getObject('FT01', '710f3f0d-94d7-4424-9d85-cc8531abc8cf');
      q.currApp.app.getObject('FT02', '61b85bf7-24c1-4a0b-8067-f3b1065fcd82');
      q.currApp.app.getObject('FT03', 'bbc9e873-9343-49c1-8e4c-8908f844326c');

      q.currApp.app.getObject('FT04', '8df6f5fb-1701-49b1-a716-a68648d5b957');
      q.currApp.app.getObject('FT05', 'd6ca8da0-afc2-4cd6-82e0-8c7acc893dd1');
      q.currApp.app.getObject('FT06', 'b04a0af6-ba34-44b7-9293-2386212e8040');

      q.currApp.app.getObject('KPI3', 'MTWLx');
      q.currApp.app.getObject('KPI4', 'fBzYuDB');
      q.currApp.app.getObject('KPI5', 'AVuCB');
      q.currApp.app.getObject('KPI6', 'SALEtUh');
      //SALEtUh
      q.currApp.app.getObject('QV03', 'KWprPV');
      q.currApp.app.getObject('QV04', 'PfUWRPj');
      q.currApp.app.getObject('QV05', 'kemeWrb');
      q.currApp.app.getObject('QV06', 'naqE');
      q.currApp.app.getObject('QV07', 'XvdujD');
      //fBzYuDB

      q.currApp.app.getObject('EX01', 'KhPcF');
      q.currApp.app.getObject('EX02', 'frtcJV');

    });
  }

  ngOnInit(): void {
    this.loadingService.loadVisible = true;
    setTimeout(() => {
      this.loadingService.loadVisible = false;
    }, 3000);
  }

  changeTab(aba: number) {
    console.log(aba);
    this.aba = aba;
    if (this.aba === 1) {

      QSApp('cad33b5b-a0b3-46d2-880d-af15ed5aee72', this.config).then((q) => {
        console.log(q);
        q.currApp.app.getObject('QV03', 'KWprPV');
      });
    }
    else if (this.aba === 2) {
      QSApp('cad33b5b-a0b3-46d2-880d-af15ed5aee72', this.config).then((q) => {
        console.log(q);
        q.currApp.app.getObject('QV04', 'PfUWRPj');
      });
    }
    else if (this.aba === 3) {
      QSApp('cad33b5b-a0b3-46d2-880d-af15ed5aee72', this.config).then((q) => {
        console.log(q);
        q.currApp.app.getObject('QV05', 'kemeWrb');
      });
    }
    else if (this.aba === 4) {
      QSApp('cad33b5b-a0b3-46d2-880d-af15ed5aee72', this.config).then((q) => {
        console.log(q);
        q.currApp.app.getObject('QV06', 'naqE');
      });
    }

  }

}
