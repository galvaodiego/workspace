import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LogisticoComponent } from './logistico.component';

describe('LogisticoComponent', () => {
  let component: LogisticoComponent;
  let fixture: ComponentFixture<LogisticoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LogisticoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LogisticoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
