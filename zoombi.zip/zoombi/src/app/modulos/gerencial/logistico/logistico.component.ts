import { Component, OnInit } from '@angular/core';
import { LoadingService } from 'src/app/shared/services/loading.service';
import { environment } from 'src/environments/environment';
import { TSQlik, QSApp } from 'ts-qlik';

@Component({
  selector: 'app-logistico',
  templateUrl: './logistico.component.html',
  styleUrls: ['./logistico.component.scss']
})
export class LogisticoComponent implements OnInit {
  qlik = null;

  config = environment.configQlik;
  constructor(private loadingService: LoadingService) {
    TSQlik(this.config).then((q) => {
      this.qlik = q;
      console.log('TSQlik', q);
    });
    QSApp('8a891f3d-e136-4d80-8cda-997d943253ac', this.config).then((q) => {
      console.log('QSApp', q);
      q.currApp.app.getObject('CurrentSelections', 'CurrentSelections');
      q.currApp.app.getObject('FT01', '0ffee4b1-6ad6-4836-8c5e-448960978961');
      q.currApp.app.getObject('FT02', 'e2f30d08-d5e5-40c1-b8e8-c9aa387d22b2');
      q.currApp.app.getObject('FT03', 'f8dec14b-dd57-4cfd-bd77-9a85b7f2513c');
      q.currApp.app.getObject('FT04', '1099f9c7-9fc6-4162-8094-ab3911300301');
      q.currApp.app.getObject('KPI1', 'jPJUJV');
      q.currApp.app.getObject('KPI2', 'QqDjkPS');
      q.currApp.app.getObject('KPI3', 'debFrV');
      q.currApp.app.getObject('KPI4', 'HJbYJf');
      q.currApp.app.getObject('QV01', 'VEnaZyL');
      q.currApp.app.getObject('QV02', 'xgFZJK');
      q.currApp.app.getObject('QV03', 'YHGAwG');
      q.currApp.app.getObject('QV04', 'XYNnmZ');
      q.currApp.app.getObject('QV05', 'pJaCV');
      q.currApp.app.getObject('QV06', 'xCmr');

      q.currApp.app.getObject('EX01', 'kBRjJ');
      q.currApp.app.getObject('EX02', 'xTDm');


    });
  }

  ngOnInit(): void {
    this.loadingService.loadVisible = true;
    setTimeout(() => {
      this.loadingService.loadVisible = false;
    }, 3000);
  }

}
