import { Component, OnInit } from '@angular/core';
import { LoadingService } from 'src/app/shared/services/loading.service';
import { environment } from 'src/environments/environment';
import { TSQlik, QSApp } from 'ts-qlik';

@Component({
  selector: 'app-pneus',
  templateUrl: './pneus.component.html',
  styleUrls: ['./pneus.component.scss']
})
export class PneusComponent implements OnInit {
  aba = 1;
  qlik = null;
  config = environment.configQlik;
  constructor(private loadingService: LoadingService) {
    this.qlik = null;

    TSQlik(this.config).then((q) => {
      this.qlik = q;
      console.log('TSQlik', q);
    });
    QSApp('5d04db7c-43a0-4ff4-abf1-4963ba321047', this.config).then((q) => {
      console.log('QSApp', q);
      q.currApp.app.getObject('CurrentSelections', 'CurrentSelections');

      q.currApp.app.getObject('QV01', 'jeEkX');
      q.currApp.app.getObject('QV02', 'MwhG');
      q.currApp.app.getObject('QV03', 'JryfaB');
      q.currApp.app.getObject('QV04', 'CJyPR');
      q.currApp.app.getObject('QV05', 'ZJsDLt');
      q.currApp.app.getObject('QV06', 'VKvJQw');
      q.currApp.app.getObject('QV07', 'tXMY');
      q.currApp.app.getObject('QV08', 'HAJjSJ');

      q.currApp.app.getObject('KPI1', 'pghgPp');
      q.currApp.app.getObject('KPI2', 'kqmDbVz');
      q.currApp.app.getObject('KPI3', 'JKHjYYb');
      q.currApp.app.getObject('KPI4', 'NrTzfuk');

      q.currApp.app.getObject('FT01', '5d9b1174-4702-4560-a36d-bf27273d1302');
      q.currApp.app.getObject('FT02', '9faf4bd4-c1c8-420e-adc3-d39b3c8f2e59');
      q.currApp.app.getObject('FT03', '1cd6c33e-1a99-454b-afbb-c9ed4ce9df1f');
      q.currApp.app.getObject('FT04', 'fb9cd337-630a-4e5e-b6fc-ad3ca7bae9dd');
      q.currApp.app.getObject('FT05', '324649fa-3375-45b5-b358-afe7b2a41437');
      q.currApp.app.getObject('FT06', '5342f52f-e6a6-4d82-90b3-f03195bcc182');
      q.currApp.app.getObject('FT07', '98445841-0d09-4505-91bc-dda7560f03d9');

      q.currApp.app.getObject('EX01', 'AFeyGQ');
      q.currApp.app.getObject('EX02', 'pjQdy');
    });

  }

  ngOnInit(): void {
    this.loadingService.loadVisible = true;
    setTimeout(() => {
      this.loadingService.loadVisible = false;
    }, 3000);
  }


  changeTab(aba: number) {
    console.log(aba);
    this.aba = aba;
    if (this.aba === 1) {

      QSApp('b1809e88-8fe0-47e5-92ef-7fe3877e1c2e', this.config).then((q) => {
        console.log(q);
        q.currApp.app.getObject('QV03', 'JryfaB');
      });
    }
    else if (this.aba === 2) {
      QSApp('b1809e88-8fe0-47e5-92ef-7fe3877e1c2e', this.config).then((q) => {
        console.log(q);
        q.currApp.app.getObject('QV04', 'CJyPR');
      });
    }
    else if (this.aba === 3) {
      QSApp('b1809e88-8fe0-47e5-92ef-7fe3877e1c2e', this.config).then((q) => {
        console.log(q);
        q.currApp.app.getObject('QV05', 'ZJsDLt');
      });
    }


  }

}
