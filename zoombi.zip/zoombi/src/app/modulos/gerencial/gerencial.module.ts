import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GerencialRoutingModule } from './gerencial-routing.module';
import { MatButtonModule } from '@angular/material/button';
import { MatTabsModule } from '@angular/material/tabs';
import { SharedModule } from 'src/app/shared/shared.module';

import { FaturamentoComponent } from './faturamento/faturamento.component';
import { IndCombustiveisComponent } from './ind-combustiveis/ind-combustiveis.component';
import { LogisticoComponent } from './logistico/logistico.component';
import { MotoristasComponent } from './motoristas/motoristas.component';
import { RecebiveisComponent } from './recebiveis/recebiveis.component';
import { PneusComponent } from './pneus/pneus.component';


@NgModule({
  declarations: [
    FaturamentoComponent,
    IndCombustiveisComponent,
    LogisticoComponent,
    MotoristasComponent,
    PneusComponent,
    RecebiveisComponent
  ],
  imports: [
    CommonModule,
    GerencialRoutingModule,
    MatTabsModule,
    MatButtonModule,
    SharedModule
  ]
})
export class GerencialModule { }
