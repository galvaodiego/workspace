import { Component, OnInit } from '@angular/core';
import { LoadingService } from 'src/app/shared/services/loading.service';
import { environment } from 'src/environments/environment';
import { TSQlik, QSApp } from 'ts-qlik';
@Component({
  selector: 'app-motoristas',
  templateUrl: './motoristas.component.html',
  styleUrls: ['./motoristas.component.scss']
})
export class MotoristasComponent implements OnInit {

  qlik = null;

  config = environment.configQlik;

  listaKPI = [
    { id: 'KPI1', img: 'assets/motoristas/rs-faturamento.png', titulo: 'R$ Faturamento' },
    { id: 'KPI3', img: 'assets/motoristas/num-viagens.png', titulo: 'Núm Viagens' },
    { id: 'KPI2', img: 'assets/motoristas/rs-medio.png', titulo: 'R$ Médio' },
    { id: 'KPI4', img: 'assets/motoristas/horas-extras.png', titulo: 'Horas extras' },
    { id: 'KPI5', img: 'assets/motoristas/custo-abastecimento.png', titulo: 'R$ Abastecimento' }
  ];

  constructor(private loadingService: LoadingService) {

    TSQlik(this.config).then((q) => {
      this.qlik = q;
      console.log('TSQlik', q);
    });

    QSApp('fc25a4a7-bb30-48fa-8331-9adeedb3b275', this.config).then((q) => {
      console.log('QSApp', q);
      q.currApp.app.getObject('CurrentSelections', 'CurrentSelections');
      q.currApp.app.getObject('QV01', 'WvySmy');
      q.currApp.app.getObject('QV02', 'HjuRuuN');
      q.currApp.app.getObject('QV03', 'PRHUxc');
      q.currApp.app.getObject('QV04', 'DNKmqQG');
      //DNKmqQG
      q.currApp.app.getObject('KPI1', 'dpJSDP');
      q.currApp.app.getObject('KPI2', 'jAuEB');
      q.currApp.app.getObject('KPI3', 'gYjPDFJ');
      q.currApp.app.getObject('KPI4', 'PNLYWX');
      q.currApp.app.getObject('KPI5', 'JNxvJJ');
      q.currApp.app.getObject('FT01', 'ekrFd');
      q.currApp.app.getObject('FT02', 'GYZfMDR');
      q.currApp.app.getObject('FT03', 'WNuHbYm');
      q.currApp.app.getObject('FT04', 'YRtmYz');

      q.currApp.app.getObject('EX01', 'JhHWeR');
      q.currApp.app.getObject('EX02', 'dFxAzv');
    });

  }

  ngOnInit(): void {
    
    this.loadingService.loadVisible = true;
    setTimeout(() => {
      this.loadingService.loadVisible = false;
    }, 3000);
  }

 
}



