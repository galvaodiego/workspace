import { Component, OnInit } from '@angular/core';
import { LoadingService } from 'src/app/shared/services/loading.service';
import { environment } from 'src/environments/environment';
import { TSQlik, QSApp } from 'ts-qlik'

@Component({
  selector: 'app-recebiveis',
  templateUrl: './recebiveis.component.html',
  styleUrls: ['./recebiveis.component.scss']
})
export class RecebiveisComponent implements OnInit {
  qlik = null;
  config = environment.configQlik;
  constructor(private loadingService: LoadingService) {

    TSQlik(this.config).then((q) => {
      this.qlik = q;
      console.log('TSQlik', q);
    });
    QSApp('d644a52b-5d4d-47bb-baed-008e515eb62a', this.config).then((q) => {
      console.log('QSApp', q);
      q.currApp.app.getObject('CurrentSelections', 'CurrentSelections');
      q.currApp.app.getObject('FT01', 'c09b9fa0-964f-49e2-87dd-a2b2981bb044');
      q.currApp.app.getObject('FT02', 'd7833732-e1ba-4fda-bdb5-c2b6db664f09');
      q.currApp.app.getObject('FT03', '9478f036-bd47-484e-88f9-95639a307839');
      q.currApp.app.getObject('FT04', '6f18a5b1-86a3-46f3-aefb-dd269fdb155b');
      q.currApp.app.getObject('QV01', 'bZPMusM');
      q.currApp.app.getObject('QV02', 'WCQjFvu');
      q.currApp.app.getObject('QV03', 'aZKkmp');
      q.currApp.app.getObject('QV04', 'ddARg');
      q.currApp.app.getObject('KPI1', 'ryJYM');
      q.currApp.app.getObject('KPI2', 'cjRPD');
      q.currApp.app.getObject('KPI3', 'YLnjwN');
      q.currApp.app.getObject('KPI4', 'JVjmQy');

      q.currApp.app.getObject('EX01', 'fpGb');
      q.currApp.app.getObject('EX02', 'Xpzyjga');
    });

  }

  ngOnInit(): void {
    this.loadingService.loadVisible = true;
    setTimeout(() => {
      this.loadingService.loadVisible = false;
    }, 3000);
  }

}
