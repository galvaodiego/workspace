import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnaliseVazioComponent } from './analise-vazio.component';

describe('AnaliseVazioComponent', () => {
  let component: AnaliseVazioComponent;
  let fixture: ComponentFixture<AnaliseVazioComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnaliseVazioComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnaliseVazioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
