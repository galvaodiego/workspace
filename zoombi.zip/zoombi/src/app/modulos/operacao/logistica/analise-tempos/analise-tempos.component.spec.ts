import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnaliseTemposComponent } from './analise-tempos.component';

describe('AnaliseTemposComponent', () => {
  let component: AnaliseTemposComponent;
  let fixture: ComponentFixture<AnaliseTemposComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnaliseTemposComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnaliseTemposComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
