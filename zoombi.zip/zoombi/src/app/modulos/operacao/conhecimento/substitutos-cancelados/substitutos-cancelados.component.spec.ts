import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SubstitutosCanceladosComponent } from './substitutos-cancelados.component';

describe('SubstitutosCanceladosComponent', () => {
  let component: SubstitutosCanceladosComponent;
  let fixture: ComponentFixture<SubstitutosCanceladosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SubstitutosCanceladosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SubstitutosCanceladosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
