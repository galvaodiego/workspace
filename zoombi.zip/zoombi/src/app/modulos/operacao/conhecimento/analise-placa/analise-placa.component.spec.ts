import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnalisePlacaComponent } from './analise-placa.component';

describe('AnalisePlacaComponent', () => {
  let component: AnalisePlacaComponent;
  let fixture: ComponentFixture<AnalisePlacaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnalisePlacaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnalisePlacaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
