import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConhecimentoDashboardComponent } from './conhecimento-dashboard.component';

describe('ConhecimentoDashboardComponent', () => {
  let component: ConhecimentoDashboardComponent;
  let fixture: ComponentFixture<ConhecimentoDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConhecimentoDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConhecimentoDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
