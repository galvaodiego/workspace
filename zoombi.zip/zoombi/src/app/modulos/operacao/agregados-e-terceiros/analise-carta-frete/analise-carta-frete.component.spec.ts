import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnaliseCartaFreteComponent } from './analise-carta-frete.component';

describe('AnaliseCartaFreteComponent', () => {
  let component: AnaliseCartaFreteComponent;
  let fixture: ComponentFixture<AnaliseCartaFreteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnaliseCartaFreteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnaliseCartaFreteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
