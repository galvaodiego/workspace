import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AvulsasComponent } from './avulsas.component';

describe('AvulsasComponent', () => {
  let component: AvulsasComponent;
  let fixture: ComponentFixture<AvulsasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AvulsasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AvulsasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
