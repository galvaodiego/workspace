import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AetDashboardComponent } from './aet-dashboard.component';

describe('AetDashboardComponent', () => {
  let component: AetDashboardComponent;
  let fixture: ComponentFixture<AetDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AetDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AetDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
