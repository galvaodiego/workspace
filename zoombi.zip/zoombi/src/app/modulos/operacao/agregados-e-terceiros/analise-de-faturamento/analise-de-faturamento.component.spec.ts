import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnaliseDeFaturamentoComponent } from './analise-de-faturamento.component';

describe('AnaliseDeFaturamentoComponent', () => {
  let component: AnaliseDeFaturamentoComponent;
  let fixture: ComponentFixture<AnaliseDeFaturamentoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnaliseDeFaturamentoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnaliseDeFaturamentoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
