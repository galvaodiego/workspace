import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnaliseFreteUnitarioComponent } from './analise-frete-unitario.component';

describe('AnaliseFreteUnitarioComponent', () => {
  let component: AnaliseFreteUnitarioComponent;
  let fixture: ComponentFixture<AnaliseFreteUnitarioComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnaliseFreteUnitarioComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnaliseFreteUnitarioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
