import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnaliseDeContratoComponent } from './analise-de-contrato.component';

describe('AnaliseDeContratoComponent', () => {
  let component: AnaliseDeContratoComponent;
  let fixture: ComponentFixture<AnaliseDeContratoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnaliseDeContratoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnaliseDeContratoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
