import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NotFoundComponent } from '../pages/not-found/not-found.component';
import { AetDashboardComponent } from './agregados-e-terceiros/aet-dashboard/aet-dashboard.component';
import { AnaliseCartaFreteComponent } from './agregados-e-terceiros/analise-carta-frete/analise-carta-frete.component';
import { AnaliseDeContratoComponent } from './agregados-e-terceiros/analise-de-contrato/analise-de-contrato.component';
import { AnaliseDeFaturamentoComponent } from './agregados-e-terceiros/analise-de-faturamento/analise-de-faturamento.component';
import { AnaliseFreteUnitarioComponent } from './agregados-e-terceiros/analise-frete-unitario/analise-frete-unitario.component';
import { AvulsasComponent } from './agregados-e-terceiros/avulsas/avulsas.component';
import { DetalhamentoComponent } from './agregados-e-terceiros/detalhamento/detalhamento.component';
import { PedagioComponent } from './agregados-e-terceiros/pedagio/pedagio.component';
import { AnalisePlacaComponent } from './conhecimento/analise-placa/analise-placa.component';
import { ConhecimentoDashboardComponent } from './conhecimento/conhecimento-dashboard/conhecimento-dashboard.component';
import { SubstitutosCanceladosComponent } from './conhecimento/substitutos-cancelados/substitutos-cancelados.component';
import { EvolucaoFaturamentoComponent } from './faturamento/evolucao-faturamento/evolucao-faturamento.component';
import { EvolucaoToneladasComponent } from './faturamento/evolucao-toneladas/evolucao-toneladas.component';
import { FaturamentoAnalisekmComponent } from './faturamento/faturamento-analisekm/faturamento-analisekm.component';
import { FaturamentoDashboardComponent } from './faturamento/faturamento-dashboard/faturamento-dashboard.component';
import { FaturamentoDetalhadoComponent } from './faturamento/faturamento-detalhado/faturamento-detalhado.component';
import { AnaliseCarregadoComponent } from './logistica/analise-carregado/analise-carregado.component';
import { AnaliseTemposComponent } from './logistica/analise-tempos/analise-tempos.component';
import { AnaliseVazioComponent } from './logistica/analise-vazio/analise-vazio.component';


const routes: Routes = [
  { path: '', redirectTo: 'faturamento', pathMatch: 'full' },
  {
    path: 'faturamento',
    children: [
      { path: 'principal', component: FaturamentoDashboardComponent },
      { path: 'evolucao-faturamento', component: EvolucaoFaturamentoComponent },
      { path: 'evolucao-toneladas', component: EvolucaoToneladasComponent },
      { path: 'faturamento-detalhado', component: FaturamentoDetalhadoComponent },
      { path: 'analise-de-km', component: FaturamentoAnalisekmComponent },
      { path: '', redirectTo: 'principal', pathMatch: 'full' },
    ]
  },
  {
    path: 'logistica',
    children: [
      { path: 'analise-de-tempos', component: AnaliseTemposComponent },
      { path: 'analise-de-km-carregado', component: AnaliseCarregadoComponent },
      { path: 'analise-de-km-vazio', component: AnaliseVazioComponent },
      { path: '', redirectTo: 'analise-de-tempos', pathMatch: 'full' },
    ]
  },
  {
    path: 'conhecimento',
    children: [
      { path: 'principal', component: ConhecimentoDashboardComponent },
      { path: 'substitutos-e-cancelados', component: SubstitutosCanceladosComponent },
      { path: 'analise-por-placa', component: AnalisePlacaComponent },
      { path: '', redirectTo: 'principal', pathMatch: 'full' },
    ]
  },
  {
    path: 'agregados-e-terceiros',
    children: [
      { path: 'principal', component: AetDashboardComponent },
      { path: 'analise-de-faturamento', component: AnaliseDeFaturamentoComponent },
      { path: 'analise-frete-unitario', component: AnaliseFreteUnitarioComponent },
      { path: 'pedagio', component: PedagioComponent },
      { path: 'analise-carta-frete', component: AnaliseCartaFreteComponent },
      { path: 'analise-de-contrato', component: AnaliseDeContratoComponent },
      { path: 'avulsas', component: AvulsasComponent },
      { path: 'detalhamento', component: DetalhamentoComponent },
      { path: '', redirectTo: 'principal', pathMatch: 'full' },
    ]
  },
  { path: '**', component: NotFoundComponent },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class OperacaoRoutingModule { }
