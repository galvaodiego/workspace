import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FaturamentoAnalisekmComponent } from './faturamento-analisekm.component';

describe('FaturamentoAnalisekmComponent', () => {
  let component: FaturamentoAnalisekmComponent;
  let fixture: ComponentFixture<FaturamentoAnalisekmComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FaturamentoAnalisekmComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FaturamentoAnalisekmComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
