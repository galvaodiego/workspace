import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FaturamentoDashboardComponent } from './faturamento-dashboard.component';

describe('FaturamentoDashboardComponent', () => {
  let component: FaturamentoDashboardComponent;
  let fixture: ComponentFixture<FaturamentoDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FaturamentoDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FaturamentoDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
