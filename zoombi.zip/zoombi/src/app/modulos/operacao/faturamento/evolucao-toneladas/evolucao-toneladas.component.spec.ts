import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EvolucaoToneladasComponent } from './evolucao-toneladas.component';

describe('EvolucaoToneladasComponent', () => {
  let component: EvolucaoToneladasComponent;
  let fixture: ComponentFixture<EvolucaoToneladasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EvolucaoToneladasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EvolucaoToneladasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
