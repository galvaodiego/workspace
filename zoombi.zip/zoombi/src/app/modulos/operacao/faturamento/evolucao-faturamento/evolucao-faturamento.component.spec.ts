import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EvolucaoFaturamentoComponent } from './evolucao-faturamento.component';

describe('EvolucaoFaturamentoComponent', () => {
  let component: EvolucaoFaturamentoComponent;
  let fixture: ComponentFixture<EvolucaoFaturamentoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EvolucaoFaturamentoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EvolucaoFaturamentoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
