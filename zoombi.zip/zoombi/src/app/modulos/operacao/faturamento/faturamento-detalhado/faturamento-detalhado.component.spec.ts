import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FaturamentoDetalhadoComponent } from './faturamento-detalhado.component';

describe('FaturamentoDetalhadoComponent', () => {
  let component: FaturamentoDetalhadoComponent;
  let fixture: ComponentFixture<FaturamentoDetalhadoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FaturamentoDetalhadoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FaturamentoDetalhadoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
