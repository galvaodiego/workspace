import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from 'src/app/shared/shared.module';
import { MatButtonModule } from '@angular/material/button';
import { MatSnackBarModule } from '@angular/material/snack-bar';

import { OperacaoRoutingModule } from './operacao-routing.module';
import { FaturamentoDashboardComponent } from './faturamento/faturamento-dashboard/faturamento-dashboard.component';
import { EvolucaoFaturamentoComponent } from './faturamento/evolucao-faturamento/evolucao-faturamento.component';
import { EvolucaoToneladasComponent } from './faturamento/evolucao-toneladas/evolucao-toneladas.component';
import { FaturamentoDetalhadoComponent } from './faturamento/faturamento-detalhado/faturamento-detalhado.component';
import { FaturamentoAnalisekmComponent } from './faturamento/faturamento-analisekm/faturamento-analisekm.component';
import { AnaliseTemposComponent } from './logistica/analise-tempos/analise-tempos.component';
import { AnaliseCarregadoComponent } from './logistica/analise-carregado/analise-carregado.component';
import { AnaliseVazioComponent } from './logistica/analise-vazio/analise-vazio.component';
import { ConhecimentoDashboardComponent } from './conhecimento/conhecimento-dashboard/conhecimento-dashboard.component';
import { SubstitutosCanceladosComponent } from './conhecimento/substitutos-cancelados/substitutos-cancelados.component';
import { AnalisePlacaComponent } from './conhecimento/analise-placa/analise-placa.component';
import { AetDashboardComponent } from './agregados-e-terceiros/aet-dashboard/aet-dashboard.component';
import { AnaliseDeFaturamentoComponent } from './agregados-e-terceiros/analise-de-faturamento/analise-de-faturamento.component';
import { AnaliseFreteUnitarioComponent } from './agregados-e-terceiros/analise-frete-unitario/analise-frete-unitario.component';
import { PedagioComponent } from './agregados-e-terceiros/pedagio/pedagio.component';
import { AnaliseCartaFreteComponent } from './agregados-e-terceiros/analise-carta-frete/analise-carta-frete.component';
import { AnaliseDeContratoComponent } from './agregados-e-terceiros/analise-de-contrato/analise-de-contrato.component';
import { AvulsasComponent } from './agregados-e-terceiros/avulsas/avulsas.component';
import { DetalhamentoComponent } from './agregados-e-terceiros/detalhamento/detalhamento.component';




@NgModule({
  declarations: [FaturamentoDashboardComponent, EvolucaoFaturamentoComponent, EvolucaoToneladasComponent, FaturamentoDetalhadoComponent, FaturamentoAnalisekmComponent, AnaliseTemposComponent, AnaliseCarregadoComponent, AnaliseVazioComponent, ConhecimentoDashboardComponent, SubstitutosCanceladosComponent, AnalisePlacaComponent, AetDashboardComponent, AnaliseDeFaturamentoComponent, AnaliseFreteUnitarioComponent, PedagioComponent, AnaliseCartaFreteComponent, AnaliseDeContratoComponent, AvulsasComponent, DetalhamentoComponent],
  imports: [
    CommonModule,
    OperacaoRoutingModule,
    SharedModule,
    MatButtonModule,
    MatSnackBarModule
  ]
})
export class OperacaoModule { }
