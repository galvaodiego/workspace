import { Component, Input, OnInit } from '@angular/core';
import { ToolsService } from '../services/tools.service';

@Component({
  selector: 'app-frame-body',
  templateUrl: './frame-body.component.html',
  styleUrls: ['./frame-body.component.scss']
})
export class FrameBodyComponent implements OnInit {
  @Input() componentes;
  @Input() id;
  @Input() customStyle;
  constructor(public tools: ToolsService) { }

  ngOnInit(): void {
  }

}
