import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  url = environment.api;
  constructor(
    private http: HttpClient,
  ) { }

  // tslint:disable-next-line: typedef
  public backendCall(operation: string, parameters?: any) {
    let headers: HttpHeaders = new HttpHeaders();
    if (parameters == null) {
      parameters = {};
    }

    const requestData: any = {
      parameters
    };

    headers = headers.append('Content-Type', 'application/json');
    const url = this.url + '/' + operation;
    console.log('Requisição a api: ', url, requestData);
    return new Promise((resolvePai, rejectPai) => {
      this.send(url, requestData, headers).then(
        (data) => {
          if (data.result != null) {
            resolvePai(data.result);
          } else {
            resolvePai(data);
          }
        }
      ).catch(dataError => {
        console.log('dataError', dataError);
        rejectPai(dataError);
      }
      );
    });
  }

  // tslint:disable-next-line: deprecation
  public send(url: string, requestData: any, headers: HttpHeaders): Promise<any> {
    return new Promise((resolve, reject) => {
      this.http.post(url, JSON.stringify(requestData), { headers }).subscribe(
        data => resolve(data),
        err => reject(err));
    });

  }

}
