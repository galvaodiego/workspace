import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';


@Injectable({
   providedIn: 'root'
})
export class GatewayService {
   url = 'http://kmm.com.br/_remote/gateway.php';
   constructor(
      private http: HttpClient,
      private router: Router,
   ) { }

   // tslint:disable-next-line: typedef
   public backendCall(module: string, operation: string, parameters?: any) {
      let headers: HttpHeaders = new HttpHeaders();
      if (parameters == null) {
         parameters = {};
      }

      const requestData: any = {
         module,
         operation,
         parameters
      };

      headers = headers.append('Content-Type', 'application/json');
      // @TODO PRECISA DE UM METODO LOGON PARA LOGAR E PEGAR O TOKEN E PASSAR NA CHAMADA A BAIXO.

      // if (this.user.token) {
      //    headers = headers.append('Authorization', 'Bearer ' + this.user.token);
      // } else {
      //    headers = headers.append('Token-Time-Hours', (180 * 24) + ''); // 180 dias
      // }

      headers = headers.append('KMM-Platform', 'Web');
      console.log('Requisição ao banco: ', requestData);

      return new Promise((resolvePai, rejectPai) => {
         this.send(this.url, requestData, headers).then(
            (data) => {
               // data = data.json();
               if (data.result != null) {
                  resolvePai(data.result);
               } else {
                  resolvePai(data);
               }
            }
         ).catch(dataError => {
            // dataError = dataError.json();
            console.log('dataError', dataError);

            // Não autorizado - Quando o token é inválido ou expirado
            if (dataError.code === 401) {
               // this.user.logout();
            } else if (dataError.code === 403) {
               console.log('dataError', dataError);
               // this.user.logout();
               this.router.navigate(['']);
               rejectPai(dataError);
            } else if (dataError.code === 404) {
               // this.user.logout();
            } else {
               try {
                  console.log('dataError', dataError);
               } catch (er) { }
               rejectPai(dataError); // Chama o reject do promise de retorno
            }
         }
         );
      });
   }

   // tslint:disable-next-line: deprecation
   public send(url: string, requestData: any, headers: HttpHeaders): Promise<any> {
      return new Promise((resolve, reject) => {
         this.http.post(url, JSON.stringify(requestData), { headers }).subscribe(
            data => resolve(data),
            err => reject(err));
      });

   }
}
