import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ToolsService {
  tsqlik: any = new BehaviorSubject({});
  empresa = new BehaviorSubject('KMM');
  userName = new BehaviorSubject('DEV');
  pacotesMenu = new BehaviorSubject([]);
  constructor() { }

  filtraComponente(componente: any, id: string) {
    if (componente) {
      const c: Array<any> = componente.filter(res => res.componente === id);
      return c[0];
    }
  }
}

export class Componente {
  aba: string;
  componente: string;
  hash: string;
  iframe: string;
  subtitulo: string;
  titulo: string;
}
