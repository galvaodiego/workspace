import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class NavbarService {
  openMenu: Subject<boolean> = new Subject<boolean>();
  constructor() { }
  changeValue(v: boolean) {
    this.openMenu.next(v);
  }
}
