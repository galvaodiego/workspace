import { Component, Input, OnInit } from '@angular/core';
import { ToolsService } from '../services/tools.service';

@Component({
  selector: 'app-filtro',
  templateUrl: './filtro.component.html',
  styleUrls: ['./filtro.component.scss']
})
export class FiltroComponent implements OnInit {
  @Input() componentes;
  @Input() filtros;
  constructor(public tools: ToolsService) { }

  ngOnInit(): void {
  }

}
