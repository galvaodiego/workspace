import { Component, OnInit } from '@angular/core';
import { NavbarService } from '../services/navbar.service';

@Component({
  selector: 'app-toolbar-filter',
  templateUrl: './toolbar-filter.component.html',
  styleUrls: ['./toolbar-filter.component.scss']
})
export class ToolbarFilterComponent implements OnInit {
  isShown = false;
  showMenu = false;

  constructor(
    private navbarService: NavbarService,

  ) {}

  ngOnInit(): void {
  }
  toggle() {
    this.isShown = !this.isShown;
  }

  openMenu() {
    this.showMenu = !this.showMenu;
    this.navbarService.changeValue(this.showMenu);
  }
}
