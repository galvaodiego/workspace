import { Component, OnInit } from '@angular/core';
import { NavbarService } from '../services/navbar.service';

@Component({
  selector: 'app-calendar-filter',
  templateUrl: './calendar-filter.component.html',
  styleUrls: ['./calendar-filter.component.scss']
})
export class CalendarFilterComponent implements OnInit {

  isShown = false;
  showMenu = false;

  constructor(
    private navbarService: NavbarService,

  ) {}

  ngOnInit(): void {
  }
  toggle() {
    this.isShown = !this.isShown;
  }

  openMenu() {
    this.showMenu = !this.showMenu;
    // this.navbarService.changeValue(this.showMenu);
  }

}
