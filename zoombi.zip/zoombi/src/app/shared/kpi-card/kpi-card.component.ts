import { Component, Input, OnInit } from '@angular/core';
import { ToolsService } from '../services/tools.service';

@Component({
  selector: 'app-kpi-card',
  templateUrl: './kpi-card.component.html',
  styleUrls: ['./kpi-card.component.scss']
})
export class KpiCardComponent implements OnInit {
  @Input() componentes;
  @Input() id;
  @Input() icone;
  constructor(public tools: ToolsService) { }

  ngOnInit(): void {
  }

}
