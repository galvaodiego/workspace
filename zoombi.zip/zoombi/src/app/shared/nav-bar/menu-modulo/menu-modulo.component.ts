import { Component, OnInit } from '@angular/core';
import { ToolsService } from '../../services/tools.service';
import { DomSanitizer } from '@angular/platform-browser';
import { MatIconRegistry } from '@angular/material/icon';
@Component({
  selector: 'app-menu-modulo',
  templateUrl: './menu-modulo.component.html',
  styleUrls: ['./menu-modulo.component.scss']
})
export class MenuModuloComponent implements OnInit {
  modGerencial = [
    { routerLink: 'gerencial/faturamento', title: 'Faturamento', icon: 'assets/icones/faturamento.png', description: 'Faturamento', },
    { routerLink: 'gerencial/logistico', title: 'Logístico', icon: 'assets/icones/logistico.png', description: 'Logístico' },
    { routerLink: 'gerencial/ind-combustiveis', title: 'Ind. Combustíveis', icon: 'assets/icones/indCombustiveis.png', description: 'Ind. Combustíveis' },
    { routerLink: 'gerencial/pneus', title: 'Pneus', icon: 'assets/icones/pneus.png', description: 'Pneus' },
    { routerLink: 'gerencial/motoristas', title: 'Motoristas', icon: 'assets/icones/motoristas.png', description: 'Motoristas' },
    { routerLink: 'gerencial/recebiveis', title: 'Recebíveis', icon: 'assets/icones/recebiveis.png', description: 'Recebíveis' },
  ];

  menu = [];
  clicked: string;
  constructor(
    private tools: ToolsService,
    iconRegistry: MatIconRegistry,
    sanitizer: DomSanitizer
  ) {
    iconRegistry.addSvgIcon('gerencial', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/menu-icon/gerencial.svg'));
    iconRegistry.addSvgIcon('frota', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/menu-icon/frota.svg'));
    iconRegistry.addSvgIcon('operacao', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/menu-icon/operacao.svg'));
    iconRegistry.addSvgIcon('financas', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/menu-icon/financas.svg'));

    iconRegistry.addSvgIcon('gerencial-white', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/menu-icon/gerencial-white.svg'));
    iconRegistry.addSvgIcon('frota-white', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/menu-icon/frota-white.svg'));
    iconRegistry.addSvgIcon('operacao-white', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/menu-icon/operacao-white.svg'));
    iconRegistry.addSvgIcon('financas-white', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/menu-icon/financas-white.svg'));

    this.tools.pacotesMenu.subscribe(res => {
      // console.log('update pacotesMenu', res);
      this.menu = res;
    });
  }

  ngOnInit(): void {
  }

  ajustaClicked(ev) {
    this.clicked = null;
  }

}
