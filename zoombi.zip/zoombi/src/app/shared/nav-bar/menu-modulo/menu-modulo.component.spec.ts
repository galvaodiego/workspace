import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MenuModuloComponent } from './menu-modulo.component';

describe('MenuModuloComponent', () => {
  let component: MenuModuloComponent;
  let fixture: ComponentFixture<MenuModuloComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MenuModuloComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MenuModuloComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
