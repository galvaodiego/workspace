import { Component, OnInit, ViewChild } from '@angular/core';
import { MatSidenav } from '@angular/material/sidenav';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { ApiService } from '../services/api.service';
import { NavbarService } from '../services/navbar.service';
import { ToolsService } from '../services/tools.service';

@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.scss']
})
export class NavBarComponent implements OnInit {
  @ViewChild('snav') snav: MatSidenav;
  listLink = [
    { routerLink: 'gerencial/faturamento', title: 'Faturamento', icon: 'assets/icones/faturamento.png', description: 'Faturamento', },
    { routerLink: 'gerencial/logistico', title: 'Logístico', icon: 'assets/icones/logistico.png', description: 'Logístico' },
    { routerLink: 'gerencial/ind-combustiveis', title: 'Ind. Combustíveis', icon: 'assets/icones/indCombustiveis.png', description: 'Ind. Combustíveis' },
    { routerLink: 'gerencial/pneus', title: 'Pneus', icon: 'assets/icones/pneus.png', description: 'Pneus' },
    { routerLink: 'gerencial/motoristas', title: 'Motoristas', icon: 'assets/icones/motoristas.png', description: 'Motoristas' },
    { routerLink: 'gerencial/recebiveis', title: 'Recebíveis', icon: 'assets/icones/recebiveis.png', description: 'Recebíveis' },
  ];
  sideTitle = 'ZoomBI';
  openMenu: boolean;
  empresa: string;
  userName: string;
  showMenu: boolean;
  showSair = false;
  constructor(
    private navbarService: NavbarService,
    private tools: ToolsService,
    private cookies: CookieService,
    private router: Router,
    private api: ApiService
  ) {
    this.tools.empresa.subscribe(res => {
      this.empresa = res
    });
    this.tools.userName.subscribe(res => {
      this.userName = res;
    });
  }

  ngOnInit(): void {

    const sessao = sessionStorage.getItem('usuario')
    if (sessao) {
      const cookie = this.cookies.get('X-Qlik-Session-External');
      if (cookie) {
        this.showSair = true;
      } else {
        this.showSair = false;
      }
    } else {
      this.showSair = false;
    }

    this.navbarService.openMenu.subscribe(res => {
      this.openMenu = res;
      this.snav.toggle();
    });
  }

  logout() {
    const session = sessionStorage.getItem('usuario');
    let nome_usuario = '';
    if (session) {
      nome_usuario = session;
    }
    this.api.backendCall('zoombi/logout', { usuario: nome_usuario })
      .then(() => {
        sessionStorage.removeItem('usuario');
        this.cookies.delete('X-Qlik-Session-External', '/', '.kmm.com.br');
        this.cookies.delete('usuario', '/', '.kmm.com.br');
        this.router.navigate(['/pages/home']);
        location.reload();
      })
      .catch(err => console.log('ERRO NO LOGOUT:', err));
  }

  goHome() {
    this.router.navigate(['/pages/home']);
  }

}
