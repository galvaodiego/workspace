import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';


@Component({
  selector: 'app-bread-crumb',
  templateUrl: './bread-crumb.component.html',
  styleUrls: ['./bread-crumb.component.scss']
})
export class BreadCrumbComponent implements OnInit {
  bc: Array<any> = [];
  constructor(
    private router: Router
  ) { }

  ngOnInit(): void {

    this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe((res:any) => {
        this.bc = res.url.split('/');
        this.bc.shift();
        // console.log(this.bc, '------');
      });
  }

  tratar(texto:string){
    let temp = texto;
    switch(texto){
      case 'frota':
        temp = 'Frota';
        break;
      case 'motoristas':
        temp = 'Motoristas';
        break;
      case 'principal':
        temp = 'Principal';
        break;
      case 'infracoes':
        temp = 'Infrações';
        break;
      case 'analise-sobre-km':
        temp = 'Análise sobre KM';
        break;
      case 'ocorrencias':
        temp = 'Ocorrências';
        break;
      case 'horas-extras':
        temp = 'Horas extras';
        break;
      case 'logistico':
        temp = 'Logístico';
        break;
      case 'ind-combustiveis':
        temp = 'Ind. Combustíveis';
        break;
      case 'recebiveis':
        temp = 'Recebíveis';
        break;
      case 'combustiveis':
        temp = 'Combustíveis';
        break;
      case 'analise-de-volume':
        temp = 'Análise de volume';
        break;
      case 'negociacao':
        temp = 'Negociação';
        break;
      case 'analise-de-medias':
        temp = 'Análise de médias';
        break;
      case 'pneus':
        temp = 'Pneus';
        break;
      case 'aquisicao':
        temp = 'Aquisição';
        break;
      case 'pneus-em-estoque':
        temp = 'Pneus em estoque';
        break;
      case 'movimentacoes':
        temp = 'Movimentações';
        break;
      case 'inspecoes':
        temp = 'Inspeções';
        break;
      case 'desempenho-detalhes':
        temp = 'Desempenho - Detalhes';
        break;
      case 'cpk-detalhes':
        temp = 'CPK - Detalhes';
        break;
      case 'manutencao':
        temp = 'Manutenção';
        break;
      case 'ordens-de-servico-abertas':
        temp = 'O.S. abertas';
        break;
      case 'tempo-em-execucao':
        temp = 'Tempo em execução';
        break;
      case 'detalhamento-de-item':
        temp = 'Detal. de itens';
        break;
      case 'compras':
        temp = 'Compras';
        break;
      case 'mashup':
        temp = 'Mashup';
        break;
      case 'pages':
        temp = 'Pages';
        break;
      case 'home':
        temp = 'Home';
        break;
      case 'sucateamento':
        temp = 'Sucateamento';
        break;
      case 'desempenho':
        temp = 'Desempenho';
        break;
      case 'reforma':
        temp = 'Reforma';
        break;
      case 'dashboard':
        temp = 'Dashboard';
        break;
      case 'jornada':
        temp = 'Jornada';
        break;
      case 'viagens':
        temp = 'Viagens';
        break;
      case 'operacao':
        temp = 'Operação';
        break;
      case 'faturamento':
        temp = 'Faturamento';
        break;
      case 'evolucao-faturamento':
        temp = 'Evolução Fat.';
        break;
      case 'evolucao-toneladas':
        temp = 'Evolução Ton.';
        break;
      case 'faturamento-detalhado':
        temp = 'Fat. Detalhado';
        break;
      case 'analise-de-km':
        temp = 'Análise de KM';
        break;
      case 'logistica':
        temp = 'Logística';
        break;
      case 'analise-de-tempos':
        temp = 'Análise de Tempos';
        break;
      case 'analise-de-km-carregado':
        temp = 'Análise:KM Carregado';
        break;
      case 'analise-de-km-vazio':
        temp = 'Análise:KM Vazio';
        break;
      case 'conhecimento':
        temp = 'Conhecimento';
        break;
      case 'substitutos-e-cancelados':
        temp = 'Subst./Cancel.';
        break;
      case 'analise-por-placa':
        temp = 'Análise por Placa';
        break;
      case 'financas':
        temp = 'Finanças';
        break;
      case 'fluxo-caixa':
        temp = 'Fluxo Caixa';
        break;
      case 'a-receber':
        temp = 'A Receber';
        break;
      case 'a-receber-graficos':
        temp = 'A Receber - Gráficos';
        break;
      case 'a-pagar':
        temp = 'A Pagar';
        break;
      case 'a-pagar-graficos':
        temp = 'A Pagar - Gráficos';
        break;
      case 'car':
        temp = 'CAR';
        break;
      case 'analise-mensal':
        temp = 'Análise Mensal';
        break;
      case 'inadimplencia':
        temp = 'Inadimplência';
        break;
      case 'a-faturar':
        temp = 'A Faturar';
        break;
      case 'financiamentos':
        temp = 'Financiamentos';
        break;
      case 'contratos':
        temp = 'Contratos';
        break;
      case 'parcelas':
        temp = 'Parcelas';
        break;
      case 'arrendadoras':
        temp = 'Arrendadoras';
        break;
      case 'endividamento':
        temp = 'Endividamento';
        break;
      case 'dre':
        temp = 'DRE';
        break;
      case 'dre-gestao':
        temp = 'DRE Gestão';
        break;
      case 'evolucao-mensal':
        temp = 'Evolução Mensal';
        break;
      case 'analise-ccg':
        temp = 'Análise CCG';
        break;
      case 'base-contabil':
        temp = 'Base Contábil';
        break;
      case 'analise-frota':
        temp = 'Análise: Frota';
        break;
      case 'agregados-e-terceiros':
        temp = 'Agregados e Terceiros';
        break;
      case 'analise-de-faturamento':
        temp = 'Faturamento';
        break;
      case 'analise-frete-unitario':
        temp = 'Frete unit.';
        break;
      case 'pedagio':
        temp = 'Pedágio';
        break;
      case 'analise-carta-frete':
        temp = 'Carta Frete';
        break;
      case 'analise-de-contrato':
        temp = 'Contrato';
        break;
      case 'avulsas':
        temp = 'Avulsas';
        break;
      case 'detalhamento':
        temp = 'Detalhamento';
        break;
    }
    return temp;
  }

}
