import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { NavBarComponent } from './nav-bar/nav-bar.component';

import { MatSidenavModule } from '@angular/material/sidenav';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatListModule } from '@angular/material/list';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatMenuModule } from '@angular/material/menu';
import { ToolbarFilterComponent } from './toolbar-filter/toolbar-filter.component';
import { SpinnerLoaderComponent } from './spinner-loader/spinner-loader.component';
import { HttpClientModule } from '@angular/common/http';
import { MenuModuloComponent } from './nav-bar/menu-modulo/menu-modulo.component';
import { KpiComponent } from './kpi/kpi.component';
import { BreadCrumbComponent } from './bread-crumb/bread-crumb.component';
import { CalendarFilterComponent } from './calendar-filter/calendar-filter.component';
import { QlikFrameComponent } from './qlik-frame/qlik-frame.component';
import { FiltroComponent } from './filtro/filtro.component';
import { BarraComponent } from './barra/barra.component';
import { QvCardComponent } from './qv-card/qv-card.component';
import { KpiCardComponent } from './kpi-card/kpi-card.component';
import { FrameBodyComponent } from './frame-body/frame-body.component';
import { FrameFiltroComponent } from './frame-filtro/frame-filtro.component';
import { TemplateComponent } from './template/template.component';

@NgModule({
  declarations: [
    NavBarComponent, 
    ToolbarFilterComponent, 
    SpinnerLoaderComponent, 
    MenuModuloComponent, 
    KpiComponent, 
    BreadCrumbComponent,
    CalendarFilterComponent, 
    QlikFrameComponent, 
    FiltroComponent, 
    BarraComponent, 
    QvCardComponent, 
    KpiCardComponent, 
    FrameBodyComponent, 
    FrameFiltroComponent, TemplateComponent
  ],
  imports: [
    CommonModule,
    RouterModule,
    HttpClientModule,
    MatSidenavModule,
    MatIconModule,
    MatListModule,
    MatToolbarModule,
    MatButtonModule,
    MatMenuModule,
    MatTooltipModule
  ],
  exports: [
    NavBarComponent, 
    ToolbarFilterComponent, 
    SpinnerLoaderComponent, 
    KpiComponent, 
    BreadCrumbComponent, 
    CalendarFilterComponent,
    QlikFrameComponent,
    FiltroComponent,
    BarraComponent,
    QvCardComponent,
    KpiCardComponent,
    FrameBodyComponent,
    FrameFiltroComponent,
    TemplateComponent
  ]
})
export class SharedModule { }
