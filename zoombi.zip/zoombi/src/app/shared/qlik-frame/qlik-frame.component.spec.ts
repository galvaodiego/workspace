import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QlikFrameComponent } from './qlik-frame.component';

describe('QlikFrameComponent', () => {
  let component: QlikFrameComponent;
  let fixture: ComponentFixture<QlikFrameComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QlikFrameComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QlikFrameComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
