import { Component, ElementRef, Input, OnChanges, SimpleChanges, ViewChild } from '@angular/core';

import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-qlik-frame',
  templateUrl: './qlik-frame.component.html',
  styleUrls: ['./qlik-frame.component.scss']
})
export class QlikFrameComponent implements OnChanges {
  @ViewChild('iframe', { static: true }) iframe: ElementRef
  @Input() src: string;
  srcUrl: any;
  constructor(private sanitizer: DomSanitizer) { }

  ngOnChanges(changes: SimpleChanges): void {
    this.srcUrl = this.sanitizer.bypassSecurityTrustResourceUrl(this.src);
    // this.srcUrl = this.sanitizer.bypassSecurityTrustResourceUrl('https://qliksense.kmm.com.br/ext/single/?appid=4135889c-976d-4185-bfe9-385539e5d96f&sheet=c96bc282-8606-48cb-b8e1-89ee759e875f&opt=nointeraction&select=clearall');
    // this.srcUrl = this.sanitizer.bypassSecurityTrustResourceUrl('https://qliksense.kmm.com.br/ext/single/?appid=4135889c-976d-4185-bfe9-385539e5d96f&sheet=b7420dc8-98c8-434d-8ee1-5dac08b4486f&opt=currsel&select=clearall');
    // let doc =  this.iframe.nativeElement.contentDocument || this.iframe.nativeElement.contentWindow;
    // console.log('iframe', doc);
  }

  myLoad(e) {
    // console.log('...', e);
    // console.log(e.target);
    if (e.target !== null) {

    }
  }




}
