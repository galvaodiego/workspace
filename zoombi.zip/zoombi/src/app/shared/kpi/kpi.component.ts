import { Component, Input, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { MatIconRegistry } from '@angular/material/icon';
@Component({
  selector: 'app-kpi',
  templateUrl: './kpi.component.html',
  styleUrls: ['./kpi.component.scss']
})
export class KpiComponent implements OnInit {
  @Input() titulo: string;
  @Input() valor: string;
  @Input() icone: string = 'total-de-motoristas';

  constructor(iconRegistry: MatIconRegistry, sanitizer: DomSanitizer) {
    iconRegistry.addSvgIcon('worker', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/worker.svg'));
    iconRegistry.addSvgIcon('truck-time', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/truck-time.svg'));
    iconRegistry.addSvgIcon('route-marker', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/route-marker.svg'));
    iconRegistry.addSvgIcon('case-time', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/case-time.svg'));
    iconRegistry.addSvgIcon('box-warning', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/box-warning.svg'));
    iconRegistry.addSvgIcon('map-marker', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/map-marker.svg'));
    iconRegistry.addSvgIcon('box-money', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/box-money.svg'));
    iconRegistry.addSvgIcon('cloud-percent', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/cloud-percent.svg'));
    iconRegistry.addSvgIcon('paste-user', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/paste-user.svg'));
    iconRegistry.addSvgIcon('hourglass', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/hourglass.svg'));
    iconRegistry.addSvgIcon('funnel-money', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/funnel-money.svg'));
    iconRegistry.addSvgIcon('circle-money', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/circle-money.svg'));
    iconRegistry.addSvgIcon('truck', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/truck.svg'));
    iconRegistry.addSvgIcon('truck2', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/truck2.svg'));
    iconRegistry.addSvgIcon('truck-white', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/truck-white.svg'));
    iconRegistry.addSvgIcon('truck-speed', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/truck-speed.svg'));
    iconRegistry.addSvgIcon('file-money', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/file-money.svg'));
    iconRegistry.addSvgIcon('gas-pump', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/gas-pump.svg'));
    iconRegistry.addSvgIcon('gauge', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/gauge.svg'));
    iconRegistry.addSvgIcon('gauge2', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/gauge2.svg'));
    iconRegistry.addSvgIcon('wheel', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/wheel.svg'));
    iconRegistry.addSvgIcon('wheel2', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/wheel2.svg'));
    iconRegistry.addSvgIcon('wheel-half', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/wheel-half.svg'));
    iconRegistry.addSvgIcon('find-money', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/find-money.svg'));
    iconRegistry.addSvgIcon('box-stuff', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/box-stuff.svg'));
    iconRegistry.addSvgIcon('bullseye', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/bullseye.svg'));
    iconRegistry.addSvgIcon('clipboard', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/clipboard.svg'));
    iconRegistry.addSvgIcon('tools', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/tools.svg'));
    iconRegistry.addSvgIcon('file-search', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/file-search.svg'));
    iconRegistry.addSvgIcon('cancel', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/cancel.svg'));
    iconRegistry.addSvgIcon('clipboard-check', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/clipboard-check.svg'));
    iconRegistry.addSvgIcon('road', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/road.svg'));
    iconRegistry.addSvgIcon('warning', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/warning.svg'));
    iconRegistry.addSvgIcon('checklist', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/checklist.svg'));
    iconRegistry.addSvgIcon('checklist-white', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/checklist-white.svg'));
    iconRegistry.addSvgIcon('money', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/money.svg'));
    iconRegistry.addSvgIcon('money-bag', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/money-bag.svg'));
    iconRegistry.addSvgIcon('money-bag2', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/money-bag2.svg'));
    iconRegistry.addSvgIcon('gears', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/gears.svg'));
    iconRegistry.addSvgIcon('list', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/list.svg'));
    iconRegistry.addSvgIcon('coins', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/coins.svg'));
    iconRegistry.addSvgIcon('weight', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/weight.svg'));
    iconRegistry.addSvgIcon('file-up', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/file-up.svg'));
    iconRegistry.addSvgIcon('forklift', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/forklift.svg'));
    iconRegistry.addSvgIcon('forklift2', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/forklift2.svg'));
    iconRegistry.addSvgIcon('file', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/file.svg'));
    iconRegistry.addSvgIcon('file-reload', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/file-reload.svg'));
    iconRegistry.addSvgIcon('percent', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/percent.svg'));
    iconRegistry.addSvgIcon('checkbook', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/checkbook.svg'));
    iconRegistry.addSvgIcon('checkbook2', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/checkbook2.svg'));
    iconRegistry.addSvgIcon('piggy-bank', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/piggy-bank.svg'));
    iconRegistry.addSvgIcon('chart-down', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/chart-down.svg'));
    iconRegistry.addSvgIcon('hand-money', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/hand-money.svg'));
    iconRegistry.addSvgIcon('cronometer', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/cronometer.svg'));
    iconRegistry.addSvgIcon('account-bank', sanitizer.bypassSecurityTrustResourceUrl('assets/novo-layout/kpi-icon/account-bank.svg'));
  }

  ngOnInit(): void {
  }

}
