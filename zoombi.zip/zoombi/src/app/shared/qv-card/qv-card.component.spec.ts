import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QvCardComponent } from './qv-card.component';

describe('QvCardComponent', () => {
  let component: QvCardComponent;
  let fixture: ComponentFixture<QvCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QvCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QvCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
