import { Component, Input, OnInit } from '@angular/core';
import { ToolsService } from '../services/tools.service';

@Component({
  selector: 'app-qv-card',
  templateUrl: './qv-card.component.html',
  styleUrls: ['./qv-card.component.scss']
})
export class QvCardComponent implements OnInit {
  @Input() componentes;
  @Input() id;
  @Input() customStyle;

  constructor(public tools: ToolsService) { }

  ngOnInit(): void {
  }

}
