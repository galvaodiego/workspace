import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FrameFiltroComponent } from './frame-filtro.component';

describe('FrameFiltroComponent', () => {
  let component: FrameFiltroComponent;
  let fixture: ComponentFixture<FrameFiltroComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FrameFiltroComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FrameFiltroComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
