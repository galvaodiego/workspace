import { Component, Input, OnInit } from '@angular/core';
import { ToolsService } from '../services/tools.service';

@Component({
  selector: 'app-frame-filtro',
  templateUrl: './frame-filtro.component.html',
  styleUrls: ['./frame-filtro.component.scss']
})
export class FrameFiltroComponent implements OnInit {
  @Input() componentes;
  constructor(public tools: ToolsService) { }

  ngOnInit(): void {
  }

}
