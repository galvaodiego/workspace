import { Component } from '@angular/core';
import { LoadingService } from './shared/services/loading.service';
import { ToolsService } from './shared/services/tools.service';
import { ApiService } from './shared/services/api.service';
import { CookieService } from 'ngx-cookie-service';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'Zoombi';
  usuario: string;
  cookie: string;

  constructor(
    public loadingService: LoadingService,
    private tools: ToolsService,
    private api: ApiService,
    private cookieService: CookieService,
    public dialog: MatDialog,
  ) {
    this.cookie = this.cookieService.get('X-Qlik-Session-External');
    const session = sessionStorage.getItem('usuario');
    if (session) {
      this.usuario = session
    } else {
      this.usuario = null;
      this.cookie = null;
      this.cookieService.delete('X-Qlik-Session-External');
    }

    this.api.backendCall('getMenu', { usuario: this.usuario }).then((res: any) => {
      console.log('getMenu', res);
      if (res.menu) {
        this.tools.empresa.next(res.menu.empresa);
        this.tools.userName.next(this.usuario);
        this.tools.pacotesMenu.next(res.menu.pacotes);
      }
    }).catch(err => {
      console.error('ERROR', err.error.message, 'PARAM:', this.usuario);
    });
  }

  islogged() {
    if (this.usuario) {
      this.cookie = this.cookieService.get('X-Qlik-Session-External');
      if (this.cookie) {
        return true;
      } else {
        this.usuario = null;
        this.cookie = null;
        this.cookieService.delete('X-Qlik-Session-External');
        return false;
      }
    } else {
      return false;
    }
  }

}
