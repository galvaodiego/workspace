export const environment = {
  production: true,
  time_loading: 1000,
  api: 'https://dash-backend.kmm.com.br',
  qliksenseUrl: 'https://qliksense.kmm.com.br',
  loginUrl: 'https://dash-backend.kmm.com.br/ext',
  configQlik: {
    host: 'qliksense.kmm.com.br',
    port: '',
    prefix: '/',
    secure: true,
    isSecure: false
  },
  customStyleIframe: { 'height': '820px' }
};
