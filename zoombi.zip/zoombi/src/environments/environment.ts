// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  time_loading: 1000,
  api: 'https://dash-backend.kmm.com.br',
  qliksenseUrl: 'https://qliksense.kmm.com.br',
  loginUrl: 'https://dash-backend.kmm.com.br/ext',
  configQlik: {
    host: 'qliksense.kmm.com.br',
    port: '',
    prefix: '/',
    secure: true,
    isSecure: false
  },
  customStyleIframe: { 'height': '820px' }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
