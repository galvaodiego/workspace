/* eslint-disable @typescript-eslint/camelcase */
import { MatchAlertaInterface, GroupAlertaInterface, RequestAlertaInterface } from '../interfaces/Alerta.interface'

export class GroupAlerta {
  public group : GroupAlertaInterface
  public match : MatchAlertaInterface

  constructor () {
    this.initGroup()
    this.initMatch()
  }

  private initGroup (): void{
    const group = {} as GroupAlertaInterface
    group._id = {}
    group._id.data = null
    group._id.cliente = null
    group._id.operador = null
    group._id.segmento = null
    group._id.tipo_alerta = null
    group.qtd_aberto = { $sum: '$ABERTO' }
    group.qtd_resolvido = { $sum: '$RESOLVIDO' }
    group.tempo_medio = { $sum: '$TOTAL_TEMPO_RESOLUCAO' }

    this.group = group
  }

  public setGroup (req: RequestAlertaInterface, group: string): void {
    switch (group) {
      case 'periodo':
        break
      case 'tempo':
        break
      case 'cliente':
        this.group._id.cliente = '$CLIENTE'
        break
      case 'operador':
        this.group._id.operador = '$RESOLVIDO_POR'
        break
      case 'segmento':
        this.group._id.segmento = '$SEGMENTO'
        break
      case 'tipo_alerta':
        this.group._id.tipo_alerta = '$TIPO_ALERTA'
        break
      default:
        break
    }

    this.prepareQuery()
  }

  public cleanGroup ():void {
    this.initGroup()
  }

  private initMatch (): void {
    const match = {} as MatchAlertaInterface
    match.CLIENTE = null
    match.DATA = null
    match.OPERADOR = null
    match.SEGMENTO = null
    match.TIPO_ALERTA = null

    this.match = match
  }

  public getReturn (ret: Array<any>, group = ''):Array<any> {
    ret.forEach(element => {
      element.qtd_aberto = parseInt(element.qtd_aberto)
      element.qtd_resolvido = parseInt(element.qtd_resolvido)
      element.tempo_medio = parseFloat(element.tempo_medio) / element.qtd_resolvido

      if (element._id) {
        Object.assign(element, element._id)
        delete element._id
      }

      if (group === 'operador') {
        delete element.qtd_aberto
        delete element.tempo_medio
      }

      if (group === 'segmento') {
        delete element.qtd_aberto
        delete element.tempo_medio
        element.descricao = element.segmento
        delete element.segmento
      }

      if (group === 'cliente') {
        delete element.qtd_aberto
        delete element.tempo_medio
        element.descricao = element.cliente
        delete element.cliente
      }

      if (group === 'periodo') {
        delete element.tempo_medio
        const arr = []
        arr.push({
          descricao: 'Não Resolvido',
          valor: element.qtd_aberto
        })
        arr.push({
          descricao: 'Resolvido',
          valor: element.qtd_resolvido
        })

        delete element.qtd_aberto
        delete element.qtd_resolvido
        element.arr = arr
      }

      if (group === 'tempo') {
        delete element.qtd_aberto
        delete element.qtd_resolvido
        element.tempo_medio = element.tempo_medio * 24 * 60
      }

      if (group === 'indicador') {
        delete element.total
        delete element._id
      }
    })
    return ret
  }

  public setMatchAlerta (req: RequestAlertaInterface): void {
    // const dia = new Date()
    // dia.setUTCHours(-0)
    // dia.setUTCMinutes(-0)
    // dia.setUTCSeconds(-0)
    // dia.setUTCMilliseconds(-0)
    // const periodoSemanal = new Date(dia)
    // const x = periodoSemanal.getDay() !== 1 ? periodoSemanal.setUTCHours(-24 * (periodoSemanal.getDay() - 1)) : periodoSemanal
    // const periodoAnual = new Date(dia.getUTCFullYear(), 0, 1)
    // const periodoMensal = new Date(dia.getUTCFullYear(), dia.getUTCMonth(), 1)
    // // const periodoSemanal = new Date(new Date().getUTCFullYear(), new Date().getUTCMonth(), 1, new Date().getUTCDay(), -diaSemana)
    // periodoAnual.setUTCHours(-0)

    // const periodoSemanal =
    // const periodoDiario = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getUTCDate(), 0, 0, 0)
    // const dataFiltro = null
    // switch (req.periodo) {
    //   case 'diario' :
    //     dataFiltro = periodoDiario
    //     break
    //   case 'semanal':

    //     dataFiltro = periodoSemanal
    //     break
    //   case 'mensal':
    //     dataFiltro = new Date(periodoMensal.setHours(0, 0, 0, 0) - (60 * 60000 * 3))
    //     break
    //   case 'anual':
    //     dataFiltro = periodoAnual
    //     break
    //   default:
    //     dataFiltro = periodoAnual
    // }

    this.match = {} as MatchAlertaInterface
    this.match.CLIENTE = req.cliente ? { $in: req.cliente } : null
    this.match.ALERTA_TIPO_ID = req.alerta_tipo_id ? { $nin: req.alerta_tipo_id } : null
    this.match.SEGMENTO_ID = req.segmento_id ? { $in: req.segmento_id } : null
    // this.match.DESTINO = req.destino ? { $in: req.destino } : null
    // this.match.MERCADORIA = req.mercadoria ? { $in: req.mercadoria } : null
    // this.match.PLACA = req.placa ? { $in: req.placa } : null
    // this.match.FROTA = req.frota ? { $in: req.frota } : null
    // this.match.MODALIDADE = req.modalidade ? { $in: req.modalidade } : null
    // this.match.DATA_EMISSAO = { $gte: dataFiltro }
    // this.match.MODELO = req.modelo ? { $in: req.modelo } : null
    // this.match.FILIAL = req.filial ? { $in: req.filial } : null
    this.prepareQuery()
  }

  public prepareQuery ():void {
    Object.keys(this.group._id).forEach((key) => (this.group._id[key] == null) && delete this.group._id[key])
    Object.keys(this.match).forEach((key) => (this.match[key] == null) && delete this.match[key])
  }
}
export default GroupAlerta
