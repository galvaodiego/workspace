import {
    MatchContratoTranspInterface,
    GroupContratoTranspInterface,
    RequestContratoTranspInterface
} from '../interfaces/contrato_transp.inferface'

export class GroupContratoTransp {

    public group: GroupContratoTranspInterface
    public match: MatchContratoTranspInterface

    constructor() {
        this.initGroup()
        this.initMatch()
    }

    public initGroup(): void {
        const group = {} as GroupContratoTranspInterface
        group._id = {}
        // group.qtde = { $sum: 1 }
        this.group = group
    }



    public setGroup(req: RequestContratoTranspInterface, group: Array<any>): void {

        /**
         * Foreach para casos de agrupar por mais de um atributo
         * Ex: situacao por cliente, produto por cliente e etc
         */
        group.forEach((x, index) => {
            switch (x) {

                case 'media_frete':
                    this.group.total = { $avg: '$VL_FRETE_LIQUIDO' }
                    break
                

                case 'user_insert':
                    Object.assign(this.group._id, { 'user_insert': '$USER_INSERT' })
                    break

                case 'operacao':
                    Object.assign(this.group._id, { 'operacao': '$OPERACAO_DESC' })
                    break;

                case 'destinatario':
                    Object.assign(this.group._id, { 'destinatatio': '$DESTINATARIO_CLIENTE' })
                    break;

                case 'cliente':
                    Object.assign(this.group._id, { 'cliente': '$CLIENTE_DESC' })
                    break

                case 'produto':
                    Object.assign(this.group._id, { 'produto': '$PRODUTO_DESC' })
                    break

                case 'grupo_produto':
                    Object.assign(this.group._id, { 'grupo_produto': '$GRUPO_PRODUTO_DESC' })
                    break

                case 'origem':
                    Object.assign(this.group._id, { 'origem': '$ORIGEM_MUNICIPIO_DESC' })
                    break;

                case 'destino':
                    Object.assign(this.group._id, { 'destino': '$DESTINO_MUNICIPIO_DESC' })
                    break;


                default:

                    break
            }

        });

        this.prepareQuery()
    }


    public cleanGroup(): void {
        this.initGroup()
    }

    private initMatch(): void {
        const match = {} as MatchContratoTranspInterface
        match.CANCELADA = null
        match.DATA_EMISSAO = null

        this.match = match
    }

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    public getReturn(ret: Array<any>): Array<any> {
        ret.forEach((element, index) => {
            // element.total = parseFloat(element.total)

            if (element._id) {
                Object.assign(element, element._id)
                delete element._id
            }
        })

        // se tiver mais de um atributo significa agrupamento por mais de um campo
        let n_key = ret[0] && Object.keys(ret[0]).length

        if (ret && ret.length > 0 && n_key < 2) {

            /**
             * É PRECISO TRATAR AQUI CADA ACUMULADOR
             */
            if (ret[0] && ret[0].total) {
                return ret[0].total

            } if (ret[0] && ret[0].qtde) {
                return ret[0].qtde
            }

        } else {
            return ret

        }
    }

    public setMatchContratoTransp(req: RequestContratoTranspInterface): void {

        const diaSemana = new Date().getDay() - 1
        const periodoDiario = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getUTCDate())
        const periodoSemanal = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getUTCDate() - diaSemana)
        const periodoMensal = new Date(new Date().getFullYear(), new Date().getMonth(), 1)

        const semanalFim = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getUTCDate() + (7 - diaSemana))
        const mesFim = new Date(new Date().getFullYear(), new Date().getMonth() + 1, 1)
        const diaFim = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getUTCDate() + 1)


        let dataInicial = null
        let dataFinal = null


        switch (req.periodo) {
            case 'diario':
                dataInicial = periodoDiario 
                   // new Date(periodoDiario.setHours(0, 0, 0, 0) - (60 * 60000 * 3))
                dataFinal = diaFim
               // new Date(diaFim.setHours(0, 0, 0, 0) - (60 * 60000 * 3))
                break

            case 'semanal':
                dataInicial = periodoSemanal
                dataFinal = semanalFim
                break

            case 'mensal':
                dataInicial = new Date(periodoMensal.setHours(0, 0, 0, 0) - (60 * 60000))
                   // new Date(periodoMensal.setHours(0, 0, 0, 0) - (60 * 60000 * 4))
                dataFinal = mesFim
                   // new Date(mesFim.setHours(0, 0, 0, 0) - (60 * 60000 * 3))
                break

            default:
                dataInicial = periodoDiario
                dataFinal = diaFim

        }


        this.match = {} as MatchContratoTranspInterface

        this.match.DATA_EMISSAO = req.data_emissao ? { $gte: dataInicial, $lt: dataFinal } : null
        this.match.CANCELADA = req.cancelada != null ? { $eq: req.cancelada } : null



        this.prepareQuery()
    }

    public prepareQuery (): void {
        Object.keys(this.group._id).forEach((key) => (this.group._id[key] == null) && delete this.group._id[key])
        Object.keys(this.match).forEach((key) => (this.match[key] == null) && delete this.match[key])
    }
}
export default GroupContratoTransp
