/* eslint-disable prefer-const */
/* eslint-disable camelcase */
/* eslint-disable @typescript-eslint/camelcase */
import {
  MatchDoctoFiscalInterface,
  GroupDoctoFiscalInterface,
  RequestDoctoFiscalInterface
} from '../interfaces/docto_fiscal.interface'


export class GroupDoctoFiscal {

  public group: GroupDoctoFiscalInterface
  public match: MatchDoctoFiscalInterface

  constructor() {
    this.initGroup()
    this.initMatch()
  }

  public initGroup(): void {
    const group = {} as GroupDoctoFiscalInterface
    group._id = {}
    // group.qtde = { $sum: 1 }
    this.group = group
  }



  public setGroup(req: RequestDoctoFiscalInterface, group: Array<any>): void {

    /**
     * Foreach para casos de agrupar por mais de um atributo
     * Ex: situacao por cliente, produto por cliente e etc
     */
    group.forEach((x, index) => {
      switch (x) {

        case 'qtde':
          this.group.qtde = { $sum: 1 }
          break

        case 'automatizado':
          this.group.valor = { $sum: 1 }
          break

        case 'media':
          this.group.media = { $avg: '$VL_FATURADO' }
          break

        case 'faturamento':
          this.group.total = { $sum: '$VL_FATURADO' }
          break

        case 'peso':
          this.group.peso = { $sum: '$VL_PESO_REAL' }
          break

        case 'user_insert':
          Object.assign(this.group._id, { user_insert: '$USER_INSERT' })
          break
        case 'operacao':
          Object.assign(this.group._id, { operacao: '$OPERACAO' })
          break

        case 'remetente':
          Object.assign(this.group._id, { remetente: '$REMETENTE_CLIENTE' })
          break

        case 'destinatario':
          Object.assign(this.group._id, { destinatatio: '$DESTINATARIO_CLIENTE' })
          break

        case 'cliente':
          Object.assign(this.group._id, { cliente: '$CLIENTE' })
          break


        /**
         * Usado para AbastecimentoController
         */
        case 'pessoa_filial':
          Object.assign(this.group._id, { chave: '$PESSOA_FILIAL' })
          break

        case 'placa':
          Object.assign(this.group._id, { chave: '$VEICULO_CONTROLE_PLACA' })
          break

        /** FIM
       * Usado para AbastecimentoController
       */

        case 'produto':
          Object.assign(this.group._id, { produto: '$PRODUTO' })
          break

        case 'grupo_produto':
          Object.assign(this.group._id, { grupo_produto: '$GRUPO_PRODUTO' })
          break

        case 'origem':
          Object.assign(this.group._id, { origem: '$ORIGEM_MUNICIPIO' })
          break

        case 'destino':
          Object.assign(this.group._id, { destino: '$DESTINO_MUNICIPIO' })
          break

        case 'placa_controle':
          Object.assign(this.group._id, { placa_controle: '$VEICULO_CONTROLE_PLACA' })
          break

        case 'veiculo_classificacao':
          Object.assign(this.group._id, { veiculo_classificacao: '$VEICULO_CONTROLE_CLASSIFICACAO' })
          break

        case 'veiculo_padrao':
          Object.assign(this.group._id, { veiculo_padrao: '$VEICULO_CONTROLE_PADRAO' })
          break

        case 'tipo_frete':
          Object.assign(this.group._id, { tipo_frete: '$TIPO_FRETE' })
          break

        case 'grupo_negociador':
          Object.assign(this.group._id, { grupo_negociador: '$GRUPO_NEGOCIADOR' })
          break

        case 'filial':
          Object.assign(this.group._id, { filial: '$PESSOA_FILIAL' })
          break

        case 'operacao_n1':
          Object.assign(this.group._id, { operacao_pai: '$OPERACAO_N1' })
          break

        case 'tipo_docto':
          Object.assign(this.group._id, { tipo_docto: '$TIPO_DOCTO' })
          break

        // case 'tipo_frete':
        //   Object.assign(this.group._id, { tipo_docto: '$TIPO_FRETE' })
        //   break

        case 'cancelado_por':
          Object.assign(this.group._id, { cancelado_por: '$CANCELADO_POR' })
          break

        case 'cancelada':
          Object.assign(this.group._id, { cancelado: '$CANCELADA' })
          break

        case 'data':
          Object.assign(this.group._id, { data: '$DATA' })
          break

        case 'dia_mes':
          Object.assign(this.group._id, { data: '$DIA_MES' })
          break

        // usado dash meta CJLOG
        case 'dia_mes_abr':
          Object.assign(this.group._id, { dia_mes: '$DIA_MES' })
          break

        case 'mes':
          Object.assign(this.group._id, { data: '$NM_MES' })
          break

        case 'mes_ano':
          Object.assign(this.group._id, { data: '$MES_ANO' })
          break

        case 'coordenador':
          Object.assign(this.group._id, { coordenador: '$COORDENADOR' })
          break

        case 'ccg':
          Object.assign(this.group._id, { ccg: '$ORGANIZACIONAL' })
          break

        case 'modalidade':
          Object.assign(this.group._id, { modalidade: '$MODALIDADE' })
          break

        case 'motorista':
          Object.assign(this.group._id, { motorista: '$CLIENTE_MOTORISTA' })
          break

        case 'last_update':
          this.group.valor = { $max: '$DATA_CARGA' }
          break

        default:
          break
      }
    })

    this.prepareQuery()
  }


  public cleanGroup(): void {
    this.initGroup()
  }

  private initMatch(): void {
    const match = {} as MatchDoctoFiscalInterface
    match.CANCELADA = null
    match.DATA_EMISSAO = null
    match.DATA = null
    match.NR_HORA = null
    match.NR_DIA_MES = null
    match.NR_ANO = null
    match.NR_MES = null
    match.ORIGEM = null
    match.USER_INSERT = null
    match.CANCELADO_POR = null
    match.AUTOMATIZADO = null
    match.INTEGRADO = null
    match.VEICULO_CONTROLE_PLACA = null
    match.PESSOA_FILIAL = null
    match.SITUACAO_ID = null
    match.EXCLUIDO = null
    match.TIPO_DOCTO = null
    this.match = match
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public getReturn(ret: Array<any>): Array<any> {

    ret.forEach((element, index) => {

      if (element._id) {
        Object.assign(element, element._id)
        delete element._id
      }
    })

    // se tiver mais de um atributo significa agrupamento por mais de um campo
    let n_key = ret[0] && Object.keys(ret[0]).length

    if (ret && ret.length > 0 && n_key < 2) {

      /**
       * É PRECISO TRATAR AQUI CADA ACUMULADOR
       */
      if (ret[0] && ret[0].total) {
        return ret[0].total

      } if (ret[0] && ret[0].qtde) {
        return ret[0].qtde

      } if (ret[0] && ret[0].peso) {
        return ret[0].peso

      } if (ret[0] && ret[0].media) {
        return ret[0].media
      }
    }
    // } else {
    return ret

    // }
  }

  public setMatchDoctoFiscal (req: RequestDoctoFiscalInterface): void {

    // const diaSemana = new Date().getDay() - 1
    // const periodoDiario = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getUTCDate())
    // const periodoSemanal = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getUTCDate() - diaSemana)
    // const periodoMensal = new Date(new Date().getFullYear(), new Date().getMonth(), 1)

    // const semanalFim = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getUTCDate() + (7 - diaSemana))
    // const mesFim = new Date(new Date().getFullYear(), new Date().getMonth() + 1, 1)
    // const diaFim = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getUTCDate() + 1)

    // const mesFim = new Date(new Date().getFullYear(), new Date().getMonth() + 1, 1)
    const data = new Date(new Date().valueOf() - new Date().getTimezoneOffset() - (60 * 60000 * 3))
    const ano = data.getFullYear()
    const mes = data.getMonth() + 1
    const dia = data.getUTCDate()
    const semana = data.getDay()

    // let dataInicial = null
    // let dataFinal = null
    let nr_ano = null
    let nr_mes = null
    let nr_semana = null
    let nr_dia = null



    switch (req.periodo) {
      case 'diario':
        nr_ano = ano
        nr_mes = mes
        nr_dia = dia
        // dataInicial = periodoDiario
        // new Date(periodoDiario.setHours(0, 0, 0, 0) - (60 * 60000 * 3))
        // dataFinal = diaFim
        // new Date(diaFim.setHours(0, 0, 0, 0) - (60 * 60000 * 3))
        break

      case 'semanal':
        nr_ano = ano
        nr_semana = semana
        // dataInicial = periodoSemanal
        // dataFinal = semanalFim
        break

      case 'mensal':
        // dataInicial = new Date(periodoMensal.setHours(0, 0, 0, 0) - (60 * 60000))
        // new Date(periodoMensal.setHours(0, 0, 0, 0) - (60 * 60000 * 4))
        // dataFinal = mesFim
        // new Date(mesFim.setHours(0, 0, 0, 0) - (60 * 60000 * 3))
        nr_ano = ano
        nr_mes = mes
        break

      case 'anual':
        nr_ano = ano
        break

      default:
        // dataInicial = periodoDiario
        // dataFinal = diaFim
        nr_ano = ano
        nr_mes = mes
        nr_dia = dia
    }


    this.match = {} as MatchDoctoFiscalInterface

    this.match.NR_ANO = nr_ano ? { $eq: nr_ano } : null
    this.match.NR_MES = nr_mes ? { $eq: nr_mes } : null
    this.match.NR_DIA_MES = nr_dia ? { $eq: nr_dia } : null
    this.match.NR_HORA = req.hora ? { $eq: req.hora } : null

    // this.match.DATA = req.data_inicio_emissao ? { $gte: dataInicial, $lt: dataFinal } : null
    this.match.CANCELADA = req.cancelada != null ? { $eq: req.cancelada } : null
    this.match.ORIGEM = req.origem ? { $eq: req.origem } : null
    this.match.USER_INSERT = req.user_insert ? { $eq: req.user_insert } : null
    this.match.CANCELADO_POR = req.cancelado_por ? { $eq: req.cancelado_por } : null
    this.match.AUTOMATIZADO = req.automatizado ? { $eq: req.automatizado } : null
    this.match.INTEGRADO = req.integrado ? { $eq: req.integrado } : null
    this.match.VEICULO_CONTROLE_PLACA = req.placa ? { $in: req.placa } : null
    this.match.PESSOA_FILIAL = req.filial ? { $in: req.filial } : null
    this.match.SITUACAO_ID = req.situacao ? { $in: req.situacao } : null
    this.match.EXCLUIDO = { $eq: 0 }
    this.match.TIPO_DOCTO = req.tipo_docto ? { $eq: req.tipo_docto } : null
    
    // Usado pelo abastecimento
    if (!req.periodo && !req.data_inicial) {

      this.match.NR_ANO = { $eq: ano }

      this.match.NR_ANO = null
      this.match.NR_MES = null
      this.match.NR_DIA_MES = null
      this.match.NR_HORA = null

    } if (req.data_inicial && req.data_final) {
      // this.match.NR_ANO = { $eq: ano }
      this.match.DATA = req.data_inicial && req.data_final ? { $gte: new Date(req.data_inicial), $lte: new Date(req.data_final) } : null
      this.match.NR_ANO = null
      this.match.NR_MES = null
      this.match.NR_DIA_MES = null
      this.match.NR_HORA = null

    }

    if (req.periodo === 'diario' && !!req.dias) {
      let inicio = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getUTCDate() - req.dias)
      // eslint-disable-next-line prefer-const
      let fim = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getUTCDate() + 1)

      // para rodar local
      // let ii = new Date(inicio.setHours(0, 0, 0, 0) - (60 * 60000 * 3))
      // let ff = new Date(fim.setHours(0, 0, 0, 0) - (60 * 60000 * 3))
      // this.match.DATA = req.dias ? { $gte: ii, $lt: ff } : null
      this.match.DATA = req.dias ? { $gte: inicio, $lt: fim } : null
      this.match.NR_ANO = null
      this.match.NR_MES = null
      this.match.NR_DIA_MES = null
    }

    this.prepareQuery()
  }

  public prepareQuery (): void {
    Object.keys(this.group._id).forEach((key) => (this.group._id[key] == null) && delete this.group._id[key])
    Object.keys(this.match).forEach((key) => (this.match[key] == null) && delete this.match[key])
  }

}
export default GroupDoctoFiscal
