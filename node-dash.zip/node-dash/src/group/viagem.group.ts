import { GroupViagemInterface, MatchViagemInterface, RequestViagemInterface } from '../interfaces/viagem.interface'

export class GroupViagem {
    public group: GroupViagemInterface
    public match: MatchViagemInterface

    constructor () {
      this.initGroup()
      this.initMatch()
    }

    private initGroup (): void {
      const group = {} as GroupViagemInterface
      group._id = {}
      group._id.data = null
      group._id.cliente = null
      group._id.mercadoria = null
      group._id.destino = null
      group._id.rota = null
      group._id.origem_destino = null
      group._id.origem = null

      group.km_carregado = { $sum: '$KM_CARREGADO' }
      group.km_total = { $sum: '$KM_TOTAL' }
      group.km_vazio = { $sum: '$KM_VAZIO' }
      group.tonelagem = { $sum: '$PESO' }
      group.viagens = { $sum: '$QTD_VIAGEM' }
      group.volume = { $sum: '$VOLUME' }

      this.group = group
    }

    public setGroup (req: RequestViagemInterface, group: string): void {
      switch (group) {
        case 'cliente':
          this.group._id.cliente = '$CLIENTE'
          break
        case 'mercadoria':
          this.group._id.mercadoria = '$MERCADORIA'
          break
        case 'destino':
          this.group._id.destino = '$DESTINO'
          break
        case 'rota':
          this.group._id.rota = '$ROTA'
          break
        case 'origem_destino':
          this.group._id.origem_destino = { uf_origem: '$UF_ORIGEM', uf_destino: '$UF_DESTINO' }
          break
        case 'origem':
          this.group._id.origem = '$ORIGEM'
          break
        default:
          break
      }
      this.prepareQuery()
    }

    public cleanGroup (): void {
      this.initGroup()
    }

    private initMatch (): void {
      const match = {} as MatchViagemInterface
      match.DATA = null
      match.CLIENTE = null
      match.MERCADORIA = null
      match.DESTINO = null
      match.ROTA = null
      match.ORIGEM_DESTINO = null
      match.ORIGEM = null
      this.match = match
    }

    public getReturn (ret: Array<any>): Array<any> {
      ret.forEach(element => {
        element.km_carregado = parseFloat(element.km_carregado)
        element.km_vazio = parseFloat(element.km_vazio)
        element.km_total = parseFloat(element.km_total)
        element.viagens = parseInt(element.viagens)
        element.tonelagem = parseFloat(element.tonelagem)
        element.volume = parseFloat(element.volume)
        /**
             *  passando valor do _id para o array e depois excluindo a tag _id
             */
        if (element._id) {
          Object.assign(element, element._id)
          delete element._id
        }
      })

      return ret
    }

    public setMatchViagem (req: RequestViagemInterface): void {
      const periodoAnual = new Date(new Date().getFullYear(), 0, 1)
      const periodoMensal = new Date(new Date().getFullYear(), new Date().getMonth(), 1)

      const diaSemana = new Date().getDay()
      const periodoSemanal = new Date(new Date().getFullYear(), new Date().getMonth(), 1, new Date().getDay(), -diaSemana)

      let dataFiltro = null
      switch (req.periodo) {
        case 'semanal':
          dataFiltro = periodoSemanal
          break
        case 'mensal':
          dataFiltro = periodoMensal
          break
        case 'anual':
          dataFiltro = periodoAnual
          break
        default:
          dataFiltro = periodoAnual
      }
      this.match = {} as MatchViagemInterface
      this.match.DATA = { $gte: dataFiltro }
      this.match.CLIENTE = req.cliente ? { $in: req.cliente } : null
      this.match.MERCADORIA = req.mercadoria ? { $in: req.mercadoria } : null
      this.match.DESTINO = req.destino ? { $in: req.destino } : null
      this.match.ROTA = req.rota ? { $in: req.rota } : null
      this.match.ORIGEM = req.origem ? { $in: req.origem } : null
      this.match.ORIGEM_DESTINO = req.origem_destino ? { $in: req.origem_destino } : null
      this.prepareQuery()
    }

    public prepareQuery (): void {
      Object.keys(this.group._id).forEach((key) => (this.group._id[key] == null) && delete this.group._id[key])
      Object.keys(this.match).forEach((key) => (this.match[key] == null) && delete this.match[key])
    }
}
