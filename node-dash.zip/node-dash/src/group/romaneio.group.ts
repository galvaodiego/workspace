/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable camelcase */
import {
  MatchRomaneioInterface,
  GroupRomaneioInterface,
  RequestRomaneioInterface
} from '../interfaces/romaneio.interface'

export class GroupRomaneio {

  public group: GroupRomaneioInterface
  public match: MatchRomaneioInterface

  constructor() {
    this.initGroup()
    this.initMatch()
  }

  private initGroup(): void {
    const group = {} as GroupRomaneioInterface
    group._id = {}
    group.qtde = { $sum: 1 }

    this.group = group
  }

  public setGroup(req: RequestRomaneioInterface, group: Array<any>): void {
    // Object.assign(this.group._id, null)
    /**
     * Foreach para casos de agrupar por mais de um atributo
     * Ex: situacao por cliente, produto por cliente e etc
     */
    group.forEach((x, index) => {
      switch (x) {

        case 'situacao_desc':
          Object.assign(this.group._id, { situacao_desc: '$SITUACAO' })
          break

        case 'situacao_viagem_desc':
          Object.assign(this.group._id, { situacao_viagem_desc: '$SITUACAO_VIAGEM' })
          break

        case 'placa_controle':
          Object.assign(this.group._id, { placa_controle: '$VEICULO_PLACA' })
          break

        case 'remetente':
          Object.assign(this.group._id, { remetente: '$REMETENTE_CLIENTE' })
          break

        case 'destinatario':
          Object.assign(this.group._id, { destinatatio: '$DESTINATARIO_CLIENTE' })
          break

        case 'cliente':
          Object.assign(this.group._id, { cliente: '$CLIENTE' })
          break

        case 'produto':
          Object.assign(this.group._id, { produto: '$PRODUTO' })
          break

        case 'operacao':
          Object.assign(this.group._id, { operacao: '$OPERACAO' })
          break

        case 'grupo_produto':
          Object.assign(this.group._id, { grupo_produto: '$GRUPO_PRODUTO' })
          break

        case 'origem':
          Object.assign(this.group._id, { origem: '$ORIGEM_MUNICIPIO' })
          break

        case 'destino':
          Object.assign(this.group._id, { destino: '$DESTINO_MUNICIPIO' })
          break

        default:
          break
      }
    })

    this.prepareQuery()
  }

  public cleanGroup(): void {
    this.initGroup()
  }


  private initMatch(): void {
    const match = {} as MatchRomaneioInterface
    match.CANCELADA = null
    match.FATURADO = null
    match.DATA_INICIO = null
    match.DATA = null
    match.ORIGEM = null
    match.DATA_TERMINO_CARGA = null
    match.NR_ANO = null
    match.NR_SEMANA = null
    match.SITUACAO_VIAGEM_ID = null
    match.EXCLUIDO = null
    match.TIPO_DOCUMENTO = null // tipo de documento da operacao
    this.match = match
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any


  public setMatchRomaneio(req: RequestRomaneioInterface): void {

    // const diaSemana = new Date().getDay() - 1
    const periodoDiario = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getUTCDate() - 30)
    // const periodoSemanal = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getUTCDate() - diaSemana)
    // const periodoMensal = new Date(new Date().getFullYear(), new Date().getMonth(), 1)

    // const semanalFim = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getUTCDate() + (7 - diaSemana))
    // const mesFim = new Date(new Date().getFullYear(), new Date().getMonth() + 1, 1)
    // const diaFim = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getUTCDate() + 1)
    // let dataInicial = null
    // let dataFinal = null

    const data = new Date(new Date().valueOf() - new Date().getTimezoneOffset() - (60 * 60000 * 3))
    const ano = data.getFullYear()
    const mes = data.getMonth() + 1
    const dia = data.getUTCDate()
    const semana = data.getDay()


    // eslint-disable-next-line @typescript-eslint/camelcase
    let nr_mes = null
    let nr_dia = null
    let nr_ano = null
    let nr_semana = null

    switch (req.periodo) {
      case 'diario':
        // dataInicial = periodoDiario
        // dataFinal = diaFim

        nr_ano = ano
        nr_mes = mes
        nr_dia = dia

        // dataInicial = new Date(periodoDiario.setHours(0, 0, 0, 0) - (60 * 60000 * 3))
        //dataFinal = new Date(diaFim.setHours(0, 0, 0, 0) - (60 * 60000 * 1))
        break

      case 'semanal':
        nr_ano = ano
        nr_semana = semana
        // dataInicial = periodoSemanal
        // dataFinal = semanalFim
        break

      case 'mensal':
        // dataInicial = new Date(periodoMensal.setHours(0, 0, 0, 0) - (60 * 60000))
        // dataFinal = mesFim
        nr_ano = ano
        nr_mes = mes

        // dataInicial = new Date(periodoMensal.setHours(0, 0, 0, 0) - (60 * 60000 * 4))
        // dataFinal = new Date(mesFim.setHours(0, 0, 0, 0) - (60 * 60000 * 3))
        break

      case 'anual':
        nr_ano = ano
        break

      default:
        nr_ano = ano
        nr_mes = mes
        nr_dia = dia
      // dataInicial = periodoDiario
      // dataFinal = diaFim
      // dataInicial = new Date(periodoDiario.setHours(0, 0, 0, 0) - (60 * 60000 * 3))
      // dataFinal = new Date(diaFim.setHours(0, 0, 0, 0) - (60 * 60000 * 3))
    }

    this.match = {} as MatchRomaneioInterface

    // this.match.DATA = dataInicial ? { $gte: dataInicial, $lt: dataFinal } : null
    // DATA_INICIO
    this.match.NR_ANO = nr_ano ? { $eq: nr_ano } : null
    this.match.NR_MES = nr_mes ? { $eq: nr_mes } : null
    this.match.NR_SEMANA = nr_semana ? { $eq: nr_semana } : null
    this.match.NR_DIA_MES = nr_dia ? { $eq: nr_dia } : null
    this.match.NR_HORA = req.hora ? { $eq: req.hora } : null

    this.match.CANCELADA = req.cancelada != null ? { $eq: req.cancelada } : null
    this.match.FATURADO = req.faturado != null ? { $eq: req.faturado } : null
    this.match.ORIGEM = req.origem ? { $eq: req.origem } : null
    this.match.SITUACAO_VIAGEM_ID = req.situacao_viagem_id ? { $eq: req.situacao_viagem_id } : null
    this.match.DATA_TERMINO_CARGA = req.data_termino_carga ? { $ne: null } : null
    this.match.EXCLUIDO = req.excluido != null ? { $eq: req.excluido } : null
    this.match.TIPO_DOCUMENTO = req.tipo_documento ? { $ne: req.tipo_documento } : null // tipo_documento <> 1

    // req.data_termino_carga ?

    // usado para pega os dias anteriores da data atual
    if (req.periodo == 'diario' && !!req.dias) {
      let inicio = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getUTCDate() - req.dias)
      let fim = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getUTCDate() + 1)

      // console.log('Inicio: ', inicio, ' fim: ', fim)
      let ii = new Date(inicio.setHours(0, 0, 0, 0) - (60 * 60000 * 2))
      let ff = new Date(fim.setHours(0, 0, 0, 0) - (60 * 60000 * 3))
      this.match.DATA = req.dias ? { $gte: ii, $lt: ff } : null

      // nr_ano = Number(dias.substr(0,4));
      // nr_mes = Number(dias.substr(5,2));
      // this.match.DATA = req.dias ? { $gte: inicio, $lt: fim } : null
      this.match.NR_ANO = null
      this.match.NR_MES = null
      this.match.NR_DIA_MES = null


    }


    this.prepareQuery()
  }

  public prepareQuery(): void {
    Object.keys(this.group._id).forEach((key) => (this.group._id[key] == null) && delete this.group._id[key])
    Object.keys(this.match).forEach((key) => (this.match[key] == null) && delete this.match[key])
  }


  public getReturn(ret: Array<any>): Array<any> {

    ret.forEach((element, index) => {

      if (element._id) {
        Object.assign(element, element._id)
        delete element._id
      }
    })
    // se tiver mais de um atributo significa agrupamento por mais de um campo
    let n_key = ret[0] && Object.keys(ret[0]).length

    if (ret && ret.length > 0 && n_key < 2) {
      return ret[0].qtde
    }
    return ret
  }
}
export default GroupRomaneio
