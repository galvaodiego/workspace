/* eslint-disable no-redeclare */
/* eslint-disable no-unused-vars */
/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable camelcase */
/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable prefer-const */
import {
  GroupAbastecimentoInterface,
  RequestAbastecimentoInterface,
  MatchAbastecimentoInterface

} from '../interfaces/abastecimento.interface'

export class GroupAbastecimentoLog {

  public group: GroupAbastecimentoInterface
  public match: MatchAbastecimentoInterface

  constructor() {
    this.initGroup()
    this.initMatch()
  }

  private initGroup(): void {
    const group = {} as GroupAbastecimentoInterface
    group._id = {}

    this.group = group
  }

  private initFilter(): void {
    const group = {} as GroupAbastecimentoInterface
    group._id = {}

    this.group = group
  }

  public setGroup(req: RequestAbastecimentoInterface, group: Array<any>): void {
    Object.assign(this.group._id, null)
    /**
     * Foreach para casos de agrupar por mais de um atributo
     * Ex: situacao por cliente, produto por cliente e etc
     */
    group.forEach((x) => {
      switch (x) {

        case 'cliente':
          Object.assign(this.group._id, { chave: '$CLIENTE' })
          break

        case 'posto':
          Object.assign(this.group._id, { chave: '$POSTO' })
          break

        case 'posto_id':
          Object.assign(this.group._id, { posto_id: '$COD_POSTO' })
          break

        case 'produto':
          Object.assign(this.group._id, { chave: '$PRODUTO_FISCAL' })
          break

        case 'municipio_uf':
          Object.assign(this.group._id, { chave: '$MUNICIPIO_UF' })
          break

        case 'lat':
          Object.assign(this.group._id, { lat: '$MUNICIPIO_LAT' })
          break

        case 'lng':
          Object.assign(this.group._id, { lng: '$MUNICIPIO_LNG' })
          break

        case 'combustivel':
          Object.assign(this.group._id, { combustivel: '$NM_COMBUSTIVEL' })
          break

        case 'placa':
          Object.assign(this.group._id, { chave: '$VEICULO_PLACA' })
          break

        case 'mes':
          Object.assign(this.group._id, { mes: '$MES_ANO' })
          break

        case 'total':
          this.group.valor = { $sum: '$VL_TOTAL' }
          break

        case 'litros':
          this.group.valor = { $sum: '$QTDE_ABASTECIDA' }
          break

        case 'qtde':
          this.group.valor = { $sum: 1 } // '$QTDE_ABASTECIMENTO' }
          break

        case 'qtde1':
          this.group.qtde = { $sum: 1 } // '$QTDE_ABASTECIMENTO' }
          break

        case 'media':
          this.group.valor = { $avg: '$VL_UNITARIO' }
          break

        case 'last_update':
          this.group.valor = { $max: '$DATA_CARGA' }
          break

        case 'maior_vl_unitario':
          this.group.valor = { $max: '$VL_UNITARIO' }
          break

        case 'menor_vl_unitario':
          this.group.valor = { $min: '$VL_UNITARIO' }
          break

        default:
          break
      }
    })

    this.prepareQuery()
  }


  public setFilter(req: RequestAbastecimentoInterface, group: Array<any>): void {
    Object.assign(this.group._id, null)

    group.forEach((x) => {
      switch (x) {

        case 'posto':
          Object.assign(this.group._id, { chave: '$POSTO' })
          break

        case 'posto_id':
          Object.assign(this.group._id, { valor: '$COD_POSTO' })
          break

        case 'produto':
          Object.assign(this.group._id, { chave: '$PRODUTO_FISCAL' })
          break

        case 'produto_id':
          Object.assign(this.group._id, { valor: '$PRODUTO_FICAL_ID' })
          break

        case 'estado':
          Object.assign(this.group._id, { chave: '$MUNICIPIO_UF' })
          break

        case 'estado_id':
          Object.assign(this.group._id, { valor: '$MUNICIPIO_ID' })
          break

        case 'placa':
          Object.assign(this.group._id, { chave: '$VEICULO_PLACA' })
          break

        case 'veiculo_id':
          Object.assign(this.group._id, { valor: '$VEICULO_ID' })
          break



        default:
          break
      }
    })

    this.prepareQuery()
  }

  public cleanGroup(): void {
    this.initGroup()
  }

  public cleanFilter(): void {
    this.initFilter()
  }

  public cleanMath(): void {
    this.initMatch()
  }

  private initMatch(): void {
    const match = {} as MatchAbastecimentoInterface

    // eslint-disable-next-line @typescript-eslint/camelcase
    match.CLIENTE = null
    match.POSTO = null
    match.COMBUSTIVEL = null
    match.MUNICIPIO_UF = null

    this.match = match

  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public async getReturn(ret: Array<any>): Promise<any[]> {

    ret.forEach(element => {
      if (element._id) {

        Object.assign(element, element._id)
        delete element._id
      }
    })
    return ret
  }

  public setMatchAbastecimento(req: RequestAbastecimentoInterface): void {

    const data = new Date(new Date().valueOf() - new Date().getTimezoneOffset() - (60 * 60000 * 3))
    const ano = data.getFullYear()
    const mes = data.getMonth() + 1
    const dia = data.getUTCDate()

    let nr_mes = null
    let nr_ano = null


    switch (req.periodo) {
      case 'mensal':
        nr_ano = ano
        nr_mes = mes
        break
      case 'anual':
        nr_ano = ano
    }



    this.match = {} as MatchAbastecimentoInterface
  
    const new_date_init = req.data_inicial ? new Date(req.data_inicial.substr(0, 10)) : null
    const new_date_end = req.data_final ? new Date(req.data_final.substr(0, 10)) : null

    this.match.EXCLUIDO = { $eq: 0 }

    this.match.POSTO = req.posto ? { $in: req.posto } : null
    this.match.COD_POSTO = req.posto_id ? { $in: [ req.posto_id ] } : null

    this.match.VEICULO_PLACA = req.placa ? { $in: req.placa } : null
    this.match.VEICULO_ID = req.placa_id ? { $in: req.placa_id } : null

    this.match.PRODUTO_FISCAL = req.produto ? { $in: req.produto } : null
    this.match.PRODUTO_FISCAL_ID = req.produto_id ? { $in: req.produto_id } : null
    this.match.MUNICIPIO_UF = req.estado ? { $in: req.estado } : null

    this.match.COMBUSTIVEL = req.combustivel ? { $in: req.combustivel } : null

    this.match.DATA = req.data_inicial && req.data_final ? { $gte: new_date_init, $lte: new_date_end } : null

    this.match.NR_ANO = nr_ano ? { $eq: nr_ano } : null
    this.match.NR_MES = nr_mes ? { $eq: nr_mes } : null
    this.match.VL_UNITARIO = req.valor_uni !== null ? { $ne: 0 } : null

    
    

    if (!req.periodo && !req.data_inicial && !req.filtro) {
      this.match.NR_ANO = { $eq: ano }
      this.match.NR_MES = {$eq: mes }
      this.match.NR_DIA_MES = { $eq: dia }
    }
    
    this.prepareQuery()

    
  }

  public prepareQuery(): void {
    Object.keys(this.group._id).forEach((key) => (this.group._id[key] == null) && delete this.group._id[key])
    Object.keys(this.match).forEach((key) => (this.match[key] == null) && delete this.match[key])
  }
}
export default GroupAbastecimentoLog
