/* eslint-disable no-case-declarations */
/* eslint-disable camelcase */
/* eslint-disable @typescript-eslint/explicit-function-return-type */
/* eslint-disable no-self-assign */
/* eslint-disable @typescript-eslint/camelcase */

export class GroupMeta {

  public group
  public match

  constructor () {
    this.initGroup()
    this.initMatch()
  }

  public initGroup () {
    const group = {
      _id: {

      },
      documento: { $sum: '$QTDE_DOCUMENTO' },
      total_peso: { $sum: '$VL_PESO' }, 
      total_documento: { $sum: '$VL_DOCUMENTO' }, 
      media_total_documento: { $avg: '$TOTAL_DOCUMENTO' },
      media_total_peso: { $avg: '$TOTAL_PESO' },
      meta_faturamento: { $sum: '$VL_META_FAT' }, 
      meta_tonelagem: { $sum: '$VL_META_TON' }
    }
    this.group = group
  }

  private initMatch (): void {
    const match = {
      CANCELADA: null,
      DATA_BASE: null,
      FLAG_DATA: null,
      FLAG_MAIOR_MES: null
    }
    this.match = match
  }

  public setMatch (req): void {
    const periodoDiario = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getUTCDate())
    const periodoMensal = new Date(new Date().getFullYear(), new Date().getMonth(), 1)

    const mesFim = new Date(new Date().getFullYear(), new Date().getMonth() + 1, 1)
    const diaFim = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getUTCDate() + 1)

    let dataInicial = null
    let dataFinal = null

    switch (req.periodo) {
      case 'diario':

        dataInicial = periodoDiario
        //  dataInicial = new Date(periodoDiario.setHours(0, 0, 0, 0) - (60 * 60000 * 3))
        dataFinal = diaFim
        // dataFinal = new Date(diaFim.setHours(0, 0, 0, 0) - (60 * 60000 * 3))
        break

      case 'mensal':
        dataInicial = periodoMensal
        // dataInicial = new Date(periodoMensal.setHours(0, 0, 0, 0) - (60 * 60000 * 3))
        dataFinal = mesFim
        // dataFinal = new Date(mesFim.setHours(0, 0, 0, 0) - (60 * 60000 * 3))
        break

      default:
        dataInicial = periodoDiario
        dataFinal = diaFim
    }

    this.match.DATA_BASE = { $gte: dataInicial, $lt: dataFinal }
    this.match.CANCELADA = req.cancelada != null ? { $eq: req.cancelada } : null
    this.match.FLAG_DATA = req.flag_data != null ? { $eq: req.flag_data } : null
    this.match.FLAG_MAIOR_MES = req.flag_maior_mes != null ? { $eq: req.flag_maior_mes } : null
    this.match.OPERACAO_DESC = req.operacao_desc != null ? { $in: req.operacao_desc } : null
    // console.log('Data_base', this.match.DATA_BASE)

    Object.keys(this.match).forEach((key) => (this.match[key] == null) && delete this.match[key])
  }

  public setGroup (group: Array<string>): void {
    const obj = JSON.parse(JSON.stringify(this.group))
    Object.keys(obj._id).forEach((key) => (!group.includes(key)) && delete obj._id[key])
    this.group = obj
  }

  public cleanGroup (): void {
    this.initGroup()
  }

  public cleanMath (): void {
    this.initMatch()
  }
}
export default GroupMeta
