import {
   MatchSolicitacaoCargaInterface,
   GroupSolicitacaoCargaInterface,
   RequestSolicitacaoCargaInterface
} from '../interfaces/solicitacao_carga.interface'

export class GroupSolicitacaoCarga {

   public group: GroupSolicitacaoCargaInterface
   public match: MatchSolicitacaoCargaInterface

   constructor() {
      this.initGroup()
      this.initMatch()
   }

   private initGroup(): void {
      const group = {} as GroupSolicitacaoCargaInterface
      group._id = {}
      group.qtde = { $sum: 1 }

      this.group = group
   }

   public setGroup(req: RequestSolicitacaoCargaInterface, group: Array<any>): void {
      Object.assign(this.group._id, null)
      /**
       * Foreach para casos de agrupar por mais de um atributo
       * Ex: situacao por cliente, produto por cliente e etc
       */
      group.forEach((x, index) => {
         switch (x) {


            case 'situacao':
               Object.assign(this.group._id, { 'situacao': '$SITUACAO_ID' })
               break

            case 'situacao_desc':
               Object.assign(this.group._id, { 'situacao_desc': '$SITUACAO' })
               break

            case 'remetente':
               Object.assign(this.group._id, { 'remetente': '$REMETENTE_CLIENTE' })
               break;

            case 'destinatario':
               Object.assign(this.group._id, { 'destinatatio': '$DESTINATARIO_CLIENTE' })
               break;

            case 'cliente':
               Object.assign(this.group._id, { 'cliente': '$CLIENTE' })
               break

            case 'produto':
               Object.assign(this.group._id, { 'produto': '$PRODUTO' })
               break

            case 'operacao':
               Object.assign(this.group._id, { 'operacao': '$OPERACAO' })
               break

            case 'origem':
               Object.assign(this.group._id, { 'origem': '$ORIGEM_MUNICIPIO' })
               break;

            case 'destino':
               Object.assign(this.group._id, { 'destino': '$DESTINO_MUNICIPIO' })
               break;

            case 'motivo_can':
               Object.assign(this.group._id, { 'motivo_can': '$MOTIVO_CAN' })
               break;

            case 'last_update':
               this.group.valor = { $max: '$DATA_CARGA' }
               break

            default:
               break
         }

      });

      this.prepareQuery()
   }


   public cleanGroup(): void {
      this.initGroup()
   }

   public cleanMath(): void {
      this.initMatch()
   }

   private initMatch(): void {
      const match = {} as MatchSolicitacaoCargaInterface
      match.DATA = null
      match.NR_HORA = null
      match.CANCELADA = null
      match.SITUACAO_ID = null
      match.DATA_CARREGAMENTO_INICIO = null
      match.DATA_INICIO_CARGA = null
      match.ORIGEM = null
      match.NR_SEMANA = null
      this.match = match
   }

   // eslint-disable-next-line @typescript-eslint/no-explicit-any
   public getReturn(ret: Array<any>): Array<any> {
      ret.forEach((element, index) => {

         if (element._id) {
            Object.assign(element, element._id)
            delete element._id
         }
      })

      // se tiver mais de um atributo significa agrupamento por mais de um campo
      let n_key = ret[0] && Object.keys(ret[0]).length

      if (ret && ret.length > 0 && n_key < 2) {

         if (ret[0] && ret[0].qtde) {
            return ret[0].qtde

         } if (ret[0] && ret[0].valor) {
            return ret[0].valor

         }

      }
      return ret

   }

   public setMatchSolicitacaoCarga (req: RequestSolicitacaoCargaInterface): void {
      // const timeZone = ('en-US', { timeZone: 'America/Santiago' });


      // const diaSemana = new Date().getDay() - 1
      // const periodoDiario = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate())
      // const periodoSemanal = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getUTCDate() - diaSemana)
      // const periodoMensal = new Date(new Date().getFullYear(), new Date().getMonth(), 1)

      // const semanalFim = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getUTCDate() + (7 - diaSemana))
      // const mesFim = new Date(new Date().getFullYear(), new Date().getMonth() + 1, 1)
      // const diaFim = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getUTCDate() + 1)



      const data = new Date(new Date().valueOf() - new Date().getTimezoneOffset() - (60 * 60000 * 3))
      const ano = data.getFullYear()
      const mes = data.getMonth() + 1
      const dia = data.getUTCDate()
      const semana = data.getDay()

      let nr_mes = null;
      let nr_dia = null;
      let nr_ano = null;
      let nr_semana = null;

      switch (req.periodo) {


         case 'diario':
            // dataInicial = data.substr(0, 10)
            // dataFinal = data1.substr(0, 10)

            nr_ano = ano
            nr_mes = mes
            nr_dia = dia
            break

         case 'semanal':
            // dataInicial = periodoSemanal
            // dataFinal = semanalFim
            nr_ano = ano;
            nr_semana = semana;
            break

         case 'mensal':
            // dataInicial = new Date(periodoMensal.setHours(0, 0, 0, 0) - (60 * 60000))
            // dataFinal = mesFim//new Date(mesFim.setHours(0, 0, 0, 0) - (60 * 60000))
            nr_ano = ano;
            nr_mes = mes;
            break
         case 'anual':
            nr_ano = ano;
            break;

         // case 'hora':
         //    dataInicial = new Date(periodoDiario.setHours(req.hora))//new Date(periodoDiario.setHours(0, 0, 0, 0) - (60 * 60000 - req.hora))
         //    dataFinal = new Date(periodoDiario.setHours(req.hora + 1))
         //    break;


         default:
            // dataInicial = periodoDiario
            // dataFinal = diaFim
            nr_ano = ano
            nr_mes = mes
            nr_dia = dia
      }


      this.match = {} as MatchSolicitacaoCargaInterface


      // this.match.DATA_CARREGAMENTO_INICIO =  //req.data_carregamento_inicio ? 
      //  { $gte: dataInicial, $lt: dataFinal }  // referente a solic_carga
      // this.match.DATA = req.data_carregamento_inicio ? { $gte: dataInicial, $lt: dataFinal } : null
      this.match.DATA_INICIO_CARGA = req.data_inicio_carga ? { $ne: null } : null // referente ao romaneio

      this.match.SITUACAO_ID = req.situacao_id ? { $eq: req.situacao_id } : null
      this.match.CANCELADA = req.cancelada != null ? { $eq: req.cancelada } : null
      this.match.ORIGEM = req.origem ? { $eq: req.origem } : null
      this.match.NR_HORA = req.hora ? { $eq: req.hora } : null


      this.match.NR_ANO = nr_ano ? { $eq: nr_ano } : null
      this.match.NR_MES = nr_mes ? { $eq: nr_mes } : null
      this.match.NR_SEMANA = nr_semana ? { $eq: nr_semana } : null
      this.match.NR_DIA_MES = nr_dia ? { $eq: nr_dia } : null
      this.match.NR_HORA = req.hora ? { $eq: req.hora } : null


      this.prepareQuery()
   }

   public prepareQuery(): void {
      Object.keys(this.group._id).forEach((key) => (this.group._id[key] == null) && delete this.group._id[key])
      Object.keys(this.match).forEach((key) => (this.match[key] == null) && delete this.match[key])
   }
}
export default GroupSolicitacaoCarga
