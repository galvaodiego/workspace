import { MatchFaturamentoInterface, GroupFaturamentoInterface, RequestFaturamentoInterface } from '../interfaces/faturamento.interface'

export class GroupFaturamento {
  public group : GroupFaturamentoInterface
  public match : MatchFaturamentoInterface

  constructor () {
    this.initGroup()
    this.initMatch()
  }

  private initGroup (): void{
    const group = {} as GroupFaturamentoInterface
    group._id = {}
    group._id.data = null
    group._id.cliente = null
    group._id.mercadoria = null
    group._id.tipoCarroceria = null
    group._id.placa = null
    group._id.frota = null
    group._id.modalidade = null
    group._id.filial = null
    group.valor = { $sum: '$VALOR' }
    group.meta = { $sum: '$META' }
    group.viagens = { $sum: '$QTD_VIAGENS' }
    group.subistituto = { $sum: '$SUBSTITUTO' }
    this.group = group
  }

  public setGroup (req: RequestFaturamentoInterface, group: string): void {
    switch (group) {
      case 'data':
        this.group._id.data = req.periodo === 'anual' ? {
          $dateToString: {
            date: '$DATA_EMISSAO',
            format: '%m/%Y'
          }
        } : {
          $dateToString: {
            date: '$DATA_EMISSAO',
            format: '%d/%m'
          }
        }
        break
      case 'cliente':
        this.group._id.cliente = '$CLIENTE'
        break
      case 'mercadoria':
        this.group._id.mercadoria = '$MERCADORIA'
        break
      case 'modalidade':
        this.group._id.modalidade = '$MODALIDADE'
        break
      case 'destino':
        this.group._id.destino = '$DESTINO'
        break
      case 'carroceria':
        this.group._id.tipoCarroceria = '$TIPO_CARROCERIA'
        break
      case 'filial':
        this.group._id.filial = '$FILIAL'
        break
      case 'placa':
        this.group._id.placa = '$PLACA'
        this.group._id.frota = '$FROTA'
        this.group._id.modelo = '$MODELO'
        break
      default:
        break
    }

    this.prepareQuery()
  }

  public cleanGroup ():void {
    this.initGroup()
  }

  private initMatch (): void {
    const match = {} as MatchFaturamentoInterface
    match.CLIENTE = null
    match.DESTINO = null
    match.MERCADORIA = null
    match.PLACA = null
    match.FROTA = null
    match.MODELO = null
    match.MODALIDADE = null
    match.DATA_EMISSAO = null
    match.FILIAL = null
    match.META = null
    this.match = match
  }

  public getReturn (ret: Array<any>):Array<any> {
    ret.forEach(element => {
      element.valor = parseFloat(element.valor)
      element.meta = parseFloat(element.meta)
      element.viagens = parseInt(element.viagens)
      element.subistituto = parseInt(element.subistituto)

      if (element._id) {
        Object.assign(element, element._id)
        delete element._id
      }
    })
    return ret
  }

  public setMatchFaturamento (req: RequestFaturamentoInterface): void {
    const dia = new Date()
    dia.setUTCHours(-0)
    dia.setUTCMinutes(-0)
    dia.setUTCSeconds(-0)
    dia.setUTCMilliseconds(-0)
    const periodoSemanal = new Date(dia)
    const x = periodoSemanal.getDay() !== 1 ? periodoSemanal.setUTCHours(-24 * (periodoSemanal.getDay() - 1)) : periodoSemanal
    const periodoAnual = new Date(dia.getUTCFullYear(), 0, 1)
    const periodoMensal = new Date(dia.getUTCFullYear(), dia.getUTCMonth(), 1)
    // const periodoSemanal = new Date(new Date().getUTCFullYear(), new Date().getUTCMonth(), 1, new Date().getUTCDay(), -diaSemana)
    periodoAnual.setUTCHours(-0)

    // const periodoSemanal =
    const periodoDiario = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getUTCDate(), 0, 0, 0)
    let dataFiltro = null
    console.log('periodo ', req.periodo)
    switch (req.periodo) {
      case 'diario' :
        dataFiltro = periodoDiario
        break
      case 'semanal':

        dataFiltro = periodoSemanal
        break
      case 'mensal':
        dataFiltro = new Date(periodoMensal.setHours(0, 0, 0, 0) - (60 * 60000 * 3))
        break
      case 'anual':
        dataFiltro = periodoAnual
        break
      default:
        dataFiltro = periodoAnual
    }
   
    this.match = {} as MatchFaturamentoInterface
    this.match.CLIENTE = req.cliente ? { $in: req.cliente } : null
    this.match.DESTINO = req.destino ? { $in: req.destino } : null
    this.match.MERCADORIA = req.mercadoria ? { $in: req.mercadoria } : null
    this.match.PLACA = req.placa ? { $in: req.placa } : null
    this.match.FROTA = req.frota ? { $in: req.frota } : null
    this.match.MODALIDADE = req.modalidade ? { $in: req.modalidade } : null
    this.match.DATA_EMISSAO = { $gte: dataFiltro }
    this.match.MODELO = req.modelo ? { $in: req.modelo } : null
    this.match.FILIAL = req.filial ? { $in: req.filial } : null
    this.match.META = req.meta !== undefined ? { $eq: req.meta } : null
    this.prepareQuery()
  }

  public prepareQuery ():void {
    Object.keys(this.group._id).forEach((key) => (this.group._id[key] == null) && delete this.group._id[key])
    Object.keys(this.match).forEach((key) => (this.match[key] == null) && delete this.match[key])
  }
}
export default GroupFaturamento
