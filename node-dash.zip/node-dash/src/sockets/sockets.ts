/* eslint-disable camelcase */
/* eslint-disable no-unused-vars */
/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/camelcase */

import socketIo from 'socket.io'

import MonitoramentoController from '../modules/app-monitoramento/monitoramento.controller'
import IndicadorLogisticoController from '../modules/app-monitoramento/indicador_log.controller'
import AcompLogisticoController from '../modules/app-monitoramento/acomp_logistico.controller'

import ViagemController from '../controllers/viagem.controller'
import ProdutividadeController from '../modules/produtividade/produtividade.controller'
import FaturamentoController from '../controllers/faturamento.controller'
import lobbyController from '../controllers/lobby.controller'

import MetaController from '../controllers/meta.controller'
import CentralCargaController from '../controllers/central_carga.controller'

import alertaController from '../controllers/alerta.controller'
import FluxoLogisticoController from '../modules/integracao/fluxo_logistico.controller'
import NivelServicoController from '../modules/nivel-servico/nivel-servico.controller'

import JornadaController from '../modules/jornada/controller/jornada.controller'
import JornadaController_v2 from '../modules/jornada_v2/controller/jornada.controller'
import DescargaController from '../modules/descarga/controller/descarga.controller'
import DescargaController_v2 from '../modules/descarga_v2/controller/descarga.controller'
import CargaController from '../modules/carga/controller/carga.controller'
import CargaController_v2 from '../modules/carga_v2/controller/carga.controller'
import TransitTimeController from '../modules/transit-time/controller/transit_time.controller'
import TransitTimeController_v2 from '../modules/transit-time_v2/controller/transit_time.controller'
import ServiceCenterController from '../modules/service-center/controller/service_center.controller'

import ManutencaoController from '../modules/manutencao/manutencao.controller'
import DemandaControler from '../modules/demanda/controller/demanda.controller'
import DisponibilidadeMotoristaController from '../modules/disponibilidade-motorista/controller/disponibilidade-motorista.controller'
import ListaAtendimentoController from '../modules/lista-atendimento/controller/lista-atendimento.controller'
import automacaoController from '../modules/automacao/automacao.controller'
import preventivasController from '../modules/preventivas/preventivas.controller'
import preventivasController_v2 from '../modules/preventivas_v2/preventivas.controller'
import velocidadeController from '../modules/velocidade/velocidade.controller'
import acompDecargaController from '../modules/acomp-descarga/acomp-descarga.controller'
import controleTrafegoController from '../modules/controle-trafego/controle-trafego.controller'
import logger from '../logger'
import oficinaController from '../modules/oficina/oficina.controller'
import recebiveisController from '../modules/recebiveis/recebiveis.controller'

import ViagensMapsController from '../modules/viagens_maps/controller/viagens_maps.controller'
import ViagensTempController from '../modules/viagens_temperatura/controller/viagens_temp.controller'
import ViagensTempDetalhesController from '../modules/viagens_temperatura_detalhes/controller/viagens_temp_detalhes.controller'
import ViagensHistController from '../modules/viagens_historico/controller/viagens_hist.controller'
import ViagensHistDetalhesController from '../modules/viagens_historico_detalhes/controller/viagens_hist_detalhes.controller'



// Talend Versão 2.0
import BoxManutencaoController from '../modules/box_manutencao/controller/box.controller'
// Perguntar por que tem dois?
import FaturamentoController_v2 from '../modules/faturamento/controller/faturamento.controller'
import ViagensController_v2 from '../modules/viagens/controller/viagens.controller'

// Playground
import PlaygroundController from '../modules/playground/controller/playground_controller'

const onlineClients = []

export class Sockets {
  public io: SocketIO.Server
  private port: number
  public clients: Array<object>

  public socket(server): void {
    this.io = socketIo(server)
    // console.log('socket on')
    logger.info('Socket on')
  }

  private socketUnregistry(socket): void {
    this.clients.forEach((value, key) => {
      if (value.id === socket.id) {
        if (this.clients[key]) { delete this.clients[key] }
      }
    })
  }

  private socketRegistry(socket, origin, filtro): void {
    let update
    const obj = {
      f: filtro,
      s: socket,
      d: origin,
      id: socket.id
    }

    this.clients.forEach((value, key) => {
      if (value.id === socket.id) {
        update = key
      }
    })
    if (update !== undefined && update !== null) {
      this.clients[update] = obj
    } else {
      this.clients.push(obj)
    }
  }

  public listen(server, porta): void {
    server.listen(porta, () => {
      // console.log('Running server on port %s', porta)
      logger.info('Running server on port %s', porta)
    })
    const faturamento = this.io.of('/faturamento')
    const alerta = this.io.of('/alerta')
    const viagem = this.io.of('/viagem')
    const produtividade = this.io.of('/produtividade')

    const meta = this.io.of('/meta')
    const central_carga = this.io.of('/central_carga')
    const lobbyApp = this.io.of('/lobby')
    const fluxo_logistico = this.io.of('/fluxo_logistico')
    const indicador_logistico = this.io.of('/indicador_logistico')
    const monitoramento = this.io.of('/monitoramento')
    const acomp_logistico = this.io.of('/acomp_logistico')
    const nivel_servico = this.io.of('/nivel_servico')

    const jornada = this.io.of('/jornada')
    const descarga = this.io.of('/descarga')
    const carga = this.io.of('/carga')
    const transit_time = this.io.of('/transit_time')
    const service_center = this.io.of('/service_center')
    const manutencao = this.io.of('/manutencao')
    const demanda = this.io.of('/demanda')
    const disponibilidade_motorista = this.io.of('/disponibilidade_motorista')
    const lista_atendimento = this.io.of('/lista_atendimento')
    const automacao = this.io.of('/automacao')
    const preventivas = this.io.of('/preventivas')
    const velocidade = this.io.of('/velocidade')
    const acomp_descarga = this.io.of('/acomp_descarga')
    const controle_trafego = this.io.of('/controle_trafego')
    const oficina = this.io.of('/oficina')
    const recebiveis = this.io.of('/recebiveis')

    const viagens_maps = this.io.of('/viagens_maps')
    const viagens_temp = this.io.of('/viagens_temp')
    const viagens_hist = this.io.of('/viagens_hist')

    // Talend Versão 2.0
    const faturamento_v2 = this.io.of('/faturamento_v2')
    const viagens_v2 = this.io.of('/viagens_v2')



    const box = this.io.of('/box')


    const playground = this.io.of('/playground')

    this.clients = []
    this.objeto = {}

    lobbyApp.on('connection', (socket) => {
      // console.log('lobby')

      socket.on('getInfo', (filtro) => {
        filtro.base = filtro.base === 'ritmolog' ? 'ritmo' : filtro.base
        // console.log('array: ', onlineClients.length)

        lobbyController.getInfo(filtro, socket)
      })
    })

    faturamento.on('connection', (socket) => {
      // console.log('\x1b[32m', 'in', '\x1b[0m', 'faturamento', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
      socket.on('getFaturamento', (filtro) => {
        // console.log('getFaturamento', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        filtro.base = filtro.base === 'ritmolog' ? 'ritmo' : filtro.base
        this.socketRegistry(socket, 'faturamento', filtro)
        FaturamentoController.getFaturamento(filtro, socket)
      })
      socket.on('disconnect', () => {
        // console.log('\x1b[31m', 'out', '\x1b[0m', 'Faturamento', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketUnregistry(socket)
      })
    })

    faturamento.on('connection', (socket) => {
      // console.log('\x1b[32m', 'in', '\x1b[0m', 'faturamento', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
      socket.on('getFaturamento_v2', (filtro) => {
        // console.log('getFaturamento', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        filtro.base = filtro.base === 'ritmolog' ? 'ritmo' : filtro.base
        this.socketRegistry(socket, 'faturamento', filtro)
        FaturamentoController.getFaturamentoV2(filtro, socket)
      })
      socket.on('disconnect', () => {
        // console.log('\x1b[31m', 'out', '\x1b[0m', 'Faturamento', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketUnregistry(socket)
      })
    })

    alerta.on('connection', (socket, tt) => {
      // console.log('\x1b[32m', 'in', '\x1b[0m', 'alerta', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
      socket.on('getAlerta', (filtro) => {
        this.socketRegistry(socket, 'alerta', filtro)

        // console.log('getAlerta', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        filtro.base = filtro.base === 'ritmolog' ? 'ritmo' : filtro.base

        alertaController.getAlerta(filtro, socket)
      })
      socket.on('disconnect', () => {
        // console.log('\x1b[31m', 'out', '\x1b[0m', 'Alerta', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketUnregistry(socket)
      })
    })

    viagem.on('connection', (socket) => {
      // console.log('\x1b[32m', 'in', '\x1b[0m', 'viagem', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
      socket.on('getViagem', (filtro) => {
        this.socketRegistry(socket, 'viagem', filtro)
        // console.log('getViagem', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)

        ViagemController.getViagem(filtro, socket)
      })
      socket.on('disconnect', () => {
        // console.log('\x1b[31m', 'out', '\x1b[0m', 'Viagem', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketUnregistry(socket)
      })
    })

    viagem.on('connection', (socket) => {
      // console.log('\x1b[32m', 'in', '\x1b[0m', 'viagem', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
      socket.on('getViagem_v2', (filtro) => {
        this.socketRegistry(socket, 'viagem', filtro)
        // console.log('getViagem', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)

        ViagemController.getViagemV2(filtro, socket)
      })
      socket.on('disconnect', () => {
        // console.log('\x1b[31m', 'out', '\x1b[0m', 'Viagem', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketUnregistry(socket)
      })
    })

    produtividade.on('connection', (socket) => {
      // console.log('\x1b[32m', 'in', '\x1b[0m', 'produtividade', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
      socket.on('getProdutividade', (filtro) => {
        this.socketRegistry(socket, 'produtividade', filtro)
        // console.log('getProdutividade', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)

        ProdutividadeController.getProdutividade(filtro, socket)
      })
      socket.on('disconnect', () => {
        // console.log('\x1b[31m', 'out', '\x1b[0m', 'Produtividade', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)

        this.socketUnregistry(socket)
      })
    })

    meta.on('connection', (socket) => {
      // console.log('\x1b[32m', 'in', '\x1b[0m', 'meta', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
      socket.on('getMeta', (filtro) => {
        this.socketRegistry(socket, 'meta', filtro)
        // console.log('getMeta', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)

        MetaController.getMeta(filtro, socket)
      })
      socket.on('disconnect', () => {
        // console.log('\x1b[31m', 'out', '\x1b[0m', 'Meta', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketUnregistry(socket)
      })
    })

    central_carga.on('connection', (socket) => {
      // console.log('\x1b[32m', 'in', '\x1b[0m', 'central_carga', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
      socket.on('getCentralCarga', (filtro) => {
        // console.log('getSolicitacao', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketRegistry(socket, 'centralcarga', filtro)

        CentralCargaController.getCentralCarga(filtro, socket)
        // SolicitacaoController.getSolicitacaoCarga(filtro, socket)
      })
      socket.on('disconnect', () => {
        // console.log('\x1b[31m', 'out', '\x1b[0m', 'CentralCarga', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketUnregistry(socket)
      })
    })

    // feed.on('connection', (socket) => {
    //   socket.on('getFeed', (filtro) => {
    // console.log('feed')
    //     this.socketRegistry(socket, 'feed', filtro)
    //     UsuarioController.insertUsuario(socket.id, filtro.base, 'feed', socket)

    //     FeedController.getFeed(filtro, socket)
    //   })
    //   socket.on('disconnect', async () => {
    //     if (socket.id) {
    //       const user = await UsuarioController.findOne(socket.id)

    //       if (user) {
    //         UsuarioController.deleteUsuario(user)
    //       }
    //     }
    //   })
    // })

    fluxo_logistico.on('connection', (socket) => {
      // console.log('\x1b[32m', 'in', '\x1b[0m', 'fluxo_logistico', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
      socket.on('getFluxoLogistico', (filtro) => {
        this.socketRegistry(socket, 'fluxologistico', filtro)
        // console.log('getSolicitacao', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)

        FluxoLogisticoController.getFluxoLogistico(filtro, socket)
      })
      socket.on('disconnect', () => {
        // console.log('\x1b[31m', 'out', '\x1b[0m', 'FluxoLogistico', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketUnregistry(socket)
      })
    })

    indicador_logistico.on('connection', (socket) => {
      // console.log('\x1b[32m', 'in', '\x1b[0m', 'indicador_logistico', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
      socket.on('getIndicadorLogistico', (filtro) => {
        // console.log('getSolicitacao', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketRegistry(socket, 'indicadorlogistico', filtro)

        IndicadorLogisticoController.getIndicadorLogistico(filtro, socket)
      })

      socket.on('disconnect', () => {
        // console.log('\x1b[31m', 'out', '\x1b[0m', 'IndicadorLogistico', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketUnregistry(socket)
      })
    })

    monitoramento.on('connection', (socket) => {
      // console.log('\x1b[32m', 'in', '\x1b[0m', 'monitoramento', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
      socket.on('getMonitoramento', (filtro) => {
        // console.log('getSolicitacao', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketRegistry(socket, 'monitoramento', filtro)

        MonitoramentoController.getMonitoramento(filtro, socket)
      })

      socket.on('disconnect', () => {
        // console.log('\x1b[31m', 'out', '\x1b[0m', 'Monitoramento', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)

        this.socketUnregistry(socket)
      })
    })

    acomp_logistico.on('connection', (socket) => {
      // console.log('\x1b[32m', 'in', '\x1b[0m', 'acomp_logistico', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
      socket.on('getAcompLogistico', (filtro) => {
        // console.log('getSolicitacao', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketRegistry(socket, 'acomplogistico', filtro)

        AcompLogisticoController.getAcompLogistico(filtro, socket)
      })

      socket.on('disconnect', () => {
        // console.log('\x1b[31m', 'out', '\x1b[0m', 'AcompLogistico', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketUnregistry(socket)
      })
    })

    nivel_servico.on('connection', (socket) => {
      // console.log('\x1b[32m', 'in', '\x1b[0m', 'nivel_servico', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
      socket.on('getNivelServico', (filtro) => {
        // console.log('getSolicitacao', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketRegistry(socket, 'nivelservico', filtro)
        NivelServicoController.getNivelServico(filtro, socket)
      })

      socket.on('disconnect', () => {
        // console.log('\x1b[31m', 'out', '\x1b[0m', 'NivelServico', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketUnregistry(socket)
      })
    })

    jornada.on('connection', (socket) => {
      // console.log('\x1b[32m', 'in', '\x1b[0m', 'jornada', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
      socket.on('getJornada', (filtro) => {
        this.socketRegistry(socket, 'jornada', filtro)
        JornadaController.getJornada(filtro, socket)
      })

      socket.on('disconnect', () => {
        // console.log('\x1b[31m', 'out', '\x1b[0m', 'Jornada', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketUnregistry(socket)
      })
    })

    jornada.on('connection', (socket) => {
      // console.log('\x1b[32m', 'in', '\x1b[0m', 'jornada', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
      socket.on('getJornada_v2', (filtro) => {
        this.socketRegistry(socket, 'jornada', filtro)
        JornadaController_v2.getJornada(filtro, socket)
      })

      socket.on('disconnect', () => {
        // console.log('\x1b[31m', 'out', '\x1b[0m', 'Jornada', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketUnregistry(socket)
      })
    })

    transit_time.on('connection', (socket) => {
      // console.log('\x1b[32m', 'in', '\x1b[0m', 'transit-time', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
      socket.on('getTransitTime', (filtro) => {
        this.socketRegistry(socket, 'transit-time', filtro)
        TransitTimeController.getTransitTime(filtro, socket)
      })
      socket.on('disconnect', () => {
        // console.log('\x1b[31m', 'out', '\x1b[0m', 'transit-time', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketUnregistry(socket)
      })
    })

    transit_time.on('connection', (socket) => {
      // console.log('\x1b[32m', 'in', '\x1b[0m', 'transit-time', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
      socket.on('getTransitTime_v2', (filtro) => {
        this.socketRegistry(socket, 'transit-time', filtro)
        TransitTimeController_v2.getTransitTime(filtro, socket)
      })
      socket.on('disconnect', () => {
        // console.log('\x1b[31m', 'out', '\x1b[0m', 'transit-time', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketUnregistry(socket)
      })
    })

    carga.on('connection', (socket) => {
      // console.log('\x1b[32m', 'in', '\x1b[0m', 'carga', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
      socket.on('getCarga', (filtro) => {
        this.socketRegistry(socket, 'carga', filtro)
        CargaController.getCarga(filtro, socket)
      })
      socket.on('disconnect', () => {
        // console.log('\x1b[31m', 'out', '\x1b[0m', 'Carga', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketUnregistry(socket)
      })
    })

    carga.on('connection', (socket) => {
      // console.log('\x1b[32m', 'in', '\x1b[0m', 'carga_v2', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
      socket.on('getCarga_v2', (filtro) => {
        this.socketRegistry(socket, 'carga', filtro)
        CargaController_v2.getCarga_v2(filtro, socket)
      })
      socket.on('disconnect', () => {
        // console.log('\x1b[31m', 'out', '\x1b[0m', 'Carga', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketUnregistry(socket)
      })
    })

    descarga.on('connection', (socket) => {
      // console.log('\x1b[32m', 'in', '\x1b[0m', 'descarga', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
      socket.on('getDescarga', (filtro) => {
        this.socketRegistry(socket, 'descarga', filtro)
        DescargaController.getDescarga(filtro, socket)
      })
      socket.on('disconnect', () => {
        // console.log('\x1b[31m', 'out', '\x1b[0m', 'Descarga', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketUnregistry(socket)
      })
    })

    descarga.on('connection', (socket) => {
      // console.log('\x1b[32m', 'in', '\x1b[0m', 'descarga_v2', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
      socket.on('getDescarga_v2', (filtro) => {
        this.socketRegistry(socket, 'descarga', filtro)
        DescargaController_v2.getDescarga_v2(filtro, socket)
      })
      socket.on('disconnect', () => {
        // console.log('\x1b[31m', 'out', '\x1b[0m', 'Descarga', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketUnregistry(socket)
      })
    })

    service_center.on('connection', (socket) => {
      // console.log('\x1b[32m', 'in', '\x1b[0m', 'serviceCenter', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)

      socket.on('getDashboard', (filtro) => {
        // console.log('getDashboard', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        filtro.base = filtro.base === 'ritmolog' ? 'ritmo' : filtro.base
        this.socketRegistry(socket, 'dashboard', filtro)

        ServiceCenterController.getDashboard(filtro, socket)
      })

      socket.on('getListaAtendimentos', (filtro) => {
        // console.log('getListaAtendimentos', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        filtro.base = filtro.base === 'ritmolog' ? 'ritmo' : filtro.base
        this.socketRegistry(socket, 'listaAtendimentos', filtro)
        ServiceCenterController.getListaAtendimentos(filtro, socket)
      })
      socket.on('disconnect', () => {
        // console.log('\x1b[31m', 'out', '\x1b[0m', 'serviceCenter', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketUnregistry(socket)
      })
    })

    manutencao.on('connection', (socket) => {
      // console.log('\x1b[32m', 'in', '\x1b[0m', 'manutencao', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
      socket.on('getManutencao', (filtro) => {
        this.socketRegistry(socket, 'manutencao', filtro)
        ManutencaoController.getManutencao(filtro, socket)
      })
      socket.on('disconnect', () => {
        // console.log('\x1b[31m', 'out', '\x1b[0m', 'Manutencao', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketUnregistry(socket)
      })
    })

    demanda.on('connection', (socket) => {
      // console.log('\x1b[32m', 'in', '\x1b[0m', 'demanda', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
      socket.on('getDemanda', (filtro) => {
        this.socketRegistry(socket, 'demanda', filtro)
        DemandaControler.getDemanda(filtro, socket)
      })
      socket.on('disconnect', () => {
        // console.log('\x1b[31m', 'out', '\x1b[0m', 'demanda', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketUnregistry(socket)
      })
    })

    disponibilidade_motorista.on('connection', (socket) => {
      // console.log('\x1b[32m', 'in', '\x1b[0m', 'disponibilidade_motorista', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
      socket.on('getDisponibilidadeMotorista', (filtro) => {
        this.socketRegistry(socket, 'disponibilidade-motorista', filtro)
        DisponibilidadeMotoristaController.getDisponibilidadeMotorista(filtro, socket)
      })
      socket.on('disconnect', () => {
        // console.log('\x1b[31m', 'out', '\x1b[0m', 'disponibilidade_motorista', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketUnregistry(socket)
      })
    })

    lista_atendimento.on('connection', (socket) => {
      // console.log('\x1b[32m', 'in', '\x1b[0m', 'lista_atendimento', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
      socket.on('getListaAtendimento', (filtro) => {
        this.socketRegistry(socket, 'lista-atendimento', filtro)
        ListaAtendimentoController.getListaAtendimento(filtro, socket)
      })
      socket.on('disconnect', () => {
        // console.log('\x1b[31m', 'out', '\x1b[0m', 'lista_atendimento', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketUnregistry(socket)
      })
    })

    automacao.on('connection', (socket) => {
      // console.log('\x1b[32m', 'in', '\x1b[0m', 'automacao', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
      socket.on('getAutomacao', (filtro) => {
        this.socketRegistry(socket, 'automacao', filtro)
        automacaoController.getAutomacao(filtro, socket)
      })
      socket.on('disconnect', () => {
        // console.log('\x1b[31m', 'out', '\x1b[0m', 'automacao', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketUnregistry(socket)
      })
    })

    preventivas.on('connection', (socket) => {
      // console.log('\x1b[32m', 'in', '\x1b[0m', 'perventivas', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
      socket.on('getPreventivas', (filtro) => {
        this.socketRegistry(socket, 'automacao', filtro)
        preventivasController.getPreventivas(filtro, socket)
      })
      socket.on('disconnect', () => {
        // console.log('\x1b[31m', 'out', '\x1b[0m', 'perventivas', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketUnregistry(socket)
      })
    })

    preventivas.on('connection', (socket) => {
      // console.log('\x1b[32m', 'in', '\x1b[0m', 'perventivas', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
      socket.on('getPreventivas_v2', (filtro) => {
        this.socketRegistry(socket, 'automacao', filtro)
        preventivasController_v2.getPreventivas(filtro, socket)
      })
      socket.on('disconnect', () => {
        // console.log('\x1b[31m', 'out', '\x1b[0m', 'perventivas', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketUnregistry(socket)
      })
    })

    velocidade.on('connection', (socket) => {
      // console.log('\x1b[32m', 'in', '\x1b[0m', 'velocidade', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
      socket.on('getVelocidade', (filtro) => {

        this.socketRegistry(socket, 'velocidade', filtro)
        velocidadeController.getVelocidade(filtro, socket)
      })
      socket.on('disconnect', () => {
        // console.log('\x1b[31m', 'out', '\x1b[0m', 'velocidade', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketUnregistry(socket)
      })
    })

    acomp_descarga.on('connection', (socket) => {
      // console.log('\x1b[32m', 'in', '\x1b[0m', 'acomp-descarga', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
      socket.on('getAcompDescarga', (filtro) => {
        // console.log('Socket')
        this.socketRegistry(socket, 'acomp-descarga', filtro)
        acompDecargaController.getAcompDescarga(filtro, socket)
      })
      socket.on('disconnect', () => {
        // console.log('\x1b[31m', 'out', '\x1b[0m', 'acomp-descarga', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketUnregistry(socket)
      })
    })

    controle_trafego.on('connection', (socket) => {
      // console.log('\x1b[32m', 'in', '\x1b[0m', 'controle-trafego', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
      socket.on('getControleTrafego', (filtro) => {

        this.socketRegistry(socket, 'controle-trafego', filtro)
        controleTrafegoController.getControleTrafego(filtro, socket)
      })

      socket.on('disconnect', () => {
        // console.log('\x1b[31m', 'out', '\x1b[0m', 'controle-trafego', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketUnregistry(socket)
      })
    })

    oficina.on('connection', (socket) => {
      // console.log('\x1b[32m', 'in', '\x1b[0m', 'oficina', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
      socket.on('getOficina', (filtro) => {

        this.socketRegistry(socket, 'oficina', filtro)
        oficinaController.getOficina(filtro, socket)
      })

      socket.on('disconnect', () => {
        // console.log('\x1b[31m', 'out', '\x1b[0m', 'oficina', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketUnregistry(socket)
      })
    })

    recebiveis.on('connection', (socket) => {
      // console.log('\x1b[32m', 'in', '\x1b[0m', 'recebiveis', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
      socket.on('getRecebiveis', (filtro) => {

        this.socketRegistry(socket, 'oficina', filtro)
        recebiveisController.getRecebiveis(filtro, socket)
      })

      socket.on('disconnect', () => {
        // console.log('\x1b[31m', 'out', '\x1b[0m', 'recebiveis', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketUnregistry(socket)
      })
    })

    viagens_maps.on('connection', (socket) => {
      // console.log('\x1b[32m', 'in', '\x1b[0m', 'viagens_maps', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
      socket.on('getViagensMaps', (filtro) => {
        this.socketRegistry(socket, 'viagens_maps', filtro)
        ViagensMapsController.getViagensMaps(filtro, socket)
      })
      socket.on('disconnect', () => {
        // console.log('\x1b[31m', 'out', '\x1b[0m', 'DashViagem', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketUnregistry(socket)
      })
    })

    viagens_temp.on('connection', (socket) => {
      // console.log('\x1b[32m', 'in', '\x1b[0m', 'viagens_temp', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
      socket.on('getViagensTemp', (filtro) => {
        this.socketRegistry(socket, 'viagens_temp', filtro)
        ViagensTempController.getViagensTemp(filtro, socket)
      })
      socket.on('disconnect', () => {
        // console.log('\x1b[31m', 'out', '\x1b[0m', 'DashViagem', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketUnregistry(socket)
      })
    })
    //ViagensTempDetalhesController
    viagens_temp.on('connection', (socket) => {
      // console.log('\x1b[32m', 'in', '\x1b[0m', 'viagens_temp', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
      socket.on('getViagensDetalhes', (filtro) => {
        this.socketRegistry(socket, 'viagens_temp', filtro)
        ViagensTempDetalhesController.getViagensDetalhes(filtro, socket)
      })
      socket.on('disconnect', () => {
        // console.log('\x1b[31m', 'out', '\x1b[0m', 'DashViagem', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketUnregistry(socket)
      })
    })


    viagens_hist.on('connection', (socket) => {
      // console.log('\x1b[32m', 'in', '\x1b[0m', 'viagens_hist', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
      socket.on('getViagensHist', (filtro) => {
        this.socketRegistry(socket, 'viagens_hist', filtro)
        ViagensHistController.getViagensHist(filtro, socket)
      })
      socket.on('disconnect', () => {
        // console.log('\x1b[31m', 'out', '\x1b[0m', 'DashViagem', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketUnregistry(socket)
      })
    })

    viagens_hist.on('connection', (socket) => {
      // console.log('\x1b[32m', 'in', '\x1b[0m', 'viagens_hist', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
      socket.on('getHistDetalhes', (filtro) => {
        this.socketRegistry(socket, 'viagens_hist', filtro)
        ViagensHistDetalhesController.getHistDetalhes(filtro, socket)
      })
      socket.on('disconnect', () => {
        // console.log('\x1b[31m', 'out', '\x1b[0m', 'DashViagem', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketUnregistry(socket)
      })
    })

    box.on('connection', (socket) => {
      // console.log('\x1b[32m', 'in', '\x1b[0m', 'viagens_hist', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
      socket.on('getBox', (filtro) => {
        this.socketRegistry(socket, 'box', filtro)
        BoxManutencaoController.getBox(filtro, socket)
      })
      socket.on('disconnect', () => {
        // console.log('\x1b[31m', 'out', '\x1b[0m', 'DashViagem', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketUnregistry(socket)
      })
    })

    faturamento_v2.on('connection', (socket) => {
      // console.log('\x1b[32m', 'in', '\x1b[0m', 'viagens_hist', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
      socket.on('getFaturamento', (filtro) => {
        this.socketRegistry(socket, 'faturamento_v2', filtro)
        FaturamentoController_v2.getFaturamento(filtro, socket)
      })
      socket.on('disconnect', () => {
        // console.log('\x1b[31m', 'out', '\x1b[0m', 'DashViagem', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketUnregistry(socket)
      })
    })

    viagens_v2.on('connection', (socket) => {
      // console.log('\x1b[32m', 'in', '\x1b[0m', 'viagens_hist', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
      socket.on('getViagens', (filtro) => {
        this.socketRegistry(socket, 'viagens_v2', filtro)
        ViagensController_v2.getViagens(filtro, socket)
      })
      socket.on('disconnect', () => {
        // console.log('\x1b[31m', 'out', '\x1b[0m', 'DashViagem', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketUnregistry(socket)
      })
    })

    playground.on('connection', (socket) => {
      // console.log('\x1b[32m', 'in', '\x1b[0m', 'playground', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
      socket.on('getPlayground', (filtro) => {
        this.socketRegistry(socket, 'playground', filtro)
        PlaygroundController.getPlayground(filtro, socket)
      })
      socket.on('disconnect', () => {
        // console.log('\x1b[31m', 'out', '\x1b[0m', 'DashViagem', socket.request.headers.origin, socket.handshake.address, 'c:', this.io.engine.clientsCount)
        this.socketUnregistry(socket)
      })
    })



  }
}

export default new Sockets()
