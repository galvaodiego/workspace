/* eslint-disable lines-between-class-members */
import GroupAbastecimentoLog from '../group/abastecimento.group'
import { AbastecimentoService } from '../services/abastecimento.service'

class AbastecimentoFilter {

  private _abastecimentoService = new AbastecimentoService()
  private _groupAbastecimento = new GroupAbastecimentoLog()

  public async getFilter (req: object, socket: Socket): Promise<void> {

    const logInicio = new Date()
    const req2 = { base: req.base, filtro: 1 }
    

    const retorno: any = {
      produto: [],
      posto: [],
      placa: [],
      estado: []

    }

    let res = null
    
    this._groupAbastecimento.setMatchAbastecimento(req2)
    res = await this._abastecimentoService.filter({ match: this._groupAbastecimento.match, req: req2 }, ['produto', 'produto_id'], { _id: { chave: -1 } })
    retorno.produto = res

    this._groupAbastecimento.setMatchAbastecimento(req2)
    res = await this._abastecimentoService.filter({ match: this._groupAbastecimento.match, req: req2 }, ['posto', 'posto_id'], { _id: { chave: -1 } })
    retorno.posto = res

    this._groupAbastecimento.setMatchAbastecimento(req2)
    res = await this._abastecimentoService.filter({ match: this._groupAbastecimento.match, req: req2 }, ['placa', 'veiculo_id'], { _id: { chave: -1 } })
    retorno.placa = res

    this._groupAbastecimento.setMatchAbastecimento(req2)
    res = await this._abastecimentoService.filter({ match: this._groupAbastecimento.match, req: req2 }, ['estado'], { _id: { chave: -1 } })
    retorno.estado = res

    console.log('base', req.base,  (new Date() - logInicio) / 1000, 'segundos')
    socket.emit('filtro', retorno)
  }
}

export default new AbastecimentoFilter()

