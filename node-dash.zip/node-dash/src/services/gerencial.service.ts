/* eslint-disable quote-props */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable space-before-function-paren */
/* eslint-disable indent */
import GerencialUsuario from '../schemas/gerencial_usuario.schema'
import GerencialUsuarioGrupoNegociador from '../schemas/gerencial_usuario_grupo_negociador'
import GerencialModulo from '../schemas/gerencial_modulo.schema'
import mongoose from 'mongoose'

export class GerencialService {
    async saveModulo(data: any): Promise<any> {
        const colectionName = 'gerencial_modulo'
        const gerencialModuloModel = mongoose.model(colectionName, GerencialModulo.schema, colectionName)
        const modulo = new GerencialModulo({
            descricao: data.descricao,
            referencia: data.referencia,
            origem: data.origem
        })

        const filter = { _id: data._id }
        gerencialModuloModel.findOneAndUpdate(filter, data, { new: true }).then((e: any) => {
            if (e === null) {
                gerencialModuloModel.collection.insertOne(modulo, function (err) {
                    if (err) {
                        return console.error(err)
                    }
                })
            }
            return true
        })
    }

    async saveUsuario(data: any): Promise<any> {
        const colectionName = 'gerencial_usuario'
        const gerencialUsuarioModel = mongoose.model(colectionName, GerencialUsuario.schema, colectionName)
        const usuario = new GerencialUsuario({
            usuario: data.usuario,
            ativo: data.ativo,
            gerencial: data.gerencial,
            modulos: data.modulos,
            origem: data.origem
        })

        const filter = { _id: data._id }
        gerencialUsuarioModel.findOneAndUpdate(filter, data, { new: true }).then((e: any) => {
            if (e === null) {
                gerencialUsuarioModel.collection.insertOne(usuario, function (err) {
                    if (err) {
                        return console.error(err)
                    }
                })
            }
            return true
        })
    }

    async saveUsuarioGrupo(data: any): Promise<any> {
        const colectionName = 'gerencial_usuario_grupo_negociador'
        const gerencialUsuarioGNModel = mongoose.model(colectionName, GerencialUsuarioGrupoNegociador.schema, colectionName)
        const usuarioGN = new GerencialUsuarioGrupoNegociador({
            usuario: data.usuario,
            grupo_negociador: data.grupo_negociador,
            origem: data.origem
        })

        const filter = { _id: data._id }
        gerencialUsuarioGNModel.findOneAndUpdate(filter, data, { new: true }).then((e: any) => {
            if (e === null) {
                gerencialUsuarioGNModel.collection.insertOne(usuarioGN, function (err) {
                    if (err) {
                        return console.error(err)
                    }
                })
            }
            return true
        })
    }

    async getUsuario(data: any): Promise<any> {
        const filter = { _id: data._id }
        const colectionName = 'gerencial_usuario'
        const gerencialUsuarioModel = mongoose.model(colectionName, GerencialUsuario.schema, colectionName)
        const result = await gerencialUsuarioModel.find(filter)
        return result
    }

    async getUsuarios(data: any): Promise<any> {
        const colectionName = 'gerencial_usuario'
        const gerencialUsuarioModel = mongoose.model(colectionName, GerencialUsuario.schema, colectionName)
        const result = await gerencialUsuarioModel.find({ 'origem': { '$eq': data.origem } })
        return result
    }

    async getModulos(data: any): Promise<any> {
        const colectionName = 'gerencial_modulo'
        const gerencialModuloModel = mongoose.model(colectionName, GerencialModulo.schema, colectionName)
        const result = await gerencialModuloModel.find({ 'origem': { '$eq': data.origem } })
        return result
    }

    async searchUsuarios(data: any): Promise<any> {
        const colectionName = 'gerencial_usuario'
        const gerencialUsuarioModel = mongoose.model(colectionName, GerencialUsuario.schema, colectionName)
        const result = await gerencialUsuarioModel.find({ 'origem': { '$eq': data.origem }, 'usuario': { '$regex': '.*' + data.usuario + '.*', '$options': 'i' } })
        return result
    }

    async getUsuariosGrupo(data: any): Promise<any> {
        const colectionName = 'gerencial_usuario_grupo_negociador'
        const gerencialUsuarioGNModel = mongoose.model(colectionName, GerencialUsuarioGrupoNegociador.schema, colectionName)
        const result = await gerencialUsuarioGNModel.find({ 'origem': { '$eq': data.origem } })
        return result
    }

    async delUsuario(data: any): Promise<any> {
        const filter = { _id: data._id }
        const colectionName = 'gerencial_usuario'
        const gerencialUsuarioModel = mongoose.model(colectionName, GerencialUsuario.schema, colectionName)
        const result = await gerencialUsuarioModel.deleteOne(filter)
        return result
    }

    async delUsuarioGrupo(data: any): Promise<any> {
        const filter = { _id: data._id }
        const colectionName = 'gerencial_usuario_grupo_negociador'
        const gerencialUsuarioGNModel = mongoose.model(colectionName, GerencialUsuarioGrupoNegociador.schema, colectionName)
        const result = await gerencialUsuarioGNModel.deleteOne(filter)
        return result
    }

    async delModulo(data: any): Promise<any> {
        const filter = { _id: data._id }
        const colectionName = 'gerencial_modulo'
        const gerencialModuloModel = mongoose.model(colectionName, GerencialModulo.schema, colectionName)
        const result = await gerencialModuloModel.deleteOne(filter)
        return result
    }
}
