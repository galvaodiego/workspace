/* eslint-disable comma-dangle */
/* eslint-disable semi */
/* eslint-disable quotes */
/* eslint-disable quote-props */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable space-before-function-paren */
/* eslint-disable indent */
import KPI from "../schemas/tos/gmo/kpi.schema";
import Ciclo from "../schemas/tos/gmo/ciclo.schema";
import DescargaHora from "../schemas/tos/gmo/descargaHora.schema";
import Dimensoes from "../schemas/tos/gmo/dimensoes.schema";
import Performance from "../schemas/tos/gmo/performance.schema";
import VeiculoEtapa from "../schemas/tos/gmo/veiculoEtapa.schema";
import Configuracao from "../schemas/tos/gmo/configuracao.schema";
import mongoose from "mongoose";

export class TosService {
  async getGMO(req: any): Promise<any> {
    const obj = {};
    const kpiModel = mongoose.model(
      "tos_gmo_kpi_" + req.body.base,
      KPI.schema,
      "tos_gmo_kpi_" + req.body.base
    );
    const cicloModel = mongoose.model(
      "tos_gmo_ciclo_" + req.body.base,
      Ciclo.schema,
      "tos_gmo_ciclo_" + req.body.base
    );
    const descargaHoraModel = mongoose.model(
      "tos_gmo_descarga_hora_" + req.body.base,
      DescargaHora.schema,
      "tos_gmo_descarga_hora_" + req.body.base
    );
    const dimensoesModel = mongoose.model(
      "tos_gmo_dimensoes_" + req.body.base,
      Dimensoes.schema,
      "tos_gmo_dimensoes_" + req.body.base
    );
    const performanceModel = mongoose.model(
      "tos_gmo_performance_" + req.body.base,
      Performance.schema,
      "tos_gmo_performance_" + req.body.base
    );
    const veiculoEtapaModel = mongoose.model(
      "tos_gmo_veiculo_etapa_" + req.body.base,
      VeiculoEtapa.schema,
      "tos_gmo_veiculo_etapa_" + req.body.base
    );
    const kpiResult = await kpiModel.find();
    const cicloResult = await cicloModel.find();
    const descargaHoraResult = await descargaHoraModel.find();
    const dimensoesResult = await dimensoesModel.find();
    const performanceResult = await performanceModel.find();

    const veiculoEtapaResult = await veiculoEtapaModel.find();
    Object.assign(obj, {
      kpi: kpiResult,
      ciclo: cicloResult,
      descargaHora: descargaHoraResult,
      dimensoes: dimensoesResult,
      performance: this.preparaPerformance(performanceResult),
      veiculoEtapa: veiculoEtapaResult,
    });
    return obj;
  }

  async saveConfig(data: any): Promise<any> {
    const collection = "tos_gmo_config";
    const configModel = mongoose.model(
      collection,
      Configuracao.schema,
      collection
    );
    const config = new Configuracao({
      user: data.user,
      usuario_logon_id: data.usuario_logon_id,
      codGestao: data.codGestao,
      gmo_config: data.gmo_config,
      gmo_config_exibicao: data.gmo_config_exibicao,
    });

    const filter = {
      user: data.user,
      usuario_logon_id: data.usuario_logon_id,
      codGestao: data.codGestao,
    };
    configModel.findOneAndUpdate(filter, data, { new: true }).then((e: any) => {
      if (e === null) {
        configModel.collection.insertOne(config, function(err) {
          if (err) {
            return console.error(err);
          }
        });
      }
      return true;
    });
  }

  async getConfig(data: any): Promise<any> {
    const collection = "tos_gmo_config";
    const configModel = mongoose.model(
      collection,
      Configuracao.schema,
      collection
    );
    const result = await configModel.find({
      usuario_login_id: { $eq: data.usuario_login_id },
      codGestao: { $eq: data.codGestao },
    });
    return result;
  }

  private preparaPerformance(dados: any): any {
    const temp = [];
    for (let index = 0; index < 24; index++) {
      const item = dados.filter((e) => e.hora == index);
      if (item.length > 0) {
        temp.push(item[0]);
      } else {
        temp.push({ _id: null, hora: index.toString(), realizado: 0 });
      }
    }
    return temp;
  }
}
