import Usuario, { UsuarioInterface } from '../schemas/usuario.schema'

import mongoose from 'mongoose'


export class UsuarioService {

    async findOne(socket_id): Promise<any> {

        const usuario = mongoose.model('Usuario', Usuario.schema, 'usuario')
        const result = await usuario.find({ 'socket_id': { '$eq': socket_id } })

        return result

    }

    async findAll(): Promise<any> {

        const usuario = mongoose.model('usuario', Usuario.schema, 'usuario')
        const result = await usuario.find({})

        return result

    }

    async delete(id): Promise<any> {

        const usuario = mongoose.model('usuario', Usuario.schema, 'usuario')

        usuario.deleteOne({ 'socket_id': id }, function (err) {
            if (err) {
                return console.error(err);
            } 
        });
    }


    async insert(data): Promise<any> {


        let date = new Date()

        const userModel = mongoose.model('usuario', Usuario.schema, 'usuario')

        var usuario = new Usuario({ 'cliente': data.base
                                  , 'socket_id': data.socket_id
                                  , 'from': data.from
                                  , 'socket': data.s
                                  , 'date_insert': date
                                 });

        // save multiple documents to the collection referenced by Book Model
        userModel.collection.insertOne(usuario, function (err, docs) {
            if (err) {
                return console.error(err);
            } 
        });


    }


}





