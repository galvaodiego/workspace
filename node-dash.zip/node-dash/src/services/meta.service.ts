
import mongoose from 'mongoose'
import GroupMeta from '../group/meta.group';

export class MetaService {


  private _groupMeta = new GroupMeta()


  // async aggregate (params, agrupador, sort, limit?): Promise<MetaInterface[]> {

  //   let result = null;
  //   let n = limit ? limit : 30
  //   this._groupMeta.setGroup(params.req, agrupador)


  //   const meta = mongoose.model('Meta', Meta.schema, 'st_meta_' + params.req.base)
  //   result = await meta.aggregate([{ $match: params.match }, { $group: this.metaGroup.group }]).sort(sort).limit(n)
  //     , ((err) => {
  //       if (err) {
  //         return []
  //       }
  //     });


  //   this._groupMeta.cleanGroup()

  //   return this._groupMeta.getReturn(result)
// 
  // }
  async aggregate (req, agrupador, sort, limit?): Promise<object> {
    console.log(req)
  
    this._groupMeta.setMatch(req)
    this._groupMeta.setGroup(agrupador)

    const tgSchema = new mongoose.Schema({}, { strict: false })
    let tg

    try {
      tg = mongoose.model('st_meta_' + req.base)
    } catch (error) {
      tg = mongoose.model('st_meta_' + req.base, tgSchema, 'st_meta_' + req.base)
    }

    const res = !limit ? await tg.aggregate([{ $match: this._groupMeta.match }, { $group: this._groupMeta.group }]).sort(sort) :
      await tg.aggregate([{ $match: this._groupMeta.match }, { $group: this._groupMeta.group }]).sort(sort).limit(limit)

    this._groupMeta.cleanGroup()
    this._groupMeta.cleanMath()

    return res
  }


  async findAll (req, sort, select?, limit?): Promise<object> {


    this._groupMeta.setMatch(req)

    // console.log(this._groupMeta.match)

    let n = limit ? limit : 30

    let tg = null
    const tgSchema = new mongoose.Schema({}, { strict: false, _id: false })

    try {
      tg = mongoose.model('st_meta_' + req.base)
    } catch (error) {
      tg = mongoose.model('st_meta_' + req.base, tgSchema, 'st_meta_' + req.base)
    }

    const res = await tg.find(this._groupMeta.match).sort(sort).limit(n)

    this._groupMeta.cleanMath()
    

    return res
  }
}