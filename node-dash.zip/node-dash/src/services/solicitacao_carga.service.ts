
import GroupSolicitacaoCarga from '../group/solicitacao_carga.group'
import SolicitacaoCarga, { SolicitacaoCargaInterface } from '../schemas/solicitacao_carga.shema'

//import mongoose, { mongo, Mongoose, Schema } from 'mongoose'

import mongoose from 'mongoose'




export class SolicitacaoCargaService {

    private solicitacaoCargaGroup = new GroupSolicitacaoCarga();

    // async aggregate(params, agrupador, sort, look, limit?): Promise<SolicitacaoCargaInterface[]> {
        // this.solicitacaoCargaGroup.setGroup(params.req, agrupador);
        // let n = limit ? limit : 30;
        // /**
        //  *  parametros para inner das tabelas
        //  */
        // let lookup = look.lookup

        // const solicitacao = mongoose.model('st_solic_carga_' + params.req.base,  SolicitacaoCarga.schema)

        // const result = await solicitacao.aggregate([
        //     { $match: params.match },
        //     { $group: this.solicitacaoCargaGroup.group },
        //     {
        //         $lookup: {
        //             from: lookup.from + params.req.base,
        //             localField: '_id.' + lookup.localField,
        //             foreignField: '_id',
        //             as: lookup.name
        //         }
        //     },

        // ]).sort(sort).limit(n);

        // this.solicitacaoCargaGroup.cleanGroup()
        // return this.solicitacaoCargaGroup.getReturn(result)
   // }

    async agreggate(params, agrupador, sort, limit?): Promise<SolicitacaoCargaInterface[]> {
        let result = []
        let n = limit ? limit : 30
        
        // console.log();
        // console.log(params);
        
        this.solicitacaoCargaGroup.setGroup(params.req, agrupador);
        const solicitacao = mongoose.model('solic_carga', SolicitacaoCarga.schema, 'st_solic_carga_' + params.req.base );

        result = await solicitacao.aggregate([{ $match: params.match }, { $group: this.solicitacaoCargaGroup.group }] ).sort(sort).limit(n)
           , ((err) => {
            if (err) {
                console.log('ERRRPOOR', err);
                return []
            }
        });
        
        // console.log('RESULT', result);
        
        this.solicitacaoCargaGroup.cleanGroup()
        return this.solicitacaoCargaGroup.getReturn(result)

    }

   async findAll(params, sort, select?, limit?): Promise<SolicitacaoCargaInterface[]> {
        let result;
        let campos = select? select: 'SOLICITACAO_CARGA_ID DATA_CARREGAMENTO_INICIO DESTINO_MUNICIPIO_UF ORIGEM_MUNICIPIO_UF OPERACAO';
        let n = limit ? limit : 30

        const solicitacao = mongoose.model('solic_carga', SolicitacaoCarga.schema, 'st_solic_carga_' + params.req.base)

         result = await solicitacao.find(params['match']).select('roll ' + campos).sort(sort).limit(n)
         , ((err) => {
             if (err) {
                 return []
             }
         });
 

        return this.solicitacaoCargaGroup.getReturn(result)

    }

}