/* eslint-disable no-unused-expressions */
/* eslint-disable no-undef */

import DoctoFiscal, { DoctoFiscalInterface } from '../schemas/docto_fiscal.schema'
import GroupDoctoFiscal from '../group/docto_fiscal.group'

import mongoose from 'mongoose'


export class DoctoFiscalService {

  private doctoFiscalGroup = new GroupDoctoFiscal();

  /*
    async aggregate(params, agrupador, sort, limit?): Promise<DoctoFiscalInterface[]> {
      let result = null;
      let n = limit ? limit : 30
      let res = null;
      let match = {}
      let aggregate = {}
  
  
      this.doctoFiscalGroup.setGroup(params.req, agrupador)
  
      Object.assign(match, params.match)
      Object.assign(aggregate, this.doctoFiscalGroup.group)
  
  
      const tgSchema = new mongoose.Schema({}, { strict: false })
      let tg
      try {
        tg = mongoose.model(params.req.base + '_filtro')
      } catch (error) {
        tg = mongoose.model(params.req.base + '_filtro', tgSchema, 'st_docto_fiscal_' + params.req.base)
      }
  
  
      res = await tg.aggregate([{ $match: match }, { $group: aggregate }
      ]).sort(sort).limit(n),
        ((err) => {
          if (err) {
            return []
          }
        })
  
      this.doctoFiscalGroup.cleanGroup()
  
      return this.doctoFiscalGroup.getReturn(res)
  
    }*/

  async aggregate(params, agrupador, sort, limit?): Promise<DoctoFiscalInterface[]> {
    let result = []
    let n = limit ? limit : 30

    // console.log(params);

    this.doctoFiscalGroup.setGroup(params.req, agrupador)
    const doctoFiscal = mongoose.model('docto_fiscal', DoctoFiscal.schema, 'st_docto_fiscal_' + params.req.base)

    result = await doctoFiscal.aggregate([{ $match: params.match }, { $group: this.doctoFiscalGroup.group }]).sort(sort).limit(n)
      , ((err) => {
        if (err) {
          console.log('ERRRPOOR', err);
          return []
        }
      });

    // console.log('RESULT', result);

    this.doctoFiscalGroup.cleanGroup()

    return this.doctoFiscalGroup.getReturn(result)

  }


  async findAll(params, sort, select?, limit?): Promise<DoctoFiscalInterface[]> {
    let result = null;
    let campos = select ? select : 'DIM_META DATA_BASE TOTAL_DOCUMENTO TOTAL_PESO';

    let n = limit ? limit : 30



    const docto = mongoose.model('Docto_fiscal', DoctoFiscal.schema, 'st_docto_fiscal_' + params.req.base)
    result = await docto.find(params['match']).select('roll ' + campos).sort(sort).limit(n)
      , ((err) => {
        if (err) {
          return []
        }
      });

    // console.log('RESUK', result);
    // return result
    return this.doctoFiscalGroup.getReturn(result)
  }


  async view(params, nome, limit?): Promise<DoctoFiscalInterface[]> {
    let result = null;
    let name = nome ? nome : 'st_peso_fat_frete'
    let n = limit ? limit : 30

    // console.log();
    // console.log('PARAMS', params);


    const docto = mongoose.model('Docto_fiscal', DoctoFiscal.schema, name)
    result = await docto.find()

      , ((err) => {
        if (err) {
          return []
        }
      });


    return this.doctoFiscalGroup.getReturn(result)
  }



  // async findAll(params, agrupador, sort, look): Promise<ConhecimentoInterface[]> {
  //     this.conhecimentoGroup.setGroup(params.req, agrupador);

  //     /**
  //      *  parametros para inner das tabelas
  //      */
  //     let lookup = look.lookup

  //     const conhecimento = mongoose.model('fato_conhecimento', Conhecimento.schema, 'fato_conhecimento_' + params.req.base)

  //     const result = await conhecimento.aggregate([
  //         { $match: params.match },
  //         { $group: this.conhecimentoGroup.group },
  //         {
  //             $lookup: {
  //                 from: lookup.from + params.req.base,
  //                 localField: '_id.' + lookup.localField,
  //                 foreignField: '_id',
  //                 as: lookup.name
  //             }
  //         },

  //     ]).sort(sort);



  //     this.conhecimentoGroup.cleanGroup()
  //     return this.conhecimentoGroup.getReturn(result)
  // }



}