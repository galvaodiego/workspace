/* eslint-disable quote-props */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable space-before-function-paren */
/* eslint-disable indent */
import Template from '../schemas/template.schema'
import mongoose from 'mongoose'

export class TemplateService {
    private collectionName = 'dash_template'
    async save(data: any): Promise<any> {
        const templateModel = mongoose.model(this.collectionName, Template.schema, this.collectionName)
        const template = new Template({
            dash_id: data.dash_id,
            usuario_bi_id: data.usuario_bi_id,
            dash: data.dash,
            usuario: data.usuario,
            modelo_id: data.modelo_id,
            slots: data.slots,
            cliente: data.cliente
        })

        const filter = { dash_id: data.dash_id, usuario_bi_id: data.usuario_bi_id }
        templateModel.findOneAndUpdate(filter, data, { new: true }).then((e: any) => {
            if (e === null) {
                templateModel.collection.insertOne(template, function (err) {
                    if (err) {
                        return console.error(err)
                    }
                })
            }
            return true
        })
    }

    async getTemplates(data: any): Promise<any> {
        const templateModel = mongoose.model(this.collectionName, Template.schema, this.collectionName)
        const result = await templateModel.find({ 'usuario_bi_id': { '$eq': data.usuario_bi_id }, 'dash_id': { '$eq': data.dash_id } })
        return result
    }
}
