/* eslint-disable quote-props */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable space-before-function-paren */
/* eslint-disable indent */
import IonicApp from '../schemas/ionic_app.schema'
import mongoose from 'mongoose'

export class IonicAppService {
    private collectionName = 'ionic_app_config'
    async getDados(): Promise<any> {
        const ionicAppModel = mongoose.model(this.collectionName, IonicApp.schema, this.collectionName)
        const result = await ionicAppModel.find()
        return result
    }
}
