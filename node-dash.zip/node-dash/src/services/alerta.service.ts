import Groupalerta from '../group/alerta.group'
import Alerta, { AlertaInterface } from '../schemas/alerta.schema'

import mongoose from 'mongoose'

export class AlertaService {
    private alertaGroup = new Groupalerta();

    async findAll (matchParams, cliente, requisicao, agrupador, sort): Promise<AlertaInterface[]> {
      // let v_sort = sort ? sort : this.sortP
      this.alertaGroup.setGroup(requisicao, agrupador)

      const alerta = mongoose.model('alerta', Alerta.schema, 'dash_alerta_' + cliente)
      const limit = cliente === 'panorama' && agrupador === 'cliente' ? 5 : 100
      const result = await alerta.aggregate([{ $match: matchParams }, { $group: this.alertaGroup.group }]).sort(sort).limit(limit)

      this.alertaGroup.cleanGroup()
      return this.alertaGroup.getReturn(result, agrupador)
    }

    async findAllIndicador (cliente): Promise<any> {
      const tgSchema = new mongoose.Schema({}, { strict: false })
      let tg
      try {
        tg = mongoose.model('indicador')
      } catch (error) {
        tg = mongoose.model('indicador', tgSchema, 'dash_alerta_indicador_' + cliente)
      }
      const info = await tg.find()

      return info
    }

    async findNivel (cliente): Promise<any> {
      const tgSchema = new mongoose.Schema({}, { strict: false })
      let tg
      try {
        tg = mongoose.model('nivel')
      } catch (error) {
        tg = mongoose.model('nivel', tgSchema, 'dash_alerta_indicador_' + cliente)
      }
      const info = await tg.find().select({ _id: 0, TOTAL: 1, TIPO: 1, CLASSE: 0 })

      return info
    }

    async findAllMapa (cliente): Promise<any> {
      const tgSchema = new mongoose.Schema({}, { strict: false })

      let tg
      try {
        tg = mongoose.model('mapa')
      } catch (error) {
        tg = mongoose.model('mapa', tgSchema, 'dash_alerta_mapa_' + cliente)
      }
      const info = await tg.find()

      return info
    }
}
