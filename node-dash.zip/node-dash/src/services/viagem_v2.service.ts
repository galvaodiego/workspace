/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable space-before-function-paren */
/* eslint-disable import/no-duplicates */
import { ViagemInterface } from '../schemas/viagem.schema'
import Viagem from '../schemas/viagem.schema'

import mongoose from 'mongoose'
import { GroupViagem } from '../group/viagem.group'
import logger from '../logger'

export class ViagemV2Service {

  private viagemGroup = new GroupViagem();
  dash = 'dash_viagem_'
  // async findAll (params, agrupador, sort): Promise<ViagemInterface[]> {
  //   this.viagemGroup.setGroup(params.req, agrupador)
  //   let result

  //   try {
  //     const viagem = mongoose.model('dash_viagem', Viagem.schema, 'dash_viagem_' + params.req.base)
  //     result = await viagem.aggregate([{ $match: params.match }, { $group: this.viagemGroup.group }]).sort(sort);
  //   } catch (error) {
  //     logger.error(error + ' path: alerta.service line 21')
  //   }

  //   this.viagemGroup.cleanGroup()
  //   return this.viagemGroup.getReturn(result)
  // }
  async findAll(matchParams, cliente, requisicao, agrupador, sort): Promise<ViagemInterface[]> {
    this.viagemGroup.setGroup(requisicao, agrupador)
    let result: any

    try {
      const viagem = mongoose.model('dash_viagem', Viagem.schema, this.dash + cliente)
      result = await viagem.aggregate([{ $match: matchParams }, { $group: this.viagemGroup.group }]).sort(sort)
    } catch (error) {
      logger.error(error + ' path: viagem.service line 19')
    }

    this.viagemGroup.cleanGroup()
    return this.viagemGroup.getReturn(result)
  }
}
