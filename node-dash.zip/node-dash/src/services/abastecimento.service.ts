

import Abastecimento, { AbastecimentoInterface } from '../schemas/abastecimento.schema'

import mongoose from 'mongoose'
import GroupAbastecimento from '../group/abastecimento.group'



export class AbastecimentoService {

  private abastecimentoGroup = new GroupAbastecimento();


  async aggregate (params, agrupador, sort, limit?): Promise<AbastecimentoInterface[]> {

    let result = null;
    let n = limit ? limit : 30
    this.abastecimentoGroup.setGroup(params.req, agrupador)
    // console.log()
    // console.log('PAMRAS', params.match)
  
    const abastecimento = mongoose.model('Abastecimento', Abastecimento.schema, 'st_abastecimento_' + params.req.base)
    result = await abastecimento.aggregate([{ $match: params.match }, { $group: this.abastecimentoGroup.group }]).sort(sort).limit(n)
      , ((err) => {
        if (err) {
          return []
        }
      });


    this.abastecimentoGroup.cleanGroup()

    return this.abastecimentoGroup.getReturn(result)
  }

  async findAll (params, sort, select?, limit?): Promise<abastecimentoInterface[]> {
    let result = null;
    let campos = select ? select : 'DIM_abastecimento DATA_BASE TOTAL_DOCUMENTO TOTAL_PESO'

    let n = limit ? limit : 30

    const abastecimento = mongoose.model('Abastecimento', Abastecimento.schema, 'st_abastecimento_' + params.req.base)
    result = await abastecimento.find(params['match']).select('roll ' + campos).sort(sort).limit(n)
      , ((err) => {
        if (err) {
          return []
        }
      });

    return this.abastecimentoGroup.getReturn(result)
  }



  async filter (params, agrupador, sort): Promise<AbastecimentoInterface[]> {

    let result = null;
    this.abastecimentoGroup.setFilter(params.req, agrupador)
  
    const abastecimento = mongoose.model('Abastecimento', Abastecimento.schema, 'st_abastecimento_' + params.req.base)
    result = await abastecimento.aggregate([{ $match: params.match }, { $group: this.abastecimentoGroup.group }]).sort(sort) //.limit(n)
      , ((err) => {
        if (err) {
          return []
        }
      });


    this.abastecimentoGroup.cleanFilter()

    return this.abastecimentoGroup.getReturn(result)
  }


}