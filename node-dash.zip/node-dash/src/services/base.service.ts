/* eslint-disable @typescript-eslint/camelcase */

import mongoose from 'mongoose'

export class BaseService {
  async findAllIndicador (cliente): Promise<any> {
    const tgSchema = new mongoose.Schema({}, { strict: false })
    let tg
    try {
      tg = mongoose.model('indicador')
    } catch (error) {
      tg = mongoose.model('indicador', tgSchema, 'st_docto_fiscal_' + cliente)
    }
    const match = {
      // NR_MES: { $eq: 1 },
      NR_ANO: { $eq: 2019 }
    }
    const group = {

      _id: {
        cliente: '$CLIENTE',
        situacao: '$SITUACAO',
        carroceria: '$VEICULO_CONTROLE_CLASSIFICACAO',
        modalidade: '$MODALIDADE',
        grupo_produto: '$GRUPO_PRODUTO',
        produto: '$PRODUTO',
        placa: '$VEICULO_CONTROLE_PLACA',
        motorista: '$MOTORISTA_RAZAO_SOCIAL',
        mes: '$MES_ANO',
        dia: '$DIA_MES'
      },
      documento: { $sum: '$QTDE_DOCUMENTO' },
      faturamento: { $sum: '$VL_FATURADO' },
      peso: { $sum: '$VL_PESO_REAL' },
      emitido: { $sum: { $cond: [{ $eq: ['$CANCELADA', 0] }, 1, 0] } },
      cancelado: { $sum: '$CANCELADA' }
    }
    const sort = {

    }

    const formatedGroup = this.setGroup(group, ['mes'])
    const carroceriaGroup = this.setGroup(group, ['carroceria'])
    console.log(carroceriaGroup, '-----------')

    const res = await tg.aggregate([{ $match: match }, { $group: formatedGroup }]).sort({ '_id.mes': 1 })
    const resCarroceria = await tg.aggregate([{ $match: match }, { $group: carroceriaGroup }]).sort({ faturamento: -1 })
    const fatMes = await this.setGraphic(res, { key: 'mes', value: 'faturamento' }, 'Faturamento')
    const pesoMes = await this.setGraphic(res, { key: 'mes', value: 'peso' }, 'Tonelagem')
    const docMes = await this.setGraphicMultikey(res, { key: 'mes', value: 'emitido', value2: 'cancelado' }, 'Documentos')
    const fatCarroceria = await this.setGraphic(resCarroceria, { key: 'carroceria', value: 'faturamento' }, 'Faturamento por Carroceria')
    const info = {
      grafico: {
        fatMes: fatMes,
        pesoMes: pesoMes,
        docMes: docMes,
        fatCarroceria,
        resCarroceria

      }
    }
    console.log(info)

    return info
  }

  async setGraphic (data, dataset, title):Promise<object> {
    const grafico = {
      title: title,
      data: []
    }
    data.forEach(element => {
      grafico.data.push({
        chave: element._id[dataset.key],
        valor: element[dataset.value]
      })
    })
    return grafico
  }

  async setGraphicMultikey (data, dataset, title):Promise<object> {
    const grafico = {
      titulo: title,
      data: []
    }
    data.forEach(element => {
      grafico.data.push({
        chave: element._id[dataset.key],
        valor: parseFloat(element[dataset.value]),
        valor2: parseFloat(element[dataset.value2])
      })
    })
    return grafico
  }

  setGroup (fullGroup, group: Array<string>):object {
    Object.keys(fullGroup._id).forEach((key) => (!group.includes(key)) && delete fullGroup._id[key])
    return fullGroup
  }
}
