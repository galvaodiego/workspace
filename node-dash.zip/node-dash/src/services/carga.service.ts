
import mongoose from 'mongoose'
import { MongoHelper } from '../../../helpers/mongo-helper'
import logger from '../../../logger'
import { CargaModel } from '../schemas/carga.model'
import { Response } from 'express'

export class CargaService {
  private _model = new CargaModel();
  private dash = 'dash_carga_descarga_2'
  res: Response

  async aggregate (req, agrupador, sort, limit?): Promise<object> {
    this._model.setMatch(req)
    this._model.setGroup(agrupador)
    let result

    const tgSchema = new mongoose.Schema({}, { strict: false })
    let tg
    try {
      tg = mongoose.model(this.dash + req.base)
    } catch (error) {
      tg = mongoose.model(this.dash + req.base, tgSchema, this.dash + req.base)
    }

    try {
      result = !limit ? await tg.aggregate([{ $match: this._model.match }, { $group: this._model.group }]).sort(sort) :
        await tg.aggregate([{ $match: this._model.match }, { $group: this._model.group }]).sort(sort).limit(limit)
    } catch (error) {
      logger.error(error + ' path: carga.service line 31')
    }

    this._model.cleanGroup()
    this._model.cleanMath()

    return MongoHelper.map(result)
  }

  async findAll (req, sort, select?, limit?): Promise<object> {
    this._model.setMatch(req)
    let res

    const tgSchema = new mongoose.Schema({}, { strict: false })
    let tg
    try {
      tg = mongoose.model(this.dash + req.base)
    } catch (error) {
      tg = mongoose.model(this.dash + req.base, tgSchema, this.dash + req.base)
    }

    try {
      res = !select ? await tg.find(this._model.match).sort(sort) : await tg.find(this._model.match).select('roll ' + select).sort(sort) //.limit(limit)
    } catch (error) {
      logger.error(error + ' path: carga.service line 55')
    }

    this._model.cleanMath()

    return res
  }

  async exists (base): Promise<boolean> {
    const tgSchema = new mongoose.Schema({}, { strict: false })
    let tg
    try {
      tg = mongoose.model(this.dash + base)
    } catch (error) {
      tg = mongoose.model(this.dash + base, tgSchema, this.dash + base)
    }

    const res = await tg.exists()

    return res
  }
}
