import Feed from '../schemas/feed.schema'

import mongoose from 'mongoose'

export class FeedService {

    async findAll(cliente, sort): Promise<any> {
        
        const feed = mongoose.model('Feed', Feed.schema, 'feed_' + cliente)
        const result = await feed.find({}).sort(sort)
        
        return this.getReturn(result)

    }


    public getReturn(data: Array<any>): Array<any> {
        data.forEach(element => {
            element.prioridade = parseInt(element.prioridade)
            element.tipo = parseInt(element.tipo)

            if (element._id) {
                Object.assign(element, element._id)
                delete element._id
            }
        })
        return data
    }

}





