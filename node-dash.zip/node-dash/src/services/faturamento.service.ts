import GroupFaturamento from '../group/faturamento.group'
import Faturamento, { FaturamentoInterface } from '../schemas/faturamento.schema'

import mongoose from 'mongoose'
import logger from '../logger'

export class FaturamentoService {
  private fatGroup = new GroupFaturamento();

  async findAll (matchParams, cliente, requisicao, agrupador, sort): Promise<FaturamentoInterface[]> {
    // let v_sort = sort ? sort : this.sortP
    this.fatGroup.setGroup(requisicao, agrupador)
    let result

    try {
      const faturamento = mongoose.model('Faturamento', Faturamento.schema, 'dash_faturamento_' + cliente)
      result = await faturamento.aggregate([{ $match: matchParams }, { $group: this.fatGroup.group }]).sort(sort)
    } catch (error) {
      logger.error(error + ' path: faturamento.service line 19')
    }

    this.fatGroup.cleanGroup()
    return this.fatGroup.getReturn(result)
  }
}
