

import ContratoTransp, { ContratoTranspInterface } from '../schemas/contrato_transp.schema'

import mongoose from 'mongoose'
import GroupContratoTransp from '../group/contrato_transp.group';



export class ContratoTranspService {

    private contratoGroup = new GroupContratoTransp();


    async aggregate(params, agrupador, sort, limit?): Promise<ContratoTranspInterface[]> {

        let result = null;
        let n = limit ? limit : 30

        this.contratoGroup.setGroup(params.req, agrupador);


        const contrato = mongoose.model('st_contrato_transp', ContratoTransp.schema, 'st_contrato_transp_' + params.req.base)
        result = await contrato.aggregate([{ $match: params.match }, { $group: this.contratoGroup.group }]).sort(sort).limit(n)
         , ((err) => {
            if (err) {
                return []
            }
        });
        

        this.contratoGroup.cleanGroup()
        return this.contratoGroup.getReturn(result)

    }

    async findAll(params, sort, select?, limit?): Promise<ContratoTranspInterface[]> {
        let result = null;
        let campos = select? select: 'DIM_META DATA_BASE TOTAL_DOCUMENTO TOTAL_PESO';
        let n = limit ? limit : 30



        const contrato = mongoose.model('contrato_transp', ContratoTransp.schema, 'contrato_transp_' + params.req.base)
        result = await contrato.find(params['match']).select('roll ' + campos).sort(sort).limit(n)
        , ((err) => {
            if (err) {
                return []
            }
        });

     
        
        return this.contratoGroup.getReturn(result)
    }



}