

import Romaneio, { RomaneioInterface } from '../schemas/romaneio.schema'

import mongoose from 'mongoose'
import GroupRomaneio from '../group/romaneio.group';



export class RomaneioService {

  private romaneioGroup = new GroupRomaneio();


  async aggregate(params, agrupador, sort, limit?): Promise<RomaneioInterface[]> {

    let result = null;
    let n = limit ? limit : 30
    this.romaneioGroup.setGroup(params.req, agrupador);

    // console.log('AGG')
    // console.log(params)

    const romaneio = mongoose.model('romaneio', Romaneio.schema, 'st_romaneio_' + params.req.base)

    result = await romaneio.aggregate([{ $match: params.match }, { $group: this.romaneioGroup.group }]).sort(sort).limit(n)
      , ((err) => {
        if (err) {
          return []
        }
      });

    this.romaneioGroup.cleanGroup()

    return this.romaneioGroup.getReturn(result)

  }

  async findAll(params, sort, select?, limit?): Promise<RomaneioInterface[]> {


    let result = null;
    let campos = select ? select : 'NUM_ROMANEIO DATA_TERMINO_CARGA CLIENTE_MOTORISTA DESTINO_MUNICIPIO_UF ORIGEM_MUNICIPIO_UF OPERACAO ALERT_SEM_DOC DATA TIPO_DOCUMENTO'
    let n = limit ? limit : 30

    // console.log('FINDALL');
    // console.log(params);

    const romaneio = mongoose.model('romaneio', Romaneio.schema, 'st_romaneio_' + params.req.base)
    result = await romaneio.find(params['match']).select('roll ' + campos).sort(sort).limit(n)

      , ((err) => {
        if (err) {
          return []
        }
      });


    return this.romaneioGroup.getReturn(result)
  }



}