/* eslint-disable quote-props */
/* eslint-disable @typescript-eslint/explicit-function-return-type */
import * as https from 'https'
// import * as request from 'request'

export class GatewayService {
  public body: string

  public async backendCall (param: object, module: string, operation: string): Promise<any> {
    const parametroUrl = param.url
    const url = parametroUrl.substring(parametroUrl.indexOf('//') + 2)
    let obj = {}
    if (param.aba) {
      obj = {
        usuario: param.usuario,
        pacote: param.pacote,
        assunto: param.assunto,
        aba: param.aba
      }
    } else {
      if (param.senha) {
        obj = {
          usuario: param.usuario,
          token: param.user_token,
          senha: param.senha
        }
      } else {
        obj = {
          usuario: param.usuario
        }
      }
    }

    const options = {
      host: url,
      path: '/_remote/gateway.php',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': param.token
      },
      body: {
        module: module,
        operation: operation,
        parameters: obj
      }
    }

    const data = await this.send(options)
    return data.result ? data.result : data
  }

  async send (options: any): Promise<any> {
    return new Promise((resolve, reject) => {
      const req = https.request(options, (res) => {
        let data = ''

        res.on('data', (chunk) => {
          data += chunk
        })
        res.on('end', () => {
          resolve(JSON.parse(data))
        })
      }).on('error', (err) => {
        reject(err)
        console.log('Error: ', err.message)
      })
      req.write((JSON.stringify(options.body)))
      req.end()
    })
  }
}
