import { Router } from 'express'
import Sockets from './sockets/sockets'
import request from 'request'

import alertaController from './controllers/alerta.controller'
import viagemController from './controllers/viagem.controller'
import faturamentoController from './controllers/faturamento.controller'
import produtividadeController from './modules/produtividade/produtividade.controller'
import abastecimentoController from './controllers/abastecimento.controller'
import fluxoLogisticoController from './modules/integracao/fluxo_logistico.controller'
import nivelServicoController from './modules/nivel-servico/nivel-servico.controller'
import cargaController from './modules/carga/controller/carga.controller'
import descargaController from './modules/descarga/controller/descarga.controller'
import transitTimeController from './modules/transit-time/controller/transit_time.controller'
import sessionController from './modules/session/session.controler'
import velocidadeController from './modules/velocidade/velocidade.controller'
import acompDescargaController from './modules/acomp-descarga/acomp-descarga.controller'
import controleTragefoController from './modules/controle-trafego/controle-trafego.controller'
import zoombiController from './modules/zoombi/controller/zoombi.controller'
import logger from './logger'
import playlistService from './modules/playlist/playlist.service'
import zoombiSessionController from './modules/zoombi/controller/zoombi_session.controller'

import ViagensMapsController from './modules/viagens_maps/controller/viagens_maps.controller'
import ViagensTempController from './modules/viagens_temperatura/controller/viagens_temp.controller'
import ViagensHistController from './modules/viagens_historico/controller/viagens_hist.controller'
import jornadaController from './modules/jornada/controller/jornada.controller'
import templateController from './controllers/template.controller'
import GerencialController from './controllers/gerencial.controller'
import IonicAppController from './controllers/ionic_app.controller'
import TosController from './controllers/tos.controller'

const routes = Router()

routes.get('/', (req, res) => {
  res.send('__')
})

// ROTAS TOS SEM PASSAR POR SOCKET
routes.post('/tos/getGMO', (req, res) => {
  TosController.getGMO(req)
    .then((e) => {
      return res.status(200).json({ status: 200, dados: e })
    })
    .catch((err) => {
      return res.status(500).json({
        status: 500,
        message: 'Houve um erro na requisição, erro:' + err
      })
    })
})

routes.post('/tos/saveGMOConfig', (req, res) => {
  TosController.saveGMOConfig(req)
    .then((e) => {
      return res.status(200).json({ status: 200, dados: e })
    })
    .catch((err) => {
      return res.status(500).json({
        status: 500,
        message: 'Houve um erro na requisição, erro:' + err
      })
    })
})

routes.post('/tos/getGMOConfig', (req, res) => {
  TosController.getGMOConfig(req)
    .then((e) => {
      return res.status(200).json({ status: 200, dados: e })
    })
    .catch((err) => {
      return res.status(500).json({
        status: 500,
        message: 'Houve um erro na requisição, erro:' + err
      })
    })
})
// FIM-ROTAS TOS SEM PASSAR POR SOCKET

// ROTAS APP IONIC SEM PASSAR POR SOCKET
routes.post('/ionic-app/getDados', (req, res) => {
  IonicAppController.getDados()
    .then((e) => {
      return res.status(200).json({ status: 200, dados: e })
    })
    .catch((err) => {
      return res.status(500).json({
        status: 500,
        message: 'Houve um erro na requisição, erro:' + JSON.stringify(err)
      })
    })
})
// FIM-ROTAS APP IONIC SEM PASSAR POR SOCKET

// ROTAS DO DASHTV SEM PASSAR POR SOCKET
routes.post('/template/save', (req, res) => {
  templateController
    .saveTemplate(req.body)
    .then(() => {
      return res
        .status(200)
        .json({ status: 200, message: 'Template salvo com sucesso' })
    })
    .catch((err) => {
      return res.status(500).json({
        status: 500,
        message:
          'Não foi possível salvar o registro, erro:' + JSON.stringify(err)
      })
    })
})

routes.post('/template/get', (req, res) => {
  templateController
    .getTemplate(req.body)
    .then((e) => {
      return res.status(200).json({ status: 200, dados: e })
    })
    .catch((err) => {
      return res.status(500).json({
        status: 500,
        message: 'Houve um erro na requisição, erro:' + JSON.stringify(err)
      })
    })
})

// FIM-ROTAS DO DASHTV SEM PASSAR POR SOCKET

// ROTAS DO VIAGENS.KMM SEM SER SOCKET
routes.post('/gerencial/saveModulo', (req, res) => {
  GerencialController.saveModulo(req.body)
    .then(() => {
      return res
        .status(200)
        .json({ status: 200, message: 'Módulo salvo com sucesso' })
    })
    .catch((err) => {
      return res.status(500).json({
        status: 500,
        message:
          'Não foi possível salvar o registro, erro:' + JSON.stringify(err)
      })
    })
})
routes.post('/gerencial/saveUsuario', (req, res) => {
  GerencialController.saveUsuario(req.body)
    .then(() => {
      return res
        .status(200)
        .json({ status: 200, message: 'Usuário salvo com sucesso' })
    })
    .catch((err) => {
      return res.status(500).json({
        status: 500,
        message:
          'Não foi possível salvar o registro, erro:' + JSON.stringify(err)
      })
    })
})
routes.post('/gerencial/saveUsuarioGrupo', (req, res) => {
  GerencialController.saveUsuarioGrupo(req.body)
    .then(() => {
      return res.status(200).json({
        status: 200,
        message: 'Usuário / Grupo Negociador salvo com sucesso'
      })
    })
    .catch((err) => {
      return res.status(500).json({
        status: 500,
        message:
          'Não foi possível salvar o registro, erro:' + JSON.stringify(err)
      })
    })
})
routes.post('/gerencial/getUsuario', (req, res) => {
  GerencialController.getUsuario(req.body)
    .then((e) => {
      return res.status(200).json({ status: 200, dados: e })
    })
    .catch((err) => {
      return res.status(500).json({
        status: 500,
        message: 'Houve um erro na requisição, erro:' + JSON.stringify(err)
      })
    })
})
routes.post('/gerencial/getUsuarios', (req, res) => {
  GerencialController.getUsuarios(req.body)
    .then((e) => {
      return res.status(200).json({ status: 200, dados: e })
    })
    .catch((err) => {
      return res.status(500).json({
        status: 500,
        message: 'Houve um erro na requisição, erro:' + JSON.stringify(err)
      })
    })
})
routes.post('/gerencial/searchUsuarios', (req, res) => {
  GerencialController.searchUsuarios(req.body)
    .then((e) => {
      return res.status(200).json({ status: 200, dados: e })
    })
    .catch((err) => {
      return res.status(500).json({
        status: 500,
        message: 'Houve um erro na requisição, erro:' + JSON.stringify(err)
      })
    })
})
routes.post('/gerencial/getUsuariosGrupo', (req, res) => {
  GerencialController.getUsuariosGrupo(req.body)
    .then((e) => {
      return res.status(200).json({ status: 200, dados: e })
    })
    .catch((err) => {
      return res.status(500).json({
        status: 500,
        message: 'Houve um erro na requisição, erro:' + JSON.stringify(err)
      })
    })
})
routes.post('/gerencial/getModulos', (req, res) => {
  GerencialController.getModulos(req.body)
    .then((e) => {
      return res.status(200).json({ status: 200, dados: e })
    })
    .catch((err) => {
      return res.status(500).json({
        status: 500,
        message: 'Houve um erro na requisição, erro:' + JSON.stringify(err)
      })
    })
})
routes.post('/gerencial/delUsuario', (req, res) => {
  GerencialController.delUsuario(req.body)
    .then(() => {
      return res
        .status(200)
        .json({ status: 200, message: 'Usuário removido com sucesso' })
    })
    .catch((err) => {
      return res.status(500).json({
        status: 500,
        message: 'Houve um erro na requisição, erro:' + JSON.stringify(err)
      })
    })
})
routes.post('/gerencial/delUsuarioGrupo', (req, res) => {
  GerencialController.delUsuarioGrupo(req.body)
    .then(() => {
      return res.status(200).json({
        status: 200,
        message: 'Grupo Negociador removido com sucesso'
      })
    })
    .catch((err) => {
      return res.status(500).json({
        status: 500,
        message: 'Houve um erro na requisição, erro:' + JSON.stringify(err)
      })
    })
})
routes.post('/gerencial/delModulo', (req, res) => {
  GerencialController.delModulo(req.body)
    .then(() => {
      return res
        .status(200)
        .json({ status: 200, message: 'Módulo removido com sucesso' })
    })
    .catch((err) => {
      return res.status(500).json({
        status: 500,
        message: 'Houve um erro na requisição, erro:' + JSON.stringify(err)
      })
    })
})
// FIM-ROTAS DO VIAGENS.KMM SEM SER SOCKET

routes.get('/update', function(req, res) {
  Sockets.clients.forEach((element: any) => {
    if (element.f.base === req.query.base && element.d === req.query.destino) {
      console.log('Base: ', req.query.base, ' destino: ', req.query.destino)

      switch (element.d) {
        case 'alerta':
          alertaController.getAlerta(element.f, element.s)
          break

        case 'viagem':
          viagemController.getViagem(element.f, element.s)
          break

        case 'faturamento':
          faturamentoController.getFaturamento(element.f, element.s)
          break

        case 'produtividade':
          produtividadeController.getProdutividade(element.f, element.s)
          break

        case 'abastecimento':
          abastecimentoController.getAbastecimento(element.f, element.s)
          break

        case 'fluxo-logistico':
          fluxoLogisticoController.getFluxoLogistico(element.f, element.s)
          break

        case 'nivel-servico':
          nivelServicoController.getNivelServico(element.f, element.s)
          break

        case 'carga':
          cargaController.getCarga(element.f, element.s)
          break

        case 'descarga':
          descargaController.getDescarga(element.f, element.s)
          break

        case 'transit-time':
          transitTimeController.getTransitTime(element.f, element.s)
          break

        case 'acomp-descarga':
          acompDescargaController.getAcompDescarga(element.f, element.s)
          break

        case 'velocidade':
          velocidadeController.getVelocidade(element.f, element.s)
          break

        case 'controle-trafego':
          controleTragefoController.getControleTrafego(element.f, element.s)
          break

        case 'viagens_maps':
          ViagensMapsController.getViagensMaps(element.f, element.s)
          break

        case 'viagens_temp':
          ViagensTempController.getViagensTemp(element.f, element.s)
          break

        case 'viagens_hist':
          ViagensHistController.getViagensHist(element.f, element.s)
          break

        case 'jornada':
          jornadaController.getJornada(element.f, element.s)
          break

        default:
          break
      }
    }
  })

  res.json(1)
})

routes.post('/logout', async (req, res) => {
  if (req.body.base && req.body.usuario) {
    await sessionController.insertSession(
      req.body.base,
      req.body.usuario,
      '/logout'
    )
    return res.status(200).json({ status: 200, message: 'Logout com sucesso' })
  } else {
    return res
      .status(400)
      .json({ status: 400, message: 'Usuário e/ou base não encontrado' })
  }
})

routes.post('/validate_route', async (req, res, next) => {
  try {
    if (req.body.base && req.body.usuario && req.body.rota && req.body.modulo) {
      await sessionController.insertSession(
        req.body.base,
        req.body.usuario,
        req.body.rota,
        req.body.modulo
      )
      return res
        .status(200)
        .json({ status: 200, message: 'Sessão inserida com sucesso' })
    } else {
      return res.status(400).json({
        status: 400,
        message: 'Usuário, base, modulo e/ou rota  não foram encontrados'
      })
    }
  } catch (err) {
    console.log('ERR:', err)

    next(err)
  }
})

routes.post('/save_playlist', async (req, res, next) => {
  try {
    if (req.body.base && req.body.usuario_bi && req.body.playlist) {
      const result = await playlistService.insert(
        req.body.usuario_bi,
        req.body.base,
        req.body.playlist
      )
      return res.status(200).json({ status: 200, message: result })
    }
    if (!req.body.playlist) {
      return res
        .status(400)
        .json({ status: 400, message: 'Playlist não encontrada' })
    }
    if (!req.body.usuario_bi) {
      return res
        .status(400)
        .json({ status: 400, message: 'Usuário não encontrado' })
    }
    if (!req.body.base) {
      return res
        .status(400)
        .json({ status: 400, message: 'Base não encontrado' })
    }
  } catch (err) {
    logger.error(err + ' path: routes.ts line 145')

    next(err)
  }
})

routes.get('/playlist', async (req, res, next) => {
  try {
    if (req.query.base && req.query.usuario_bi) {
      const result = await playlistService.find(
        req.query.usuario_bi,
        req.query.base
      )
      return res.status(200).json({ status: 200, result: result })
    }
    if (!req.query.usuario_bi) {
      return res
        .status(400)
        .json({ status: 400, message: 'Usuário não encontrado' })
    }
    if (!req.query.base) {
      return res
        .status(400)
        .json({ status: 400, message: 'Base não encontrado' })
    }
  } catch (err) {
    logger.error(err + ' path: routes.ts line 161')

    next(err)
  }
})

/**
 * Zommbi
 */
routes.post('/getComponente', async (req, res, next) => {
  try {
    console.log('getComponente req', req)

    const logInicio = new Date()
    const parameters = req.body.parameters

    const ip =
      req.headers['x-forwarded-for'] ||
      req.connection.remoteAddress ||
      req.socket.remoteAddress ||
      req.connection.socket.remoteAddress
    const y = await zoombiController.getCliente(req)
    const base = y.cliente.cliente

    if (parameters.usuario && parameters.pacote) {
      await zoombiSessionController.insertSession(
        base,
        parameters.usuario,
        ip,
        parameters.pacote,
        parameters.assunto,
        parameters.aba
      )
      const x = await zoombiController.getComponente(req)

      console.log(
        'usuario: ',
        parameters.usuario,
        'path:',
        parameters.pacote + '/' + parameters.assunto + '/' + parameters.aba,
        ' ',
        (new Date() - logInicio) / 1000,
        'segundos'
      )

      return res.status(200).json({ status: 200, result: x })
    } else {
      return res
        .status(400)
        .json({ status: 400, message: 'Usuário e/ou pacote não encontrado' })
    }
  } catch (err) {
    console.log('ERR:', err)

    next(err)
  }
})

/**
 * Zommbi
 */
routes.post('/getMenu', async (req, res, next) => {
  try {
    if (req.body.parameters.usuario) {
      const x = await zoombiController.getMenu(req)

      return res.status(200).json({ status: 200, result: x })
    } else {
      return res
        .status(400)
        .json({ status: 400, message: 'Usuário não encontrado' })
    }
  } catch (err) {
    console.log('ERR:', err)

    next(err)
  }
})

/**
 * Zommbi
 * 1 -  Login com usuario e senha do cliente ex:  brambila
 * 2 - SetToken, passando o token retornado do login
 * 3 - front chama getMenu
 * 4 -  getComponetes
 */
routes.post('/zoombi/login', async (req, res, next) => {
  try {
    const x = await zoombiController.login(req)

    if (x.hasOwnProperty('login')) {
      return res.status(200).json({ status: 200, result: x })
    } else {
      return res
        .status(400)
        .json({ status: 400, message: 'Usuário ou senha não encontrado' })
    }
  } catch (err) {
    console.log('ERR:', err)
    next(err)
  }
})

/**
 * Zommbi
 */
routes.post('/zoombi/logout', async (req, res, next) => {
  try {
    const ip =
      req.headers['x-forwarded-for'] ||
      req.connection.remoteAddress ||
      req.socket.remoteAddress ||
      req.connection.socket.remoteAddress
    const parameters = req.body.parameters
    const y = await zoombiController.getCliente(req)
    const base = y.cliente.cliente

    if (base && parameters.usuario) {
      const x = await zoombiSessionController.deleteSession(
        base,
        parameters.usuario,
        ip
      )

      return res.status(200).json({ status: 200, message: x })
    } else {
      return res
        .status(400)
        .json({ status: 400, message: 'Usuário e/ou base não encontrado' })
    }
  } catch (err) {
    console.log('ERR:', err)

    next(err)
  }
})

// routes.get('/zoombi/logout', async (req, res, next) => {
//   try {
//     const options = {
//       method: 'GET',
//       url: 'https://qliksense.kmm.com.br/qps/logout?targetUri=https://qliksense.kmm.com.br/hub/'

//     }
//     request(options, async function (error, response) {
//       if (error) throw error
//       res.clearCookie('X-Qlik-Session-External')
//       res.clearCookie('usuario')

//       res.status(302)
//       res.header('Access-Control-Allow-Origin', '*')
//       res.location('http://zoombi.kmm.com.br')
//       // res.end()
//     })
//   } catch (err) {
//     console.log('ERR:', err)
//     next(err)
//   }
// })

/**
 * Zommbi
 */
routes.get('/setTokenTeste', async (req, res, next) => {
  const logInicio = new Date()
  try {
    const x = await zoombiController.validateToken(req)

    if (x.hasOwnProperty('login')) {
      const options = {
        method: 'GET',
        url: 'https://qliksense.kmm.com.br/ext/hub',
        headers: {
          Authorization: x.login.token
        }
      }

      request(options, async function(error, response) {
        if (error) throw error
        // console.log(response)
        // res.cookie(response.headers['set-cookie'][0].substr(0, response.headers['set-cookie'][0].indexOf('=')),
        //   response.headers['set-cookie'][0].substr(response.headers['set-cookie'][0].indexOf('=') + 1, response.headers['set-cookie'][0].indexOf(';') - 1 - response.headers['set-cookie'][0].indexOf('=')),
        //   { domain: '.kmm.com.br', path: '/', secure: false, maxAge: 3600000 * 5 })
        // res.cookie('usuario', x.login.usuario, { domain: '.kmm.com.br', path: '/', secure: false, maxAge: 3600000 * 5 })
        // res.status(302)
        // console.log(res.getHeader('set-cookie'))
        // res.header('Access-Control-Allow-Origin', '*')

        // res.location('http://zoombi.kmm.com.br')
        // res.location('http://talend.kmm.com.br')
        // res.location('https://qliksense.kmm.com.br/ext/single/?appid=4bcafb8d-1b06-4046-88a7-3881d8c20e78&obj=f1975038-f43a-4bb6-907e-e8fd83f07809&opt=nointeraction&select=clearall')

        // res.end()
        return res.status(200).json({ status: 200, dados: response })
      })
      console.log(
        'usuario',
        x.login.usuario,
        'setToken: ',
        (new Date() - logInicio) / 1000,
        'segundos'
      )
    } else {
      return res.status(400).json({ status: 400, message: 'Token inválido' })
    }
  } catch (err) {
    console.log('ERR:', err)

    next(err)
  }
})
routes.get('/brado/setToken', async (req, res, next) => {
  const logInicio = new Date()
  try {
    const x = await zoombiController.validateToken(req)

    if (x.hasOwnProperty('login')) {
      const options = {
        method: 'GET',
        url: 'https://qliksense.brado.com.br/ext/hub',
        headers: {
          Authorization: x.login.token
        }
      }

      request(options, async function(error, response) {
        if (error) throw error
        res.cookie(
          response.headers['set-cookie'][0].substr(
            0,
            response.headers['set-cookie'][0].indexOf('=')
          ),
          response.headers['set-cookie'][0].substr(
            response.headers['set-cookie'][0].indexOf('=') + 1,
            response.headers['set-cookie'][0].indexOf(';') -
              1 -
              response.headers['set-cookie'][0].indexOf('=')
          ),
          {
            domain: '.brado.com.br',
            path: '/',
            secure: false,
            maxAge: 3600000 * 5
          }
        )
        res.cookie('usuario', x.login.usuario, {
          domain: '.brado.com.br',
          path: '/',
          secure: false,
          maxAge: 3600000 * 5
        })
        res.status(302)
        res.header('Access-Control-Allow-Origin', '*')
        res.location('https://qliksense.brado.com.br')
        res.end()
      })
      console.log(
        'usuario',
        x.login.usuario,
        'setToken: ',
        (new Date() - logInicio) / 1000,
        'segundos'
      )
    } else {
      return res.status(400).json({ status: 400, message: 'Token inválido' })
    }
  } catch (err) {
    console.log('ERR:', err)

    next(err)
  }
})
routes.get('/setToken', async (req, res, next) => {
  const logInicio = new Date()
  try {
    const x = await zoombiController.validateToken(req)

    if (x.hasOwnProperty('login')) {
      const options = {
        method: 'GET',
        url: 'https://qliksense.kmm.com.br/ext/hub',
        headers: {
          Authorization: x.login.token
        }
      }

      request(options, async function(error, response) {
        if (error) throw error
        // console.log(response)
        res.cookie(
          response.headers['set-cookie'][0].substr(
            0,
            response.headers['set-cookie'][0].indexOf('=')
          ),
          response.headers['set-cookie'][0].substr(
            response.headers['set-cookie'][0].indexOf('=') + 1,
            response.headers['set-cookie'][0].indexOf(';') -
              1 -
              response.headers['set-cookie'][0].indexOf('=')
          ),
          {
            domain: '.kmm.com.br',
            path: '/',
            secure: false,
            maxAge: 3600000 * 5
          }
        )
        res.cookie('usuario', x.login.usuario, {
          domain: '.kmm.com.br',
          path: '/',
          secure: false,
          maxAge: 3600000 * 5
        })
        res.status(302)
        // console.log(res.getHeader('set-cookie'))
        res.header('Access-Control-Allow-Origin', '*')

        res.location('http://zoombi.kmm.com.br')
        // res.location('http://talend.kmm.com.br')
        // res.location('https://qliksense.kmm.com.br/ext/single/?appid=4bcafb8d-1b06-4046-88a7-3881d8c20e78&obj=f1975038-f43a-4bb6-907e-e8fd83f07809&opt=nointeraction&select=clearall')

        res.end()
      })
      console.log(
        'usuario',
        x.login.usuario,
        'setToken: ',
        (new Date() - logInicio) / 1000,
        'segundos'
      )
    } else {
      return res.status(400).json({ status: 400, message: 'Token inválido' })
    }
  } catch (err) {
    console.log('ERR:', err)

    next(err)
  }
})
/**
 * Teste Zommbi
 */
routes.get('/ext', async (req, res, next) => {
  try {
    const options = {
      method: 'GET',
      url: 'https://qliksense.kmm.com.br/ext/hub',
      headers: {
        Authorization:
          'Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImttbV9pbXBsYW50YWNhbyIsInVzZXJkaXIiOiJRU0VOU0UwMSJ9.Td2Iw1DJHSuVLCfzChTuZZWzYcAN-YNY9uwJzX8fE4LUxCxo4iE2ZVsaXnFQC5FKmTR-j_FzNnAlnqr4vQrEqYTC_c1sB_pKgQfhn2avxsFeZPbS2aCuiQrXrPbWslIlAgON7MLWd4I_BRZrriNP7WKnccGUIaM7gSGDiuo-PLtzERhPCHKtdehY41dUlhMLREmXWQUx7YaC9aOMJyzIfSNIZ1MIDdGbwoOsFHYtk168og5jNM_ZKtrACD141u8JETA5kfPZO90b9qb6Wex-I8LApay55uYfaVVypL6K-3x19I7SnLpf1HcR_Od3Gasq5l2ADB2_oglxN-Kja1z6Lg'
      }
    }

    request(options, async function(error, response) {
      if (error) throw error
      // console.log(response)
      res.cookie(
        response.headers['set-cookie'][0].substr(
          0,
          response.headers['set-cookie'][0].indexOf('=')
        ),
        response.headers['set-cookie'][0].substr(
          response.headers['set-cookie'][0].indexOf('=') + 1,
          response.headers['set-cookie'][0].indexOf(';') -
            1 -
            response.headers['set-cookie'][0].indexOf('=')
        ),
        { domain: '.kmm.com.br', path: '/', secure: false, maxAge: 3600000 * 5 }
      )
      res.cookie('usuario', 'nome-do-usuario', {
        domain: '.kmm.com.br',
        path: '/',
        secure: false,
        maxAge: 3600000 * 5
      })
      res.status(302)
      // console.log(res.getHeader('set-cookie'))
      res.header('Access-Control-Allow-Origin', '*')

      res.location('http://zoombi.kmm.com.br')
      // res.location('http://talend.kmm.com.br')
      // res.location('https://qliksense.kmm.com.br/ext/single/?appid=4bcafb8d-1b06-4046-88a7-3881d8c20e78&obj=f1975038-f43a-4bb6-907e-e8fd83f07809&opt=nointeraction&select=clearall')

      res.end()
    })
  } catch (err) {
    console.log('ERR:', err)

    next(err)
  }
})

// rota não encontrada
routes.use((req, res, next) => {
  const erro = new Error('Não encontrato')
  Object.assign(erro, {
    status: 400
  })
  next(erro)
})

// repasse do erro
routes.use((error, req, res, next) => {
  res.status(error.status || 500)
  return res.send({
    error: {
      status: error.status,
      message: error.message
    }
  })
})

export default routes
