import app from './app'

console.log(app.express.listenerCount('1'))
