import express from 'express'
import cors from 'cors'
import mongoose from 'mongoose'
import Sockets from './sockets/sockets'
import routes from './routes'
import { Server, createServer } from 'http'
import logger from './logger'

export class App {
  public express: express.Application
  public io: SocketIO.Server
  private server: Server
  private port: number

  constructor () {
    this.port = parseInt(process.env.PORT) || 30042
    this.express = express()
    this.middlewares()
    this.database()
    this.createServer()
    this.createSockets()
    this.routes()
  }

  public down (): void {
    this.server.close()
  }

  private database (): void {
    mongoose.connect('mongodb://kmm_bi:kmm2014@talend.kmm.com.br:27017/kmm_bi?keepAlive=true&poolSize=30&autoReconnect=true&socketTimeoutMS=360000&connectTimeoutMS=360000', {
      useNewUrlParser: true,
      useUnifiedTopology: true
    }, (error) => {
      if (error) {
        logger.error(error)
      }
    })
  }

  private createServer (): void {
    this.server = createServer(this.express)
  }

  private createSockets (): void {
    Sockets.socket(this.server)
    Sockets.listen(this.server, this.port)
  }

  private middlewares (): void {
    this.express.use(express.json())
    this.express.use(cors())
  }

  private routes (): void {
    this.express.use(routes)
  }
}

export default new App()
