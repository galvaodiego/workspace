
export interface GroupMetaIdInterface {
    cancelada?: any,

}
export interface MatchMetaInterface {
    OPERACAO_DESC?: object
    DIM_DOCTO_FISCAL?: object
    DIM_META?: object
    DIM_DOCUMENTO_FISCAL?: object
    FLAG_MAIOR_MES?: object
    FLAG_DATA?: object
    ORIGEM?: object
    DATA_BASE?: object
    CANCELADA?: object


}
export interface GroupMetaInterface {

    _id: GroupMetaIdInterface
    total_peso?: object
    total_documento?: object
    qtde?: object
    total?: object
    ton?: object

    media_peso?: object,
    total_ton?: object,
    meta_ton?: object,
    meta_faturamento?: object
    media_doc?: object


}

export interface RequestMetaInterface {
   
    operacao_desc: any;
    docto_fiscal?: number;
    flag_data?: any;
    flag_maior_mes?: any;
    data_base?: any;
    cancelada?: number,
    periodo?: string,
    


}

