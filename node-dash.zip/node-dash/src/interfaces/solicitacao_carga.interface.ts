
export interface GroupSolicitacaoCargaIdInterface {

   operacao: any;
   cancelada?: any,
   situacao_id?: any
}
export interface MatchSolicitacaoCargaInterface {
   DATA?: object
   NR_HORA?: object
   NR_MES?: object
   NR_ANO?: object
   NR_SEMANA?: object
   NR_DIA_MES?: object
   DATA_INICIO_CARGA?: object
   ORIGEM?: object
   // DATA_INICIO_CARGA_ROMANEIO?: object
   DATA_CARREGAMENTO_INICIO?: object
   CANCELADA?: object
   SITUACAO_ID?: object
   OPERACAO_ID?: object

}
export interface GroupSolicitacaoCargaInterface {
   _id: GroupSolicitacaoCargaIdInterface,

   qtde?: object
   operacao_id?: object
   situacao_id?: object
   total_situacao: object
   valor?: object


}

export interface RequestSolicitacaoCargaInterface {
   origem?: string;
   hora: number;
   data_inicio_carga?: number;
   data_carregamento_inicio?: number;
   situacao_id?: number;
   cancelada?: number,
   periodo?: string,
   base?: string



}

