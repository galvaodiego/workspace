
export interface GroupDoctoFiscalIdInterface {
  NR_DIA_MES: any;
  cancelada?: any,

}
export interface MatchDoctoFiscalInterface {
  USER_INSERT: object
  CANCELADO_POR: object
  ORIGEM: object;
  DATA_EMISSAO?: object
  DATA?: object
  CANCELADA?: object
  NR_MES?: object
  NR_ANO?: object
  NR_DIA_MES?: object
  NR_HORA?: object
  AUTOMATIZADO?: object
  INTEGRADO?: object
  VEICULO_CONTROLE_PLACA?: object
  PESSOA_FILIAL?: object
  SITUACAO_ID?: object
  EXCLUIDO ?: object
  TIPO_DOCTO ?: object

}
export interface GroupDoctoFiscalInterface {
  peso?: object
  _id: GroupDoctoFiscalIdInterface
  qtde?: object
  total?: object
  media?: object
  valor?: object

}

export interface RequestDoctoFiscalInterface {
  data_inicial: any;
  data_final: any;
  user_insert: string;
  cancelado_por: string;
  hora: number;
  origem: any;
  data_inicio_emissao: any;
  data_emissao: any;
  cancelada?: number;
  periodo?: string;
  integrado?: number;
  automatizado?: number;
  dias?: number;
  placa?: any;
  filial?: any;
  situacao?: any;
  tipo_docto?:any
}
