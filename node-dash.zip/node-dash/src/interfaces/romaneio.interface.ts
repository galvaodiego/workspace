
export interface GroupRomaneioIdInterface {

   operacao: any
   cancelada?: any

}
export interface MatchRomaneioInterface {
   NR_HORA?: object
   NR_MES?: object
   NR_ANO?:object
   NR_SEMANA?: object
   NR_DIA_MES?: object
   DATA_TERMINO_CARGA?: object
   DATA?: object
   ORIGEM?: object
   FATURADO?: object
   DATA_INICIO?: object
   CANCELADA?: object
   OPERACAO_ID?: object
   SITUACAO_VIAGEM_ID?:object
   EXCLUIDO?: object
   TIPO_DOCUMENTO?: object

}
export interface GroupRomaneioInterface {
   _id?: GroupRomaneioIdInterface
   qtde?: object
   total?: object

}

export interface RequestRomaneioInterface {
   data_termino_carga: any
   situacao_viagem_id: any
   origem: any
   faturado: any
   hora: number
   data_inicio: any
   cancelada?: number
   periodo?: string
   dias?: number
   excluido?: number
   tipo_documento?: any

}
