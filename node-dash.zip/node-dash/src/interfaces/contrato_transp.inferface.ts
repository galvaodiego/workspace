
export interface GroupContratoTranspIdInterface {
    cancelada?: any,

}
export interface MatchContratoTranspInterface {
   ORIGEM: { $eq: any; };
  DATA_EMISSAO?: object
  CANCELADA?: object
 

}
export interface GroupContratoTranspInterface {
  _id: GroupContratoTranspIdInterface
  qtde?: object
  total?: object


}

export interface RequestContratoTranspInterface {
   origem: any;
  data_emissao: any;
  cancelada?: number,
  periodo?: string,


}

