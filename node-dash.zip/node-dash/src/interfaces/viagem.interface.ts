export interface GroupViagemIdInterface {
    data?: any,
    cliente?: string,
    mercadoria?: string,
    destino?: string,
    rota?: string,
    origem_destino: string,
    uf_origem: string,
    uf_destino: string,
    origem: string

}
export interface MatchViagemInterface {
    DATA?: object
    CLIENTE?: object,
    MERCADORIA?: object,
    DESTINO?: object,
    ROTA?: object,
    ORIGEM_DESTINO: object,
    ORIGEM: object

}
export interface GroupViagemInterface {
    _id: GroupViagemIdInterface,
    data: object,
    cliente: object,
    mercadoria: object,
    destino: object,
    rota?: object
    uf_origem: object,
    uf_destino: object,
    viagens: object,
    km_total: object,
    km_vazio: object,
    km_carregado: object,
    tonelagem: object
    origem_destino: object
    origem: object
    volume: object
}
export interface RequestViagemInterface {

    periodo?: string,
    data?: number,
    cliente?: string,
    mercadoria?: string,
    destino?: string,
    rota?: string
    origem_destino?: string
    origem?: string
}
