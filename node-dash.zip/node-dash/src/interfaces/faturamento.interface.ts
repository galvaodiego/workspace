
export interface GroupFaturamentoIdInterface {
    data ?: any,
    cliente ?: string,
    modalidade ?: string,
    mercadoria ?: string,
    destino ?: string,
    tipoCarroceria ?: string,
    placa ?: string,
    modelo ?: string,
    frota ?: string,
    filial ?: string
  }
export interface MatchFaturamentoInterface {
        CLIENTE ?: object
        DESTINO ?: object
        MERCADORIA ?: object
        PLACA ?: object
        MODELO ?: object
        MODALIDADE ?: object
        DATA_EMISSAO ?: object
        FROTA ?: object
        FILIAL ?: object
        META ?: object
  }
export interface GroupFaturamentoInterface{
    _id : GroupFaturamentoIdInterface,
    valor : object,
    meta : object,
    viagens : object,
    subistituto: object
  }
export interface RequestFaturamentoInterface{
    periodo ?: string,
    cliente ?: string,
    destino ?: string,
    mercadoria ?: string,
    placa ?: string,
    frota ?: string,
    modelo ?: string,
    modalidade ?: string,
    filial ?: string
    meta ?: number

  }
