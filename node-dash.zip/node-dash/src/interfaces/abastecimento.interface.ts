/* eslint-disable camelcase */

export interface GroupAbastecimentoIdInterface {
    CANCELADA?: number
}
export interface MatchAbastecimentoInterface {
    CLIENTE?: object
    MUNICIPIO?: string
    COMBUSTIVEL?: object
    DATA?: object
    NR_ANO: object
    NR_MES: object
    EXCLUIDO?: object
    CANCELADA?: object
    POSTO?: object
    COD_POSTO?: object
    VEICULO_PLACA?: object
    VEICULO_ID?: object
    PRODUTO_FISCAL?: object
    PRODUTO_FISCAL_ID?: object
    MUNICIPIO_ID?: object
    MUNICIPIO_UF?: object
    VL_UNITARIO?: object
    NR_DIA_MES?:object

}
export interface GroupAbastecimentoInterface {
    media?: object
    _id: GroupAbastecimentoIdInterface
    qtde?: object
    total?: object
    valor?: object
}

export interface RequestAbastecimentoInterface {
    filtro: number;
    combustivel?: number
    cliente?: object
    municipio: string
    periodo?: string
    dias: number
    posto?: object
    posto_id?: object
    produto?: object
    produto_id?: object
    placa?: object
    placa_id?: object
    produto_fiscal_id?: object
    produto_fiscal?: object
    data_inicial?: any
    data_final?: any
    valor_uni?: number
    municipio_id?: object
    estado?: object

}
