/* eslint-disable camelcase */

export interface GroupAlertaIdInterface {

  data ?: any,
  cliente ?: string,
  operador ?: string,
  segmento ?: string,
  tipo_alerta ?: string,

  }

export interface MatchAlertaInterface {
        DATA ?: object
        CLIENTE ?: object
        OPERADOR ?: object
        SEGMENTO ?: object
        TIPO_ALERTA ?: object
        ALERTA_TIPO_ID ?: object
        SEGMENTO_ID ?: object
  }
export interface GroupAlertaInterface{
    _id : GroupAlertaIdInterface,
    qtd_resolvido : object,
    qtd_aberto : object,
    tempo_medio : object
  }
export interface RequestAlertaInterface{
    cliente ?: string,
    operador ?: string,
    alerta_tipo_id ?: string,
    segmento ?: string,
    segmento_id ?: string,

  }
