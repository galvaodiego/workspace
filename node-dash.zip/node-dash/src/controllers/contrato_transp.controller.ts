/* eslint-disable @typescript-eslint/camelcase */
import { GroupContratoTransp } from '../group/contrato_transp.group'
import { ContratoTranspService } from '../services/contrato_transp.service'



export class ContratoTranspController {


  public async getContrato(req: object): Promise<object> {

    const query = new GroupContratoTransp()
    const cliente = req.base ? req.base : null
    const _contrato_transp = new ContratoTranspService()
    const sort = { total: -1 }

    const retorno = {
      frete_medio: null // diario
    }


    let res = null;
    Object.assign(req, { perido: 'diario', cancelada: 0, data_emissao: 1 })
    query.setMatchContratoTransp(req)
    res = await _contrato_transp.aggregate({ match: query.match, req: req }, ['media_frete'], sort)
    
    retorno.frete_medio = res > 0 ? res : 0


    return retorno

  }
}

export default new ContratoTranspController()
