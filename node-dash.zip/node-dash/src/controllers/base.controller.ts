import { Socket } from 'socket.io'
import { BaseService } from '../services/base.service'

class FaturamentoController {
  public async getBase (req: object, socket: Socket): Promise <void> {
    const _baseService = new BaseService()

    const logInicio = new Date()

    const retorno = await _baseService.findAllIndicador('axon')

    console.log('base', req.base, 'BASE:', (new Date() - logInicio) / 1000, 'segundos')
    socket.emit('base', retorno)
  }
}

export default new FaturamentoController()
