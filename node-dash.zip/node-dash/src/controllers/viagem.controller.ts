/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable space-before-function-paren */
import { GroupViagem } from '../group/viagem.group'
import { ViagemService } from '../services/viagem.service'
import { ViagemV2Service } from '../services/viagem_v2.service'

export class ViagemController {
  public async getViagem(req: object, socket: Socket): Promise<object> {
    const queryVia = new GroupViagem()
    const _viagemService = new ViagemService()

    const sort = { valor: -1 }

    const retorno = {
      viagemCiente: null,
      viagemMercadoria: null,
      viagemDestino: null,
      viagemRota: null,
      totalizadores: null,
      origemDestino: null,
      viagemOrigem: null
    }

    queryVia.setMatchViagem(req)

    const params = { match: queryVia.match, req: req }

    const logInicio = new Date()

    retorno.viagemCiente = await _viagemService.findAll(params, 'cliente', sort)

    retorno.viagemMercadoria = await _viagemService.findAll(params, 'mercadoria', sort)

    retorno.viagemDestino = await _viagemService.findAll(params, 'destino', sort)

    retorno.viagemRota = await _viagemService.findAll(params, 'rota', sort)

    retorno.origemDestino = await _viagemService.findAll(params, 'origem_destino', sort)

    retorno.totalizadores = await _viagemService.findAll(params, 'totalizador', sort)

    retorno.viagemOrigem = await _viagemService.findAll(params, 'origem', sort)

    console.log('base', req.base, 'VIAGEM: ', (new Date() - logInicio) / 1000, 'segundos')
    socket.emit('viagem', retorno)
  }

  public async getViagemV2(req: any, socket: Socket): Promise<void> {
    req.base = req.base === 'ciaverdelog' ? 'viaverde' : req.base

    const queryVia = new GroupViagem()
    const _viagemService = new ViagemV2Service()
    const sort = { valor: -1 }
    const cliente = req.base
    const retorno = {
      viagemCiente: null,
      viagemMercadoria: null,
      viagemDestino: null,
      viagemRota: null,
      totalizadores: null,
      origemDestino: null,
      viagemOrigem: null
    }

    let filter: any = {}
    const logInicio = new Date()

    queryVia.setMatchViagem(req)

    filter = Object.assign({}, req, { meta: 0 })
    queryVia.setMatchViagem(filter)
    retorno.viagemCiente = await _viagemService.findAll(queryVia.match, cliente, filter, 'cliente', sort)
    retorno.viagemMercadoria = await _viagemService.findAll(queryVia.match, cliente, filter, 'mercadoria', sort)
    retorno.viagemDestino = await _viagemService.findAll(queryVia.match, cliente, filter, 'destino', sort)
    retorno.viagemRota = await _viagemService.findAll(queryVia.match, cliente, filter, 'rota', sort)
    retorno.origemDestino = await _viagemService.findAll(queryVia.match, cliente, filter, 'origem_destino', sort)
    retorno.totalizadores = await _viagemService.findAll(queryVia.match, cliente, filter, 'totalizador', sort)
    retorno.viagemOrigem = await _viagemService.findAll(queryVia.match, cliente, filter, 'origem', sort)

    console.log('base', req.base, 'VIAGEM: ', (new Date() - logInicio) / 1000, 'segundos')
    socket.emit('viagem', retorno)
  }
}

export default new ViagemController()
