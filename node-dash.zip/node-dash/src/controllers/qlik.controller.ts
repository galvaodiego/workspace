const axios = require('axios').default
const jwt = require('jsonwebtoken').default
const fs = require('file-system').default
const path = require('path').default

class QlikController {
  constructor() {
    const privateKey = fs.readFileSync(
      path.join(__dirname, '../security/qlik private.pem')
    )
    const cookieName = 'X-Qlik-Session-External'
    const controlCookieName = 'X-Qlik-Control-Session'
    const expirationTime = 10 * 60 * 1000
  }

  handleRedirect(res, qlikUrl, token = null, cookie = null) {
    if (token) {
      res.set({ Authorization: `Bearer ${token}` })
      res.set({ 'Proxy-Authorization': `Bearer ${token}` })
    }
    if (cookie) {
      let expiration = new Date(Date.now() + expirationTime)
      res.cookie(cookieName, cookie, {
        httpOnly: true,
        secure: true,
        sameSite: 'lax',
        domain: '.kmm.com.br',
        path: '/',
        expires: expiration
      })

      res.cookie(controlCookieName, expiration.getTime(), {
        httpOnly: true,
        secure: true,
        domain: '.kmm.com.br',
        path: '/'
      })
    }
    res.set({ 'Cache-Control': 'public, must-revalidate, max-age=0' })
    res.redirect(307, qlikUrl)
    res.end()
  }

  async qlikController(req, res, endpoint) {
    let axiosConfig
    let extras = ''
    if (req.query.extras) {
      extras = req.query.extras.replace(/%26/g, '&')
      extras = extras.replace(/%3D/g, '=')
    }
    const qlikUrl = `https://qliksense.kmm.com.br/ext/single/?appid=${req.query.appid}&sheet=${req.query.sheet}&opt=ctxmenu,currsel${extras}`

    if (!req.query.token) {
      res.status(401).send({
        message: 'Necessário estar logado para acessar este recurso.'
      })
      return
    }

    if (!req.query.appid || !req.query.sheet) {
      res.status(400).send({
        message:
          'Necessário informar todos os parâmetros para acessar este recurso.'
      })
      return
    }

    if (
      req.headers.cookie &&
      req.headers.cookie.indexOf(cookieName) > -1 &&
      req.headers.cookie.indexOf(controlCookieName) > -1
    ) {
      let control = req.headers.cookie.substring(
        req.headers.cookie.indexOf(controlCookieName) +
          controlCookieName.length +
          1
      )
      control = control.substring(
        0,
        control.indexOf(';') > -1 ? control.indexOf(';') : undefined
      )

      if (Date.now() < Number(control)) {
        this.handleRedirect(res, qlikUrl)
        return
      }
    }

    // retrieve available user from DB
    axiosConfig = {
      method: 'POST',
      url: endpoint,
      headers: {
        authorization: req.query.token,
        'content-type': 'application/json;charset=UTF-8'
      },
      data: {
        module: 'KMM4',
        operation: 'getPoolLicenca',
        parameters: {
          aplicacao: 'QLIKSENSE',
          stream: req.query.stream || null
        }
      }
    }

    axios(axiosConfig)
      .then(async (lic) => {
        let licenca
        try {
          licenca = lic.data.result.licenca
          licenca = licenca.split(';')
        } catch (e) {
          res.status(400).send({
            message:
              'Falha ao recuperar a informação de acesso. Entre em contato com os administradores.'
          })
          return
        }

        // create QLIK token using the private key and the returned licence information
        let token = jwt.sign(
          { username: licenca[0], userdir: licenca[1] },
          privateKey,
          { algorithm: 'RS256', noTimestamp: true }
        )

        axiosConfig = {
          method: 'GET',
          url: 'https://qliksense.kmm.com.br/ext/hub',
          headers: {
            authorization: `Bearer ${token}`
          },
          withCredentials: true
        }

        axios(axiosConfig)
          .then(async (response) => {
            let headerCookie =
              response.headers['set-cookie'] &&
              response.headers['set-cookie'][0]
            if (headerCookie && headerCookie.indexOf(`${cookieName}=`) > -1) {
              headerCookie = headerCookie.substring(
                headerCookie.indexOf(`${cookieName}=`) +
                  `${cookieName}=`.length,
                headerCookie.indexOf(';')
              )
              handleRedirect(res, qlikUrl, token, headerCookie)
              return
            } else {
              res.status(400).send({
                message:
                  'Não encontrado o parâmetro de autenticação no retorno do servidor de BI.'
              })
            }
          })
          .catch((error) => {
            res.status(400).send({
              message: 'Falha na autenticação do usuário com o servidor de BI.'
            })
          })
      })
      .catch((error) => {
        res.status(400).send({
          message: 'Falha ao verificar o pool de recursos.'
        })
      })
  }
}

export default new QlikController()
