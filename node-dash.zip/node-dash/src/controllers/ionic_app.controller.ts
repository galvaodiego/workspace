/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable space-before-function-paren */
/* eslint-disable @typescript-eslint/explicit-function-return-type */
/* eslint-disable indent */
import { IonicAppService } from '../services/ionic_app.service'
class IonicAppController {
    public async getDados() {
        const _ionicAppService = new IonicAppService()
        try {
            const res = await _ionicAppService.getDados()
            return res
        } catch (error) {
            console.error(error)
            throw error
        }
    }
}

export default new IonicAppController()
