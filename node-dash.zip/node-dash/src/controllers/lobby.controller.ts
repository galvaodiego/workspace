import { Socket } from 'socket.io'
import mongoose, { Schema } from 'mongoose'

class LobbyController {
  public async getInfo (req: object, socket: Socket): Promise <void> {
    const tgSchema = new Schema({}, { strict: false })
    const cliente = req.base
    console.log(cliente)
    
    const tg = mongoose.model('w', tgSchema, 'tg_' + cliente)
    const info = await tg.find()

    console.log('fim:    ', new Date())
    socket.emit('info', info)
  }
}

export default new LobbyController()
