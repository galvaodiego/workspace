import { Socket } from 'socket.io'
import { FeedService } from '../services/feed.service';

class FeedController {

    
  public async getFeed (req: object, socket: Socket): Promise <void> {
    
    const _feedService =  new FeedService();
    const cliente = req.base

    console.log(cliente);
    

    console.log('inicio: ', new Date())

    const retorno = await _feedService.findAll(cliente, { 'prioridade': -1, 'date_update': -1 });

    console.log('fim:    ', new Date())

    // console.log(socket);
    
    // return retorno
    
    socket.emit('feed', retorno)
  }
}

export default new FeedController()
