/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/explicit-function-return-type */
/* eslint-disable camelcase */
/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable no-unused-vars */
import GroupSolicitacaoCarga from '../group/solicitacao_carga.group'
import { SolicitacaoCargaService } from '../services/solicitacao_carga.service'
import { DoctoFiscalService } from '../services/docto_fiscal.service'
import { RomaneioService } from '../services/romaneio.service'
import GroupDoctoFiscal from '../group/docto_fiscal.group'
import GroupRomaneio from '../group/romaneio.group'
import { ReturnComponents } from '../componentes/return.components'

class CentralCargaController {
  
  private sol_criada = []
  private _solicitacaoCargaService = new SolicitacaoCargaService()
  private _doctoFiscalService = new DoctoFiscalService()
  private _romaneioService = new RomaneioService()
  private _groupSolicitacao = new GroupSolicitacaoCarga()
  private _groupDoctoFiscal = new GroupDoctoFiscal()
  private _groupRomaneio = new GroupRomaneio()
  private _component = new ReturnComponents()

  public async getCentralCarga (req: object, socket: Socket): Promise<object> {

    const cliente = req.base //? req.base : 'axon'
    const periodo = req.periodo
    const copy_req = { ...req } /** COPY origiran da requisicao */
    const copy = { ...req }

    const sort = { qtde: -1 }

    const data = new Date(new Date().valueOf() - new Date().getTimezoneOffset() - (60 * 60000 * 3))
    const hora = data.getUTCHours() // hora atual
  
    const hora_anterior = hora - 6 // 6 hora anterior
    const horas = []// array das ultimas 6 horas
    const sol_criada = []

    let _j = 1

    for (let _i = hora_anterior; _i < hora; _i++) {
      horas.push(hora_anterior + _j)
      _j++
    }

    const retorno = {
      sol_cancelada: null,
      sol_atendida: null,
      sol_aberta: null,
      sol_total: null,
      dataSolicitacoes: [], // Qtde de solicitações agendadas e atendidas por hora
      lista_sol_aberta_op: null,
      lista_sol_aberta: null,
      lista_sol_atendida_op: null,
      lista_ccg_diario: null,
      lista_ccg_mensal: null,

      // DOCUMENTO FISCAL
      doc_emitido: 0, // total de documento emitido, cancelados e não cancelados
      lista_qtde_doc_usuario: [], //  Lista de documentos emitidos por usuário
      ctes_emitidos: 0, // Documentos emitidos não cancelados
      ctes_cancelado: 0, // Documento cancelado
      ctes_operacao: 0, // Tabela Documentos Emitidos por operação
      lista_ctes_cancelados: 0, // Cancelamento Fiscal por usuário
      dataCtes: [], // gráfico de emissoes nas ultimas 6 horas

      // ROMANEIO
      rom_qtde: null,
      rom_pendente: null,
      rom_emitido: null,
      lista_rom_fat_op: null,
      lista_rom_fat: null,
      lista_rom_fat2: null,
      atualizacao: null

    }

    const logInicio = new Date()

    let res = null

    /**
     * SOLICITACAO DE CARGA
     */
    req = { base: cliente, periodo: periodo, cancelada: 1 }
    this._groupSolicitacao.setMatchSolicitacaoCarga(req)
    res = await this._solicitacaoCargaService.agreggate({ match: this._groupSolicitacao.match, req: req }, [], sort)
    retorno.sol_cancelada = res > 0 ? res : 0

    req = { base: cliente, periodo: periodo, situacao_id: 4, cancelada: 0 }
    this._groupSolicitacao.setMatchSolicitacaoCarga(req)
    res = await this._solicitacaoCargaService.agreggate({ match: this._groupSolicitacao.match, req: req }, [], sort)
    retorno.sol_atendida = res > 0 ? res : 0

    req = { base: cliente, periodo: periodo, situacao_id: 1, cancelada: 0 }
    this._groupSolicitacao.setMatchSolicitacaoCarga(req)
    res = await this._solicitacaoCargaService.agreggate({ match: this._groupSolicitacao.match, req: req }, [], sort)
    retorno.sol_aberta = res > 0 ? res : 0

    req = { base: cliente, periodo: periodo }
    this._groupSolicitacao.setMatchSolicitacaoCarga(req)
    res = await this._solicitacaoCargaService.agreggate({ match: this._groupSolicitacao.match, req: req }, [], sort)
    retorno.sol_total = res > 0 ? res : 0

    req = { base: cliente, periodo: periodo, situacao_id: 1, cancelada: 0 }
    this._groupSolicitacao.setMatchSolicitacaoCarga(req)
    retorno.lista_sol_aberta = await this._solicitacaoCargaService.findAll({ match: this._groupSolicitacao.match, req: req }, sort)

    req = { base: cliente, periodo: periodo, situacao_id: 1, cancelada: 0 }
    this._groupSolicitacao.setMatchSolicitacaoCarga(req)
    retorno.lista_sol_aberta_op = await this._solicitacaoCargaService.agreggate({ match: this._groupSolicitacao.match, req: req }, ['operacao'], sort)

    req = { base: cliente, periodo: periodo, situacao_id: 1, cancelada: 0 }
    this._groupSolicitacao.setMatchSolicitacaoCarga(req)
    retorno.lista_sol_atendida_op = await this._solicitacaoCargaService.agreggate({ match: this._groupSolicitacao.match, req: req }, ['operacao'], sort)

    retorno.dataSolicitacoes = await this.search(cliente, horas, sort)
    /**
     *  FIM SOLICITACAO DE CARGA 
     */

    /**
     * DOCUMENTO FISCAL
     */

    req = { base: cliente, periodo: periodo, tipo_docto: 'CTe' }
    this._groupDoctoFiscal.setMatchDoctoFiscal(req)
    res = await this._doctoFiscalService.aggregate({ match: this._groupDoctoFiscal.match, req: req }, ['qtde'], sort)
    retorno.doc_emitido = res > 0 ? res : 0

    req = { base: cliente, periodo: 'diario', hora: horas[0], cancelada: 0, tipo_docto: 'CTe' }
    this._groupDoctoFiscal.setMatchDoctoFiscal(req)
    res = await this._doctoFiscalService.aggregate({ match: this._groupDoctoFiscal.match, req: req }, ['qtde'], { qtde: -1 })
    retorno.dataCtes.push({ descricao: horas[0] + 'h00', valor: res > 0 ? res : 0 })

    req = { base: cliente, periodo: 'diario', hora: horas[1], cancelada: 0, tipo_docto: 'CTe' }
    this._groupDoctoFiscal.setMatchDoctoFiscal(req)
    res = await this._doctoFiscalService.aggregate({ match: this._groupDoctoFiscal.match, req: req }, ['qtde'], { qtde: -1 })
    retorno.dataCtes.push({ descricao: horas[1] + 'h00', valor: res > 0 ? res : 0 })

    req = { base: cliente, periodo: 'diario', hora: horas[2], cancelada: 0, tipo_docto: 'CTe' }
    this._groupDoctoFiscal.setMatchDoctoFiscal(req)
    res = await this._doctoFiscalService.aggregate({ match: this._groupDoctoFiscal.match, req: req }, ['qtde'], { qtde: -1 })
    retorno.dataCtes.push({ descricao: horas[2] + 'h00', valor: res > 0 ? res : 0 })

    req = { base: cliente, periodo: 'diario', hora: horas[3], cancelada: 0, tipo_docto: 'CTe' }
    this._groupDoctoFiscal.setMatchDoctoFiscal(req)
    res = await this._doctoFiscalService.aggregate({ match: this._groupDoctoFiscal.match, req: req }, ['qtde'], { qtde: -1 })
    retorno.dataCtes.push({ descricao: horas[3] + 'h00', valor: res > 0 ? res : 0 })

    req = { base: cliente, periodo: 'diario', hora: horas[4], cancelada: 0, tipo_docto: 'CTe' }
    this._groupDoctoFiscal.setMatchDoctoFiscal(req)
    res = await this._doctoFiscalService.aggregate({ match: this._groupDoctoFiscal.match, req: req }, ['qtde'], { qtde: -1 })
    retorno.dataCtes.push({ descricao: horas[4] + 'h00', valor: res > 0 ? res : 0 })

    req = { base: cliente, periodo: 'diario', hora: horas[5], cancelada: 0, tipo_docto: 'CTe' }
    this._groupDoctoFiscal.setMatchDoctoFiscal(req)
    res = await this._doctoFiscalService.aggregate({ match: this._groupDoctoFiscal.match, req: req }, ['qtde'], { qtde: -1 })
    retorno.dataCtes.push({ descricao: horas[5] + 'h00', valor: res > 0 ? res : 0 })

    /**
    * FIM ARRAY DE CTES EMITIDOS POR HORAS
    */

    /**
     * Usado mais pela AXON 
     */

    req = { base: cliente, periodo: 'mensal', cancelada: 0, tipo_docto: 'CTe' }
    this._groupDoctoFiscal.setMatchDoctoFiscal(req)
    res = await this._doctoFiscalService.aggregate({ match: this._groupDoctoFiscal.match, req: req }, ['qtde', 'user_insert'], { qtde: -1 })
    retorno.lista_qtde_doc_usuario = res

    retorno.lista_qtde_doc_usuario = await this.getAcuraciaUser(retorno.lista_qtde_doc_usuario, cliente)

    req = { base: cliente, periodo: periodo, cancelada: 0, tipo_docto: 'CTe' }
    this._groupDoctoFiscal.setMatchDoctoFiscal(req)
    res = await this._doctoFiscalService.aggregate({ match: this._groupDoctoFiscal.match, req: req }, ['qtde'], sort)
    retorno.ctes_emitidos = res > 0 ? res : 0

    req = { base: cliente, periodo: periodo, cancelada: 1, situacao: [3], tipo_docto: 'CTe' } //  cancelada
    this._groupDoctoFiscal.setMatchDoctoFiscal(req)
    res = await this._doctoFiscalService.aggregate({ match: this._groupDoctoFiscal.match, req: req }, ['qtde'], sort)
    retorno.ctes_cancelado = res > 0 ? res : 0

    req = { base: cliente, periodo: periodo, cancelada: 0, tipo_docto: 'CTe' }
    this._groupDoctoFiscal.setMatchDoctoFiscal(req)
    res = await this._doctoFiscalService.aggregate({ match: this._groupDoctoFiscal.match, req: req }, ['qtde', 'operacao'], { qtde: -1 })
    retorno.ctes_operacao = res

    req = { base: cliente, periodo: periodo, cancelada: 1, situacao: [3], tipo_docto: 'CTe' }
    this._groupDoctoFiscal.setMatchDoctoFiscal(req)
    res = await this._doctoFiscalService.aggregate({ match: this._groupDoctoFiscal.match, req: req }, ['qtde', 'cancelado_por'], { qtde: -1 })
    retorno.lista_ctes_cancelados = res

    req = { base: cliente, periodo: 'diario', cancelada: 0, tipo_docto: 'CTe' }
    this._groupDoctoFiscal.setMatchDoctoFiscal(req)
    res = await this._doctoFiscalService.aggregate({ match: this._groupDoctoFiscal.match, req: req }, ['ccg', 'qtde'], { qtde: -1 })
    const resCCG = await this._component.getRenameColumns2(res, ['ccg', 'qtde'], ['chave', 'valor'])
    retorno.lista_ccg_diario = resCCG

    req = { base: cliente, periodo: 'mensal', cancelada: 0, tipo_docto: 'CTe' }
    this._groupDoctoFiscal.setMatchDoctoFiscal(req)
    res = await this._doctoFiscalService.aggregate({ match: this._groupDoctoFiscal.match, req: req }, ['ccg', 'qtde'], { qtde: -1 })
    const resCCGMensal = await this._component.getRenameColumns2(res, ['ccg', 'qtde'], ['chave', 'valor'])
    retorno.lista_ccg_mensal = resCCGMensal

    /**
     * FIM DOCUMENTO FISCAL
     */

    /**
     * ROMANEIO
     * param: dias 
     * caso periodo = diario, filtra pelo dia anterior do dia atual (hoje -dias)
     */

    req = { base: cliente, periodo: periodo, excluido: 0 }
    this._groupRomaneio.setMatchRomaneio(req)
    res = await this._romaneioService.aggregate({ match: this._groupRomaneio.match, req: req }, [], sort)
    retorno.rom_qtde = res > 0 ? res : 0


    req = { base: cliente, periodo: periodo, cancelada: 0, excluido: 0, faturado: 0, data_termino_carga: 1, tipo_documento: 1 }
    this._groupRomaneio.setMatchRomaneio(req)
    res = await this._romaneioService.aggregate({ match: this._groupRomaneio.match, req: req }, [], sort)
    retorno.rom_pendente = res > 0 ? res : 0

    /**
     * Número de romaneio faturado
     */
    req = { base: cliente, periodo: periodo, cancelada: 0, excluido: 0, faturado: 1, situacao_viagem_id: 4 }
    this._groupRomaneio.setMatchRomaneio(req)
    res = await this._romaneioService.aggregate({ match: this._groupRomaneio.match, req: req }, [], sort)
    retorno.rom_emitido = res > 0 ? res : 0

    // /**
    //  * lista de romaneio não faturado
    //  * */
    req = { base: cliente, periodo: periodo, dias: 30, cancelada: 0, excluido: 0, faturado: 0, data_termino_carga: 1, tipo_documento: 1 }
    this._groupRomaneio.setMatchRomaneio(req)
    retorno.lista_rom_fat = await this._romaneioService.findAll({ match: this._groupRomaneio.match, req: req }, { DATA: 1 }, null, 200)

    req = { base: cliente, periodo: periodo, dias: 30, cancelada: 0, excluido: 0, faturado: 0, data_termino_carga: 1 }
    this._groupRomaneio.setMatchRomaneio(req)
    retorno.lista_rom_fat2 = await this._romaneioService.findAll({ match: this._groupRomaneio.match, req: req }, { DATA: 1 }, null, 200)

    /**
     * Lista de romaneio faturado por operação
     */
    req = { base: cliente, periodo: periodo, cancelada: 0, excluido: 0, faturado: 1 }
    this._groupRomaneio.setMatchRomaneio(req)
    retorno.lista_rom_fat_op = await this._romaneioService.aggregate({ match: this._groupRomaneio.match, req: req }, ['operacao'], sort)

    /**
     * FIM ROMANEIO
     */

    Object.assign(retorno,
      {
        dataEmissoes: [
          {
            descricao: 'Emitida',
            valor: retorno.rom_emitido
          },
          {
            descricao: 'Aguardando',
            valor: retorno.rom_pendente
          }
        ]
      })


    res = await this._doctoFiscalService.aggregate({ match: {}, req: req }, ['last_update'], sort)
    retorno.atualizacao = res;


    console.log('base', req.base, 'Central Carga:', (new Date() - logInicio) / 1000, 'segundos')
    // return retorno
    socket.emit('central_carga', retorno)
  }



  // eslint-disable-next-line @typescript-eslint/explicit-function-return-type
  public async search (cliente, horas, sort)  {

    this.sol_criada = []
    let res = null
    let res1 = null
    let req = null


    // HORA 0
    req = { base: cliente, periodo: 'diario', cancelada: 0, hora: horas[0] }
    this._groupSolicitacao.setMatchSolicitacaoCarga(req)
    res = await this._solicitacaoCargaService.agreggate({ match: this._groupSolicitacao.match, req: req }, [], sort)

    req = { base: cliente, data_inicio_carga: 1, periodo: 'diario', cancelada: 0, hora: horas[0] }
    this._groupSolicitacao.setMatchSolicitacaoCarga(req)
    res1 = await this._solicitacaoCargaService.agreggate({ match: this._groupSolicitacao.match, req: req }, [], sort)
    this.insert_array(res, res1, horas[0])

    // HORA 1
    req = { base: cliente, periodo: 'diario', cancelada: 0, hora: horas[1] }
    this._groupSolicitacao.setMatchSolicitacaoCarga(req)
    res = await this._solicitacaoCargaService.agreggate({ match: this._groupSolicitacao.match, req: req }, [], sort)

    req = { base: cliente, data_inicio_carga: 1, periodo: 'diario', cancelada: 0, hora: horas[1] }
    this._groupSolicitacao.setMatchSolicitacaoCarga(req)
    res1 = await this._solicitacaoCargaService.agreggate({ match: this._groupSolicitacao.match, req: req }, [], sort)
    this.insert_array(res, res1, horas[1])

    // HORA 2
    req = { base: cliente, periodo: 'diario', cancelada: 0, hora: horas[2] }
    this._groupSolicitacao.setMatchSolicitacaoCarga(req)
    res = await this._solicitacaoCargaService.agreggate({ match: this._groupSolicitacao.match, req: req }, [], sort)

    req = { base: cliente, data_inicio_carga: 1, periodo: 'diario', cancelada: 0, hora: horas[2] }
    this._groupSolicitacao.setMatchSolicitacaoCarga(req)
    res1 = await this._solicitacaoCargaService.agreggate({ match: this._groupSolicitacao.match, req: req }, [], sort)
    this.insert_array(res, res1, horas[2])

    // HORA 3
    req = { base: cliente, periodo: 'diario', cancelada: 0, hora: horas[3] }
    this._groupSolicitacao.setMatchSolicitacaoCarga(req)
    res = await this._solicitacaoCargaService.agreggate({ match: this._groupSolicitacao.match, req: req }, [], sort)

    req = { base: cliente, data_inicio_carga: 1, periodo: 'diario', cancelada: 0, hora: horas[3] }
    this._groupSolicitacao.setMatchSolicitacaoCarga(req)
    res1 = await this._solicitacaoCargaService.agreggate({ match: this._groupSolicitacao.match, req: req }, [], sort)
    this.insert_array(res, res1, horas[3])

    // HORA 4
    req = { base: cliente, periodo: 'diario', cancelada: 0, hora: horas[4] }
    this._groupSolicitacao.setMatchSolicitacaoCarga(req)
    res = await this._solicitacaoCargaService.agreggate({ match: this._groupSolicitacao.match, req: req }, [], sort)

    req = { base: cliente, data_inicio_carga: 1, periodo: 'diario', cancelada: 0, hora: horas[4] }
    this._groupSolicitacao.setMatchSolicitacaoCarga(req)
    res1 = await this._solicitacaoCargaService.agreggate({ match: this._groupSolicitacao.match, req: req }, [], sort)
    this.insert_array(res, res1, horas[4])

    // HORA 5
    req = { base: cliente, periodo: 'diario', cancelada: 0, hora: horas[5] }
    this._groupSolicitacao.setMatchSolicitacaoCarga(req)
    res = await this._solicitacaoCargaService.agreggate({ match: this._groupSolicitacao.match, req: req }, [], sort)

    req = { base: cliente, data_inicio_carga: 1, periodo: 'diario', cancelada: 0, hora: horas[5] }
    this._groupSolicitacao.setMatchSolicitacaoCarga(req)
    res1 = await this._solicitacaoCargaService.agreggate({ match: this._groupSolicitacao.match, req: req }, [], sort)
    this.insert_array(res, res1, horas[5])

    return this.sol_criada
  }
  
  public async insert_array (res, res1, hr) {
    let data = {}

    data = {
      descricao: hr + 'h00',
      agendada: res.toString() ? res : 0,
      atendida: res1.toString() ? res1 : 0
    }

    this.sol_criada.push(data)
  }

  // eslint-disable-next-line @typescript-eslint/explicit-function-return-type
  public async getAcuraciaUser (lista, cliente) {
    let req = {}
    let res = null

    lista.forEach(async x => {
    
      let acuracia: any;

      req = { base: cliente, periodo: 'mensal', data_inicio_emissao: 1, cancelada: 1, situacao: [3], tipo_docto: 'CTe', user_insert: x.user_insert }
      this._groupDoctoFiscal.setMatchDoctoFiscal(req)
      res = await this._doctoFiscalService.aggregate({ match: this._groupDoctoFiscal.match, req: req }, ['qtde'], { qtde: -1 })
      x.ctes_cancelados_mes = res > 0 ? res : 0


      req = { base: cliente, periodo: 'diario', data_inicio_emissao: 1, cancelada: 1, situacao: [3], tipo_docto: 'CTe', cancelado_por: x.user_insert }
      this._groupDoctoFiscal.setMatchDoctoFiscal(req)
      res = await this._doctoFiscalService.aggregate({ match: this._groupDoctoFiscal.match, req: req }, ['qtde'], { qtde: -1 })
      x.ctes_cancelados_dia = res > 0 ? res : 0

      req = { base: cliente, periodo: 'mensal', data_inicio_emissao: 1, cancelada: 0, tipo_docto: 'CTe', user_insert: x.user_insert }
      this._groupDoctoFiscal.setMatchDoctoFiscal(req)
      res = await this._doctoFiscalService.aggregate({ match: this._groupDoctoFiscal.match, req: req }, ['qtde'], { qtde: -1 })
      x.ctes_emitido_mes = res > 0 ? res : 0;

      req = { base: cliente, periodo: 'diario', data_inicio_emissao: 1, cancelada: 0, tipo_docto: 'CTe', user_insert: x.user_insert }
      this._groupDoctoFiscal.setMatchDoctoFiscal(req)
      res = await this._doctoFiscalService.aggregate({ match: this._groupDoctoFiscal.match, req: req }, ['qtde'], { qtde: -1 })
      x.ctes_emitido_dia = res > 0 ? res : 0

      // Todos, incluindo cancelados
      x.ctes_mes = x.ctes_emitido_mes + x.ctes_cancelados_mes

      x.acuracia_mes = (x.ctes_emitido_mes / x.ctes_mes) * 100
    })

    return lista

  }

}

export default new CentralCargaController()
