/* eslint-disable @typescript-eslint/camelcase */
import GroupAlerta from '../group/alerta.group'
import { Socket } from 'socket.io'
import { AlertaService } from '../services/alerta.service'

class AlertaController {
  public async getAlerta (req: object, socket: Socket): Promise <void> {
    const queryFat = new GroupAlerta()
    const _alertaService = new AlertaService()
    const sort = { valor: -1 }
    const cliente = req.base
    const retorno = {
      // alertaSegmento: null,
      // periodo: null,
      // operador: null,
      // tipo_alerta: null,
      indicador: {},
      mapa: {},
      grafico: {
        grupo: {},
        alertas: {},
        operador: {}
      }
    }

    const logInicio = new Date()

    queryFat.setMatchAlerta(req)

    // retorno.alertaSegmento = await _alertaService.findAll(queryFat.match, cliente, req, 'segmento', sort)
    // retorno.periodo = await _alertaService.findAll(queryFat.match, cliente, req, 'periodo', sort)
    // retorno.operador = await _alertaService.findAll(queryFat.match, cliente, req, 'operador', sort)
    // retorno.tipo_alerta = await _alertaService.findAll(queryFat.match, cliente, req, 'tipo_alerta', sort)
    // retorno.indicador = await _alertaService.findAllIndicador(cliente)
    if (!req.mapa) {
      // retorno.indicador.plano_viagem = await _alertaService.findAllIndicador(cliente)
      retorno.indicador.tipo_alerta = await _alertaService.findAll(queryFat.match, cliente, req, 'tipo_alerta', sort)
      retorno.grafico.tempo_medio = await _alertaService.findAll(queryFat.match, cliente, req, 'tempo', sort)
      retorno.grafico.operador.dados = await _alertaService.findAll(queryFat.match, cliente, req, 'operador', { qtd_resolvido: -1 })
      retorno.grafico.operador.titulo = 'Alertas resolvidos x operador'
      const x = await _alertaService.findAll(queryFat.match, cliente, req, 'periodo', sort)
      if (x[0] !== undefined) {
        retorno.grafico.alertas.dados = x[0].arr
      }

      retorno.grafico.alertas.titulo = 'Alertas do dia'
      retorno.grafico.grupo.dados = req.base == 'ritmo' ? await _alertaService.findAll(queryFat.match, cliente, req, 'segmento', { qtd_resolvido: -1 }) : await _alertaService.findAll(queryFat.match, cliente, req, 'cliente', { qtd_resolvido: -1 })
      retorno.grafico.grupo.titulo = req.base == 'ritmo' ? 'Alertas resolvidos x segmentos' : 'Alertas resolvidos x clientes'
      const xx = await _alertaService.findAllIndicador(cliente)
      retorno.grafico.nivel_servico = xx[5]
      xx[5] = null
      retorno.indicador.plano_viagem = xx
      delete retorno.mapa
    } else {
      delete retorno.grafico
      delete retorno.indicador
      retorno.mapa = await _alertaService.findAllMapa(cliente)
    }

    console.log('base', req.base, 'ALERTA:', (new Date() - logInicio) / 1000, 'segundos')
    socket.emit('alerta', retorno)
  }
}

export default new AlertaController()
