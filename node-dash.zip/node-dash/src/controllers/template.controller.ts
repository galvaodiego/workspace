/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable space-before-function-paren */
/* eslint-disable @typescript-eslint/explicit-function-return-type */
/* eslint-disable indent */
import { TemplateService } from '../services/template.service'
class TemplateController {
    public async getTemplate(data: any) {
        const _templateService = new TemplateService()
        try {
            const res = await _templateService.getTemplates(data)
            return res
        } catch (error) {
            console.error(error)
            throw error
        }
    }

    public async saveTemplate(data: any) {
        const _templateService = new TemplateService()
        try {
            await _templateService.save(data)
        } catch (error) {
            console.error(error)
            throw error
        }
    }
    // public async delTemplate() { }
}

export default new TemplateController()
