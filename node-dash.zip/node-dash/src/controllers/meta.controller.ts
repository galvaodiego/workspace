/* eslint-disable no-return-await */
/* eslint-disable @typescript-eslint/explicit-function-return-type */
/* eslint-disable prefer-const */
/* eslint-disable dot-notation */
/* eslint-disable camelcase */
/* eslint-disable @typescript-eslint/camelcase */
import { Socket } from 'socket.io'

import { MetaService } from '../services/meta.service'
import { DoctoFiscalService } from '../services/docto_fiscal.service'
import GroupDoctoFiscal from '../group/docto_fiscal.group'
import { ContratoTranspController } from './contrato_transp.controller'


/**
 * TELA ACOMPANHEMENTO LOGISTICO
 */
export class MetaController {

  private _metaService = new MetaService()
  private _doctoFiscalService = new DoctoFiscalService()
  private _groupDoctoFiscal = new GroupDoctoFiscal()
  private _contratoTranspCTR = new ContratoTranspController()

  public async getMeta(req: object, socket: Socket): Promise<object> {


    const sort = { qtde: -1 }

    const cliente = req.base
    const periodo = req.periodo
    const copy = { ...req }

    let res = null
    let temp = null

    const retorno: any = {
      realizado_mensal: [],
      totalizador: { data_base: null, meta_ton: 0, total_ton: 0, meta_faturamento: 0, total_faturamento: 0, media_frete_dia: 0 },
      meta_faturamento: 0,
      meta_tonelagem: 0,
      fat_frete: [], // Valor do faturamento por tipo de frete
      fat_grupo: [], // Valdor do faturamento por grupo negociador
      fat_filial: [], // Valor do faturamento por filial
      fat_cliente: [], // Valor do faturamento por cliente
      fat_operacao_pai: [], // Valor do faturamento por operacão pai N1
      fat_tipo_doc: [] // Valor do faturamento por tipo de documento (cte, nfe..)

    }

    const logInicio = new Date()
    const now = logInicio.toISOString().substr(0, 10).split('-').reverse().join('/')

    retorno.totalizador.data_base = now

    // req = { base: cliente, periodo: 'mensal', flag_data: 0 }
    // res = await this._metaService.findAll(req, { DATA_BASE: -1 }, 'DATA DATA_BASE VL_META_FAT VL_META_TON', 7)
    // retorno.realizado_mensal = await this.getRenameColumns(res, ['VL_META_FAT', 'VL_META_TON', 'DATA', 'DATA_BASE'], ['TOTAL_DOCUMENTO', 'TOTAL_PESO', 'DIM_META', 'DATA_BASE'])

    req = { base: cliente, periodo: 'diario', flag_data: 0 }
    res = await this._metaService.aggregate(req, ['total_documento', 'meta_faturamento', 'total_peso', 'meta_tonelagem'], sort)
    retorno.totalizador.meta_faturamento = res && res.length > 0 ? res[0].meta_faturamento : 0
    retorno.totalizador.meta_ton = res && res.length > 0 ? res[0].meta_tonelagem : 0

    req = { base: cliente, periodo: 'diario', cancelada: 0 }
    this._groupDoctoFiscal.setMatchDoctoFiscal(req)
    res = await this._doctoFiscalService.aggregate({ match: this._groupDoctoFiscal.match, req: req }, ['faturamento', 'peso'], { qtde: -1 })
    retorno.totalizador.total_faturamento = res && res.length > 0 ? res[0].total : 0
    retorno.totalizador.total_ton = res && res.length > 0 ? res[0].peso : 0

    let meta_fat = (retorno.totalizador.total_faturamento * 100) / retorno.totalizador.meta_faturamento
    let meta_ton = (retorno.totalizador.total_ton * 100) / (retorno.totalizador.meta_ton)

    retorno.meta_faturamento = { descricao: 'Meta de Faturamento', valor: meta_fat > 0 ? meta_fat > 100 ? 100 : meta_fat : 0 }
    retorno.meta_tonelagem = { descricao: 'Meta de Tonelagem', valor: meta_ton > 0 ? meta_ton > 100 ? 100 : meta_ton : 0 }
    /**
    *  Usado pela CJLOG
    */
    req = { base: cliente, periodo: periodo, cancelada: 0 }
    this._groupDoctoFiscal.setMatchDoctoFiscal(req)
    res = await this._doctoFiscalService.aggregate({ match: this._groupDoctoFiscal.match, req: req }, ['faturamento', 'tipo_frete'], { qtde: -1 })
    retorno.fat_frete = res

    req = { base: cliente, periodo: periodo, cancelada: 0 }
    this._groupDoctoFiscal.setMatchDoctoFiscal(req)
    res = await this._doctoFiscalService.aggregate({ match: this._groupDoctoFiscal.match, req: req }, ['faturamento', 'grupo_negociador'], { qtde: -1 })
    retorno.fat_grupo = res


    req = { base: cliente, periodo: periodo, cancelada: 0 }
    this._groupDoctoFiscal.setMatchDoctoFiscal(req)
    res = await this._doctoFiscalService.aggregate({ match: this._groupDoctoFiscal.match, req: req }, ['faturamento', 'filial'], { qtde: -1 })
    retorno.fat_filial = res


    req = { base: cliente, periodo: periodo, cancelada: 0 }
    this._groupDoctoFiscal.setMatchDoctoFiscal(req)
    res = await this._doctoFiscalService.aggregate({ match: this._groupDoctoFiscal.match, req: req }, ['faturamento', 'cliente'], { qtde: -1 })
    retorno.fat_cliente = res

    req = { base: cliente, periodo: periodo, cancelada: 0 }
    this._groupDoctoFiscal.setMatchDoctoFiscal(req)
    res = await this._doctoFiscalService.aggregate({ match: this._groupDoctoFiscal.match, req: req }, ['faturamento', 'operacao_n1'], { qtde: -1 })
    retorno.fat_operacao_pai = res

    req = { base: cliente, periodo: periodo, cancelada: 0 }
    this._groupDoctoFiscal.setMatchDoctoFiscal(req)
    res = await this._doctoFiscalService.aggregate({ match: this._groupDoctoFiscal.match, req: req }, ['faturamento', 'tipo_docto'], { qtde: -1 })
    retorno.fat_tipo_doc = res

    req = { base: cliente, periodo: 'mensal', cancelada: 0 }
    this._groupDoctoFiscal.setMatchDoctoFiscal(req)
    res = await this._doctoFiscalService.aggregate({ match: this._groupDoctoFiscal.match, req: req }, ['faturamento', 'peso', 'data'], { _id: { data: -1 } }, 40)
    /**
     * Adicao de data, formata dd/mm/yyyy
     */
    temp = res.reverse().slice(0, 7).map(element => {
      return Object.assign(element, {
        dia: element.data.toISOString().substr(0, 10).split('-').reverse().join('/')
      })
    })

    retorno.realizado_mensal = await this.getRenameColumns(temp, ['total', 'peso', 'data', 'dia'], ['TOTAL_DOCUMENTO', 'TOTAL_PESO', 'DATA_BASE', 'DIM_META'])

    /**
      *  Fim Usado pela CJLOG
      */

    const frete = await this._contratoTranspCTR.getContrato(req)
    retorno.totalizador.media_frete_dia = frete['frete_medio']

    console.log('base', req.base, 'META:', (new Date() - logInicio) / 1000, 'segundos')
    // return retorno
    socket.emit('meta', retorno)

  }

  async getRenameColumns (res: Array<object>, values: Array<any>, keys: Array<any>): Promise<object> {

    const grafico = {
      dados: []
    }

    if (res && res.length > 0) {

      if (keys.length === values.length) {

        res.forEach(element => {
          Object.assign(element, element['_doc'])
          const attributes = {}

          keys.forEach((i, idx) => {

            Object.assign(attributes, {
              [keys[idx]]: element[values[idx]]
              // [keys[idx]]: isNaN(element[values[idx]] % 1) === false ? parseFloat(element[values[idx]]) : element[values[idx]]

            })
          })
          grafico.dados.push(attributes)
        })
      }
    }

    const data = grafico.dados && grafico.dados.length > 0 ? grafico.dados : grafico.dados

    return data
  }

}
export default new MetaController()
