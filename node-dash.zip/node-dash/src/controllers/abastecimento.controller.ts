/* eslint-disable camelcase */
/* eslint-disable key-spacing */
/* eslint-disable no-unused-vars */
/* eslint-disable @typescript-eslint/explicit-function-return-type */
/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable prefer-const */
/* eslint-disable @typescript-eslint/camelcase */
import { Socket } from 'socket.io'
import { AbastecimentoService } from '../services/abastecimento.service'
import { DoctoFiscalService } from '../services/docto_fiscal.service';
import GroupAbastecimento from '../group/abastecimento.group'
import GroupDoctoFiscal from '../group/docto_fiscal.group'

class AbastecimentoController {

  private _abastecimentoService = new AbastecimentoService()
  private _doctoFiscalService = new DoctoFiscalService()
  private _groupAbastecimento = new GroupAbastecimento()
  private _groupDoctoFiscal = new GroupDoctoFiscal()

  public async getAbastecimento (req: object, socket: Socket): Promise<void> {
    

    const base = req.base
    const periodo = req.periodo
    const data_inicio = req.data_inicial
    const data_fim = req.data_final
    const produto_id = req.produto_id
    const placa_id = req.placa_id
    const posto_id = req.posto_id
    const estado = req.estado
    const sort = { qtde: -1 }


    // console.log('ESTADO', estado)

    Object.assign(req, {
      base: base
    })

    const retorno = {
      lista: {
        abast_total_posto: { dados: [] },
        acomp_valor_produto: { dados: [] },
        qtde_posto_estado: { dados: [] },
        arla_combustivel: { dados: [] },
        combustivel_fat: { dados: [] }
      },
      grafico: {
        abast_total_posto: { dados: [] },
        acomp_valor_produto: { dados: [] },
        qtde_posto_estado: { dados: [] },

        arla_combustivel: { dados: [] },
        combustivel_fat: { dados: [] }
      },
      indicador: {
        media_disel: null,
        qtde_abastecimentos: null,
        qtde_postos: null,
        qtde_arla: null,
        combustivel_fat: 0,
        media_arla_combustivel: 0,
        litros_gastos: 0,
        total_gastos: 0,
        maior_vl_unitario: 0,
        menor_vl_unitario: 0

      },
      mapa: {
        distribuicao_volume: { dados: [] },
        distribuicao_valor_uni: { dados: [] }
      },
      atualizacao: null,
      temp: []

    }

    const logInicio = new Date()
    let res = null
    let temp = null

    /**
     * Abastecimento total por posto: Soma do valor pago, quantidade abastecida por posto 
      (Lista ou gráfico de linha)
     */
    req = { base: base, data_inicial: data_inicio, data_final: data_fim, produto_id: produto_id, posto_id: posto_id, placa_id: placa_id, estado: estado }

    this._groupAbastecimento.setMatchAbastecimento(req)
    res = await this._abastecimentoService.aggregate({ match: this._groupAbastecimento.match, req: req }, ['posto', 'total'], { valor: -1 }, 10)
    retorno.lista.abast_total_posto.dados = res
    retorno.grafico.abast_total_posto.dados = res

    /**
     * Acompanhamento de valor unitário mensal por produto: Média de valor unitário por produto mensalmente
      (Lista ou gráfico de linha)
     */
    req = { base: base, perido: 'anual', produto_id: produto_id, posto_id: posto_id, placa_id: placa_id, estado: estado, valor_uni: 1 }
    this._groupAbastecimento.setMatchAbastecimento(req)
    res = await this._abastecimentoService.aggregate({ match: this._groupAbastecimento.match, req: req }, ['mes', 'produto', 'media'], { _id: { chave: -1 } }, 100000)
    retorno.lista.acomp_valor_produto.dados = res
    retorno.grafico.acomp_valor_produto.dados = res


    /**
     * Quantidade de postos por estado: Quantidade de postos que tiveram abastecimentos distribuídos por estado
     * (Lista e grafico)
     */
    req = { base: base, data_inicial: data_inicio, data_final: data_fim, produto_id: produto_id, posto_id: posto_id, placa_id: placa_id, estado: estado }
    this._groupAbastecimento.setMatchAbastecimento(req)
    res = await this._abastecimentoService.aggregate({ match: this._groupAbastecimento.match, req: req }, ['municipio_uf', 'qtde'], { _id: { chave1: -1 } }, 1000000)
    retorno.lista.qtde_posto_estado.dados = res
    retorno.grafico.qtde_posto_estado.dados = res


    /**
     * Arla / Combustível de veículos: Lista de veículos com % de arla/diesel
     * (Lista)
     */
    req = { base: base, data_inicial: data_inicio, data_final: data_fim, produto_id: produto_id, posto_id: posto_id, placa_id: placa_id, estado: estado, combustivel: [1, 2] }
    this._groupAbastecimento.setMatchAbastecimento(req)
    res = await this._abastecimentoService.aggregate({ match: this._groupAbastecimento.match, req: req }, ['placa', 'combustivel', 'total', 'qtde1'], { _id: { chave: -1 } }, 100000)
    temp = res && res.length > 0 ? await this.getPlacaPercentual(res) : []
    retorno.lista.arla_combustivel.dados = temp.slice(0, 10)
    retorno.grafico.arla_combustivel.dados = retorno.lista.arla_combustivel.dados
    retorno.indicador.media_arla_combustivel = temp && temp.length > 0 ? temp.map(x => x.valor).reduce((p, c) => c + p) / temp.length : 0


    /**
     * % Faturamento / Combustível placa: Valor do custo de combustível / faturamento por placa
    *(Lista)
    * Primeiro insere em um array temporario, para que  na chaamda do docto_fiscal, passe as placas como filtro
     */
    req = { base: base, data_inicial: data_inicio, data_final: data_fim, produto_id: produto_id, posto_id: posto_id, placa_id: placa_id, estado: estado, }
    this._groupAbastecimento.setMatchAbastecimento(req)
    res = await this._abastecimentoService.aggregate({ match: this._groupAbastecimento.match, req: req }, ['placa', 'total'], { _id: { chave: -1 } }, 100000)
    temp = res

    if (temp && temp.length > 0) {
      let placa = temp.map(element => { return element.chave })


      req = { base: base, data_inicial: data_inicio, data_final: data_fim, cancelada: 0, placa: placa, excluido: 0 }//, filial: clientes }
      this._groupDoctoFiscal.setMatchDoctoFiscal(req)
      res = await this._doctoFiscalService.aggregate({ match: this._groupDoctoFiscal.match, req: req }, ['placa', 'faturamento'], sort, 100000)

      res = await this.getFaturamentoAbastecimento(temp, res)
      retorno.lista.combustivel_fat.dados = res[0].lista.slice(0, 10)
      retorno.grafico.combustivel_fat.dados = retorno.lista.combustivel_fat.dados

      /**
       *  % Faturamento / Combustível: Valor do custo de combustível / faturamento
       * (Indicador)
       */
      retorno.indicador.combustivel_fat = res[0].indicador
    }



    /**
     * Valor médio unitário de diesel: Indicador de valor médio unitário da empresa
    * (Indicador)
     */
    req = { base: base, data_inicial: data_inicio, data_final: data_fim, produto_id: produto_id, posto_id: posto_id, placa_id: placa_id, estado: estado, combustivel: [1], valor_uni: 1 }// Diesel
    this._groupAbastecimento.setMatchAbastecimento(req)
    res = await this._abastecimentoService.aggregate({ match: this._groupAbastecimento.match, req: req }, ['media'], sort, 100000)
    retorno.indicador.media_disel = res && res.length > 0 ? res[0].valor : 0



    /* Quantidade de abastecimentos: Quantidade abastecimentos da empresa
    * (Indicador)
    */
    req = { base: base, data_inicial: data_inicio, data_final: data_fim, produto_id: produto_id, posto_id: posto_id, placa_id: placa_id, estado: estado }
    this._groupAbastecimento.setMatchAbastecimento(req)
    res = await this._abastecimentoService.aggregate({ match: this._groupAbastecimento.match, req: req }, ['qtde'], sort, 100000)
    retorno.indicador.qtde_abastecimentos = res && res.length > 0 ? Number((res[0].valor).toFixed(2)) : 0

    /**
     * Quantidade de postos: Quantidade de postos que tiveram abastecimentos
     * (Indicador)
     */
    req = { base: base, data_inicial: data_inicio, data_final: data_fim, produto_id: produto_id, posto_id: posto_id, placa_id: placa_id, estado: estado }
    this._groupAbastecimento.setMatchAbastecimento(req)
    res = await this._abastecimentoService.aggregate({ match: this._groupAbastecimento.match, req: req }, ['posto'], sort, 10000)
    retorno.indicador.qtde_postos = res && res.length > 0 ? res.length : 0




    /**
     * Quantidade de arla abastecida: Valor de arla abastecida
     * (Indicador)
     */
    req = { base: base, data_inicial: data_inicio, data_final: data_fim, produto_id: produto_id, posto_id: posto_id, placa_id: placa_id, estado: estado, combustivel: [2] } // Arla
    this._groupAbastecimento.setMatchAbastecimento(req)
    res = await this._abastecimentoService.aggregate({ match: this._groupAbastecimento.match, req: req }, ['qtde'], sort, 10000)
    retorno.indicador.qtde_arla = res && res.length > 0 ? Number((res[0].valor).toFixed(2)) : 0

    req = { base: base, data_inicial: data_inicio, data_final: data_fim, produto_id: produto_id, posto_id: posto_id, placa_id: placa_id, estado: estado, combustivel: [1]  }
    this._groupAbastecimento.setMatchAbastecimento(req)
    res = await this._abastecimentoService.aggregate({ match: this._groupAbastecimento.match, req: req }, ['maior_vl_unitario'], { _id: { chave1: -1 } }, 1000000)
    retorno.indicador.maior_vl_unitario = res && res.length > 0 ? res[0].valor : 0

    req = { base: base, data_inicial: data_inicio, data_final: data_fim, produto_id: produto_id, posto_id: posto_id, placa_id: placa_id, estado: estado, combustivel: [1] }
    this._groupAbastecimento.setMatchAbastecimento(req)
    res = await this._abastecimentoService.aggregate({ match: this._groupAbastecimento.match, req: req }, ['menor_vl_unitario'], { _id: { chave1: -1 } }, 1000000)
    retorno.indicador.menor_vl_unitario = res && res.length > 0 ? res[0].valor : 0


    req = { base: base, data_inicial: data_inicio, data_final: data_fim, produto_id: produto_id, posto_id: posto_id, placa_id: placa_id, estado: estado }
    this._groupAbastecimento.setMatchAbastecimento(req)
    res = await this._abastecimentoService.aggregate({ match: this._groupAbastecimento.match, req: req }, ['total'], { valor: -1 }, 10)
    retorno.indicador.total_gastos = res && res.length > 0 ? res[0].valor : 0

    req = { base: base, data_inicial: data_inicio, data_final: data_fim, produto_id: produto_id, posto_id: posto_id, placa_id: placa_id, estado: estado }
    this._groupAbastecimento.setMatchAbastecimento(req)
    res = await this._abastecimentoService.aggregate({ match: this._groupAbastecimento.match, req: req }, ['litros'], { valor: -1 }, 10)
    retorno.indicador.litros_gastos = res && res.length > 0 ? res[0].valor : 0


    /**
     * Distribuição de volume por estado: Quantidade abastecida por estado
     * (Mapa)
     */
    req = { base: base, data_inicial: data_inicio, data_final: data_fim, produto_id: produto_id, posto_id: posto_id, placa_id: placa_id, estado: estado }
    this._groupAbastecimento.setMatchAbastecimento(req)
    res = await this._abastecimentoService.aggregate({ match: this._groupAbastecimento.match, req: req }, ['posto', 'qtde', 'lat', 'lng'], { _id: { chave: -1 } }, 10000)
    retorno.mapa.distribuicao_volume.dados = await this.getStatus(res, 'qtde')

    /**
      * Distribuição de valor unitário estado: Média de valor unitário por estado
      * (Mapa)
      */
    req = { base: base, data_inicial: data_inicio, data_final: data_fim, produto_id: produto_id, posto_id: posto_id, placa_id: placa_id, estado: estado, valor_uni: 1 }
    this._groupAbastecimento.setMatchAbastecimento(req)
    res = await this._abastecimentoService.aggregate({ match: this._groupAbastecimento.match, req: req }, ['posto', 'posto_id', 'media', 'lat', 'lng'], { _id: { chave: -1 } }, 10000)
    retorno.mapa.distribuicao_valor_uni.dados = await this.getStatus(res, 'media')
    // retorno.temp = res



    res = await this._abastecimentoService.aggregate({ match: {}, req: req }, ['last_update'], sort)
    retorno.atualizacao = res && res.length > 0 ? res[0].valor : 0

    console.log('base', req.base, 'ABASTECIMENTO: ', (new Date() - logInicio) / 1000, 'segundos')
    socket.emit('abastecimento', retorno)
  }

  private async getPlacaPercentual (lista: Array<any>): any {

    let elements: any = {}
    let distinct: any = []
    let obj: any = []
    let indicador: any = []

    // let fat = null
    // let abast = null

    // Pega apenas os elementos referente a placa
    elements = lista.map(element => { return element.chave })

    // distinct das placas
    elements = [...new Set(elements)]

    // Agrupa por placa
    lista.filter(x => {
      let t = distinct.map(d => d).find(p => p.placa === x.chave)


      if (!t) {

        distinct.push({
          placa: x.chave,
          diesel: x.combustivel === 'Diesel' ? x.valor : 0,
          arla: x.combustivel === 'Arla' ? x.valor : 0,
          // qtde: x.qtde,
          total: x.valor
        })
      } else {
        Object.assign(t, {
          diesel: x.combustivel === 'Diesel' ? x.valor : t.diesel,
          arla: x.combustivel === 'Arla' ? x.valor : t.arla,
          total: x.valor ? x.valor + t.total : t.total
        })
      }
    })

    // Total de combustivel : valor faturada do arla e diesel
    // Valor: valor de arla * 100 / total de combustivel
    // filtrado os valor 0
    obj = distinct.map(m => {
      let arla = (m.arla > 0 ? (m.arla * 100) / m.total : 0).toFixed(2)
      return {
        chave: m.placa, valor: Number(arla)
      }
    })
      .filter(el => { return el.valor > 0 })
      .sort((a, b) => { return b.valor - a.valor })

    return obj
  }

  /**
   * Função de valores do abastecimento e faturamento da placa
   * Retorna uma lista e um indicador 
   * [0] lista
   * [1] indicador
   */
  private async getFaturamentoAbastecimento(abastecimento: Array<any>, faturamento: Array<any>): any {

    let obj: any = []
    let indicador: any = []
    let fat = null
    let abast = null

    // % do combustivel em cima do total de faturamento da placa = (valor_combustivel) * 100 / total_faturamento
    faturamento.filter(x => {
      let a = abastecimento.map(d => d).find(p => p.chave === x.chave)

      fat += x.total ? x.total : 0 // soma dos faturamentos
      abast += a.valor ? a.valor : 0 // soma dos abastecimento

      obj.push({
        chave: x.chave,
        valor: Number((a.valor !== 0 && x.total !== 0 ? (a.valor * 100) / x.total : 0).toFixed(0))
      })

    })

    indicador = (abast * 100) / fat

    return [{ lista: obj.sort((a, b) => { return b.valor - a.valor }), indicador: Number(indicador.toFixed(0)) }]
  }


  /**
   * Função que atribui o campo status ao array de lista de mapas
   * Media: Lista do mapa sobre a media do vl unitario do combustivel
   * qtde: Lipa de mapa sobre a qtde total de abasteicmento
   */

  private async getStatus(lista: Array<any>, tipo: string): any {

    let obj: any = []


    lista.filter(x => {
      if (tipo === 'media') {

        if (x.valor >= 0 && x.valor < 3) {
          Object.assign(x, { status: 0 })
        }
        if (x.valor >= 3 && x.valor < 3.5) {
          Object.assign(x, { status: 1 })
        }
        if (x.valor >= 3.5 && x.valor < 4.0) {
          Object.assign(x, { status: 2 })
        }
        if (x.valor >= 4) {
          Object.assign(x, { status: 3 })
        }

      } if (tipo === 'qtde') {
        if (x.valor >= 0 && x.valor < 100) {
          Object.assign(x, { status: 0 })
        }
        if (x.valor >= 100 && x.valor < 200) {
          Object.assign(x, { status: 1 })
        }
        if (x.valor >= 200 && x.valor < 300) {
          Object.assign(x, { status: 2 })
        }
        if (x.valor >= 300 && x.valor < 400) {
          Object.assign(x, { status: 3 })
        }
        if (x.valor > 400) {
          Object.assign(x, { status: 4 })
        }
      }
    })

    return lista
  }
}
export default new AbastecimentoController()
