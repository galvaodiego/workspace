import GroupFaturamento from '../group/faturamento.group'
import { Socket } from 'socket.io'
import { FaturamentoService } from '../services/faturamento.service'
import { FaturamentoV2Service } from '../services/faturamento_v2.service'

class FaturamentoController {
  public async getFaturamento(req: object, socket: Socket): Promise<void> {

    req.base = req.base === 'ciaverdelog' ? 'viaverde' : req.base

    const queryFat = new GroupFaturamento()
    const _faturamentoService = new FaturamentoService()
    const sort = { valor: -1 }
    const cliente = req.base
    const retorno = {
      faturamentoPeriodo: null,
      faturamentoCliente: null,
      faturamentoMercadoria: null,
      faturamentoModalidade: null,
      faturamentoDestino: null,
      faturamentoCarroceria: null,
      faturamentoPlaca: null,
      faturamentoFilial: null
    }

    let filter: any = {}
    const logInicio = new Date()

    queryFat.setMatchFaturamento(req)

    retorno.faturamentoPeriodo = await _faturamentoService.findAll(queryFat.match, cliente, req, 'data', { '_id.data': 1 })

    filter = Object.assign({}, req, { meta: 0 })
    queryFat.setMatchFaturamento(filter)
    retorno.faturamentoCliente = await _faturamentoService.findAll(queryFat.match, cliente, filter, 'cliente', sort)

    retorno.faturamentoMercadoria = await _faturamentoService.findAll(queryFat.match, cliente, filter, 'mercadoria', sort)

    retorno.faturamentoModalidade = await _faturamentoService.findAll(queryFat.match, cliente, filter, 'modalidade', sort)

    retorno.faturamentoDestino = await _faturamentoService.findAll(queryFat.match, cliente, filter, 'destino', sort)

    retorno.faturamentoCarroceria = await _faturamentoService.findAll(queryFat.match, cliente, filter, 'carroceria', sort)

    retorno.faturamentoPlaca = await _faturamentoService.findAll(queryFat.match, cliente, filter, 'placa', sort)

    retorno.faturamentoFilial = await _faturamentoService.findAll(queryFat.match, cliente, filter, 'filial', sort)


    console.log('base', req.base, 'FATURAMENTO:', (new Date() - logInicio) / 1000, 'segundos')
    socket.emit('faturamento', retorno)
  }

  public async getFaturamentoV2(req: object, socket: Socket): Promise<void> {

    req.base = req.base === 'ciaverdelog' ? 'viaverde' : req.base

    const queryFat = new GroupFaturamento()
    const _faturamentoService = new FaturamentoV2Service()
    const sort = { valor: -1 }
    const cliente = req.base
    const retorno = {
      faturamentoPeriodo: null,
      faturamentoCliente: null,
      faturamentoMercadoria: null,
      faturamentoModalidade: null,
      faturamentoDestino: null,
      faturamentoCarroceria: null,
      faturamentoPlaca: null,
      faturamentoFilial: null
    }

    let filter: any = {}
    const logInicio = new Date()

    queryFat.setMatchFaturamento(req)

    retorno.faturamentoPeriodo = await _faturamentoService.findAll(queryFat.match, cliente, req, 'data', { '_id.data': 1 })

    filter = Object.assign({}, req, { meta: 0 })
    queryFat.setMatchFaturamento(filter)
    retorno.faturamentoCliente = await _faturamentoService.findAll(queryFat.match, cliente, filter, 'cliente', sort)

    retorno.faturamentoMercadoria = await _faturamentoService.findAll(queryFat.match, cliente, filter, 'mercadoria', sort)

    retorno.faturamentoModalidade = await _faturamentoService.findAll(queryFat.match, cliente, filter, 'modalidade', sort)

    retorno.faturamentoDestino = await _faturamentoService.findAll(queryFat.match, cliente, filter, 'destino', sort)

    retorno.faturamentoCarroceria = await _faturamentoService.findAll(queryFat.match, cliente, filter, 'carroceria', sort)

    retorno.faturamentoPlaca = await _faturamentoService.findAll(queryFat.match, cliente, filter, 'placa', sort)

    retorno.faturamentoFilial = await _faturamentoService.findAll(queryFat.match, cliente, filter, 'filial', sort)


    console.log('base', req.base, 'FATURAMENTO:', (new Date() - logInicio) / 1000, 'segundos')
    socket.emit('faturamento', retorno)
  }
}

export default new FaturamentoController()
