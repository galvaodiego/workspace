/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable space-before-function-paren */
/* eslint-disable @typescript-eslint/explicit-function-return-type */
/* eslint-disable indent */
import { TosService } from '../services/tos.service'
class TosController {
    public async getGMO(req: any): Promise<void> {
        const _tosService = new TosService()
        try {
            if (!req.body.base) {
                throw new Error("PARAMETRO 'BASE' É OBRIGATÓRIO")
            }
            const res = await _tosService.getGMO(req)
            return res
        } catch (error) {
            console.error(error)
            throw error
        }
    }

    public async saveGMOConfig(req: any): Promise<void> {
        const _tosService = new TosService()
        try {
            // if (!req.body.base) {
            //     throw new Error("PARAMETRO 'BASE' É OBRIGATÓRIO")
            // }
            const res = await _tosService.saveConfig(req.body)
            return res
        } catch (error) {
            console.error(error)
            throw error
        }
    }

    public async getGMOConfig(req: any): Promise<void> {
        const _tosService = new TosService()
        try {
            // if (!req.body.base) {
            //     throw new Error("PARAMETRO 'BASE' É OBRIGATÓRIO")
            // }
            const res = await _tosService.getConfig(req.body)
            return res
        } catch (error) {
            console.error(error)
            throw error
        }
    }
}

export default new TosController()
