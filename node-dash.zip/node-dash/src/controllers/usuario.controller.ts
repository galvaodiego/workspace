import { UsuarioService } from '../services/usuario.service';

class UsuarioController {


    public async getUsuario(): Promise<any> {
        const _usuarioService = new UsuarioService();
        const retorno = await _usuarioService.findAll();

        return retorno
    }


    public async findOne(id): Promise<any> {
        const _usuarioService = new UsuarioService();
        const retorno = await _usuarioService.findOne(id);

        return retorno
    }

    public async insertUsuario(socket_id, base, from, socket): Promise<void> {
      // let copy = typeof socket
        var cache = [];
        const s = JSON.stringify(socket, function (key, value) {
          if (typeof value === 'object' && value !== null) {
            if (cache.indexOf(value) !== -1) {
              // Duplicate reference found, discard key
              return;
            }
            // Store value in our collection
            cache.push(value);
          }
          return value;
        });
        cache = null; // Enable garbage collection

        const data = { socket_id, base, from };
        const _usuarioService = new UsuarioService();
        
        /**
         * Verifica se já existe o cliente, se insere
         */
        const user = await _usuarioService.findOne(socket_id);

        if (!!user && user.length <= 0) {
           await _usuarioService.insert(data);
        }

    }

    public async deleteUsuario(user): Promise<any> {
        let id = user[0].socket_id
        const _usuarioService = new UsuarioService();
        await _usuarioService.delete(id)
        
    }
}

export default new UsuarioController()
