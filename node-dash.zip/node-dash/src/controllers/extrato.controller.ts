import { Socket } from 'socket.io'
import { DoctoFiscalService } from '../services/docto_fiscal.service'
import GroupDoctoFiscal from '../group/docto_fiscal.group'

class ExtratoController {

  private _groupDocto = new GroupDoctoFiscal()
  private _doctoService = new DoctoFiscalService()
  public async getExtrato(req: object, socket: Socket): Promise<void> {


    const cliente = req.base
    const periodo = req.periodo
    const sort = { qtde: -1 }

    let emitidos = null
    let cancelados = null


    const retorno = {
      modalidade: null,
      cliente: null,
      grupo_produto: null,
      documentos: { totalizadores: {}, dist: [] },
      tipo_frete: { totalizadores: [], dist: [] },
      veiculo: { totalizadores: [], dist: [], resumo: [] },
      placa: null,
      media: {},
      motorista: null

    }

    const logInicio = new Date()


    let res = null;
    let agg = null;

    agg = await this.aggtempo(periodo);

    /**
     * Documentos
     */

    req = { 'base': cliente, 'periodo': periodo, 'cancelada': 0 }
    this._groupDocto.setMatchDoctoFiscal(req)
    emitidos = await this._doctoService.aggregate({ match: this._groupDocto.match, req: req }, ['qtde', 'faturamento', 'peso', agg], { _id: -1 }, 100)



    req = { 'base': cliente, 'periodo': periodo, 'cancelada': 1 }
    this._groupDocto.setMatchDoctoFiscal(req)
    cancelados = await this._doctoService.aggregate({ match: this._groupDocto.match, req: req }, ['qtde', 'faturamento', 'peso', agg], { _id: -1 }, 100)

    retorno.documentos.dist = await this.documento(emitidos, cancelados, agg)
    retorno.documentos.totalizadores = await this.kpis(req, '')
    /**
     * Docuemtnos
     */



    req = { 'base': cliente, 'periodo': periodo, 'cancelada': 0 }
    this._groupDocto.setMatchDoctoFiscal(req)
    retorno.modalidade = await this._doctoService.aggregate({ match: this._groupDocto.match, req: req }, ['modalidade', 'qtde', 'faturamento', 'peso', agg], sort, 1000)


    req = { 'base': cliente, 'periodo': periodo, 'cancelada': 0 }
    this._groupDocto.setMatchDoctoFiscal(req)
    retorno.cliente = await this._doctoService.aggregate({ match: this._groupDocto.match, req: req }, ['cliente', 'qtde', 'faturamento', 'peso', agg], { total: -1 }, 300)

    req = { 'base': cliente, 'periodo': periodo, 'cancelada': 0 }
    this._groupDocto.setMatchDoctoFiscal(req)
    retorno.grupo_produto = await this._doctoService.aggregate({ match: this._groupDocto.match, req: req }, ['produto', 'grupo_produto', 'qtde', 'faturamento', 'peso', agg], sort, 2000);


    /**
     * Tipo de frete
     */

    req = { 'base': cliente, 'periodo': periodo, 'cancelada': 0 }
    this._groupDocto.setMatchDoctoFiscal(req)
    retorno.tipo_frete.totalizadores = await this._doctoService.aggregate({ match: this._groupDocto.match, req: req }, ['tipo_frete', 'qtde', 'faturamento', 'peso'], { total: -1 }, 1000);

    req = { 'base': cliente, 'periodo': periodo, 'cancelada': 0 }
    this._groupDocto.setMatchDoctoFiscal(req)
    retorno.tipo_frete.dist = await this._doctoService.aggregate({ match: this._groupDocto.match, req: req }, ['tipo_frete', 'qtde', 'faturamento', 'peso', agg], { total: -1 }, 1000);
    /**
     * tipo frete
     */



    req = { 'base': cliente, 'periodo': periodo, 'cancelada': 0 }
    this._groupDocto.setMatchDoctoFiscal(req)
    retorno.veiculo.totalizadores = await this._doctoService.aggregate({ match: this._groupDocto.match, req: req }, ['veiculo_classificacao', 'veiculo_padrao', 'qtde', 'faturamento', 'peso'], { total: -1 }, 4);

    req = { 'base': cliente, 'periodo': periodo, 'cancelada': 0 }
    this._groupDocto.setMatchDoctoFiscal(req)
    retorno.veiculo.dist = await this._doctoService.aggregate({ match: this._groupDocto.match, req: req }, ['veiculo_classificacao', 'qtde', 'faturamento', 'peso', 'media', agg], { total: -1 }, 1000);


    Object.assign(retorno.veiculo.resumo, await this.totalizador(retorno.veiculo.totalizadores))


    req = { 'base': cliente, 'periodo': periodo, 'cancelada': 0 }
    this._groupDocto.setMatchDoctoFiscal(req)
    retorno.placa = await this._doctoService.aggregate({ match: this._groupDocto.match, req: req }, ['placa_controle', 'qtde', 'faturamento', 'media',], { total: -1 }, 1000);

    Object.assign(retorno.media, {
      'carroceria': await this.media(retorno.veiculo.dist),
      'placa': await this.media(retorno.placa)
    });

    req = { 'base': cliente, 'periodo': periodo, 'cancelada': 0 }
    this._groupDocto.setMatchDoctoFiscal(req)
    retorno.motorista = await this._doctoService.aggregate({ match: this._groupDocto.match, req: req }, ['motorista', 'qtde', 'faturamento', 'media',], { total: -1 }, 11);

    /*
 
       req = { 'base': cliente, 'periodo': periodo, 'cancelada': 0 }
       this._groupDocto.setMatchDoctoFiscal(req)
       retorno.coordenador.dist = await this._doctoService.aggregate({ match: this._groupDocto.match, req: req }, ['coordenador', 'qtde', 'faturamento', 'peso', agg], { _id: -1 }, 100);
       retorno.coordenador.totalizadores = await this.kpis(req, 'coordenador');
   
   
       // req = { 'base': cliente, 'periodo': 'mensal', 'cancelada': 0 }
       // this._groupDocto.setMatchDoctoFiscal(req)
       // retorno.dist_ccg = await this._doctoService.aggregate({ match: this._groupDocto.match, req: req }, ['ccg', 'qtde', 'faturamento', 'peso', 'dia_mes'], { _id: -1 }, 100);
       // this.totalizadores(req, retorno.dist_ccg);
*/

    console.log('base', req.base, 'EXTRATO: ', (new Date() - logInicio) / 1000, 'segundos')
    socket.emit('extrato', retorno)
  }



  private async kpis(req, agrupador) {

    let params = null;
    let cancelados = null;
    let total = null;
    let x: any = [];

    params = { 'base': req.base, 'periodo': req.periodo, 'cancelada': 1 }
    this._groupDocto.setMatchDoctoFiscal(params)
    cancelados = await this._doctoService.aggregate({ match: this._groupDocto.match, req: params }, ['qtde'], { qtde: -1 });


    params = { 'base': req.base, 'periodo': req.periodo, 'cancelada': 0 }
    this._groupDocto.setMatchDoctoFiscal(params)
    total = await this._doctoService.aggregate({ match: this._groupDocto.match, req: params }, ['qtde', 'faturamento', 'peso'], { qtde: -1 });



    x.push({
      'cancelados': cancelados,
      'emitidos': total[0].qtde,
      'faturamento': total[0].total,
      'peso': total[0].peso,
      'total_docs': (cancelados.length > 0 ? cancelados : 0) + total[0].qtde,
    })

    return x

  }

  private async aggtempo(periodo) {

    let res = null;

    if (periodo == 'anual') {
      res = 'mes_ano'
    } if (periodo == 'mensal') {
      res = 'dia_mes'
    } if (periodo == 'diario') {
      res = null
    }

    return res;

  }

  private async documento(emitidos, cancelados, agg) {

    let docs: any = [];
    let n = emitidos.length;
    let data_can: null;


    for (let _i = 0; _i < n; _i++) {

      // Verifica se valores da data está vazio, ex 01/12 não tem cancelados = undefined como result
      data_can = cancelados[_i] ? cancelados[_i].data : ' ';

      // Totalizadores conforme data (mes/ano/diario) - Apenas o diario não traz a data
      if (emitidos[_i].data == data_can || data_can != '') {

        docs.push({
          'data': emitidos[_i].data,
          'emitidos': emitidos[_i].qtde,
          'cancelados': cancelados[_i] ? cancelados[_i].qtde : 0,
          'fat_emitidos': emitidos[_i].total,
          'fat_cancelados': cancelados[_i] ? cancelados[_i].total : 0,
          'peso_emitido': emitidos[_i].peso,
          'peso_cancelados': cancelados[_i] ? cancelados[_i].peso : 0,
          'total_docs': emitidos[_i].qtde + (cancelados[_i] ? cancelados[_i].qtde : 0),
          'total_fat': emitidos[_i].total + (cancelados[_i] ? cancelados[_i].total : 0),
          'total_peso': emitidos[_i].peso + (cancelados[_i] ? cancelados[_i].peso : 0),

        })
      }
    }

    return docs

  }

  private async media(lista) {

    let count = 0;
    let total = 0;

    lista.forEach(e => {
      count += 1;
      total = total + e.media;
    });

    return total;
  }

  private async totalizador(lista) {

    let peso = 0;
    let total = 0;
    let qtde = 0;
    let docs: any = [];

    lista.forEach(e => {
      qtde = qtde + e.qtde,
        total = total + e.total,
        peso = peso + e.peso

    });

    docs.push({
      'qtde': qtde,
      'total': total,
      'peso': peso
    })

    return docs

  }
}

export default new ExtratoController()
