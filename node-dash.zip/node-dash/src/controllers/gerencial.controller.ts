/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable space-before-function-paren */
/* eslint-disable @typescript-eslint/explicit-function-return-type */
/* eslint-disable indent */
import { GerencialService } from '../services/gerencial.service'
class GerencialController {
    public async getUsuario(data: any) {
        const _gerencialService = new GerencialService()
        try {
            const res = await _gerencialService.getUsuario(data)
            return res
        } catch (error) {
            console.error(error)
            throw error
        }
    }

    public async getUsuarios(data: any) {
        const _gerencialService = new GerencialService()
        try {
            const res = await _gerencialService.getUsuarios(data)
            return res
        } catch (error) {
            console.error(error)
            throw error
        }
    }

    public async getModulos(data: any) {
        const _gerencialService = new GerencialService()
        try {
            const res = await _gerencialService.getModulos(data)
            return res
        } catch (error) {
            console.error(error)
            throw error
        }
    }

    public async searchUsuarios(data: any) {
        const _gerencialService = new GerencialService()
        try {
            const res = await _gerencialService.searchUsuarios(data)
            return res
        } catch (error) {
            console.error(error)
            throw error
        }
    }

    public async getUsuariosGrupo(data: any) {
        const _gerencialService = new GerencialService()
        try {
            const res = await _gerencialService.getUsuariosGrupo(data)
            return res
        } catch (error) {
            console.error(error)
            throw error
        }
    }

    public async saveModulo(data: any) {
        const _gerencialService = new GerencialService()
        try {
            await _gerencialService.saveModulo(data)
        } catch (error) {
            console.error(error)
            throw error
        }
    }

    public async saveUsuario(data: any) {
        const _gerencialService = new GerencialService()
        try {
            await _gerencialService.saveUsuario(data)
        } catch (error) {
            console.error(error)
            throw error
        }
    }

    public async saveUsuarioGrupo(data: any) {
        const _gerencialService = new GerencialService()
        try {
            await _gerencialService.saveUsuarioGrupo(data)
        } catch (error) {
            console.error(error)
            throw error
        }
    }

    public async delUsuario(data: any) {
        const _gerencialService = new GerencialService()
        try {
            await _gerencialService.delUsuario(data)
        } catch (error) {
            console.error(error)
            throw error
        }
    }

    public async delUsuarioGrupo(data: any) {
        const _gerencialService = new GerencialService()
        try {
            await _gerencialService.delUsuarioGrupo(data)
        } catch (error) {
            console.error(error)
            throw error
        }
    }

    public async delModulo(data: any) {
        const _gerencialService = new GerencialService()
        try {
            await _gerencialService.delModulo(data)
        } catch (error) {
            console.error(error)
            throw error
        }
    }
}

export default new GerencialController()
