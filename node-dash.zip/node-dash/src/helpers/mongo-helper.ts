
export const MongoHelper = {

  map: (data: any): any => {
    data.forEach(element => {
      if (element._id) {
        Object.assign(element, element._id)
        delete element._id
      }
    })
    return data
  },

  mapFindAll: (data: any): any => {
    data.forEach(element => {
      delete element._doc._id
    })
    return data
  }
}
