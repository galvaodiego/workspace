import mongoose, { Schema, model, Document } from 'mongoose'


export interface ContratoTranspInterface extends Document {


}

const ContratoTranspSchema = new Schema({

})

export default model<ContratoTranspInterface>('ContratoTransp', ContratoTranspSchema)