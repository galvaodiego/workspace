import mongoose, { Schema, model, Document } from 'mongoose'


export interface MetaInterface extends Document {


    dim_meta?: number,
    dim_remetente?: number,
    dim_destinatario?: number,
    dim_origem_municipio?: number,
    dim_destino_municipio?: number,
    dim_cliente?: number,
    dim_produto?: number,
    dim_operacao?: number,
    dim_veiculo?: number,
    total_documento?: number,
    total_peso?: number,
    meta_faturamento?: number,
    meta_tonelagem?: number,
    data_base?: Date,
    flag_data?: number,
    flag_mario_mes?: number,


    toJson(): Document
}

const MetaSchema = new Schema({
    /**
      * Colunas da tablela
      */

    dim_meta: Number,
    dim_remetente: Number,
    dim_destinatario: Number,
    dim_origem_municipio: Number,
    dim_destino_municipio: Number,
    dim_cliente: Number,
    dim_produto: Number,
    dim_operacao: Number,
    total_documento: {
        type: Schema.Types.Decimal128,
        required: false
    },
    total_peso: {
        type: Schema.Types.Decimal128,
        required: false
    },
    meta_faturamento: {
        type: Schema.Types.Decimal128,
        required: false
    },
    meta_tonelagem: {
        type: Schema.Types.Decimal128,
        required: false
    },
    data_base: Date,
    flag_data: Number,
    flag_mario_mes: Number,


})


export default model<MetaInterface>('Meta', MetaSchema)

