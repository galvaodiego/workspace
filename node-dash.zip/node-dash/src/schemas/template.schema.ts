/* eslint-disable indent */
/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable camelcase */
import { Schema, model, Document } from 'mongoose'

export interface TemplateInterface extends Document {
    dash_id: number,
    dash: string,
    usuario_bi_id: number,
    usuario: string,
    modelo_id: number,
    slots: Array<number>,
    cliente: string
    toJson(): Document
}

const TemplateSchema = new Schema({
    dash_id: Number,
    dash: String,
    usuario_bi_id: Number,
    usuario: String,
    modelo_id: Number,
    slots: Array,
    cliente: String
})

export default model<TemplateInterface>('template', TemplateSchema)
