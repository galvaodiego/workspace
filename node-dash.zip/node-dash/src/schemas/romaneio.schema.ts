import { Schema, model, Document } from 'mongoose'

export interface RomaneioInterface extends Document {

   dim_romaneio?: number,
   dim_remetente?: number,
   dim_destinatario?: number,
   dim_origem_municipio?: number,
   dim_destino_municipio?: number,
   dim_cliente?: number,
   dim_produto?: number,
   dim_operacao?: number,
   faturado?: number,
   cancelada?: number,
   placa_controle?: string
   data_inicio?: Date,
   data_inicio_carga?: Date,
   data_termino_carga?: Date,
   data_inicio_descarga?: Date,
   data_termino_descarga?: Date,
   situacao_id?: number,
   situacao_descricao?: string
   situacao_viagem_id?: number,
   situacao_viagem_desc?: string
   
   toJson(): Document
}

const RomaneioShema = new Schema({

   dim_romaneio: Number,
   dim_remetente: Number,
   dim_destinatario: Number,
   dim_origem_municipio: Number,
   dim_destino_municipio: Number,
   dim_cliente: Number,
   dim_produto: Number,
   dim_operacao: Number,
   faturado: Number,
   cancelada: Number,
   placa_controle: String,
   data_inicio: Date,
   data_inicio_carga: Date,
   data_termino_carga: Date,
   data_inicio_descarga: Date,
   data_termino_descarga: Date,
   situacao_id: Number,
   situacao_descricao: String,
   situacao_viagem_id: Number,
   situacao_viagem_desc: String


})

export default model<RomaneioInterface>('romaneio', RomaneioShema)

