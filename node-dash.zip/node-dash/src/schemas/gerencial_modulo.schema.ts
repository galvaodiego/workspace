/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable indent */
/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable camelcase */
import { Schema, model, Document } from 'mongoose'

export interface GerencialModuloInterface extends Document {
    descricao: string,
    referencia: string,
    origem: string,
    toJson(): Document
}

const GerencialModuloSchema = new Schema({
    descricao: String,
    referencia: String,
    origem: String
})

export default model<GerencialModuloInterface>('gerencialModulo', GerencialModuloSchema)
