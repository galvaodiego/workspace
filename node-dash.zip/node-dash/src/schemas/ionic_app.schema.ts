/* eslint-disable indent */
/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable camelcase */
import { Schema, model, Document } from 'mongoose'

export interface IonicAppInterface extends Document {
    map_key: string,
    toJson(): Document
}

const IonicAppSchema = new Schema({
    map_key: String
})

export default model<IonicAppInterface>('ionicApp', IonicAppSchema)
