import { Schema, model, Document } from 'mongoose'

export interface ViagemInterface extends Document {

   peso?: number,
   km_vazio?: number,
   km_carregado?: number,
   km_total?: number,
   qtd_viagem?: number,
   data?: Date,
   mercadoria: string
   cliente?: string,
   destino?: string,
   rota?: string,
   flag_semana?: number,
   flag_mes: number,
   uf_origem: string,
   uf_destino: string

   toJson(): Document
}

const ViagemSchema = new Schema({
  /**
    * Colunas da tablela
    */
  peso: Number,
  km_vazio: Number,
  km_carregado: Number,
  km_total: Number,
  qtd_viagem: Number,
  data: Date,
  mercadoria: String,
  cliente: String,
  destino: String,
  rota: String,
  flag_semana: Number,
  flag_mes: Number,
  uf_origem: String,
  uf_destino: String

})

// model<ViagemInterface>('Viagem', ViagemSchema, 'sulista')
// const Viagem = model('Viagem', ViagemSchema)

export default model<ViagemInterface>('dash_viagem', ViagemSchema)
// module.exports = model<ViagemInterface>('Viagem', ViagemSchema, 'sulista')
