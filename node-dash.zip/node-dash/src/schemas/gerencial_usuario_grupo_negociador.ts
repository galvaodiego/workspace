/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable indent */
/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable camelcase */
import { Schema, model, Document } from 'mongoose'

export interface GerencialUsuarioGrupoNegociadorInterface extends Document {
    usuario: string,
    grupo_negociador: Array<any>,
    origem: string,
    toJson(): Document
}

const GerencialUsuarioGrupoNegociadorSchema = new Schema({
    usuario: String,
    grupo_negociador: Array,
    origem: String
})

export default model<GerencialUsuarioGrupoNegociadorInterface>('gerencialUsuarioGrupoNegociador', GerencialUsuarioGrupoNegociadorSchema)
