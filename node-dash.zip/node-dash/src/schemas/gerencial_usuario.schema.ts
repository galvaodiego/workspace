/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable indent */
/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable camelcase */
import { Schema, model, Document } from 'mongoose'

export interface GerencialUsuarioInterface extends Document {
    usuario: string,
    ativo: boolean,
    gerencial: boolean,
    modulos: Array<any>,
    origem: string,
    toJson(): Document
}

const GerencialUsuarioSchema = new Schema({
    usuario: String,
    ativo: Boolean,
    gerencial: Boolean,
    modulos: Array,
    origem: String
})

export default model<GerencialUsuarioInterface>('gerencialUsuario', GerencialUsuarioSchema)
