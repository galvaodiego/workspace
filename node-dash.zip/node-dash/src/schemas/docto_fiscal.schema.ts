import mongoose, { Schema, model, Document } from 'mongoose'


export interface DoctoFiscalInterface extends Document {

   dim_documento_fiscal?: number,
   dim_romaneio?: number,
   dim_solic_carga?: number,
   dim_remetente?: number,
   dim_destinatario?: number,
   dim_origem_municipio?: number,
   dim_destino_municipio?: number,
   dim_cliente?: number,
   dim_produto?: number,
   dim_operacao?: number,
   valor_faturado?: number,
   cancelada?: number,
   tempo_emissao?: number,
   num_docto?: number,
   placa_tracao?: string,
   placa_carreta?: string,
   conhecimento_tipo_id?: number,
   conhecimento_tipo_desc?: string,
   tipo_conhecimento?: string,
   tipo_docto?: string,
   data_emissao?: Date,
   data_viagem?: Date,
   user_insert?: string,
   NUM_DOCTO?: Number,
   AUTOMATIZADO?: Number,
   INTEGRADO?: Number,
   NR_DIA_MES?: Number,
   MES_ANO?: String,
   DIA_MES?: String,
   CLIENTE?: String


   toJson(): Document
}

const DoctoFiscalSchema = new Schema({
   /**
     * Colunas da tablela
     */
   dim_documento_fiscal: Number,
   dim_romaneio: Number,
   dim_solic_carga: Number,
   dim_remetente: Number,
   dim_destinatario: Number,
   dim_origem_municipio: Number,
   dim_destino_municipio: Number,
   dim_cliente: Number,
   dim_produto: Number,
   dim_operacao: Number,
   valor_faturado: {
      type: Schema.Types.Decimal128,
      required: false
   },
   cancelada: Number,
   tempo_emissao: Number,
   num_docto: Number,
   placa_tracao: String,
   placa_carreta: String,
   conhecimento_tipo_id: Number,
   conhecimento_tipo_desc: String,
   tipo_conhecimento: String,
   tipo_docto: String,
   data_emissao: Date,
   data_viagem: Date,
   user_insert: String,
   
   NUM_DOCTO: Number,
   AUTOMATIZADO: Number,
   INTEGRADO: Number,
   NR_DIA_MES: Number,
   MES_ANO: String,
   DIA_MES: String,
   CLIENTE: String


})


export default model<DoctoFiscalInterface>('docto_fiscal', DoctoFiscalSchema)

