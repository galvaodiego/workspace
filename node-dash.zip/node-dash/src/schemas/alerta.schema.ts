import { Schema, model, Document } from 'mongoose'

export interface AlertaInterface extends Document{
  // eslint-disable-next-line camelcase
  data ?: Date,
  cliente ?: string,
  operador ?: string,
  // eslint-disable-next-line camelcase
  alerta_tipo_id?: number,
  segmento ?: string,
  // eslint-disable-next-line camelcase
  tipo_alerta ?: string,
  // eslint-disable-next-line camelcase
  qtd_resolvido ?: number,
  // eslint-disable-next-line camelcase
  qtd_aberto ?: number,
  // eslint-disable-next-line camelcase
  tempo_medio ?: number,
  toJson(): Document
}

const AlertaSchema = new Schema({
  // eslint-disable-next-line @typescript-eslint/camelcase
  data: Date,
  cliente: String,
  operador: String,
  // eslint-disable-next-line @typescript-eslint/camelcase
  alerta_tipo_id: Number,
  segmento: String,
  // eslint-disable-next-line @typescript-eslint/camelcase
  tipo_alerta: String,
  // eslint-disable-next-line @typescript-eslint/camelcase
  qtd_resolvido: Number,
  // eslint-disable-next-line @typescript-eslint/camelcase
  qtd_aberto: Number,
  // eslint-disable-next-line @typescript-eslint/camelcase
  tempo_medio: Number

})

export default model<AlertaInterface>('Alerta', AlertaSchema)
