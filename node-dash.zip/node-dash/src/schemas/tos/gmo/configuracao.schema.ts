/* eslint-disable comma-dangle */
/* eslint-disable semi */
/* eslint-disable quotes */
/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable camelcase */
import { Schema, model, Document } from "mongoose";

export interface ConfiguracaoInterface extends Document {
  user: string;
  usuario_logon_id: number;
  codGestao: number;
  gmo_config: object;
  gmo_config_exibicao: Array<object>;
  toJson(): Document;
}

const ConfiguracaoSchema = new Schema({
  user: String,
  usuario_logon_id: Number,
  codGestao: Number,
  gmo_config: Object,
  gmo_config_exibicao: Array,
});

export default model<ConfiguracaoInterface>("Configuracao", ConfiguracaoSchema);
