/* eslint-disable camelcase */
/* eslint-disable @typescript-eslint/camelcase */
import { Schema, model, Document } from 'mongoose'

export interface CicloInterface extends Document {
    chave: string,
    gmo_id: number,
    etapa_id: number,
    etapa: string,
    terminal: string,
    produto: string,
    tempo_etapa: number,
    veiculo_categoria: string,
    toJson(): Document
}

const CicloSchema = new Schema({
  chave: String,
  gmo_id: Number,
  etapa_id: Number,
  etapa: String,
  terminal: String,
  produto: String,
  tempo_etapa: Number,
  veiculo_categoria: String
})

export default model<CicloInterface>('Ciclo', CicloSchema)
