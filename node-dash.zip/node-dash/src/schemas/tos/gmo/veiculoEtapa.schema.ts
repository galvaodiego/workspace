import { Schema, model, Document } from 'mongoose'

export interface VeiculoEtapaInterface extends Document {
    etapa: string,
    valor: number,
    toJson(): Document
}

const VeiculoEtapaSchema = new Schema({
  etapa: String,
  valor: Number
})

export default model<VeiculoEtapaInterface>('VeiculoEtapa', VeiculoEtapaSchema)
