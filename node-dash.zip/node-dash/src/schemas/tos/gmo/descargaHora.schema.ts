/* eslint-disable camelcase */
/* eslint-disable @typescript-eslint/camelcase */
import { Schema, model, Document } from 'mongoose'

export interface DescargaHoraInterface extends Document {
    chave: string,
    valor: number,
    terminal: string,
    produto: string,
    veiculo_categoria: string,
    toJson(): Document
}

const DescargaHoraSchema = new Schema({
  chave: String,
  valor: Number,
  terminal: String,
  produto: String,
  veiculo_categoria: String
})

export default model<DescargaHoraInterface>('DescargaHora', DescargaHoraSchema)
