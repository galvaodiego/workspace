import { Schema, model, Document } from 'mongoose'

export interface DimensoesInterface extends Document {
    chave: string,
    valor: string,
    toJson(): Document
}

const DimensoesSchema = new Schema({
  chave: String,
  valor: String
})

export default model<DimensoesInterface>('Dimensoes', DimensoesSchema)
