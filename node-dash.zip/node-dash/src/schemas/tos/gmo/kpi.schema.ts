import { Schema, model, Document } from 'mongoose'

export interface KpiInterface extends Document {
    kpi: string,
    chave: string,
    valor: number,
    toJson(): Document
}

const KpiSchema = new Schema({
  kpi: String,
  chave: String,
  valor: Number
})

export default model<KpiInterface>('Kpi', KpiSchema)
