import { Schema, model, Document } from 'mongoose'

export interface PerformanceInterface extends Document {
  hora: string,
  realizado: number,
  toJson(): Document
}

const PerformanceSchema = new Schema({
  hora: String,
  realizado: Number
})

export default model<PerformanceInterface>('Performance', PerformanceSchema)
