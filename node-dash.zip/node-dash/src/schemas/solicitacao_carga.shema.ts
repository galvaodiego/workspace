import { Schema, model, Document } from 'mongoose'

export interface SolicitacaoCargaInterface extends Document {

   num_romaneio?:number,
   cod_remetente?: number,
   cod_destinatario?: number,
   origem_municipio_id?: number,
   destino_municipio_id?: number,
   cod_cliente?: number,
   produto_id?: number,
   operacao_id?: number,
   cancelada?: number,
   situacao_id?: number,
   situacao?: string,
   situacao_logistica_id?: number,
   situacao_logistica?: string,
   motivo_can_id?: number,
   motivo_can?: string,
   data_carregamento_inicio?: Date,
   data_carregamento_fim?: Date,
   data_entrega_incio?: Date,
   data_entraga_fim?: Date


   toJson(): Document
}

const SolicitacaoCargaSchema = new Schema({

   num_romaneio: Number,
   cod_remetente: Number,
   cod_destinatario: Number,
   origem_municipio_id: Number,
   destino_municipio_id: Number,
   cod_cliente: Number,
   produto_id: Number,
   operacao_id: Number,
   cancelada: Number,
   situacao_id: Number,
   situacao: String,
   situacao_logistica_id: Number,
   situacao_logistica: String,
   motivo_can_id: Number,
   motivo_can: String,
   data_carregamento_inicio: Date,
   data_carregamento_fim: Date,
   data_entrega_incio: Date,
   data_entraga_fim: Date,

})

export default model<SolicitacaoCargaInterface>('solic_carga', SolicitacaoCargaSchema)

