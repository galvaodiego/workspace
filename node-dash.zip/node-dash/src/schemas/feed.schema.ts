import { Schema, model, Document } from 'mongoose'

export interface  FeedInterface extends Document{
  // eslint-disable-next-line camelcase
  assunto ?: string,
  nome ?: string,
  // eslint-disable-next-line camelcase
  descricao ?: string,
  // eslint-disable-next-line camelcase
  prioridade ?: number,
  // eslint-disable-next-line camelcase
  tipo ?: number,
  // eslint-disable-next-line camelcase
  colunas ?: object,
  // eslint-disable-next-line camelcase
  counteudo ?: object,
  // eslint-disable-next-line camelcase
  date_insert ?: Date,
  // eslint-disable-next-line camelcase
  date_update ?: Date,
  toJson(): Document
}

const FeedSchema = new Schema({
  // eslint-disable-next-line @typescript-eslint/camelcase
  assunto: String,
  nome: String,
  // eslint-disable-next-line @typescript-eslint/camelcase
  descricao: String,
  // eslint-disable-next-line camelcase
  prioridade: Number,
  // eslint-disable-next-line camelcase
  tipo: Number,
  // eslint-disable-next-line camelcase
  colunas : Object,
  // eslint-disable-next-line camelcase
  counteudo : Object,
  // eslint-disable-next-line camelcase
  date_insert : Date,
  // eslint-disable-next-line camelcase
  date_update : Date,

})

export default model<FeedInterface>('Feed', FeedSchema)
