import { Schema, model, Document } from 'mongoose'

export interface UsuarioInterface extends Document{
  // eslint-disable-next-line camelcase
  socket_id ?: string,
  cliente ?: string,
  from ?: string
   // eslint-disable-next-line camelcase
  socket?: string,
  date_insert ?: Date

  toJson(): Document
}

const UsuarioSchema = new Schema({
  // eslint-disable-next-line @typescript-eslint/camelcase
  socket_id: String,
  cliente : String,
  from: String,
  socket: String,
   // eslint-disable-next-line camelcase
  date_insert : Date

})

export default model<UsuarioInterface>('usuario', UsuarioSchema)

