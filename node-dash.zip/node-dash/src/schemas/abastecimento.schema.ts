import { Schema, model, Document } from 'mongoose'

export interface AbastecimentoInterface extends Document {

  status?: string,
  cliente?: string,
  municipio: string,
  // eslint-disable-next-line camelcase
  posto: string,

  toJson(): Document
}

const AbastecimentoSchema = new Schema({
  /**
    * Colunas da tablela
   */
  status: String,
  cliente: String,
  municipio: String,
  // eslint-disable-next-line @typescript-eslint/camelcase
  posto: String

})

export default model<AbastecimentoLogInterface>('Abastecimento', AbastecimentoSchema)
