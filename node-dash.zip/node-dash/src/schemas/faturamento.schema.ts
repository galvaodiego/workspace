import { Schema, model, Document } from 'mongoose'

export interface FaturamentoInterface extends Document{
  // eslint-disable-next-line camelcase
  data_emissao ?: Date,
  placa ?: string,
  modalidade ?: string,
  // eslint-disable-next-line camelcase
  tipo_carroceria ?: string,
  cliente ?: string,
  organizacional ?: number,
  mercadoria ?: string,
  // eslint-disable-next-line camelcase
  qtd_viagens ?: number,
  subistituto ?: number,
  valor ?: number,
  meta ?: number,
  toJson(): Document
}

const FaturamentoSchema = new Schema({
  // eslint-disable-next-line @typescript-eslint/camelcase
  data_emissao: Date,
  placa: String,
  modalidade: String,
  // eslint-disable-next-line @typescript-eslint/camelcase
  tipo_carroceria: String,
  cliente: String,
  // eslint-disable-next-line @typescript-eslint/camelcase
  organizacional_id: Number,
  mercadoria: String,
  // eslint-disable-next-line @typescript-eslint/camelcase
  qtd_viagens: Number,
  subistituto: Number,
  valor: {
    type: Schema.Types.Decimal128,
    required: true
  },
  meta: {
    type: Schema.Types.Decimal128,
    required: true
  }

})

export default model<FaturamentoInterface>('Faturamento', FaturamentoSchema)

