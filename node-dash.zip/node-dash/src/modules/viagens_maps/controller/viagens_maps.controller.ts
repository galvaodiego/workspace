import { ViagensMapsPage } from '../resolvers/viagens_maps.page'
import { ViagensMapsService } from '../service/viagens_maps.service'
import { GatewayService } from '../../../services/gateway.service'

class ViagensMapsController {
  private _page = new ViagensMapsPage()
  private _service = new ViagensMapsService()
  private _gatewayService = new GatewayService()

  public async getViagensMaps (req: object, socket): Promise<void> {

    const logInicio = new Date()
    let retorno
    const exist = await this._service.exists(req.base)

    if (exist) {
      retorno = await this._page.getPage(req)
    }

    else {
      if (req.token && req.url) {//V
        retorno = await this._gatewayService.backendCall(req, 'M4002', 'getMapa')
      }
    }

    console.log('viagens_maps', req.base, 'viagens_maps:', (new Date() - logInicio) / 1000, 'segundos')

    socket.emit('viagens_maps', retorno) //mudar
  }
}

export default new ViagensMapsController()