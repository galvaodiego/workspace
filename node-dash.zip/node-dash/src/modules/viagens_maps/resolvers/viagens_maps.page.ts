/* eslint-disable no-unused-vars */
/* eslint-disable camelcase */
/* eslint-disable dot-notation */
/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable no-undef */
// pegar como vem hoje e colocar nos filtros de
// socket->controllet->page->service->model->getLowerCase
import { ReturnComponents } from '../../../componentes/return.components'
import { ViagensMapsService } from '../service/viagens_maps.service'

export class ViagensMapsPage {
  private _service = new ViagensMapsService();
  private _component = new ReturnComponents();

  public async getPage (req: object): Promise<object> {
    const sort = { valor: -1 }
    let filter: any = {}


    //  filter = Object.assign({}, req, { status: 'Destinado' })
     const viagens_maps = await this._service.findAll(req, { inicio_evento: 1 }) // verificar o campo do sort
     const resViagens_maps = await this._component.getLowerCase(viagens_maps)


    
    const obj: any = {
      result: {
        location: [
            {
              resViagens_maps
            }]}
    }

    return obj
  }
}

export default new ViagensMapsPage()
