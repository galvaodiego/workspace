/* eslint-disable camelcase */
/* eslint-disable @typescript-eslint/explicit-function-return-type */
/* eslint-disable no-self-assign */
/* eslint-disable @typescript-eslint/camelcase */

export class ViagensMapsModel {
  public group
  public match

  constructor () {
    this.initGroup()
    this.initMatch()
  }

  private initGroup () {

    const group = {
      _id: {
        grupo_negociador: '$GRUPO_NEGOCIADOR'
      },

      last_update: { $max: '$DATA_VIAGENS_MAPS' },
      total: { $sum: 1 }
    }
    this.group = group
  }

  private initMatch () {
    const match = {
      GRUPO_NEGOCIADOR: null, // vERIFICAR
     
    }
    this.match = match
  }

  public setMatch (req): void {

    this.match.GRUPO_NEGOCIADOR = req.grupo_negociador ? {$in : req.grupo_negociador}: null

    Object.keys(this.match).forEach((key) => (this.match[key] == null) && delete this.match[key])
  }

  public setGroup (group: Array<string>): void {
    const obj = JSON.parse(JSON.stringify(this.group))
    Object.keys(obj._id).forEach((key) => (!group.includes(key)) && delete obj._id[key])
    this.group = obj
  }

  public cleanGroup (): void {
    this.initGroup()
  }

  public cleanMath (): void {
    this.initMatch()
  }
}

export default new ViagensMapsModel()
