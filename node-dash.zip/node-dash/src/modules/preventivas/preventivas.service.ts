/* eslint-disable @typescript-eslint/no-explicit-any */
import mongoose, { Schema, Model } from 'mongoose'
export class PreventivasService {
  private schema: mongoose.Schema
  private dynamicSchema: Schema
  private preventivasModel: Model<any>

  constructor (base) {
    this.dynamicSchema = new Schema({}, { strict: false })
    this.initModel(base)
  }

  private initModel (base):void{
    try {
      this.preventivasModel = mongoose.model('dash_preventivas_' + base)
    } catch (error) {
      this.preventivasModel = mongoose.model('dash_preventivas_' + base, this.dynamicSchema, 'dash_preventivas_' + base)
    }
  }

  public async findAll ():Promise<any> {
    const res = await this.preventivasModel.find()
    return res
  }

  async exists (): Promise<boolean> {
    const res = await this.preventivasModel.exists()

    return res
  }
}
