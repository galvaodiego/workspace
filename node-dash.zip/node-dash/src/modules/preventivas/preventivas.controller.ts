
import { Socket } from 'socket.io'
import { PreventivasService } from './preventivas.service'
import { PreventivasPage } from './preventivas.page'
import { GatewayService } from '../../services/gateway.service'

class PreventivasController {
  public async getPreventivas (req, socket:Socket): Promise<void> {
    const _preventivasService = new PreventivasService(req.base)
    const _gatewayService = new GatewayService()
    const _preventivasPage = new PreventivasPage()
    let rsPreventivas
    let retorno
    const exist = await _preventivasService.exists()
    if (exist) {
      rsPreventivas = await _preventivasService.findAll()
      retorno = await _preventivasPage.preventivas(rsPreventivas)
    } else {
      if (req.token && req.url) {
        rsPreventivas = await _gatewayService.backendCall(req, 'M4002', 'getVeiculoPreventiva')
        retorno = rsPreventivas
      }
    }

    // const rsPreventivas = await _preventivasService.findAll()

    // const retorno = await _preventivasPage.preventivas(rsPreventivas)

    socket.emit('preventivas', retorno)
  }
}
export default new PreventivasController()
