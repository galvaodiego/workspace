/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/camelcase */
// eslint-disable-file no-use-before-define

export class PreventivasPage {
  public async preventivas (rsPreventivas): Promise<object> {
    const preventivas = [
      {
        agrupamento: 'CAVALO MECÂNICO',
        agrupamento_id: 1,
        filtro_agrupamento: -1,
        veiculo_preventiva: []
      },
      {
        agrupamento: 'SEMI REBOQUE',
        agrupamento_id: 2,
        filtro_agrupamento: -1,
        veiculo_preventiva: []
      }
    ]

    for (const p in rsPreventivas) {
      const preventiva = JSON.parse(JSON.stringify(rsPreventivas[p]))
      if (preventiva.AGRUPAMENTO.toLowerCase().includes('cavalo')) {
        preventivas[0].veiculo_preventiva.push({
          placa: preventiva.PLACA,
          km_previsao: preventiva.KM_PREVISAO,
          filtro_agrupamento: preventiva.FILTRO_AGRUPAMENTO,
          alerta_km: preventiva.ALERTA_KM,
          km_atual_veiculo: preventiva.KM_ATUAL_VEICULO,
          tabela: preventiva.TABELA,
          status_id: preventiva.STATUS_ID
        })
      } else {
        preventivas[1].veiculo_preventiva.push({
          placa: preventiva.PLACA,
          km_previsao: preventiva.KM_PREVISAO,
          filtro_agrupamento: preventiva.FILTRO_AGRUPAMENTO,
          alerta_km: preventiva.ALERTA_KM,
          km_atual_veiculo: preventiva.KM_ATUAL_VEICULO,
          tabela: preventiva.TABELA,
          status_id: preventiva.STATUS_ID
        })
      }
    }

    return { preventivas: preventivas }
  }
}
