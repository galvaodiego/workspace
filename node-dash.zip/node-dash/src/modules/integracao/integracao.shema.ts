import { Schema, model, Document } from 'mongoose'

export interface IntegracaoInterface extends Document {

  TE_DOC_INT?: number,
  NUM_DOCTO?: number,
  AUTOMATIZADO?: number,
  INTEGRADO?: number,
  NR_DIA_MES?: number,
  MES_ANO?: string,
  DIA_MES?: string,
  CLIENTE?: string,
  FLAG_EMB?: number

  toJson(): Document
}

const IntegracaoSchema = new Schema({
  /**
    * Colunas da tablela
   */

  TE_DOC_INT: Number,
  NUM_DOCTO: Number,
  AUTOMATIZADO: Number,
  INTEGRADO: Number,
  NR_DIA_MES: Number,
  MES_ANO: String,
  DIA_MES: String,
  CLIENTE: String,
  FLAG_EMB: Number

})

export default model<IntegracaoInterface>('integracao', IntegracaoSchema)
