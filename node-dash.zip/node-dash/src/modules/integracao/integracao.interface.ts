
export interface GroupIntegracaoIdInterface {
  cancelada?: any,

}
export interface MatchIntegracaoInterface {
  SEGMENTO?: any

  ORIGEM: object;
  FLAG_EMB?: object
  DATA?: object
  CANCELADA?: object
  NR_MES?: object
  NR_ANO?: object
  NR_DIA_MES?: object
  NR_HORA?: object
  LAST_DIAS?: object
  TE_DOC_INT?: object
  NUMERO_NOTA?: object
  AUTOMATIZADO?: object
  EXCLUIDO?: object
  DOC_SUBSTITUTO?: object
  TIPO_CONHECIMENTO_ID?: object

}
export interface GroupIntegracaoInterface {
  _id: GroupIntegracaoIdInterface
  qtde?: object
  total?: object
  media?: object
  valor?: object

}

export interface RequestIntegracaoInterface {
  hora: number
  origem: any
  cancelada?: number
  periodo?: string
  flag_emb: number
  dias: number
  segmento: any
  automatizado: number
  doc_substituto: number
  tempo: number

}
