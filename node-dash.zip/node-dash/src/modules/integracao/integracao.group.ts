/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable camelcase */
import {
  MatchIntegracaoInterface,
  GroupIntegracaoInterface,
  RequestIntegracaoInterface
} from '../integracao/integracao.interface'

export class GroupIntegracao {

  public group: GroupIntegracaoInterface
  public match: MatchIntegracaoInterface

  constructor () {
    this.initGroup()
    this.initMatch()
  }

  public initGroup (): void {
    const group = {} as GroupIntegracaoInterface
    group._id = {}
    this.group = group
  }

  public setGroup (req: RequestIntegracaoInterface, group: Array<any>): void {
    /**
     * Foreach para casos de agrupar por mais de um atributo
     * Ex: situacao por cliente, produto por cliente e etc
     */
    group.forEach((x, index) => {
      switch (x) {

        case 'qtde':
          this.group.qtde = { $sum: 1 }
          break


        case 'media':
          this.group.valor = { $avg: '$TE_DOC_INT' }
          break

        case 'chave':
          Object.assign(this.group._id, { chave: '$CHAVE' })
          break

        case 'faturamento':
          this.group.total = { $sum: '$VL_FATURADO' }
          break

        case 'cliente':
          Object.assign(this.group._id, { chave: '$CLIENTE' })
          break

        case 'produto':
          Object.assign(this.group._id, { chave: '$PRODUTO' })
          break

        case 'segmento':
          Object.assign(this.group._id, { chave: '$SEGMENTO' })
          break

        case 'ccg':
          Object.assign(this.group._id, { chave: '$ORGANIZACIONAL' })
          break

        case 'num_docto':
          Object.assign(this.group._id, { chave: '$NUM_DOCTO' })
          break

        case 'solic_carga':
          Object.assign(this.group._id, { chave: '$SOLICITACAO_CARGA_ID' })
          break

        case 'grupo_produto':
          Object.assign(this.group._id, { chave: '$GRUPO_PRODUTO' })
          break

        case 'grupo_negociador':
          Object.assign(this.group._id, { chave: '$GRUPO_NEGOCIADOR' })
          break


        case 'cancelada':
          Object.assign(this.group._id, { cancelado: '$CANCELADA' })
          break

        case 'data':
          Object.assign(this.group._id, { data: '$DATA' })
          break

        case 'hora':
          Object.assign(this.group._id, { hora: '$NR_HORA' })
          break

        case 'dia':
          Object.assign(this.group._id, { data: '$NR_DIA_MES' })
          break

        case 'dia_mes':
          Object.assign(this.group._id, { chave: '$DIA_MES' })
          break

        case 'mes':
          Object.assign(this.group._id, { data: '$NM_MES' })
          break

        case 'mes_ano':
          Object.assign(this.group._id, { data: '$MES_ANO' })
          break

        case 'last_update':
          this.group.valor = { $max: '$DATA_CARGA' }
          break

        case 'last_data_emissao' :
          this.group.valor = { $max: '$DATA_EMISSAO_DOC' }
          break

        default:
          break
      }

    });

    this.prepareQuery()
  }


  public cleanGroup (): void {
    this.initGroup()
  }

  private initMatch (): void {
    const match = {} as MatchIntegracaoInterface
    match.CANCELADA = null
    match.DATA = null
    match.NR_HORA = null
    match.NR_DIA_MES = null
    match.NR_ANO = null
    match.NR_MES = null
    match.FLAG_EMB = null
    match.LAST_DIAS = null
    match.TE_DOC_INT = null
    match.SEGMENTO = null
    match.NUMERO_NOTA = null
    match.AUTOMATIZADO = null
    match.EXCLUIDO = null
    match.TIPO_CONHECIMENTO_ID = null
    this.match = match
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public getReturn (ret: Array<any>): Array<any> {

    ret.forEach((element, index) => {
      if (element._id) {
        Object.assign(element, element._id)
        delete element._id
      }
    })
    // se tiver mais de um atributo significa agrupamento por mais de um campo
    let n_key = ret[0] && Object.keys(ret[0]).length

    if (ret && ret.length > 0 && n_key < 2) {
      /**
       * É PRECISO TRATAR AQUI CADA ACUMULADOR
       */
      if (ret[0] && ret[0].qtde) {
        return ret[0].qtde


      }
      if (ret[0] && ret[0].chave) {
        return ret[0].chave
      }
    }
    return ret
  }

  public getReturnMediana (ret: Array<any>): Array<any> {

    ret.forEach((element, index) => {
      if (element._id) {
        Object.assign(element, element.id)
        delete element.id
      }
    })
    return ret
  }


  public setMatchIntegracao (req: RequestIntegracaoInterface): void {

    const data = new Date(new Date().valueOf() - new Date().getTimezoneOffset() - (60 * 60000 * 3))
    const ano = data.getFullYear()
    const mes = data.getMonth() + 1
    const dia = data.getUTCDate()
    const semana = data.getDay()


    //const semana =  Week

    let nr_mes = null;
    let nr_dia = null;
    let nr_ano = null;
    let nr_semana = null;


    switch (req.periodo) {
      case 'diario':
        nr_ano = ano
        nr_mes = mes
        nr_dia = dia
        break

      case 'semanal':
        nr_ano = ano
        nr_semana = semana;
        break

      case 'mensal':
        // new Date(mesFim.setHours(0, 0, 0, 0) - (60 * 60000 * 3))
        nr_ano = ano
        nr_mes = mes


        break

      case 'anual':
        nr_ano = ano
        break;

      default:
        nr_ano = ano
        nr_mes = mes
        nr_dia = dia

    }

    this.match = {} as MatchIntegracaoInterface

    // this.match.DATA = req.data_inicio_emissao ? { $gte: dataInicial, $lt: dataFinal } : null
    this.match.CANCELADA = req.cancelada != null ? { $eq: req.cancelada } : null

    this.match.FLAG_EMB = req.flag_emb != null ? { $eq: req.flag_emb } : null
    this.match.NR_HORA = req.hora ? { $eq: req.hora } : null
    // eslint-disable-next-line @typescript-eslint/camelcase
    this.match.NR_MES = nr_mes ? { $eq: nr_mes } : null
    // eslint-disable-next-line @typescript-eslint/camelcase
    this.match.NR_DIA_MES = nr_dia ? { $eq: nr_dia } : null
    // eslint-disable-next-line @typescript-eslint/camelcase
    this.match.NR_ANO = nr_ano ? { $eq: nr_ano } : null
    this.match.SEGMENTO = { $ne: 'TERCEIROS E AGREGADOS' } // req.segmento != null ? { $eq: 'SÓLIDO' } : { $eq: 'SÓLIDO' }
    this.match.EXCLUIDO = { $eq: 0 }
    this.match.AUTOMATIZADO = req.automatizado ? { $ne: null } : null

    // retira as linhas que possuem 0
    this.match.TE_DOC_INT = { $ne: 0 }
    // pega apegas com numero de nota
    this.match.NUMERO_NOTA = { $ne: null }
    this.match.DOC_SUBSTITUTO = req.doc_substituto ? { $eq: req.doc_substituto } : { $eq: 0 }
    this.match.TIPO_CONHECIMENTO_ID = { $eq: 1 } // CONHECIMENTO NORMAl

    // console.log(this.match)

    // if (req.periodo == 'mensal') {
    //     this.match.NR_DIA_MES = req.dias != null ? { $gte: nr_dia } : null
    // }
    if (req.periodo === 'diario' && !!req.dias) {
      // eslint-disable-next-line prefer-const
      let inicio = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getUTCDate() - req.dias)
      // eslint-disable-next-line prefer-const
      let fim = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getUTCDate() + 1)

      // para rodar local
      let ii = new Date(inicio.setHours(0, 0, 0, 0) - (60 * 60000 * 3))
      let ff = new Date(fim.setHours(0, 0, 0, 0) - (60 * 60000 * 3))
      // this.match.DATA = req.dias ? { $gte: ii, $lt: ff } : null

      this.match.DATA = req.dias ? { $gte: inicio, $lt: fim } : null
      this.match.NR_ANO = null
      this.match.NR_MES = null
      this.match.NR_DIA_MES = null
    }

    this.prepareQuery()
  }

  public prepareQuery (): void {
    Object.keys(this.group._id).forEach((key) => (this.group._id[key] == null) && delete this.group._id[key])
    Object.keys(this.match).forEach((key) => (this.match[key] == null) && delete this.match[key])
  }

  private renameObjectKey (oldObj, oldName, newName, i) {
    const newObj = {}

    Object.keys(oldObj).forEach(key => {


      const value = oldObj[key]
      if (key === oldName) {
        newObj[newName] = value
      } else {
        newObj[key] = value
      }
    });


    return newObj
  }
}

export default GroupIntegracao
