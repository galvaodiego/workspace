
import Integracao, { IntegracaoInterface } from './integracao.shema'
import GroupIntegracao from '../integracao/integracao.group'

import mongoose from 'mongoose'

export class IntegracaoService {

  private integracaoGroup = new GroupIntegracao();


  async aggregate(params, agrupador, sort, limit?): Promise<IntegracaoInterface[]> {
    let result = null;
    let n = limit ? limit : 10000000
    let res = null;
    this.integracaoGroup.setGroup(params.req, agrupador);

    // console.log();
    // console.log('PARAMS', params);
    // console.log('Sort',);

    const bd = mongoose.model('integracao', Integracao.schema, 'st_integracao_' + params.req.base)
    result = await bd.aggregate([{ $match: params.match }, { $group: this.integracaoGroup.group }]).sort(sort).limit(n),
      ((err) => {
        if (err) {
          return []
        }
        console.log('ErrorAgg');
      });

    // console.log(result);

    this.integracaoGroup.cleanGroup()

    return this.integracaoGroup.getReturn(result)

  }

  async findAll (params, sort, select?, limit?, old_column?, new_column?): Promise<IntegracaoInterface[]> {
    let result = null;

    // console.log();
    // console.log(params);

    let campos = select ? select : 'NUM_DOCTO CLIENTE TE_DOC_INT'
    let old_campos = old_column ? old_column : ['NUM_DOCTO', 'TE_DOC_INT']
    let new_campos = new_column ? new_column : ['documento', 'tempo']

    let n = limit ? limit : 10000


    const bd = mongoose.model('integracao', Integracao.schema, 'st_integracao_' + params.req.base)
    result = await bd.find(params['match']).select('roll ' + campos).sort(sort).limit(n)
      , ((err) => {
        if (err) {
          return []
        }
        console.log('ErrorFind');
      });

    return this.integracaoGroup.getReturn(result)
  }

  async aggregate2 (params, agrupador, campo, sort, limit?): Promise<IntegracaoInterface[]> {

    // console.log();
    // console.log(params)

    let result = null;
    let n = limit ? limit : 10000000
    let s = { _id: { sort } }

    // console.log(params.match, agrupador[0], campo)
    // console.log()
    // console.log(params)

    // console.log('agg', agrupador[0])
    // console.log('campo', campo)

    /**
     * Caso seja par, pega dois numero ,Ex: 232/2 = 116, res in (116+117)
     * Se não pega valor do meio =  Ex: 169/2 = 84.5, res = 85
     */
    const bd = mongoose.model('integracao', Integracao.schema, 'st_integracao_' + params.req.base)
    result = await bd.aggregate(
      [
        { $match: params.match },
        {
          $group: {
            _id: agrupador[0],
            count: { $sum: 1 },
            values: { $push: campo }
          }
        },
        {
          $unwind: {
            path: '$values',
            includeArrayIndex: 'number',
            preserveNullAndEmptyArrays: true
          }
        },
        {
          $sort: {
            values: 1
          }
        },
        {
          $project: {

            "count": 1,
            "values": 1,
            "midpoint": {
              $divide: [
                "$count",
                2
              ]
            }
          }
        },
        {
          $project: {
            "count": 1,
            "values": 1,
            "midpoint": 1,
            "impar": {
              $mod: ['$count', 2]
            },
            "high": {
              $ceil: "$midpoint"
            },
            "low": {
              $floor: '$midpoint'
            }
          }
        },
        {
          $group: {
            _id: '$_id',
            values: {
              $push: "$values"
            },
            high: {
              $avg: "$high"
            },

            low: {
              $avg: "$low"
            },
            impar: {
              $avg: "$impar"
            },
            count: {
              $max: "$count"
            }
          }
        },
        {
          $project: {
            "count": 1,
            "values": 1,
            "midpoint": 1,
            "impar": 1,
            //'low': 1,
            'low': {
              $subtract: ["$low", {
                $cond: {
                  if: ["$impar", 1],
                  then: 0, else: 1
                }
              }]
            },
            "high": {
              $subtract: ["$high", 1]
            }
          }
        },
        {
          $project: {
            "beginValue": {
              "$arrayElemAt": ["$values", "$high"]
            },
            "endValue": {
              "$arrayElemAt": ['$values', "$low"]
            },
            "count": 1
          }
        }, {
          $project: {
            // chave: "$_id.chave",
            //  data: "$_id.data",

            valor: {
              $avg: ["$beginValue", "$endValue"]
            },
            qtde: "$count",
            // _id: 0

          }
        }
      ]).sort(sort).limit(n),
      ((err) => {
        console.log('ErrorMed');

        if (err) {
          return []
        }
      });



    return this.integracaoGroup.getReturn(result)

  }
}