/* eslint-disable prefer-const */
/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable camelcase */
import { IntegracaoService } from './integracao.service'
import GroupIntegracao from '../integracao/integracao.group'
import { Socket } from 'socket.io'

class FluxoLogisticoController {

  private _integracaoService = new IntegracaoService()
  private _groupIntegracao = new GroupIntegracao()

  public async getFluxoLogistico (req: object, socket: Socket): Promise<object> {

    const cliente = req.base
    const periodo = req.periodo
    const copy = { ...req }

    const sort = { valor: -1 }
    
    const retorno: any = {
      graficos: {
        percentualAutomatizado: [{ chave: 'Automatizado', valor: 80 }, { chave: 'Manual', valor: 20 }],
        tempoMedioQuantidade: [],
        tempoMedioUltimosDias: [],
        tempoMedioG10UltimosDias: [],
        // [{ chave: '28/01', valor: 84 },
        // { chave: '29/01', valor: 69 },
        // { chave: '30/01', valor: 85 }],
        automatizacaoUltimosDias: [],
        // [{ chave: '29/01', valor: 77 },
        // { chave: '30/01', valor: 96 },
        // { chave: '31/01', valor: 81 },
        // ],
        tempoMedioCCG: [] // SEGMENTO
        // [{ chave: '22/01', valor: 80 }, // percentual
        // { chave: '23/01', valor: 70 }, // percentual
        // { chave: '24/01', valor: 85 }], // percentual
      },
      indicadores: { tempoMedioHora: null, tempoMedioHoje: null, tempoMedioUltimosDias: null },
      listas: { tempoEmissaoCTE: [], tempoMedioCliente: [], percentualAutomatizado: [] },
      atualizacao: null,
      val: []
      // temp: []

    }

    const logInicio = new Date()

    let res = null
    // let tempoMediaSolic: any = []
    let temp = [] // Variavel auxiliar
    let n = 0

    /**
     * GRÁFICOS
     */
    req = { base: cliente, periodo: 'diario', cancelada: 0, dias: 2 }
    this._groupIntegracao.setMatchIntegracao(req)
    res = await this._integracaoService.aggregate2({ match: this._groupIntegracao.match, req: req }, [{ chave: '$DIA_MES', data: '$NR_DIA_MES' }], '$TE_DOC_INT', { _id: { NR_DIA_MES: 1 } })
    retorno.graficos.tempoMedioUltimosDias = res


    req = { base: cliente, periodo: 'diario', cancelada: 0, flag_emb: 1, dias: 2 }
    this._groupIntegracao.setMatchIntegracao(req)
    res = await this._integracaoService.aggregate2({ match: this._groupIntegracao.match, req: req }, [{ chave: '$DIA_MES', data: '$NR_DIA_MES' }], '$TE_DOC_INT', { data: -1 })
    retorno.graficos.tempoMedioG10UltimosDias = res

    req = { base: cliente, periodo: 'diario', cancelada: 0, flag_emb: 1, dias: 2 } // sem segmento
    this._groupIntegracao.setMatchIntegracao(req)
    res = await this._integracaoService.findAll({ match: this._groupIntegracao.match, req: req }, { NR_DIA_MES: 1 }, ['CLIENTE FLAG_EMB AUTOMATIZADO INTEGRADO NR_DIA_MES DIA_MES'], 1000)
    retorno.graficos.automatizacaoUltimosDias = await this.automatizadoG10(res, 3)
    // retorno.retorno = res

    req = { base: cliente, periodo: 'mensal', cancelada: 0 }
    this._groupIntegracao.setMatchIntegracao(req)
    res = await this._integracaoService.aggregate2({ match: this._groupIntegracao.match, req: req }, [{ chave: '$SEGMENTO' }], '$TE_DOC_INT', sort)
    retorno.graficos.tempoMedioCCG = res

    /**
     * FIM GRAFICOS
     */

    //   /**
    //    * INDICADORES
    //    *  Agrupados por solicitacao de carga porque 1 documento pode ter varias cargas consolidadas mas apenas 1 solic carga
    //    * Media da Média, se uma solicitacoa de carga possuir dois tempos diferente, faz a media desse tempo, pra depois fazer a media geral
    //    */

    //   /**
    //    * Tempo médio do periodo diario
    //    */
    req = { base: cliente, periodo: periodo, cancelada: 0 }
    this._groupIntegracao.setMatchIntegracao(req)
    res = await this._integracaoService.aggregate2({ match: this._groupIntegracao.match, req: req }, [{ chave: '$DIA_MES' }], '$TE_DOC_INT', sort)
    retorno.indicadores.tempoMedioHoje = res && res.length > 0 ? res[0].valor : 0

    req = { base: cliente, periodo: periodo, cancelada: 0 }
    this._groupIntegracao.setMatchIntegracao(req)
    res = await this._integracaoService.aggregate2({ match: this._groupIntegracao.match, req: req }, [{ chave: '$NUM_DOCTO' }], '$TE_DOC_INT', sort)
    temp = res
    retorno.graficos.tempoMedioQuantidade = await this.qdteTempoMedio(temp)

    /**
     * Tempo médio da ultima hora
     */

    // eslint-disable-next-line prefer-const
    let ultima_hora = new Date().getUTCHours() - 4

    req = { base: cliente, periodo: periodo, cancelada: 0, hora: ultima_hora }
    this._groupIntegracao.setMatchIntegracao(req)
    res = await this._integracaoService.aggregate2({ match: this._groupIntegracao.match, req: req }, [{ chave: '$DIA_MES', hora: '$NR_HORA' }], '$TE_DOC_INT', sort)
    retorno.indicadores.tempoMedioHora = res && res.length > 0 ? res[0].valor : 0

    /**
     * Tempo médio das ultimos 3 dias
     */
    req = { base: cliente, periodo: 'diario', cancelada: 0, dias: 2 }
    this._groupIntegracao.setMatchIntegracao(req)
    res = await this._integracaoService.aggregate2({ match: this._groupIntegracao.match, req: req }, [null], '$TE_DOC_INT', sort)
    retorno.indicadores.tempoMedioUltimosDias = res && res.length > 0 ? res[0].valor : 0

    /**
     * FIM INDICADORES
     */

    /*
    * LISTAS
   */
    req = { base: cliente, periodo: periodo, cancelada: 0 }
    this._groupIntegracao.setMatchIntegracao(req)
    res = await this._integracaoService.aggregate2({ match: this._groupIntegracao.match, req: req }, [{ chave: '$NUM_DOCTO', cliente: '$GRUPO_NEGOCIADOR' }], '$TE_DOC_INT', sort, 10)
    retorno.listas.tempoEmissaoCTE = res

    /**
     * Tempo Medio X Cliente (Mensal)
     */
    req = { base: cliente, periodo: 'mensal', cancelada: 0 }
    this._groupIntegracao.setMatchIntegracao(req)
    res = await this._integracaoService.aggregate2({ match: this._groupIntegracao.match, req: req }, [{ chave: '$GRUPO_NEGOCIADOR' }], '$TE_DOC_INT', sort)
    temp = res

    // Para pegar quantidade total de docs
    req = { base: cliente, periodo: 'mensal', cancelada: 0 }
    this._groupIntegracao.setMatchIntegracao(req)
    res = await this._integracaoService.aggregate2({ match: this._groupIntegracao.match, req: req }, [null], '$TE_DOC_INT', sort)
    // retorno.temp = res
    n = res && res.length > 0 ? res[0].qtde : []

    if (n > 0) {
      retorno.listas.tempoMedioCliente = await this.porcent(temp, n)
    }

    /**
     * Fim Tempo Medio X CLiente (mensal)
     */

    req = { base: cliente, periodo: periodo, cancelada: 0, flag_emb: 1, segmento: 0 }
    this._groupIntegracao.setMatchIntegracao(req)
    res = await this._integracaoService.findAll({ match: this._groupIntegracao.match, req: req }, sort, ['CLIENTE FLAG_EMB AUTOMATIZADO INTEGRADO NR_DIA_MES DIA_MES'])
    retorno.listas.percentualAutomatizado = await this.automatizadoG10(res, 1)

    const dataEmissao = await this._integracaoService.aggregate({ match: {}, req: req }, ['last_data_emissao'], sort)

    req = { base: cliente, periodo: periodo, cancelada: 0 }
    this._groupIntegracao.setMatchIntegracao(req)
    const docts = await this._integracaoService.aggregate({ match: this._groupIntegracao.match, req: req }, ['qtde'], sort)

    retorno.val = { ultima_data_emissao: dataEmissao && dataEmissao.length > 0 ? dataEmissao[0]['valor'] : 0, qtde_docs: docts }

    res = await this._integracaoService.aggregate({ match: {}, req: req }, ['last_update'], sort)
    retorno.atualizacao = res

    console.log('base', req.base, 'Fluxo Logistico:', (new Date() - logInicio) / 1000, 'segundos')
    socket.emit('fluxo_logistico', retorno)
  }

  /**
   * Qquantidade por tempo médio
   *  > 1 hora = 3600 s
   *  > 30 min = 1800 s
   * > 10 min = 600 s
   * < 10 min = < 600s
   */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private async qdteTempoMedio (lista: Array<any>): any {

    let uma_hr: any = 0
    let trinta_min: any = 0
    let dez_min: any = 0
    let menor_dez: any = 0
    let obj: any = []

    lista.forEach(x => {
      if (x.valor >= 3600) {
        uma_hr += 1;
      }
      if (x.valor >= 1800 && x.valor < 3600) {
        trinta_min += 1;
      }
      if (x.valor >= 600 && x.valor < 1800) {
        dez_min += 1;

      } if (x.valor < 600) {
        menor_dez += 1;

      }
    })

    obj = [{ chave: '< 10 min', valor: menor_dez },
      { chave: '> 10 min', valor: dez_min },
      { chave: '> 30 min', valor: trinta_min },
      { chave: '> 1 hora', valor: uma_hr }]

    return obj
  }

  /**
   * @param lista: Array para contagem de automatizado ou não
   * @param dias: Numeoro que se refere, se o retorno vai se um array com data ou sem data (0,1) 
   */
  private async automatizadoG10 (lista: Array<any>, dias?: number): any {

    const obj = []
    let distinct = []
    let dia_mes: any = ''
    // let size: any = lista ? lista.length : 0
    let auto: any = 0
    let integrado: any = 0
    let cliente: any = ''

    /**
     * FIltro para pegar apenas uma data de cada do array
     */
    lista.filter(x => {
      let t = distinct.map(t => t.dia).find(p => p === x.NR_DIA_MES)
      if (!t) {
        distinct.push({ dia: x.NR_DIA_MES, dia_mes: x.DIA_MES })
      }
    })

    let n = distinct ? distinct.length : 0

    for (let _i = 0; _i < n; _i++) {

      lista.forEach(l => {
        if (l.AUTOMATIZADO == 1 && l.NR_DIA_MES == distinct[_i].dia && l.FLAG_EMB == 1) {
          auto += 1
        }

        if (l.INTEGRADO == 1 && l.NR_DIA_MES == distinct[_i].dia && l.FLAG_EMB == 1) {
          integrado += 1
        }

        if (l.NR_DIA_MES == distinct[_i].dia) {
          dia_mes = l.DIA_MES // apenas para pegar data correta
          cliente = l.CLIENTE != null ? l.CLIENTE : 'INDEFINIDO'
        }
      })

      let automatizado = auto ? ((auto / integrado) * 100).toFixed(0) : 0
      obj.push({ chave: dia_mes, valor: Number(automatizado), cliente: cliente, inte: integrado, auto: auto })

      auto = 0
      integrado = 0
    }
    // console.log(obj)

    return obj
  }
  /**
   *  Clientes que possuem mais que 10 do numero do documentos do mês
   */
  // eslint-disable-next-line lines-between-class-members
  private async porcent (lista: Array<any>, n: number): any {

    // Número de clientes
    let cliente: any = lista ? lista.length : 0;

    // console.log('nº cliente: ', cliente);
    // console.log('Total docs:', n);

    // 25% da (qtde de documentos / número de cliente)
    let valor: number = n / cliente

    // console.log('VALOR: ', valor)

    let porcent: any = valor ? ((valor * 25) / 100).toFixed(0) : 0

    let obj = lista.filter(x => {

      if (x.qtde >= porcent) {
        return x
      }
    })

    return obj.slice(0, 10)
  }

}

export default new FluxoLogisticoController()
