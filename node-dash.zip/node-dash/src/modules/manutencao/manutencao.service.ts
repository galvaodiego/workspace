/* eslint-disable @typescript-eslint/no-explicit-any */
import mongoose, { Schema, Model } from 'mongoose'
export class ManutencaoService {
  private schema: mongoose.Schema
  private dynamicSchema: Schema
  private manutencaoModel: Model<any>

  constructor (base) {
    this.dynamicSchema = new Schema({}, { strict: false })
    this.initModel(base)
  }

  private initModel (base):void{
    try {
      this.manutencaoModel = mongoose.model('dash_manutencao_' + base)
    } catch (error) {
      this.manutencaoModel = mongoose.model('dash_manutencao_' + base, this.dynamicSchema, 'dash_manutencao_' + base)
    }
  }

  public async findIndicadores (ccg):Promise<any> {
    const res = await this.manutencaoModel.find({ MONGO_AGG: 'indicador', CCG: ccg })
    return res
  }

  public async findTop10Veiculos (ccg):Promise<any> {
    const find = ccg == 'geral_agg' ? { MONGO_AGG: 'top_10_veiculos' } : { MONGO_AGG: 'top_10_veiculos', CCG: ccg }
    const res = await this.manutencaoModel.find(find)
    return res
  }

  public async findTopVeiculos (ccg):Promise<any> {
    const find = ccg == 'geral_agg' ? { MONGO_AGG: 'top_10_veiculos' } : { MONGO_AGG: 'top_10_veiculos', CCG: ccg }
    const res = await this.manutencaoModel.find(find).limit(10)
    return res
  }

  public async findOsAbertaPorMarca (ccg):Promise<any> {
    const res = await this.manutencaoModel.find({ MONGO_AGG: 'qtde_os_aberta_marca', CCG: ccg })
    return res
  }

  public async findOsAbertaPorMarcaTracao (ccg):Promise<any> {
    const res = await this.manutencaoModel.find({ MONGO_AGG: 'marca_tracao', CCG: ccg })
    return res
  }

  public async findOsAbertaPorPlaca (ccg):Promise<any> {
    const find = ccg == 'geral_agg' ? { MONGO_AGG: 'qtde_os_aberta_placa' } : { MONGO_AGG: 'qtde_os_aberta_placa', CCG: ccg }
    const res = await this.manutencaoModel.find(find)
    return res
  }

  public async findTop10Legenda ():Promise<any> {
    const res = await this.manutencaoModel.find({ MONGO_AGG: 'legenda_top10_placa' })
    return res
  }

  public async findCcgs ():Promise<any> {
    const res = await this.manutencaoModel.find({ MONGO_AGG: 'ccgs' })
    return res
  }

  public async findOsAbertaTipo (ccg):Promise<any> {
    const res = await this.manutencaoModel.find({ MONGO_AGG: 'qtde_os_aberta_tipo', CCG: ccg })
    return res
  }

  public async findKpis (ccg):Promise<any> {
    
    const res = await this.manutencaoModel.find({ MONGO_AGG: 'kpi', CCG: ccg})
    return res
  }
}
