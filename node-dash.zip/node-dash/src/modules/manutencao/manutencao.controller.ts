
import { Socket } from 'socket.io'
import { ManutencaoService } from './manutencao.service'
import { ManutencaoPage } from './manutencao.page'

class ManutencaoController {
  public async getManutencao (req, socket:Socket): Promise<void> {
    const _manutencaoService = new ManutencaoService(req.base)
    const _manutecaoPage = new ManutencaoPage()
    const ccg = req.ccg != null ? req.ccg : 'geral_agg'
    const rsIndicadores = await _manutencaoService.findIndicadores(ccg)
    const rsTop10Veiculos = await _manutencaoService.findTop10Veiculos(ccg)
    const rsOsPorMarca = await _manutencaoService.findOsAbertaPorMarca(ccg)
    const rsOsMarcaTracao = await _manutencaoService.findOsAbertaPorMarcaTracao(ccg)
    const rsOsPorPlaca = await _manutencaoService.findOsAbertaPorPlaca(ccg)
    const rsTop10Legenda = await _manutencaoService.findTop10Legenda()
    const rsOsPorTipo = await _manutencaoService.findOsAbertaTipo(ccg)
    const rsCcgs = await _manutencaoService.findCcgs()
    const rsTopVeiculos = await _manutencaoService.findTopVeiculos(ccg)
    const rsKpis = await _manutencaoService.findKpis(ccg)

    const retorno = await _manutecaoPage.manutencao(rsIndicadores, rsTop10Veiculos, rsOsPorMarca, rsOsPorPlaca, rsTop10Legenda, rsOsPorTipo, rsCcgs, rsTopVeiculos, rsKpis, rsOsMarcaTracao)

    socket.emit('manutencao', retorno)
  }
}
export default new ManutencaoController()
