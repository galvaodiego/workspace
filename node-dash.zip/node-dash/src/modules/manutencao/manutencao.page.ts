/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/camelcase */
// eslint-disable-file no-use-before-define

export class ManutencaoPage {
  public async manutencao (rsIndicadores, rsTop10Veiculos, rsOsPorMarca, rsOsPorPlaca, rsTop10Legenda, rsOsPorTipo, rsCcgs, rsTopVeiculos, rsKpis, rsOsMarcaTracao): Promise<object> {
    const indicadores:any = {}
    const listaTop10 = []
    const graficoVeiculo = []
    const listaMarca = []
    const listaVeiculo = []
    const listaTipo = []
    const listaCcg = []
    const listKpi = []
    const legenda = []
    const cores = ['#1db2f5', '#f5564a', '#97c95c', '#ffc720', '#eb3573', '#A63DB8', '#FA9B0C', '#1E24C0', '#5EFADE', '#93A5A1']
    const val = []
    const leg = []

    const kpi:any = {
      veiculos:{
        descricao: 'Veiculos com manutenção vencida',
        tracao: 0,
        carreta: 0
      },
      os_preventiva:{
        descricao: 'Ordem de Serviço Preventiva',
        interno: 0,
        externo: 0,
        total: 0
      },
      os_pneu:{
        descricao: 'Ordem de Serviço Pneus',
        interno: 0,
        externo: 0,
        total: 0
      },
      os_corretiva:{
        descricao: 'Ordem de Serviço Corretiva',
        interno: 0,
        externo: 0,
        total: 0
      },
      os_rastreador:{
        descricao: 'Ordem de Serviço Rastreador',
        interno: 0,
        externo: 0,
        total: 0
      },
      os_socorro:{
        descricao: 'Ordem de Serviço Socorro',
        interno: 0,
        externo: 0,
        total: 0
      },
      totalizador:{
        descricao: 'Totalizador de Ordem de Serviço',
        interno: 0,
        externo: 0,
        total: 0
      }
    }
    
    for (const p in rsIndicadores) {
      const indicador = JSON.parse(JSON.stringify(rsIndicadores[p]))
      indicadores.qtde_os_aberta = indicador.QTDE_OS_ABERTA
      indicadores.qtde_veiculo_os_aberta = indicador.QTDE_VEICULO_OS_ABERTA
      indicadores.qtde_itens_os_aberta = indicador.QTDE_ITENS_OS_ABERTA
      indicadores.disponibilidade = indicador.DISPONIBILIDADE
    }

    for (const p in rsTop10Veiculos) {
      const veiculo = JSON.parse(JSON.stringify(rsTop10Veiculos[p]))
      listaTop10.push({
        placa: veiculo.PLACA,
        tempo: veiculo.TEMPO_FORMATADO,
        tipo: veiculo.TIPO

      })
    }

    for (const p in rsTopVeiculos) {
      const veiculo = JSON.parse(JSON.stringify(rsTopVeiculos[p]))
      graficoVeiculo.push({
        placa: veiculo.PLACA,
        tempo: veiculo.TEMPO_FORMATADO,
        tipo: veiculo.TIPO

      })
    }

    for (const p in rsTop10Legenda) {
      const l = JSON.parse(JSON.stringify(rsTop10Legenda[p]))
      legenda.push({
        tipo: l.TIPO,
        legenda: l.LEGENDA,
        cor: l.COR

      })
    }

    for (const p in rsCcgs) {
      const l = JSON.parse(JSON.stringify(rsCcgs[p]))
      listaCcg.push({
        ccg: l.CCG
      })
    }

    for (const p in rsKpis) {
      const l = JSON.parse(JSON.stringify(rsKpis[p]))
      listKpi.push({
        tipo: l.TIPO,
        qtd_os: l.QTDE_OS_ABERTA,
        qtd_interna: l.QTDE_OS_ABERTA_INTERNO,
        qtd_externa: l.QTDE_OS_ABERTA_EXTERNO
      })
      switch (l.TIPO) {
        case 'Ordem de Serviço Preventiva':
          kpi.os_preventiva = {
            descricao: l.TIPO,
            interno: l.QTDE_OS_ABERTA_INTERNO,
            externo: l.QTDE_OS_ABERTA_EXTERNO,
            total: l.QTDE_OS_ABERTA
          }
          break;
        
        case 'Ordem de Serviço Pneus':
          kpi.os_pneu = {
            descricao: l.TIPO,
            interno: l.QTDE_OS_ABERTA_INTERNO,
            externo: l.QTDE_OS_ABERTA_EXTERNO,
            total: l.QTDE_OS_ABERTA
          }
          break;
        
        case 'Ordem de Serviço Corretiva':
          kpi.os_corretiva = {
            descricao: l.TIPO,
            interno: l.QTDE_OS_ABERTA_INTERNO,
            externo: l.QTDE_OS_ABERTA_EXTERNO,
            total: l.QTDE_OS_ABERTA
          }
          break;
        
        case 'Ordem de Serviço Rastreador':
          kpi.os_rastreador = {
            descricao: l.TIPO,
            interno: l.QTDE_OS_ABERTA_INTERNO,
            externo: l.QTDE_OS_ABERTA_EXTERNO,
            total: l.QTDE_OS_ABERTA
          }
          break;
        
        case 'Ordem de Serviço Socorro':
          kpi.os_socorro = {
            descricao: l.TIPO,
            interno: l.QTDE_OS_ABERTA_INTERNO,
            externo: l.QTDE_OS_ABERTA_EXTERNO,
            total: l.QTDE_OS_ABERTA
          }
          break;
        
          case 'Total':
            kpi.totalizador = {
              descricao: 'Totalizador de Ordem de Serviço',
              interno: l.QTDE_OS_ABERTA_INTERNO,
              externo: l.QTDE_OS_ABERTA_EXTERNO
            }
            break;
        
          case 'Carreta':
            kpi.veiculos.carreta = l.QTDE_OS_ABERTA
            break;
        
          case 'Tração':
            kpi.veiculos.tracao = l.QTDE_OS_ABERTA
            break;
      
        default:
          break;
      }
      
    }

    for (const p in rsOsPorMarca) {
      const marca = JSON.parse(JSON.stringify(rsOsPorMarca[p]))
      listaMarca.push({
        marca: marca.MARCA,
        qtde_os_aberta: marca.QTDE_OS_ABERTA

      })
    }
    const listaMarcaTracao = []
    const listaMarcaCarreta = []
    for (const p in rsOsMarcaTracao) {
      const marca = JSON.parse(JSON.stringify(rsOsMarcaTracao[p]))
      if('Tração' == marca.TRACAO){
      listaMarcaTracao.push({
        chave: marca.MARCA,
        valor: marca.QTDE_OS_ABERTA
      })}else{
      listaMarcaCarreta.push({
        chave: marca.MARCA,
        valor: marca.QTDE_OS_ABERTA
      })
      }
    }

    for (const p in rsOsPorPlaca) {
      const placa = JSON.parse(JSON.stringify(rsOsPorPlaca[p]))
      listaVeiculo.push({
        placa: placa.PLACA,
        qtde_os_aberta: placa.QTDE_OS_ABERTA
      })
    }

    const os_placa = []
    for (const p in rsOsPorPlaca) {
      const placa = JSON.parse(JSON.stringify(rsOsPorPlaca[p]))
      if(os_placa.length < 10){
      os_placa.push({
        chave: placa.PLACA,
        valor: placa.QTDE_OS_ABERTA
      })}
    }

    for (const p in rsOsPorTipo) {
      const tipo = JSON.parse(JSON.stringify(rsOsPorTipo[p]))
      listaTipo.push({
        tipo: tipo.TIPO,
        qtde_os_aberta: tipo.QTDE_OS_ABERTA
      })
      val.push(tipo.QTDE_OS_ABERTA)
      leg.push({
        nome: tipo.TIPO,
        cor: cores[p]
      })
    }

    const obj = {
      indicadores: indicadores,
      tempo_aberto_placa: { dados: listaTop10, legenda: legenda },
      qtde_os_placa: listaVeiculo,
      qtde_os_placa_grafico: graficoVeiculo,
      qtde_os_marca: listaMarca,
      qtde_os_tipo_validar: listaTipo,
      qtde_os_tipo: {
        valores: val,
        legendas: leg
      },
      lista_ccg: listaCcg,
      kpi:kpi,
      os_marca_cavalo: listaMarcaTracao,
      os_marca_carreta: listaMarcaCarreta,
      os_placa: os_placa
    }
    return obj
  }
}
