/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/camelcase */
// eslint-disable-file no-use-before-define

export class AutomacaoPage {
  public async automacao (rsIndicadores, rsAcompanhamentoMensal, rsAcompanhamentoDiario, rsIntegracaoNfUsuario, rsOperacaoAutomatizada): Promise<object> {
    const indicadores:any = {}
    const acompanhamentoMensal = []
    const integracaoUsuario = []
    const acompanhamentoDiario = []
    const operacaoAutomatizada = []

    for (const p in rsIndicadores) {
      const indicador = JSON.parse(JSON.stringify(rsIndicadores[p]))
      indicadores.total_emitido = {
        faturamento: indicador.TOTAL_CTE,
        quantidade: indicador.QTD_CTE
      }
      indicadores.total_automatizado = {
        faturamento: indicador.AUTOMACAO,
        quantidade: indicador.QTD_AUTOMACAO
      }
      indicadores.percent_automatizado = {
        porcentagem: indicador.PERCENTUAL,
        quantidade: indicador.PERCENTUAL_QTD
      }
      indicadores.tempo_emissao = indicador.TEMPO_NF_CTE
    }

    for (const p in rsAcompanhamentoMensal) {
      const acompMes = JSON.parse(JSON.stringify(rsAcompanhamentoMensal[p]))
      acompanhamentoMensal.push({
        cliente: acompMes.CLIENTE,
        faturamento: acompMes.FATURAMENTO,
        fat_automatizado: acompMes.FAT_AUTOMATIZADO,
        operacoes: acompMes.OPERACAO,
        automatizadas: acompMes.AUTOMATIZADAS

      })
    }

    for (const p in rsIntegracaoNfUsuario) {
      const integ = JSON.parse(JSON.stringify(rsIntegracaoNfUsuario[p]))
      integracaoUsuario.push({
        usuario: integ.USUARIO,
        quantidade: integ.QUANTIDADE

      })
    }

    for (const p in rsAcompanhamentoDiario) {
      const acompDia = JSON.parse(JSON.stringify(rsAcompanhamentoDiario[p]))
      acompanhamentoDiario.push({
        data: acompDia.DATA_FORMATADA,
        total_cte: acompDia.TOTAL_CTE,
        percent_automatizado: acompDia.PORCENTAGEM,
        cte_automacao: acompDia.AUTOMATIZADAS

      })
    }

    for (const p in rsOperacaoAutomatizada) {
      const operacao = JSON.parse(JSON.stringify(rsOperacaoAutomatizada[p]))

      operacaoAutomatizada.push({
        cliente: operacao.CLIENTE,
        operacoes_auto: operacao.OPERACOES
      })
    }

    const obj = {
      indicadores: indicadores,
      listas: {
        acompanhamento_mensal: acompanhamentoMensal,
        integracao_por_usuario: integracaoUsuario,
        acompanhamento_diario: acompanhamentoDiario,
        operacoes_automatizadas: operacaoAutomatizada
      }

    }
    return obj
  }
}
