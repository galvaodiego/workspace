
import { Socket } from 'socket.io'
import { AutomacaoService } from './automacao.service'
import { AutomacaoPage } from './automacao.page'

class AutomacaoController {
  public async getAutomacao (req, socket:Socket): Promise<void> {
    const _automacaoService = new AutomacaoService(req.base)
    const _automacaoPage = new AutomacaoPage()

    const rsIndicadores = await _automacaoService.findIndicadores()
    const rsAcompanhamentoMensal = await _automacaoService.findAcompanhamentoMensal()
    const rsAcompanhamentoDiario = await _automacaoService.findAcompanhamentoDiario()
    const rsIntegracaoNfUsuario = await _automacaoService.findIntegracaoNfUsuario()
    const rsOperacaoAutomatizada = await _automacaoService.findOperacaoAutomatizada()

    console.log('Teste2')

    const retorno = await _automacaoPage.automacao(rsIndicadores, rsAcompanhamentoMensal, rsAcompanhamentoDiario, rsIntegracaoNfUsuario, rsOperacaoAutomatizada)

    socket.emit('automacao', retorno)
  }
}
export default new AutomacaoController()
