/* eslint-disable @typescript-eslint/no-explicit-any */
import mongoose, { Schema, Model } from 'mongoose'
export class AutomacaoService {
  private schema: mongoose.Schema
  private dynamicSchema: Schema
  private automacaoModel: Model<any>

  constructor (base) {
    this.dynamicSchema = new Schema({}, { strict: false })
    this.initModel(base)
  }

  private initModel (base):void{
    try {
      this.automacaoModel = mongoose.model('dash_automacao_' + base)
    } catch (error) {
      this.automacaoModel = mongoose.model('dash_automacao_' + base, this.dynamicSchema, 'dash_automacao_' + base)
    }
  }

  public async findIndicadores ():Promise<any> {
    const res = await this.automacaoModel.find({ MONGO_AGG: 'indicador' })
    return res
  }

  public async findAcompanhamentoMensal ():Promise<any> {
    const res = await this.automacaoModel.find({ MONGO_AGG: 'acompanhamento_mensal' })
    return res
  }

  public async findIntegracaoNfUsuario ():Promise<any> {
    const res = await this.automacaoModel.find({ MONGO_AGG: 'integracao_nf_usuario' })
    return res
  }

  public async findAcompanhamentoDiario ():Promise<any> {
    const res = await this.automacaoModel.find({ MONGO_AGG: 'acompanhamento_diario' })
    return res
  }

  public async findOperacaoAutomatizada ():Promise<any> {
    const res = await this.automacaoModel.find({ MONGO_AGG: 'operacao_automatizada' })

    return res
  }
}
