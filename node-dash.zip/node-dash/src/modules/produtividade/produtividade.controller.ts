import GroupProdutividade from './produvidade.group'
import { Socket } from 'socket.io'
import { ProdutividadeService } from './produtividade.service'

class ProdutividadeController {
  public async getProdutividade (req: object, socket: Socket): Promise <void> {
    const queryFat = new GroupProdutividade()
    const _ProdutividadeService = new ProdutividadeService()

    const cliente = req.base
    const retorno = {
      ProdutividadePeriodo: null,
      TotalEmpresa: null
    }

    const logInicio = new Date()

    queryFat.setMatchProdutividade(req)

    retorno.ProdutividadePeriodo = await _ProdutividadeService.findAll(queryFat.match, cliente, req, 'data', { '_id.data': 1 })

    req.empresa = 1
    req.total = 1
    queryFat.setMatchProdutividade(req)
    
    retorno.TotalEmpresa = await _ProdutividadeService.findAll(queryFat.match, cliente, req, 'total', { '_id.data': 1 })
    console.log('base', req.base, 'PRODUTIVIDADE: ', (new Date() - logInicio) / 1000, 'segundos')
    socket.emit('produtividade', retorno)
  }
}

export default new ProdutividadeController()
