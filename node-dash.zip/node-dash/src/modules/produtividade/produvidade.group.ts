import { MatchProdutividadeInterface, GroupProdutividadeInterface, RequestProdutividadeInterface } from './produtividade.interface'

export class GroupProdutividade {
  public group : GroupProdutividadeInterface
  public match : MatchProdutividadeInterface

  constructor () {
    this.initGroup()
    this.initMatch()
  }

  private initGroup (): void{
    const group = {} as GroupProdutividadeInterface
    group._id = {}
    group._id.data = null
    group._id.coordenador = null
    group._id.nomeCoordenador = null
    group.valor = { $sum: '$TOTAL_REALIZADO' }
    group.meta = { $sum: '$TOTAL_PREVISTO' }
    this.group = group
  }

  public setGroup (req: RequestProdutividadeInterface, group: string): void {
    switch (group) {
      case 'data':
        if (!req.empresa || req.empresa < 1) {
          this.group._id.coordenador = '$COORDENADOR'
          this.group._id.nomeCoordenador = '$NOME_COORDENADOR'
          this.group._id.data = req.periodo === 'anual' ? {
            $dateToString: {
              date: '$DATA',
              format: '%m/%Y'
            }
          } : {
            $dateToString: {
              date: '$DATA',
              format: '%m/%Y'
            }
          }
        } else {
          this.group._id.nomeCoordenador = '$NOME_COORDENADOR'
          this.group._id.data = req.periodo === 'anual' ? {
            $dateToString: {
              date: '$DATA',
              format: '%m/%Y'
            }
          } : {
            $dateToString: {
              date: '$DATA',
              format: '%m/%Y'
            }
          }
        }
        break
      case 'cliente':
        this.group._id.coordenador = '$COORDENADOR'
        break
      case 'mercadoria':
        this.group._id.nomeCoordenador = '$NOME_COORDENADOR'
        break
      case 'total':
        break
      default:
        break
    }

    this.prepareQuery()
  }

  public cleanGroup ():void {
    this.initGroup()
  }

  private initMatch (): void {
    const match = {} as MatchProdutividadeInterface
    match.COORDENADOR = null
    match.NOME_COORDENADOR = null
    match.DATA = null
    this.match = match
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public getReturn (ret: Array<any>):Array<any> {
    ret.forEach(element => {
      element.valor = parseFloat(element.valor)
      element.meta = parseFloat(element.meta)

      if (element._id) {
        Object.assign(element, element._id)
        delete element._id
      }
    })
    return ret
  }

  public setMatchProdutividade (req: RequestProdutividadeInterface): void {
    const anoInicio = new Date(new Date().getFullYear(), 0, 1)
    const anoFim = new Date(new Date().getFullYear() + 1, 0, 1)
    const periodoMensal = new Date(new Date().getFullYear(), new Date().getMonth(), 1)
    const mesInicio = new Date(new Date().getFullYear(), new Date().getMonth(), 1)
    const mesFim = new Date(new Date().getFullYear(), new Date().getMonth() + 1, 1)
    const diaSemana = new Date().getDay()
    const periodoSemanal = new Date(new Date().getFullYear(), new Date().getMonth(), 1, new Date().getDay(), -diaSemana)
    const periodoDiario = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getUTCDate(), 0, 0, 0)
    let dataInicial = null
    let dataFinal = null
    let dataFiltro = null
    if (!req.empresa || req.empresa < 1) {
      dataInicial = new Date(mesInicio.setHours(0, 0, 0, 0) - (60 * 60000 * 3))
      dataFinal = new Date(mesFim.setHours(0, 0, 0, 0) - (60 * 60000 * 3))
    } else {
      req.periodo = 'anual'
      dataInicial = new Date(anoInicio.setHours(0, 0, 0, 0) - (60 * 60000 * 2))
      dataFinal = new Date(anoFim.setHours(0, 0, 0, 0) - (60 * 60000 * 2))
    }
    if(req.total > 0){
      dataInicial = new Date(mesInicio.setHours(0, 0, 0, 0) - (60 * 60000 * 3))
      dataFinal = new Date(mesFim.setHours(0, 0, 0, 0) - (60 * 60000 * 3))
    }
    switch (req.periodo) {
      case 'diario' :
        dataFiltro = new Date(periodoDiario.setHours(0, 0, 0, 0) - (60 * 60000 * 2))
        break
      case 'semanal':
        dataFiltro = new Date(periodoSemanal.setHours(0, 0, 0, 0) - (60 * 60000 * 2))
        break
      case 'mensal':
        dataFiltro = new Date(periodoMensal.setHours(0, 0, 0, 0) - (60 * 60000 * 2))
        break
      case 'anual':
        dataFiltro = new Date(anoInicio.setHours(0, 0, 0, 0) - (60 * 60000 * 2))
        break
      default:
        dataFiltro = new Date(anoInicio.setHours(0, 0, 0, 0) - (60 * 60000 * 2))
    }

    this.match = {} as MatchProdutividadeInterface
    this.match.COORDENADOR = req.coordenador ? { $in: req.coordenador } : null
    this.match.NOME_COORDENADOR = req.nomeCoordenador ? { $in: req.nomeCoordenador } : null
    this.match.EMPRESA = req.empresa ? parseInt(req.empresa) : 0

    if (dataInicial && dataFinal) {
      this.match.DATA = { $gte: dataInicial, $lt: dataFinal }
    } else {
      this.match.DATA = { $gte: dataFiltro }
    }
    this.prepareQuery()
  }

  public prepareQuery ():void {
    Object.keys(this.group._id).forEach((key) => (this.group._id[key] == null) && delete this.group._id[key])
    Object.keys(this.match).forEach((key) => (this.match[key] == null) && delete this.match[key])
  }
}
export default GroupProdutividade
