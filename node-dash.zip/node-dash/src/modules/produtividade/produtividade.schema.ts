import { Schema, model, Document } from 'mongoose'

export interface ProdutividadeInterface extends Document{
  // eslint-disable-next-line camelcase
  data ?: Date,
  coordenador ?: string,
  // eslint-disable-next-line camelcase
  total_realizado ?: string,
  // eslint-disable-next-line camelcase
  total_previsto ?: string,
  // eslint-disable-next-line camelcase
  nome_coordenador ?: string,
  toJson(): Document
}

const ProdutividadeSchema = new Schema({
  // eslint-disable-next-line @typescript-eslint/camelcase
  data: Date,
  coordenador: String,
  // eslint-disable-next-line @typescript-eslint/camelcase
  nome_coordenador: String,
  // eslint-disable-next-line @typescript-eslint/camelcase
  total_receita: {
    type: Schema.Types.Decimal128,
    required: true
  },
  // eslint-disable-next-line @typescript-eslint/camelcase
  total_previsto: {
    type: Schema.Types.Decimal128,
    required: true
  }

})

export default model<ProdutividadeInterface>('Produtividade', ProdutividadeSchema)
