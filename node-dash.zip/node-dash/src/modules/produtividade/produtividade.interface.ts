
export interface GroupProdutividadeIdInterface {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    data ?: any,
    coordenador ?: string,
    nomeCoordenador ?: string
  }
export interface MatchProdutividadeInterface {
        COORDENADOR ?: object
        DATA ?: object
        NOME_COORDENADOR ?: object
        EMPRESA ?: number
  }
export interface GroupProdutividadeInterface{
    _id : GroupProdutividadeIdInterface,
    valor : object,
    meta : object
  }
export interface RequestProdutividadeInterface{
    periodo ?: string,
    coordenador ?: string,
    nomeCoordenador ?: string,
    data ?: string,
    mes ?: string,
    empresa ?: number,
  }
