import GroupProdutividade from './produvidade.group'
import Produtividade, { ProdutividadeInterface } from './produtividade.schema'

import mongoose from 'mongoose'

export class ProdutividadeService {
    private prodGroup = new GroupProdutividade();

    async findAll (matchParams, cliente, requisicao, agrupador, sort): Promise<ProdutividadeInterface[]> {
      // let v_sort = sort ? sort : this.sortP
      this.prodGroup.setGroup(requisicao, agrupador)

      const produtividade = mongoose.model('produtividade', Produtividade.schema, 'dash_produtividade_' + cliente)
      const result = await produtividade.aggregate([{ $match: matchParams }, { $group: this.prodGroup.group }]).sort(sort)
      this.prodGroup.cleanGroup()
      return this.prodGroup.getReturn(result)
    }
}
