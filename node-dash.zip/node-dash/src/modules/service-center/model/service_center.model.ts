/* eslint-disable camelcase */
/* eslint-disable @typescript-eslint/explicit-function-return-type */
/* eslint-disable no-self-assign */
/* eslint-disable @typescript-eslint/camelcase */

export class ServiceCenterModel {
  public group
  public match

  constructor () {
    this.initGroup()
    this.initMatch()
  }

  private initGroup () {

    const group = {
      _id: {
        retorno: '$RETORNO'
      },

      last_update: { $max: '$DATA_CARGA' }
    }
    this.group = group
  }

  private initMatch () {
    const match = {
      RETORNO: null
    }
    this.match = match
  }

  public setMatch (req): void {
    this.match.RETORNO = req.retorno ? { $eq: req.retorno } : null
    
    Object.keys(this.match).forEach((key) => (this.match[key] == null) && delete this.match[key])
  }

  public setGroup (group: Array<string>): void {
    const obj = JSON.parse(JSON.stringify(this.group))
    Object.keys(obj._id).forEach((key) => (!group.includes(key)) && delete obj._id[key])
    this.group = obj
  }

  public cleanGroup (): void {
    this.initGroup()
  }

  public cleanMath (): void {
    this.initMatch()
  }
}

export default new ServiceCenterModel()
