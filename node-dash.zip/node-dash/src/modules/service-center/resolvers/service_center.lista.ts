/* eslint-disable no-unused-vars */
/* eslint-disable camelcase */
/* eslint-disable dot-notation */
/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable no-undef */

import { ReturnComponents } from '../../../componentes/return.components'
import { ServiceCenterService } from '../service/service_center.service'

export class ServiceCenterLista {
  private _service = new ServiceCenterService();
  private _component = new ReturnComponents();

  public async getLista (req: object): Promise<object> {
    const sort = { valor: -1 }
    let filter: any = {}

    filter = Object.assign({}, req, { retorno: 'lista_atendimentos' })
    const lista = await this._service.findAll(filter, sort, ['ABERTURA CATEGORIA CLIENTE CODIGO EXPECTATIVA SITUACAO TEMPO_ABERTO'])
    const resLista = await this._component.getLowerCase(lista)

    const indicador = await this._service.aggregate(req, [''], sort)
    const resAtualizacao = indicador && indicador.length > 0 ? indicador[0].last_update : 0

    const obj: any = {
      atendimentos: {
        lista_atendimentos: resLista,
        atualizacao: resAtualizacao
      }
    }

    return obj
  }
}

export default new ServiceCenterLista()
