/* eslint-disable no-unused-vars */
/* eslint-disable camelcase */
/* eslint-disable dot-notation */
/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable no-undef */

import { ReturnComponents } from '../../../componentes/return.components'
import { ServiceCenterService } from '../service/service_center.service'

export class ServiceCenterDashboard {
  private _service = new ServiceCenterService();
  private _component = new ReturnComponents();

  public async getDashboard (req: object): Promise<object> {
    const sort = { valor: -1 }
    let filter: any = {}
    
    filter = Object.assign({}, req, { retorno: 'atend_abertos_cliente' })
    const atend_aberto = await this._service.findAll(filter, sort, ['NOME QUANTIDADE'])
    const resAtendAbertoCliente = await this._component.getLowerCase(atend_aberto)

    filter = Object.assign({}, req, { retorno: 'atend_abertos_funcionario' })
    const atend_aberto1 = await this._service.findAll(filter, sort, ['NOME QUANTIDADE'])
    const resAtendAbertoFunc = await this._component.getLowerCase(atend_aberto1)

    filter = Object.assign({}, req, { retorno: 'grupo_atendimentos' })
    const grupoAt = await this._service.findAll(filter, sort, ['CATEGORIA EM_ATENDIMENTO PENDENTE_ATENDIMENTO'])
    const resGrupoAt = await this._component.getLowerCase(grupoAt)

    filter = Object.assign({}, req, { retorno: 'heatmap_hora' })
    const mapHora = await this._service.findAll(filter, sort, ['HORA TEMPO_MEDIO'])
    const resMapHora = await this._component.getLowerCase(mapHora)

    filter = Object.assign({}, req, { retorno: 'heatmap_turno' })
    const mapTurno = await this._service.findAll(filter, sort, ['TURNO TEMPO_MEDIO'])
    const resMapTurno = await this._component.getLowerCase(mapTurno)

    filter = Object.assign({}, req, { retorno: 'indicadores' })
    const indicadores = await this._service.findAll(filter, sort, ['STATUS QUANTIDADE'])
    const resIndicadores = await this._component.getLowerCase(indicadores)

    filter = Object.assign({}, req, { retorno: 'tempo_atendimento' })
    const tempAt = await this._service.findAll(filter, sort, ['INTERVALO QUANTIDADE QUANTIDADE_OLD'])
    const resTempAt = await this._component.getLowerCase(tempAt)

    const indicador = await this._service.aggregate(req, [''], sort)
    const resAtualizacao = indicador && indicador.length > 0 ? indicador[0].last_update : 0

    const obj: any = {
      central_atendimentos: {
        atend_abertos_cliente: resAtendAbertoCliente,
        atend_abertos_funcionario: resAtendAbertoFunc,
        grupo_atendimentos: resGrupoAt,
        heatmap_hora: resMapHora,
        heatmap_turno: resMapTurno,
        indicadores: resIndicadores,
        tempo_atendimento: resTempAt,
        atualizacao: resAtualizacao
      }
    }

    return obj
  }
}

export default new ServiceCenterDashboard()
