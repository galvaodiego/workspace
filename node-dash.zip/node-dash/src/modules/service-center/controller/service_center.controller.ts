
import { GatewayService } from '../../../services/gateway.service'
import { ServiceCenterDashboard } from '../resolvers/service_center.dashboard'
import { ServiceCenterService } from '../service/service_center.service'
import { ServiceCenterLista } from '../resolvers/service_center.lista'

class ServiceCenterController {
  private _dash = new ServiceCenterDashboard()
  private _lista = new ServiceCenterLista()
  private _service = new ServiceCenterService()
  private _gatewayService = new GatewayService()

  public async getDashboard (req: object, socket): Promise<void> {

    const logInicio = new Date()
    let retorno
    const exist = await this._service.exists(req.base)

    console.log('exist no mongo', exist)
    if (exist) {
      
      retorno = await this._dash.getDashboard(req)
    }
    else {
      if (req.token && req.url) {
        retorno = await this._gatewayService.backendCall(req, 'M4002', 'getCentralAtendimentos')
      }
    }

    console.log('service center dashboard', req.base, ' ', (new Date() - logInicio) / 1000, 'segundos')

    socket.emit('service_center', retorno)
  }

  public async getListaAtendimentos (req: object, socket): Promise<void> {

    const logInicio = new Date()
    let retorno
    const exist = await this._service.exists(req.base)

    if (exist) {
      retorno = await this._lista.getLista(req)
    }
    else {
      if (req.token && req.url) {
        retorno = await this._gatewayService.backendCall(req, 'M4002', 'getListaAtendimentos')
      }
    }

    console.log('service center lista', req.base, ' ', (new Date() - logInicio) / 1000, 'segundos')

    socket.emit('service_center', retorno)
  }
}

export default new ServiceCenterController()
