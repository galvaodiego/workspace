
import mongoose from 'mongoose'
import { ServiceCenterModel } from '../model/service_center.model'

export class ServiceCenterService {
  private _model = new ServiceCenterModel();

  async aggregate (req, agrupador, sort, limit?): Promise<object> {
    this._model.setMatch(req)
    this._model.setGroup(agrupador)

    const tgSchema = new mongoose.Schema({}, { strict: false })
    let tg
    try {
      tg = mongoose.model('dash_service_center_' + req.base)
    } catch (error) {
      tg = mongoose.model('dash_service_center_' + req.base, tgSchema, 'dash_service_center_' + req.base)
    }

    const res = !limit ? await tg.aggregate([{ $match: this._model.match }, { $group: this._model.group }]).sort(sort) :
      await tg.aggregate([{ $match: this._model.match }, { $group: this._model.group }]).sort(sort).limit(limit)

    this._model.cleanGroup()
    this._model.cleanMath()

    return res
  }

  async findAll (req, sort, select?, limit?): Promise<object> {
    this._model.setMatch(req)

    const tgSchema = new mongoose.Schema({}, { strict: false })
    let tg
    try {
      tg = mongoose.model('dash_service_center_' + req.base)
    } catch (error) {
      tg = mongoose.model('dash_service_center_' + req.base, tgSchema, 'dash_service_center_' + req.base)
    }

    const res = !select ? await tg.find(this._model.match).sort(sort) : await tg.find(this._model.match).select('roll ' + select).sort(sort) //.limit(limit)

    this._model.cleanMath()

    return res
  }

  async exists (base): Promise<boolean> {
    const tgSchema = new mongoose.Schema({}, { strict: false })
    let tg
    try {
      tg = mongoose.model('dash_service_center_' + base)
    } catch (error) {
      tg = mongoose.model('dash_service_center_' + base, tgSchema, 'dash_service_center_' + base)
    }

    const res = await tg.exists()

    return res
  }
}
