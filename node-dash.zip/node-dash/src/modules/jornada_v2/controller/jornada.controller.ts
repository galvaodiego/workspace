/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable space-before-function-paren */
import { JornadaPage } from '../resolvers/jornada.page'
import { JornadaService } from '../service/jornada.service'
import { GatewayService } from '../../../services/gateway.service'
import { Socket } from 'socket.io'
class JornadaController {
  private _page = new JornadaPage()
  private _service = new JornadaService()
  private _gatewayService = new GatewayService()

  public async getJornada(req: any, socket: Socket): Promise<void> {
    req.base = req.base === 'ciaverdelog' ? 'viaverde' : req.base
    const logInicio = new Date()
    let retorno
    const exist = await this._service.exists(req.base)
    if (exist) {
      retorno = await this._page.getPage(req)
    } else {
      if (req.token && req.url) {
        retorno = await this._gatewayService.backendCall(req, 'M4002', 'getJornada')
      }
    }

    console.log('jornada', req.base, 'jornada:', (new Date() - logInicio) / 1000, 'segundos')
    socket.emit('jornada', retorno)
  }
}

export default new JornadaController()
