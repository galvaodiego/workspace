/* eslint-disable camelcase */
/* eslint-disable @typescript-eslint/explicit-function-return-type */
/* eslint-disable no-self-assign */
/* eslint-disable @typescript-eslint/camelcase */

export class ControleTrafegoModel {
  public group
  public match

  constructor () {
    this.initGroup()
    this.initMatch()
  }

  private initGroup () {

    const group = {
      _id: {
        estado: '$ESTADO',
        grupo_carreta: '$GRUPO_CARRETA'
      },

      quantidade: { $sum: '$QUANTIDADE' },
      last_update: { $max: '$DATA_CARGA' }
    }
    this.group = group
  }

  private initMatch () {
    const match = {
      ESTADO: null,
      GRUPO_CARRETA: null
    }
    this.match = match
  }

  public setMatch (req): void {

    this.match.ESTADO = req.estado ? { $eq: req.status } : null
    this.match.GRUPO_CARRETA = req.grupo_carreta ? { $eq: req.grupo_carreta } : null
   

    Object.keys(this.match).forEach((key) => (this.match[key] == null) && delete this.match[key])
  }

  public setGroup (group: Array<string>): void {
    const obj = JSON.parse(JSON.stringify(this.group))
    Object.keys(obj._id).forEach((key) => (!group.includes(key)) && delete obj._id[key])
    this.group = obj
  }

  public cleanGroup (): void {
    this.initGroup()
  }

  public cleanMath (): void {
    this.initMatch()
  }
}

export default new ControleTrafegoModel()
