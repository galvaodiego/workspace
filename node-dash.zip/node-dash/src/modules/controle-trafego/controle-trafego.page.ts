/* eslint-disable no-unused-vars */
/* eslint-disable camelcase */
/* eslint-disable dot-notation */
/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable no-undef */

import { ReturnComponents } from '../../componentes/return.components'
import { ControleTrafegoService } from './controle-trafego.service'

export class ControleTrafegoPage {
  private _service = new ControleTrafegoService();
  private _component = new ReturnComponents();

  public async getPage(req: object): Promise<object> {
    const sort = { valor: -1 }
    let filter: any = {}


    const indicadores = await this._service.aggregate(req, [''], sort)
    const resAtualizacao = indicadores && indicadores.length > 0 ? indicadores[0].last_update : 0

    // filter = Object.assign({}, req, { grupo_carreta: 'AUTOMOTIVO' })
    const lista = await this._service.findAll(req, sort, ['STATUS_CARRETA STATUS_CARRETA_SLUG QUANTIDADE ESTADO GRUPO_CARRETA'])
    const lowerLista = await this._component.getLowerCase(lista)
    const resLista = await this.getUfCarreta(lowerLista)

    const obj: any = {
      carretaGrupo: resLista,
      atualizacao: resAtualizacao

    }

    return obj
  }



  private async getUfCarreta(res): Promise<any> {
    const data = res
    const newData = []

    const grupos = [...new Set(data.map(el => { return el.grupo_carreta }))]

    /** Filtra por grupo e faz os agrupamento -- Pai */
    for (const grupo of grupos) {
      let objFind = data.filter(x => x.grupo_carreta == grupo) // lista de por grupo
      let quantidade = objFind.map(x => x.quantidade).reduce((p, c) => c + p) // soma da quantidade

      let estados = [...new Set(objFind.map(el => { return el.estado }))] // lista de estados uniques

      let ufCarreta = []
      let sortUfCarreta = [] // array ordenado
      let newObj = {} // objeto final

      /** Criar array de UfCarreta a partir dos estados - neto **/
      for (const estado of estados) {
        let objEstado = objFind.filter(x => x.estado == estado)
        let ObjEmissao = []
        let sortObjEmissao = [] // array ordenado

        objEstado.forEach(el => {
          ObjEmissao.push({
            quantidade: el.quantidade,
            status_carreta: el.status_carreta,
            status_carreta_slug: el.status_carreta_slug
          })
        });

        sortObjEmissao = ObjEmissao.sort((a, b) => { return ('' + a.status_carreta).localeCompare(b.status_carreta) })

        /** Insere o array de UfCarreta para cada array de estado */
        ufCarreta.push({ estado: estado, graficoEmissaoCte: sortObjEmissao })
        sortUfCarreta = ufCarreta.sort((a, b) => { return ('' + a.estado).localeCompare(b.estado) })
      }

      /*** Junta toas as informações em um Objeto só **/
      Object.assign(newObj, {
        grupo_carreta: grupo,
        quantidade_carreta: quantidade,
        ufCarretaGrupo: sortUfCarreta
      })
      newData.push(newObj)
    }

    return newData

  }
}

export default new ControleTrafegoPage()
