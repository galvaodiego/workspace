import { ControleTrafegoPage } from './controle-trafego.page'
import { ControleTrafegoService } from './controle-trafego.service'
import { GatewayService } from '../../services/gateway.service'

class ControleTrafegoController {
  private _page = new ControleTrafegoPage()
  private _service = new ControleTrafegoService()
  private _gatewayService = new GatewayService()

  public async getControleTrafego (req: object, socket): Promise<void> {

    const logInicio = new Date()
    let retorno
    const exist = await this._service.exists(req.base)

    if (exist) {
      retorno = await this._page.getPage(req)
    }
    else {
      if (req.token && req.url) {
        retorno = await this._gatewayService.backendCall(req, 'M4002', 'getCarretaUFGrupo')
      }
    }

    console.log('controle_trafego', req.base, 'Controle Trafego:', (new Date() - logInicio) / 1000, 'segundos')

    socket.emit('controle_trafego', retorno)
  }
}

export default new ControleTrafegoController()
