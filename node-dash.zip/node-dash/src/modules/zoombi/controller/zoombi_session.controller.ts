/* eslint-disable camelcase */
/* eslint-disable @typescript-eslint/camelcase */
import { ZoombiSessionService } from '../services/zoombi_session.service'

class ZoombiSessionController {

  private _sessioService = new ZoombiSessionService()

  /**  Verifica se já existe uma sessao do usuario
   *  Se ixistir e o path for diferente, insere uma time_session se não insere uma nova sessão
   */
  public async insertSession (base: string, usuario: string, ip: any, pacote: string, assunto?: string, aba?: string): Promise<any> {

    const ultimoAcesso = await this._sessioService.find({ base: base, usuario: usuario, ip: ip })
    const lastPath =  ultimoAcesso.pacote + '/' + ultimoAcesso.assunto + '/' + ultimoAcesso.aba
    const newPath = pacote + '/' + assunto + '/' + aba

    if (ultimoAcesso !== undefined && !!ultimoAcesso.pacote === true) {
      if (lastPath !== newPath) {

        const session = {
          base: ultimoAcesso.base,
          usuario: ultimoAcesso.usuario,
          pacote: ultimoAcesso.pacote,
          assunto: ultimoAcesso.assunto,
          aba: ultimoAcesso.aba,
          ip: ultimoAcesso.ip,
          date_insert: ultimoAcesso.date_insert
        }
        this._sessioService.insertTimeSession(session)

        const newAcess = Object.assign({}, ultimoAcesso, { pacote: pacote, assunto: assunto, aba: aba })
        this._sessioService.insertSession(newAcess)
      }
    }
    if (ultimoAcesso.length === 0) {
      this._sessioService.insertSession({
        base: base,
        usuario: usuario,
        pacote: pacote,
        assunto: assunto,
        aba: aba,
        ip: ip
      })
    }
  }

  public async deleteSession (base: string, usuario: string, ip: any): Promise<any> {
    const ultimoAcesso = await this._sessioService.find({ base: base, usuario: usuario, ip: ip })

    if (ultimoAcesso !== undefined && !!ultimoAcesso.pacote === true) {

      const session = {
        base: ultimoAcesso.base,
        usuario: ultimoAcesso.usuario,
        pacote: ultimoAcesso.pacote,
        assunto: ultimoAcesso.assunto,
        aba: ultimoAcesso.aba,
        ip: ultimoAcesso.ip,
        date_insert: ultimoAcesso.date_insert
      }
      this._sessioService.insertTimeSession(session)
      this._sessioService.delete({ base: session.base, usuario: session.usuario, ip: ip })
    }
  }
}

export default new ZoombiSessionController()
