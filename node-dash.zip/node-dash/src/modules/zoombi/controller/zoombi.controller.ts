import { GatewayService } from '../../../services/gateway.service'
import { GatewayLoginService } from '../services/zoombi_gateway.service'

class ZoombiController {
  private _gatewayService = new GatewayService()
  private _gatewayLoginService = new GatewayLoginService()

  public async getComponente (req: object): Promise<void> {
    const logInicio = new Date()
    let retorno

    const tkn = await this._gatewayLoginService.backendLoginCall()
    const r = {}
    r.url = 'https://backend.kmm.com.br'
    r.token = tkn.token
    r.usuario = req.body.parameters.usuario
    r.pacote = req.body.parameters.pacote
    r.assunto = req.body.parameters.assunto
    r.aba = req.body.parameters.aba

    const result = await this._gatewayService.backendCall(r, 'M4002', 'getComponentes')
    return result
  }

  public async getMenu (req: object): Promise<void> {
    const logInicio = new Date()
    let retorno

    const tkn = await this._gatewayLoginService.backendLoginCall()
    const r = {}
    r.url = 'https://backend.kmm.com.br'
    r.token = tkn.token
    r.usuario = req.body.parameters.usuario

    const result = await this._gatewayService.backendCall(r, 'M4002', 'getMenu')
    return result
  }

  public async login (req: object): Promise<void> {
    const tkn = await this._gatewayLoginService.backendLoginCall()
    const r = {}
    r.url = 'https://backend.kmm.com.br'
    r.token = tkn.token
    r.usuario = req.body.parameters.usuario
    r.senha = req.body.parameters.senha

    try {
      const result = await this._gatewayService.backendCall(r, 'M4002', 'login')
      return result
    } catch (error) {
      return Promise.reject('false')
    }
  }

  public async getCliente (req: object): Promise<void> {
    const tkn = await this._gatewayLoginService.backendLoginCall()
    const r = {}
    r.url = 'https://backend.kmm.com.br'
    r.token = tkn.token
    r.usuario = req.body.parameters.usuario

    try {
      const result = await this._gatewayService.backendCall(r, 'M4002', 'getCliente')

      return result
    } catch (error) {
      return Promise.reject('error')
    }
  }

  public async validateToken (req: object): Promise<void> {
    const tkn = await this._gatewayLoginService.backendLoginCall()
    const r = {}
    r.url = 'https://backend.kmm.com.br'
    r.token = tkn.token
    r.user_token = req.query.token
    r.usuario = 'vazio'
    r.senha = 'vazio'
     
    try {
      const result = await this._gatewayService.backendCall(r, 'M4002', 'token')
      return result
    } catch (error) {
      return Promise.reject('false')
    }
  }


}

export default new ZoombiController()
