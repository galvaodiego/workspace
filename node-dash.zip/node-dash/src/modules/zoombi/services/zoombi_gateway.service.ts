/* eslint-disable quote-props */
/* eslint-disable @typescript-eslint/explicit-function-return-type */
import * as https from 'https'
// import * as request from 'request'

export class GatewayLoginService {
  public body: string

  public async backendLoginCall (): Promise<any> {
    const parametroUrl = 'https://backend.kmm.com.br'
    const url = parametroUrl.substring(parametroUrl.indexOf('//') + 2)

    const options = {
      host: url,
      path: '/_remote/gateway.php',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: {
        module: 'LOGON',
        operation: 'LOGON',
        parameters: {
          username: 'kmm_bi',
          password: 'kmm2014',
          cod_gestao: 9,
          plataforma_tipo: 3
        }
      }
    }

    const data = await this.send(options)
    return data.result ? data.result : data
  }

  async send (options: any): Promise<any> {
    return new Promise((resolve, reject) => {
      const req = https.request(options, (res) => {
        let data = ''

        res.on('data', (chunk) => {
          data += chunk
        })
        res.on('end', () => {
          resolve(JSON.parse(data))
        })
      }).on('error', (err) => {
        reject(err)
        console.log('Error: ', err.message)
      })
      req.write((JSON.stringify(options.body)))
      req.end()
    })
  }
}
