/* eslint-disable camelcase */
/* eslint-disable @typescript-eslint/camelcase */
import mongoose from 'mongoose'

export class ZoombiSessionService {

  private readonly collection_time = 'zoombi_session_time'
  private readonly collection_session = 'zoombi_session'

  public async insertSession (req): Promise<boolean> {
    const tgSchema = new mongoose.Schema({}, { strict: false, _id: false })
    let tg
    try {
      tg = mongoose.model(this.collection_session)
    } catch (error) {
      tg = mongoose.model(this.collection_session, tgSchema, this.collection_session)
    }

    const id = {
      base: req.base,
      usuario: req.usuario,
      ip: req.ip
    }

    const date = new Date()

    if (await tg.updateOne({ _id: id }, {
      usuario: req.usuario,
      base: req.base,
      pacote: req.pacote,
      assunto: req.assunto,
      aba: req.aba,
      ip: req.ip,
      date_insert: new Date(date.setHours(date.getHours() - 3))

    }, { upsert: true })) {
      return true
    }
    return false
  }

  public async insertTimeSession (req): Promise<any> {

    const nowDate = new Date()
    const now = new Date(nowDate.setHours(nowDate.getHours() - 3))
    const oldDate = new Date(req.date_insert)
    const newDate = (now - oldDate)

    const acesso = {
      base: req.base,
      usuario: req.usuario,
      pacote: req.pacote,
      assunto: req.assunto,
      aba: req.aba,
      ip: req.ip,
      segundos: Number((newDate / 1000).toFixed(0)),
      data_entrada: oldDate,
      data_saida: nowDate
    }

    const tgSchema = new mongoose.Schema({}, { strict: false, _id: false })
    let tg
    try {
      tg = mongoose.model(this.collection_time)
    } catch (error) {
      tg = mongoose.model(this.collection_time, tgSchema, this.collection_time)
    }

    await tg.collection.insertOne(acesso, (err) => {
      if (err) {
        return console.error(err)
      }
    })
  }

  public async find (params): Promise<any> {
    const tgSchema = new mongoose.Schema({}, { strict: false, _id: false })
    let tg
    try {
      tg = mongoose.model(this.collection_session)
    } catch (error) {
      tg = mongoose.model(this.collection_session, tgSchema, this.collection_session)
    }
    const res = await tg.find({ _id: { base: params.base, usuario: params.usuario, ip: params.ip } }, (err) => {
      if (err) {
        return console.error(err)
      }
    })

    return res !== undefined && res.length > 0 ? res[0]._doc : []
  }

  public async delete (req): Promise<any> {
    const tgSchema = new mongoose.Schema({}, { strict: false, _id: false })
    let tg
    try {
      tg = mongoose.model(this.collection_session)
    } catch (error) {
      tg = mongoose.model(this.collection_session, tgSchema, this.collection_session)
    }

    const id = {
      base: req.base,
      usuario: req.usuario,
      ip: req.ip
    }

    if (await tg.deleteOne({ _id: id })) {
      return true
    }
    return false
  }

}
