/* eslint-disable no-unused-vars */
/* eslint-disable camelcase */
/* eslint-disable dot-notation */
/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable no-undef */

import { ReturnComponents } from '../../../componentes/return.components'
import { FaturamentoService } from '../service/faturamento.service'

export class FaturamentoPage {
  private _service = new FaturamentoService();
  private _component = new ReturnComponents();

  public async getPage (req: object): Promise<object> {
    const sort = { valor: -1 }
    let filter: any = {}

    filter = Object.assign({}, req)
    const lista_manutencao_os = await this._service.findAll(filter, { DATA_ABERTURA: -1 } )
    const res_lista_manutencao_os = await this._component.getLowerCase(lista_manutencao_os)
    
 

console.log('lista_manutencao_os',lista_manutencao_os)

    const obj: any = {
        lista_manutencao_os: res_lista_manutencao_os,
        
    }


    return obj
  }
}

export default new FaturamentoPage()
