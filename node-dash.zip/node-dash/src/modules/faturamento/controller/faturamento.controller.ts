import { FaturamentoPage } from '../resolvers/faturamento.page'
import { FaturamentoService } from '../service/faturamento.service'
import { GatewayService } from '../../../services/gateway.service'

class FaturamentoController {
  private _page = new FaturamentoPage()
  private _service = new FaturamentoService()
  private _gatewayService = new GatewayService()

  public async getFaturamento (req: object, socket): Promise<void> {

    req.base = req.base === 'ciaverdelog' ? 'viaverde' : req.base
    
    const logInicio = new Date()
    let retorno
    const exist = await this._service.exists(req.base)

    if (exist) {
      retorno = await this._page.getPage(req)
    }

    else {
      if (req.token && req.url) {
        retorno = await this._gatewayService.backendCall(req, 'M4002', 'getFaturamento')
      }
    }

    console.log('faturamento_v2', req.base, 'faturamento_v2:', (new Date() - logInicio) / 1000, 'segundos')

    socket.emit('faturamento_v2', retorno)
  }
}

export default new FaturamentoController()