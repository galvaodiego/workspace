
import mongoose from 'mongoose'
import { NivelServicoGroup } from './nivel-servico.group'

export class NivelServicoService {
  private _nivelServicoGroup = new NivelServicoGroup();

  async aggregate (req, agrupador, sort, limit?): Promise<object> {
    this._nivelServicoGroup.setMatch(req)
    this._nivelServicoGroup.setGroup(agrupador)

    const tgSchema = new mongoose.Schema({}, { strict: false })
    let tg

    try {
      tg = mongoose.model('dash_nivel_servico_' + req.base)
    } catch (error) {
      tg = mongoose.model('dash_nivel_servico_' + req.base, tgSchema, 'dash_nivel_servico_' + req.base)
    }

    const res = !limit ? await tg.aggregate([{ $match: this._nivelServicoGroup.match }, { $group: this._nivelServicoGroup.group }]).sort(sort) :
      await tg.aggregate([{ $match: this._nivelServicoGroup.match }, { $group: this._nivelServicoGroup.group }]).sort(sort).limit(limit)

    this._nivelServicoGroup.cleanGroup()
    this._nivelServicoGroup.cleanMath()

    return res
  }
}
