/* eslint-disable camelcase */
/* eslint-disable @typescript-eslint/camelcase */
import { NivelServicoService } from './nivel-servico.service'
import { ReturnComponents } from '../../componentes/return.components'

export class NivelServicoController {
  public async getNivelServico (req: object, socket: Socket): Promise<object> {
    const logInicio = new Date()

    const _service = new NivelServicoService()
    const _component = new ReturnComponents()
    const sort = { valor: -1 }

    req = { base: req.base, situacao_viagem: ['viagem'] }
    const viagem = await _service.aggregate(req, ['situacao_viagem', 'centro_custo', 'num_romaneio', 'origem', 'destino', 'placa'], sort)
    const resViagem = await _component.getRenameColumns(viagem,
      ['situacao_viagem', 'centro_custo', 'num_romaneio', 'origem', 'destino', 'placa', 'atrasado', 'previsto', 'possibilidade_atraso', 'nivel_servico'],
      ['status', 'centro_custo', 'num_romaneio', 'origem', 'destino', 'placa', 'atrasado', 'previsto', 'possibilidade_atraso', 'nivel_servico'])

    req = { base: req.base, situacao_viagem: ['descarga'] }
    const descarga = await _service.aggregate(req, ['situacao_viagem', 'centro_custo', 'num_romaneio', 'origem', 'destino', 'placa'], sort)
    const resDescarga = await _component.getRenameColumns(descarga,
      ['situacao_viagem', 'centro_custo', 'num_romaneio', 'origem', 'destino', 'placa', 'atrasado', 'previsto', 'possibilidade_atraso', 'nivel_servico'],
      ['status', 'centro_custo', 'num_romaneio', 'origem', 'destino', 'placa', 'atrasado', 'previsto', 'possibilidade_atraso', 'nivel_servico'])

    req = { base: req.base, situacao_viagem: ['carga'] }
    const carga = await _service.aggregate(req, ['situacao_viagem', 'centro_custo', 'num_romaneio', 'origem', 'destino', 'placa'], sort)
    const resCarga = await _component.getRenameColumns(carga,
      ['situacao_viagem', 'centro_custo', 'num_romaneio', 'origem', 'destino', 'placa', 'atrasado', 'previsto', 'possibilidade_atraso', 'nivel_servico'],
      ['status', 'centro_custo', 'num_romaneio', 'origem', 'destino', 'placa', 'atrasado', 'previsto', 'possibilidade_atraso', 'nivel_servico'])

    req = { base: req.base, situacao_viagem: ['vazio_destinado'] }
    const vazio_destinado = await _service.aggregate(req, ['situacao_viagem', 'centro_custo', 'num_romaneio', 'origem', 'destino', 'placa'], sort)
    const resVazioDestinado = await _component.getRenameColumns(vazio_destinado,
      ['situacao_viagem', 'centro_custo', 'num_romaneio', 'origem', 'destino', 'placa', 'qtde_vazio', 'qtde_destinado', 'qtde'],
      ['status', 'centro_custo', 'num_romaneio', 'origem', 'destino', 'placa', 'vazio_improdutivo', 'vazio_programado', 'total'])

    req = { base: req.base }
    const indicador1 = await _service.aggregate(req, ['situacao_viagem'], sort)
    const resIndicador1 = await _component.getRenameColumns(indicador1, ['situacao_viagem', 'qtde', 'atrasado', 'previsto', 'possibilidade_atraso', 'qtde_vazio', 'qtde_destinado'], ['situacao_viagem', 'qtde', 'atrasado', 'previsto', 'possibilidade_atraso', 'qtde_vazio', 'qtde_destinado'])

    const indicador2 = await _service.aggregate(req, [''], sort)
    const resIndicador2 = await _component.getRenameColumns(indicador2, ['qtde', 'atrasado', 'previsto', 'possibilidade_atraso', 'qtde_vazio', 'qtde_destinado'], ['qtde', 'atrasado', 'previsto', 'possibilidade_atraso', 'qtde_vazio', 'qtde_destinado'])
    const resAtualizacao = indicador2 && indicador2.length > 0 ? indicador2[0].last_update : 0


    const retorno: any = {
      atualizacao: resAtualizacao,
      indicador: {
        viagem: await this.search(resIndicador1.dados, 'viagem', 'qtde'),
        descarga: await this.search(resIndicador1.dados, 'descarga', 'qtde'),
        carga: await this.search(resIndicador1.dados, 'carga', 'qtde'),
        vazio: await this.search(resIndicador1.dados, 'vazio_destinado', 'qtde_vazio'),
        destinado: await this.search(resIndicador1.dados, 'vazio_destinado', 'qtde_destinado'),
        previsto: await this.search(resIndicador2.dados, null, 'previsto'),
        possibilidade_atraso: await this.search(resIndicador2.dados, null, 'possibilidade_atraso'),
        atrasado: await this.search(resIndicador2.dados, null, 'atrasado')
      },
      lista: {
        viagem: resViagem ? resViagem.dados : [],
        descarga: resDescarga ? resDescarga.dados : [],
        carga: resCarga ? resCarga.dados : [],
        vazio_destinado: resVazioDestinado ? resVazioDestinado.dados : []
      }
    }

    console.log('base', req.base, 'Nivel de Servico: ', (new Date() - logInicio) / 1000, 'segundos')
    socket.emit('nivel_servico', retorno)
  }

  private async search (data, filter, value): number {
    let row = []
    if (filter) {
      row = data.find(x => x.situacao_viagem === filter)
    } else {
      row = data ? data[0] : []
    }
    return row ? row[value] : 0
  }
}

export default new NivelServicoController()
