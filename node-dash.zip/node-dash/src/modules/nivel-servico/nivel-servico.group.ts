/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/camelcase */

export class NivelServicoGroup {
  public group
  public match

  constructor () {
    this.initGroup()
    this.initMatch()
  }

  private initGroup (): any {
    const group = {
      _id: {
        situacao_viagem: '$SITUACAO_VIAGEM',
        centro_custo: '$CENTRO_CUSTO',
        num_romaneio: '$NUM_ROMANEIO',
        origem: '$ORIGEM',
        destino: '$DESTINO',
        placa: '$PLACA_TRACAO'

      },
      last_update: { $max: '$DATA_CARGA' },
      qtde: { $sum: '$QTDE' },
      previsto: { $sum: '$PREVISTO' },
      possibilidade_atraso: { $sum: '$POSSIBILIDADE_ATRASO' },
      atrasado: { $sum: '$ATRASADO' },
      nivel_servico: { $sum: '$NIVEL_SERVICO' },
      qtde_vazio: { $sum: '$QTDE_VAZIO' },
      qtde_destinado: { $sum: '$QTDE_DESTINADO' }
    }

    this.group = group
  }

  private initMatch (): any {
    const match = {
      SITUACAO_VIAGEM: null,
      CENTRO_CUSTO: null

    }
    this.match = match
  }

  public setMatch (req): void {
    this.match.SITUACAO_VIAGEM = req.situacao_viagem ? { $in: req.situacao_viagem } : null
    this.match.CENTRO_CUSTO = req.centro_custo ? { $in: req.centro_custo } : null

    Object.keys(this.match).forEach((key) => (this.match[key] == null) && delete this.match[key])
  }

  public setGroup (group: Array<string>): void {
    const obj = JSON.parse(JSON.stringify(this.group))
    Object.keys(obj._id).forEach((key) => (!group.includes(key)) && delete obj._id[key])
    this.group = obj
  }

  public cleanGroup (): void {
    this.initGroup()
  }

  public cleanMath (): void {
    this.initMatch()
  }
}

export default new NivelServicoGroup()
