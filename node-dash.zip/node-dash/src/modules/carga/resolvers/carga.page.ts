/* eslint-disable no-unused-vars */
/* eslint-disable camelcase */
/* eslint-disable dot-notation */
/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable no-undef */

import { ReturnComponents } from '../../../componentes/return.components'
import { CargaService } from '../service/carga.service'

export class CargaPage {
  private _service = new CargaService();
  private _component = new ReturnComponents();

  public async getPage (req: object): Promise<object> {
    const sort = { valor: -1 }
    let filter: any = {}


    filter = Object.assign({}, req, { status: 'Viagem', possui_doc: 0 })
    const aguardandoCte = await this._service.findAll(filter, { PREVISAO_CHEGADA_GRADE: -1 }, ['CCG CLIENTE DATA_TERMINO_CARGA DESTINO FROTA IDENTIFICADOR NUM_ROMANEIO ORIGEM PLACA_CARRETA PLACA_TRACAO TEMPO_ESPERA STATUS PREVISAO_CHEGADA_GRADE TEMPO_ATRASO TEMPO_MIN GESTAO COD_GESTAO'])
    const resAguardandoCte = await this._component.getLowerCase(aguardandoCte)

    filter = Object.assign({}, req, { status: 'Destinado' })
    const atrasado = await this._service.findAll(filter, { TEMPO_MIN: 1 }, ['CCG CLIENTE DESTINO IDENTIFICADOR NUM_ROMANEIO ORIGEM PLACA_CARRETA PLACA_TRACAO STATUS PREVISAO_CARGA TEMPO_ESPERA TEMPO_MIN GESTAO COD_GESTAO'])
    const resAtraso = await this._component.getLowerCase(atrasado)

    const indicadores = await this._service.aggregate(req, [''], sort)
    const resAtualizacao = indicadores && indicadores.length > 0 ? indicadores[0].last_update : 0

    // Indicadores
    filter = Object.assign({}, req, { status: 'Destinado', previsto: 1 })
    const previsto = await this._service.aggregate(filter, ['status'], sort)

    filter = Object.assign({}, req, { status: 'Destinado', atrasado: 1 })
    const qtde_atrasado = await this._service.aggregate(filter, [''], sort)

    filter = Object.assign({}, req, { status: 'Viagem', possui_doc: 0 })
    const aguardando = await this._service.aggregate(filter, [''], sort)

    filter = Object.assign({}, req, { status: 'Destinado' })
    const destinado = await this._service.aggregate(filter, [''], sort)

    const resIndicadores = [{
      qtd_previstos: previsto && previsto.length > 0 ? previsto[0].total : 0,
      qtd_atrasados: qtde_atrasado && qtde_atrasado.length > 0 ? qtde_atrasado[0].total : 0,
      qtd_aguardando_ctes: aguardando && aguardando.length > 0 ? aguardando[0].total : 0,
      qtd_destinados: destinado && destinado.length > 0 ? destinado[0].total : 0,
    }]

    const obj: any = {
      telacarga: {
        aguardandoCte: resAguardandoCte,
        cargaAtraso: resAtraso,
        carga_indicadores: resIndicadores,
        atualizacao: resAtualizacao
      }
    }

    return obj
  }
}

export default new CargaPage()
