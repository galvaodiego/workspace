/* eslint-disable camelcase */
/* eslint-disable @typescript-eslint/explicit-function-return-type */
/* eslint-disable no-self-assign */
/* eslint-disable @typescript-eslint/camelcase */

export class CargaModel {
  public group
  public match

  constructor () {
    this.initGroup()
    this.initMatch()
  }

  private initGroup () {

    const group = {
      _id: {
        status: '$STATUS',
        gestao: '$GESTAO',
        cod_gestao: '$COD_GESTAO'
      },

      last_update: { $max: '$DATA_CARGA' },
      total: { $sum: 1 }
    }
    this.group = group
  }

  private initMatch () {
    const match = {
      STATUS: null,
      CLIENTE: null,
      GESTAO: null,
      MACRO_DESCRICAO: null,
      ATRASADO: null,
      PREVISTO: null,
      POSSUI_DOC: null
    }
    this.match = match
  }

  public setMatch (req): void {

    this.match.STATUS = req.status ? { $eq: req.status } : null
    this.match.POSSUI_DOC = req.possui_doc !== null ? { $eq: req.possui_doc } : null
    this.match.COD_GESTAO = req.cod_gestao ? { $eq: req.cod_gestao } : null
    this.match.GESTAO = req.gestao ? { $eq: req.cod_gestao } : null
    this.match.ATRASADO = req.atrasado ? { $eq: req.atrasado } : null
    this.match.PREVISTO = req.previsto ? { $eq: req.previsto } : null

    Object.keys(this.match).forEach((key) => (this.match[key] == null) && delete this.match[key])
  }

  public setGroup (group: Array<string>): void {
    const obj = JSON.parse(JSON.stringify(this.group))
    Object.keys(obj._id).forEach((key) => (!group.includes(key)) && delete obj._id[key])
    this.group = obj
  }

  public cleanGroup (): void {
    this.initGroup()
  }

  public cleanMath (): void {
    this.initMatch()
  }
}

export default new CargaModel()
