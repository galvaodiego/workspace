/* eslint-disable camelcase */
/* eslint-disable @typescript-eslint/explicit-function-return-type */
/* eslint-disable no-self-assign */
/* eslint-disable @typescript-eslint/camelcase */

export class OficinaModel {
  public group
  public match
  public addToSet

  constructor () {
    this.initGroup()
    this.initMatch()
  }

  private initGroup () {

    const group = {
      _id: {
        box_id: '$BOX_ID',
        descricao: '$DESCRICAO',
        situacao_id: '$SITUACAO_ID',
        status: '$STATUS_BOX'
      },

      last_update: { $max: '$DATA_CARGA' },
      countOs: { $sum: 1 }
    }
    this.group = group
  }

  private initMatch () {
    const match = {
      COD_ORGANOGRAMA: null,
      RETORNO: null,
      USUARIO: null
    }
    this.match = match
  }

  public setMatch (req): void {

    this.match.COD_ORGANOGRAMA = req.organograma ? { $eq: req.organograma } : null
    this.match.COD_CENTRO_CUSTO = req.cod_centro_custo ? { $eq: req.cod_centro_custo } : null
    this.match.USUARIO = req.usuario && req.filterUser !== undefined ? { $eq: req.usuario.toUpperCase() } : null
    this.match.RETORNO = req.retorno ? { $eq: req.retorno } : null

    Object.keys(this.match).forEach((key) => (this.match[key] == null) && delete this.match[key])
  }

  public setGroup (group: Array<string>): void {
    const obj = JSON.parse(JSON.stringify(this.group))
    Object.keys(obj._id).forEach((key) => (!group.includes(key)) && delete obj._id[key])
    this.group = obj
  }

  public cleanGroup (): void {
    this.initGroup()
  }

  public cleanMath (): void {
    this.initMatch()
  }

}

export default new OficinaModel()
