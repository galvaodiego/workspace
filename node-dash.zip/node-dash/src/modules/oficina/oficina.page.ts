/* eslint-disable no-unused-expressions */
/* eslint-disable no-unused-vars */
/* eslint-disable camelcase */
/* eslint-disable dot-notation */
/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable no-undef */

import { ReturnComponents } from '../../componentes/return.components'
import { OficinaService } from './oficina.service'

export class OficinaPage {
  private _service = new OficinaService();
  private _component = new ReturnComponents();

  public async getPage (req: object): Promise<object> {
    const sort = { valor: -1 }
    let filter: any = {}

    filter = Object.assign({}, req, { filterUser: 1 })
    const users = await this._service.findOrganograma(filter, sort)
    const user = await this._component.getLowerCase(users)
  
    const user_centro_custo = user && user.length > 0 ? user[0].cod_centro_custo : null

    filter = Object.assign({}, req, { retorno: 'mecanicos_disponiveis' })
    const mecanicos = await this._service.findAll(filter, { MECANICO: 1 }, ['MECANICO'])
    const listaMecanicos = await this._component.getLowerCase(mecanicos)

    filter = Object.assign({}, req, { retorno: 'ordem_servico', cod_centro_custo: user_centro_custo })
    const os = await this._service.findAll(filter, { DATA_ABERTURA: -1 }, ['ATRASADA DATA_LIBERACAO DATA_ABERTURA NUM_ORDEM_SERVICO ORDEM_SERVICO_ID PLACA'])
    const listaOs = await this._component.getLowerCase(os)

    filter = Object.assign({}, req, { retorno: 'os_indicadores', cod_centro_custo: user_centro_custo })
    const osIndicadores = await this._service.findAll(filter, { QUANTIDADE: -1 }, ['SITUACAO QUANTIDADE'])
    const listaOsIndicadores = await this._component.getLowerCase(osIndicadores)

    const listaBoxes:any = await this._service.aggregateAddToset(req, ['box_id', 'descricao', 'situacao_id', 'status'], { _id: { box_id: 1 } })
    const removeListaNull = await this.getRemoveArrayNull(listaBoxes, 'os', 'countOs')

    const indicadores = await this._service.aggregate(req, [''], sort)
    const resAtualizacao = indicadores && indicadores.length > 0 ? indicadores[0].last_update : 0

    const obj: any = {
      oficina: {
        boxes: removeListaNull,
        mecanicos_disponiveis: listaMecanicos,
        ordem_servico: listaOs,
        os_indicadores: listaOsIndicadores,
        atualizacao: resAtualizacao
      }
    }

    return obj
  }

  private async getRemoveArrayNull (data: Array<any>, key, value): Promise<any> {

    if (data && data.length > 0) {
      data.forEach(element => {

        Object.assign(element, {
          [key]: element[value] > 0 ? element[key] : []
        }, delete element[key])
      })
    }
    return data
  }
}

export default new OficinaPage()
