/* eslint-disable quote-props */

import mongoose from 'mongoose'
import { MongoHelper } from '../../helpers/mongo-helper'
import logger from '../../logger'
import { OficinaModel } from './oficina.model'

export class OficinaService {
  private _model = new OficinaModel();
  private dash = 'dash_oficina_'

  async aggregate (req, agrupador, sort, limit?): Promise<object> {
    this._model.setMatch(req)
    this._model.setGroup(agrupador)

    const tgSchema = new mongoose.Schema({}, { strict: false })
    let tg
    let result
    try {
      tg = mongoose.model(this.dash + req.base)
    } catch (error) {
      tg = mongoose.model(this.dash + req.base, tgSchema, this.dash + req.base)
    }

    try {
      result = !limit ? await tg.aggregate([{ $match: this._model.match }, { $group: this._model.group }]).sort(sort) :
        await tg.aggregate([{ $match: this._model.match }, { $group: this._model.group }]).sort(sort).limit(limit)
    } catch (error) {
      logger.error(error + ' path: oficina.service line 29')
    }

    this._model.cleanGroup()
    this._model.cleanMath()

    return MongoHelper.map(result)
  }

  async findAll (req, sort, select?, limit?): Promise<object> {
    let result
    this._model.setMatch(req)

    const tgSchema = new mongoose.Schema({}, { strict: false })
    let tg
    try {
      tg = mongoose.model(this.dash + req.base)
    } catch (error) {
      tg = mongoose.model(this.dash + req.base, tgSchema, this.dash + req.base)
    }

    try {
      result = !select ? await tg.find(this._model.match).sort(sort) : await tg.find(this._model.match).select('roll ' + select).sort(sort) //.limit(limit)
    } catch (error) {
      logger.error(error + ' path: oficina.service line 53')
    }

    this._model.cleanMath()

    return MongoHelper.mapFindAll(result)
  }

  async exists (base): Promise<boolean> {
    const tgSchema = new mongoose.Schema({}, { strict: false })
    let tg
    let result

    try {
      tg = mongoose.model(this.dash + base)
    } catch (error) {
      tg = mongoose.model(this.dash + base, tgSchema, this.dash + base)
    }

    try {
      result = await tg.exists()
    } catch (error) {
      logger.error(error + ' path: oficina.service line 75')
    }

    return result
  }

  async findOrganograma (req, sort, select?, limit?): Promise<object> {
    this._model.setMatch(req)
    const dash = 'dash_organograma_'

    let result

    const tgSchema = new mongoose.Schema({}, { strict: false })
    let tg
    try {
      tg = mongoose.model(dash + req.base)
    } catch (error) {
      tg = mongoose.model(dash + req.base, tgSchema, dash + req.base)
    }
    try {
      result = !select ? await tg.find(this._model.match).sort(sort) : await tg.find(this._model.match).select('roll ' + select).sort(sort) //.limit(limit)
    } catch (error) {
      logger.error(error + ' path: oficina.service line 97')
    }

    this._model.cleanMath()

    return result
  }

  async aggregateAddToset (req, agrupador, sort, limit?): Promise<object> {
    this._model.setMatch(req)
    this._model.setGroup(agrupador)

    const tgSchema = new mongoose.Schema({}, { strict: false })
    let tg
    let result

    try {
      tg = mongoose.model(this.dash + req.base)
    } catch (error) {
      tg = mongoose.model(this.dash + req.base, tgSchema, this.dash + req.base)
    }

    try {
      result = await tg.aggregate(
        [
          {
            '$match': {
              'RETORNO': 'boxes',
              'COD_ORGANOGRAMA': '27'
            }
          }, {
            '$group': {
              '_id': {
                'box_id': '$BOX_ID',
                'descricao': '$DESCRICAO',
                'situacao_id': '$SITUACAO_ID',
                'status': '$STATUS_BOX'
              },
              'countOs': { '$sum': { '$cond': [{ '$ne': ['$NUM_OS', null] }, 1, 0] } },
              'os': {
                '$addToSet': {
                  'data_abertura': '$DATA_ABERTURA',
                  'data_atendimento': '$DATA_ATENDIMENTO',
                  'mecanico': '$MECANICO',
                  'num_os': '$NUM_OS',
                  'ordem_servico_id': '$ORDEM_SERVICO_ID',
                  'placa': '$PLACA',
                  'previsao_liberacao': '$PREVISAO_LIBERACAO',
                  'status_box': '$STATUS_BOX',
                  'status_os': '$STATUS_OS'
                }
              }
            }
          }
        ]).sort(sort)
    } catch (error) {
      logger.error(error + ' path: oficina.service line 153')
    }

    this._model.cleanGroup()
    this._model.cleanMath()

    return MongoHelper.map(result)
  }
}
