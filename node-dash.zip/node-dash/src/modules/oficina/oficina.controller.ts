import { OficinaPage } from './oficina.page'
import { OficinaService } from './oficina.service'
import { GatewayService } from '../../services/gateway.service'

class OficinaController {
  private _page = new OficinaPage()
  private _service = new OficinaService()
  private _gatewayService = new GatewayService()

  public async getOficina (req: object, socket): Promise<void> {

    const logInicio = new Date()
    let retorno
    const exist = await this._service.exists(req.base)

    if (exist) {
      retorno = await this._page.getPage(req)
    }
    else {
      if (req.token && req.url) {
        retorno = await this._gatewayService.backendCall(req, 'M4002', 'getOficinaBoxes')
      }
    }

    console.log('oficina', req.base, 'Oficina:', (new Date() - logInicio) / 1000, 'segundos')

    socket.emit('oficina', retorno)
  }
}

export default new OficinaController()
