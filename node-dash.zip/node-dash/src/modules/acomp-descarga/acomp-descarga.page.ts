/* eslint-disable no-unused-vars */
/* eslint-disable camelcase */
/* eslint-disable dot-notation */
/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable no-undef */

import { ReturnComponents } from '../../componentes/return.components'
import { AcompDescargaService } from './acomp-descarga.service'

export class AcompDescargaPage {
  private _service = new AcompDescargaService();
  private _component = new ReturnComponents();

  public async getPage (req: object): Promise<object> {
    const sort = { valor: -1 }
    let filter: any = {}
 

    const indicadores = await this._service.aggregate(req, [''], sort)
    const resAtualizacao = indicadores && indicadores.length > 0 ? indicadores[0].last_update : 0
    const resIndicadores = await this._component.getRenameColumns(indicadores, ['agendados_total_descarga', 'em_descarga',  'sem_agendamento'], ['agendados_total_descarga', 'em_descarga',  'sem_agendamento'])

    filter = Object.assign({}, req, { com_regiao: 1 })
    const regiao = await this._service.aggregate(filter, ['regiao'], sort)
    const renameRegiao = await this._component.getRenameColumns(regiao, ['regiao', 'agendados_total_descarga', 'sem_agendamento'], ['regiao', 'agendandos', 'em_descraga_sem_agendamento'])


     filter = Object.assign({}, req, { com_regiao: 1 })
     const lista = await this._service.findAll(filter, { TEMPO_MINUTOS: -1}, ['AGENDADO COORDENADOR FLAG FROTA PLACA_CONTROLE PLACA_REBOQUE REGIAO TEMPO_STATUS'])
     const resLista = await this._component.getLowerCase(lista)
    
    filter = Object.assign({}, req, { placa_grupo: 1, data_termino: 1 })
    const coordenador = await this._service.aggregate(filter, ['coordenador'], sort)
    const resCoordenador = await this._component.getRenameColumns(coordenador, ['coordenador', 'agendados', 'em_descarga_sem_agendamento'], ['coordenador', 'agendados', 'em_descarga_sem_agendamento'])

    const obj: any = {
      descarga: {
        agendamento_x_regiao: renameRegiao.dados,
        agendamento_x_coordenador: resCoordenador.dados,
        indicadores: resIndicadores,
        lista: resLista,
        atualizacao: resAtualizacao
      }
    }

    return obj
  }
}

export default new AcompDescargaPage()
