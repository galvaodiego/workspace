/* eslint-disable camelcase */
/* eslint-disable @typescript-eslint/explicit-function-return-type */
/* eslint-disable no-self-assign */
/* eslint-disable @typescript-eslint/camelcase */

export class AcompDescargaModel {
  public group
  public match

  constructor() {
    this.initGroup()
    this.initMatch()
  }

  private initGroup() {

    const group = {
      _id: {
        regiao: '$REGIAO',
        coordenador: '$COORDENADOR'
      },

      agendados_total_descarga: { $sum: '$AGENDADO' },
      em_descarga: { $sum: 1 },
      sem_agendamento: { $sum: { $cond: [{ $eq: ['$AGENDADO', 0 ]}, 1, 0] } },
      agendados: { $sum: '$PROX_VIAGEM' },
      em_descarga_sem_agendamento: { $sum: { $cond: [{ $eq: ['$PROX_VIAGEM', 0 ]}, 1, 0] } },
      last_update: { $max: '$DATA_CARGA' }

      

    }
    this.group = group
  }

  private initMatch() {
    const match = {
      REGIAO: null,
      VELOCIDADE: null,
      PLACA_GRUPO: null,
      DATA_TERMINO: null
    }
    this.match = match
  }

  public setMatch(req): void {

    this.match.REGIAO = req.com_regiao !== undefined ? { $ne: null }:  null
    this.match.PLACA_GRUPO = req.placa_grupo !== undefined ? { $eq: req.placa_grupo }: null
    this.match.DATA_TERMINO = req.data_termino !== undefined ? { $eq: null }: null
    // this.match.VELOCIDADE = req.velocidadeMin !== undefined && req.velocidadeMax !== undefined ? { $gte: req.velocidadeMin, $lte: req.velocidadeMax } : null


    Object.keys(this.match).forEach((key) => (this.match[key] == null) && delete this.match[key])
  }

  public setGroup(group: Array<string>): void {
    const obj = JSON.parse(JSON.stringify(this.group))
    Object.keys(obj._id).forEach((key) => (!group.includes(key)) && delete obj._id[key])
    this.group = obj
  }

  public cleanGroup(): void {
    this.initGroup()
  }

  public cleanMath(): void {
    this.initMatch()
  }
}

export default new AcompDescargaModel()
