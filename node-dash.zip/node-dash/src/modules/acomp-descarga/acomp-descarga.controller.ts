import { AcompDescargaPage } from './acomp-descarga.page'
import { AcompDescargaService } from './acomp-descarga.service'
import { GatewayService } from '../../services/gateway.service'

class AcompDescargaController {
  private _page = new AcompDescargaPage()
  private _service = new AcompDescargaService()
  private _gatewayService = new GatewayService()

  public async getAcompDescarga (req: object, socket): Promise<void> {

    const logInicio = new Date()
    let retorno
    const exist = await this._service.exists(req.base)

    if (exist) {
      retorno = await this._page.getPage(req)
    }
    else {
      if (req.token && req.url) {
        
        retorno = await this._gatewayService.backendCall(req, 'M4002', 'getKpiDescarga')
      }
    }

    console.log('acomp_descarga', req.base, 'AcompDescarga:', (new Date() - logInicio) / 1000, 'segundos')

    socket.emit('acomp_descarga', retorno)
  }
}

export default new AcompDescargaController()
