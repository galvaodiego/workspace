/* eslint-disable camelcase */
/* eslint-disable dot-notation */
/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable no-undef */

import { ReturnComponents } from '../../../componentes/return.components'
import { JornadaService } from '../service/jornada.service'

export class JornadaPage {
  private _service = new JornadaService();
  private _component = new ReturnComponents();

  public async getPage(req: object): Promise<object> {
    const sort = { valor: -1 }

    const indicadores = await this._service.aggregate(req, [''], sort)

    const grupo = await this._service.aggregate(req, ['grupo'], { '_id.grupo': 1 })
    const resGrupos = await this._component.getRenameColumns2(grupo, ['grupo'], ['grupo'])

    const status = await this._service.aggregate(req, ['macro', 'macro_ref'], { '_id.macro': 1 })
    
    const status_refactored = [
      status[3] ? status[3] : null,
      status[4] ? status[4] : null,
      status[0] ? status[0] : null,
      status[2] ? status[2] : null,
      status[1] ? status[1] : null,
      status[5] ? status[5] : null
    ]
    const filtered = status_refactored.filter(function (element) {
      return element != null;
    });
    
    const resStatus = (await this._component.getRenameColumns2(filtered, ['macro_ref', 'macro', 'total'], ['chave', 'macro', 'valor']))
  
    // ajustas macro parado e ver com galvao contagem
    const motoristas = await this._service.findAll(req, { '_id.inicio': 1 })
    const resMotorista = await this._component.getLowerCase(motoristas)

    const resAtualizacao = indicadores && indicadores.length > 0 ? indicadores[0].last_update : 0

    const obj: any = {
      jornada: [{
        grupos: resGrupos,
        motoristas: resMotorista,
        status: resStatus,
        atualizacao: resAtualizacao
      }]
    }

    return obj
  }
}

export default new JornadaPage()
