
import mongoose from 'mongoose'
import { JornadaModel } from '../model/jornada.model'
import { MongoHelper } from '../../../helpers/mongo-helper'

export class JornadaService {
  private _model = new JornadaModel();

  async aggregate (req, agrupador, sort, limit?): Promise<object> {
    this._model.setMatch(req)
    this._model.setGroup(agrupador)

    const tgSchema = new mongoose.Schema({}, { strict: false })
    let tg
    try {
      tg = mongoose.model('dash_jornada_' + req.base)
    } catch (error) {
      tg = mongoose.model('dash_jornada_' + req.base, tgSchema, 'dash_jornada_' + req.base)
    }

    const res = !limit ? await tg.aggregate([{ $match: this._model.match }, { $group: this._model.group }]).sort(sort) :
      await tg.aggregate([{ $match: this._model.match }, { $group: this._model.group }]).sort(sort).limit(limit)

    this._model.cleanGroup()
    this._model.cleanMath()

    return MongoHelper.map(res)
    // return res
  }

  async findAll (req, sort, limit?): Promise<object> {
    this._model.setMatch(req)

    const tgSchema = new mongoose.Schema({}, { strict: false })
    let tg
    try {
      tg = mongoose.model('dash_jornada_' + req.base)
    } catch (error) {
      tg = mongoose.model('dash_jornada_' + req.base, tgSchema, 'dash_jornada_' + req.base)
    }

    const res = !limit ? await tg.find(this._model.match).sort(sort) : await tg.find({ $match: this._model.match }).sort(sort).limit(limit)

    this._model.cleanMath()

    return res
  }

  async exists (base): Promise<boolean> {
    const tgSchema = new mongoose.Schema({}, { strict: false })
    let tg
    try {
      tg = mongoose.model('dash_jornada_' + base)
    } catch (error) {
      tg = mongoose.model('dash_jornada_' + base, tgSchema, 'dash_jornada_' + base)
    }

    const res = await tg.exists()

    return res
  }
}
