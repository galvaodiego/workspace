import { ViagensHistPage } from '../resolvers/viagens_hist_detalhes.page'
import { ViagensHistService } from '../service/viagens_hist_detalhes.service'
import { GatewayService } from '../../../services/gateway.service'

class ViagensHistController {
  private _page = new ViagensHistPage()
  private _service = new ViagensHistService()
  private _gatewayService = new GatewayService()

  public async getHistDetalhes (req: object, socket): Promise<void> {

    const logInicio = new Date()
    let retorno
    const exist = await this._service.exists(req.base)

    if (exist) {
      retorno = await this._page.getPage(req)
    }

    else {
      if (req.token && req.url) {//V
        retorno = await this._gatewayService.backendCall(req, 'M4002', 'getMapa')
      }
    }

    console.log('viagens_hist', req.base, 'viagens_hist:', (new Date() - logInicio) / 1000, 'segundos')

    socket.emit('viagens_hist', retorno) //mudar
  }
}

export default new ViagensHistController()