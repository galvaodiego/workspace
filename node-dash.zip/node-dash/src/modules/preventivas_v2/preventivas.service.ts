/* eslint-disable space-before-function-paren */
/* eslint-disable @typescript-eslint/no-explicit-any */
import mongoose, { Schema, Model } from 'mongoose'
export class PreventivasService {
  private dynamicSchema: Schema
  private preventivasModel: Model<any>
  private dash = 'dash_preventivas_'

  constructor(base: string) {
    this.dynamicSchema = new Schema({}, { strict: false })
    this.initModel(base)
  }

  private initModel(base: string): void {
    const m = this.dash + base + '_v2'
    try {
      this.preventivasModel = mongoose.model(m)
    } catch (error) {
      this.preventivasModel = mongoose.model(m, this.dynamicSchema, m)
    }
  }

  public async findAll(): Promise<any> {
    const res = await this.preventivasModel.find()
    return res
  }

  async exists(): Promise<boolean> {
    const res = await this.preventivasModel.exists()
    return res
  }
}
