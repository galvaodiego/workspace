/* eslint-disable no-unused-vars */
/* eslint-disable camelcase */
/* eslint-disable dot-notation */
/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable no-undef */
// pegar como vem hoje e colocar nos filtros de
// socket->controllet->page->service->model->getLowerCase
import { ReturnComponents } from '../../../componentes/return.components'
import { ViagensTempService } from '../service/viagens_temp.service'

export class ViagensTempPage {
  private _service = new ViagensTempService();
  private _component = new ReturnComponents();

  public async getPage (req: object): Promise<object> {
    const sort = { valor: -1 }
    let filter: string | (object & { status: string; })
   
    const local = 'pt-Br'
    const options_hours = { hour12: false, timeZone: 'America/Sao_Paulo' }

    function toLocaleDate (date: any){
      // const date_miliseconds = (new Date(date.valueOf(date) - date.getTimezoneOffset()*60000)).toISOString()
      const date_miliseconds = (new Date(date.valueOf(date))).toISOString()
      const date_brasil = date_miliseconds.slice(0, date_miliseconds.length -5)
      return date_brasil
    }
    


  
    

    //  filter = Object.assign({}, req, { status: 'Destinado' })
     const viagens_temp = await this._service.findAll(req, {}, ['_id NOTA_FISCAL NUM_ROMANEIO STATUS PLACA_REFERENCIA REFERENCIA DATA_ULTIMA_POSICAO TEMPERATURA_RASTREADOR FLAG_TEMPERATURA VELOCIDADE_RASTREADOR DATA_PREVISAO GRUPO_NEGOCIADOR COD_GRUPO_NEGOCIADOR DATA_CARGA']) // verificar o campo do sort
     const resViagens_temp = await this._component.getLowerCase(viagens_temp)
     const viagens_temp_uniq =  [...new Map(resViagens_temp.map(item => [item['num_romaneio'], item])).values()];
     const lista_viagens_temp_ajuste_data = viagens_temp_uniq.map(element => 
      {
        element.data_posicao = toLocaleDate(element.data_ultima_posicao)
        element.data_previsao = toLocaleDate(element.data_previsao)
        element.data_carga = toLocaleDate(element.data_carga)
        return  element
      })

      // console.log({viagens_temp})

     const lista = lista_viagens_temp_ajuste_data.sort((a,b) => (a.data_ultima_posicao > b.data_ultima_posicao ? 1: -1))

  // Indicadores
    const viagens_unique = resViagens_temp.filter(item =>item.status==='Viagem' )
    const viagens_unique_count = viagens_unique && viagens_unique.length > 0 ? viagens_unique.length : 0



    const carregamentos_unique = resViagens_temp.filter(item =>item.status==='Carga' )
    const carregamentos_unique_count = carregamentos_unique && carregamentos_unique.length > 0 ? carregamentos_unique.length : 0

    
    
    const descargas_unique = resViagens_temp.filter(item =>item.status==='Descarga' )
    const descargas_unique_count = descargas_unique && descargas_unique.length > 0 ? descargas_unique.length : 0
    

    const indicadores = [{
      viagens_atuais: viagens_unique_count,
      carregamentos_atuais: carregamentos_unique_count,
      descargas_atuais: descargas_unique_count,
      viagens_monitoradas: viagens_unique_count + carregamentos_unique_count+ descargas_unique_count
      
    }]

    const obj: any = {

      result: [
            {
              lista:lista,
              indicadores
            }]
    }

    return await obj
  }
}

export default new ViagensTempPage()
