/* eslint-disable camelcase */
/* eslint-disable @typescript-eslint/explicit-function-return-type */
/* eslint-disable no-self-assign */
/* eslint-disable @typescript-eslint/camelcase */

export class PlaygroundModel {
  public group
  public match

  constructor () {
    this.initGroup()
    this.initMatch()
  }

  private initGroup () {

    const group = {
      _id: {
        gestao: '$GESTAO',
        cod_gestao: '$COD_GESTAO'
      },

      last_update: { $max: '$DATA_CARGA' },
      total: { $sum: 1 }
    }

    this.group = group
  }

  private initMatch () {
    const match = {
      COD_GESTAO: null,
      GESTAO: null,
      COD_GRUPO_NEGOCIADOR: null
    }
    this.match = match
  }

  public setMatch (req): void {

    this.match.COD_GESTAO = req.cod_gestao ? { $eq: req.cod_gestao } : null
    this.match.GESTAO = req.gestao ? { $eq: req.cod_gestao } : null
    this.match.COD_GRUPO_NEGOCIADOR = req.cod_grupo_negociador && req.cod_grupo_negociador.length > 0 ? { $in: req.cod_grupo_negociador } : null
  
    Object.keys(this.match).forEach((key) => (this.match[key] == null) && delete this.match[key])
  }

  public setGroup (group: Array<string>): void {
    const obj = JSON.parse(JSON.stringify(this.group))
    Object.keys(obj._id).forEach((key) => (!group.includes(key)) && delete obj._id[key])
    this.group = obj
  }

  public cleanGroup (): void {
    this.initGroup()
  }

  public cleanMath (): void {
    this.initMatch()
  }
}

export default new PlaygroundModel()
