/* eslint-disable camelcase */
/* eslint-disable dot-notation */
/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable no-undef */

import { ReturnComponents } from '../../../componentes/return.components'
import { PlaygroundService } from '../service/playground_service'

export class PlaygroundPage {
  private _service = new PlaygroundService();
  private _component = new ReturnComponents();

  public async getPage (req: object): Promise<object> {
    const sort = { valor: -1 }

    const transit = await this._service.findAll(req, sort)
    const resTransit = await this._component.getLowerCase(transit)

    const obj: any = {
      Playground: resTransit,
    }

    return obj
  }
}

export default new PlaygroundPage()
