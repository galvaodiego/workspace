import { PlaygroundPage } from '../resolvers/playground_page'
import { PlaygroundService } from '../service/playground_service'
import { GatewayService } from '../../../services/gateway.service'

class PlaygroundController {
  private _page = new PlaygroundPage()
  private _service = new PlaygroundService()
  private _gatewayService = new GatewayService()

  public async getPlayground (req: object, socket): Promise<void> {
    
    req.base = req.base === 'ciaverdelog' ? 'viaverde' : req.base

    const logInicio = new Date()
    let retorno
    const exist = await this._service.exists(req.base)

    if (exist) {
      retorno = await this._page.getPage(req)
    }
    else {
      if (req.token && req.url) {
        retorno = await this._gatewayService.backendCall(req, 'M4002', 'getPlayground')
      }
    }

    console.log('playground', req.base, ':', (new Date() - logInicio) / 1000, 'segundos')

    socket.emit('playground', retorno)
  }
}

export default new PlaygroundController()
