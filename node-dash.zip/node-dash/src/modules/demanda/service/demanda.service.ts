
import mongoose from 'mongoose'

export class DemandaService {
  private readonly dash = 'dash_demanda_'

  async findAll (req, sort, select?, limit?): Promise<object> {

    let res
    const tgSchema = new mongoose.Schema({}, { strict: false })
    let tg
    try {
      tg = mongoose.model(this.dash + req.base)
    } catch (error) {
      tg = mongoose.model(this.dash + req.base, tgSchema, this.dash + req.base)
    }

    if (req.retorno) {
      res = !select ? await tg.find({ RETORNO: req.retorno }).sort(sort) : await tg.find({ RETORNO: req.retorno }).select('roll ' + select).sort(sort).limit(limit)
    } else {
      res = []
    }

    return res
  }

  async exists (base): Promise<boolean> {
    const tgSchema = new mongoose.Schema({}, { strict: false })
    let tg
    try {
      tg = mongoose.model(this.dash + base)
    } catch (error) {
      tg = mongoose.model(this.dash + base, tgSchema, this.dash + base)
    }

    const res = await tg.exists()

    return res
  }
}
