/* eslint-disable no-unused-vars */
/* eslint-disable camelcase */
/* eslint-disable dot-notation */
/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable no-undef */

import { ReturnComponents } from '../../../componentes/return.components'
import { DemandaService } from '../service/demanda.service';

export class DemandaPage {
  private _service = new DemandaService();
  private _component = new ReturnComponents();

  public async getPage (req: object): Promise<object> {
    const sort = { valor: -1 }
    let filter: any = {}

    filter = Object.assign({}, req, { retorno: 'indicadores_1' })
    const indicadores1 = await this._service.findAll(filter, sort, ['DATA TOTAL'])
    const resIndicadores1 = await this._component.getLowerCase(indicadores1)

    filter = Object.assign({}, req, { retorno: 'indicadores_2' })
    const indicadores2 = await this._service.findAll(filter, sort, ['TIPO TOTAL'])
    const resIndicadores2 = await this._component.getLowerCase(indicadores2)

    filter = Object.assign({}, req, { retorno: 'canceladas' })
    const canceladas = await this._service.findAll(filter, sort, ['TIPO TOTAL'])
    const resCanceladas = await this._component.getLowerCase(canceladas)

    filter = Object.assign({}, req, { retorno: 'modalidade_D' })
    const modalidade_D = await this._service.findAll(filter, sort, ['MODALIDADE TOTAL'])
    const resModalidade_D = await this._component.getLowerCase(modalidade_D)

    filter = Object.assign({}, req, { retorno: 'Modalidade_D_D3' })
    const Modalidade_D_D3 = await this._service.findAll(filter, sort, ['MODALIDADE TOTAL'])
    const resModalidade_D_D3 = await this._component.getLowerCase(Modalidade_D_D3)

    filter = Object.assign({}, req, { retorno: 'location' })
    const location = await this._service.findAll(filter, sort)
    const resLocation = await this._component.getLowerCase(location)

    const data = await this._service.findAll(filter, sort, ['DATA_CARGA'], 1)
    const resData = await this._component.getLowerCase(data)
    const resAtualizacao = resData && resData.length > 0 ? resData[0].data_carga : 0
    
    const obj: any = {
      mapaDiponibilidadeDemanda: {
        indicadores_1: resIndicadores1,
        indicadores_2: resIndicadores2,
        canceladas: resCanceladas,
        modalidade_D: resModalidade_D,
        Modalidade_D_D3: resModalidade_D_D3,
        location: resLocation,
        atualizacao: resAtualizacao
      }
    }

    return obj
  }
}

export default new DemandaPage()
