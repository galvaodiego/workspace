
import { GatewayService } from '../../../services/gateway.service'
import { DemandaPage } from '../resolvers/demanda.page'
import { DemandaService } from '../service/demanda.service'

class DemandaController {
  private _page = new DemandaPage()
  private _service = new DemandaService()
  private _gatewayService = new GatewayService()

  public async getDemanda (req: object, socket): Promise<void> {

    const logInicio = new Date()
    let retorno
    const exist = await this._service.exists(req.base)

    if (exist) {
      retorno = await this._page.getPage(req)
    }
    else {
      if (req.token && req.url) {
        retorno = await this._gatewayService.backendCall(req, 'M4002', 'getDemanda')
      }
    }

    console.log('demanda', req.base, ':', (new Date() - logInicio) / 1000, 'segundos')

    socket.emit('demanda', retorno)
  }
}

export default new DemandaController()
