import { ViagensTempPage } from '../resolvers/viagens_temp_detalhes.page'
import { ViagensTempService } from '../service/viagens_temp_detalhes.service'
import { GatewayService } from '../../../services/gateway.service'

class ViagensTempController {
  private _page = new ViagensTempPage()
  private _service = new ViagensTempService()
  private _gatewayService = new GatewayService()

  public async getViagensDetalhes (req: object, socket): Promise<void> {

    const logInicio = new Date()
    let retorno
    const exist = await this._service.exists(req.base)

    if (exist) {
      retorno = await this._page.getPage(req)
    }

    else {
      if (req.token && req.url) {//V
        retorno = await this._gatewayService.backendCall(req, 'M4002', 'getMapa')
      }
    }

    console.log('viagens_temp', req.base, 'viagens_temp:', (new Date() - logInicio) / 1000, 'segundos')

    socket.emit('viagens_temp', retorno) //mudar
  }
}

export default new ViagensTempController()