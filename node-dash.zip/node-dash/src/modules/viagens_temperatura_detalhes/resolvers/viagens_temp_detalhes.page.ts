/* eslint-disable no-unused-vars */
/* eslint-disable camelcase */
/* eslint-disable dot-notation */
/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable no-undef */
// pegar como vem hoje e colocar nos filtros de
// socket->controllet->page->service->model->getLowerCase
import { ReturnComponents } from '../../../componentes/return.components'
import { ViagensTempService } from '../service/viagens_temp_detalhes.service'

export class ViagensTempPage {
  private _service = new ViagensTempService();
  private _component = new ReturnComponents();

  public async getPage (req: object): Promise<object> {
    const sort = { valor: -1 }
    let filter: any = {}
    let viagens_temp
    let resViagens_temp
    const local = 'pt-Br'
    const options_date = {hour: '2-digit', minute:'2-digit'}
    const options_currency = {style: 'currency', currency: 'BRL'}

    function toLocaleDate (date: any){
      // const date_miliseconds = (new Date(date.valueOf(date) - date.getTimezoneOffset()*60000)).toISOString()
      const date_miliseconds = (new Date(date.valueOf(date))).toISOString()
      const date_brasil = date_miliseconds.slice(0, date_miliseconds.length -5)
      return date_brasil
    }

    function segParaHora(time: number, with_seg = true){
    
      var hours = Math.floor( time / 3600 );
      var minutes = Math.floor( (time % 3600) / 60 );
      var seconds = time % 60;
        
      minutes = minutes < 10 ? '0' + minutes : minutes;      
      seconds = seconds < 10 ? '0' + seconds : seconds;
      hours = hours < 10 ? '0' + hours : hours;
        
      if(with_seg){
         return  hours + ":" + minutes + ":" + seconds;
      }
        
      return  hours + ":" + minutes;
    }


      //  filter = Object.assign({}, req, { status: 'Destinado' })
      viagens_temp = await this._service.findAll(req,{}/*, ['_id INICIO_EVENTO PREVISAO_TERMINO REFERENCIA TEMPO_EM_EVENTO_SEGUNDOS NOTA_FISCAL MERCADORIA NUM_CONHECIMENTO TOTAL_CONHECIMENTO DATA_EMISSAO PLACA_REFERENCIA PLACA_CONTROLE MODELO RASTREADOR']*/) // verificar o campo do sort
      resViagens_temp = await this._component.getLowerCase(viagens_temp) 
      resViagens_temp = resViagens_temp && resViagens_temp.length > 0 ? resViagens_temp : [0]

      
      let lista_viagens  = await this._service.findHist(req,{}, ['DATA_POSICAO LANDMARK IGNICAO TEMPERATURA FLAG_TEMPERATURA VELOCIDADE _id']) 
      const resLista_viagens = await this._component.getLowerCase(lista_viagens) 
      const lista_viagens_ajuste_data = resLista_viagens.map(element => 
        {
          element.data_posicao = toLocaleDate(element.data_posicao)
          return  element
        })
      lista_viagens = lista_viagens_ajuste_data.sort((a,b) => (a.data_posicao > b.data_posicao ? 1: 1))

      // console.log('lista_viagens_ajuste_data', {lista_viagens_ajuste_data})

     
    // Status Logistico
    
    const inicio_evento = resViagens_temp !== [0] && resViagens_temp[0].inicio_evento ? (resViagens_temp[0].inicio_evento).toLocaleDateString(local,options_date) : ' '
    const referencia = resViagens_temp !== [0] && resViagens_temp[0].referencia ? resViagens_temp[0].referencia: 0 //ok
    const previsao_termino = resViagens_temp !== [0] && resViagens_temp[0].previsao_termino ? (resViagens_temp[0].previsao_termino).toLocaleDateString(local,options_date) : ' ' //ok
    const tempo_em_evento_horas = resViagens_temp !== [0] && resViagens_temp[0].tempo_em_evento_segundos ?  segParaHora(resViagens_temp[0].tempo_em_evento_segundos) : 0 //ok
    
    // Documento Fiscal 
    const unique_num_conhecimento_resumido = resViagens_temp !== [0] && resViagens_temp[0].num_conhecimento ? resViagens_temp[0].num_conhecimento.split('/',3).toString() : ' '
    const unique_num_conhecimento_count = resViagens_temp !== [0] && resViagens_temp[0].num_conhecimento ? resViagens_temp[0].num_conhecimento.split('/').length : 0
    let unique_num_conhecimento_extendido = resViagens_temp !== [0] && resViagens_temp[0].num_conhecimento ? resViagens_temp[0].num_conhecimento.split('/').toString():0



    const num_conhecimento_resumido = unique_num_conhecimento_resumido ? unique_num_conhecimento_resumido : 0//ok
    const num_conhecimento_extendido = unique_num_conhecimento_extendido ? unique_num_conhecimento_extendido : 0//ok

    const num_conhecimento = unique_num_conhecimento_extendido && unique_num_conhecimento_count > 3 ? { resumido: num_conhecimento_resumido, extendido: num_conhecimento_extendido} : {resumido: num_conhecimento_resumido}

    const data_emissao = resViagens_temp !== [0] && resViagens_temp[0].data_emissao ? (resViagens_temp[0].data_emissao).toLocaleDateString(local,options_date) : ' '//ok
    const total_conhecimento = resViagens_temp !== [0] && resViagens_temp[0].total_conhecimento ? (resViagens_temp[0].total_conhecimento).toLocaleString(local, options_currency) : ' '//ok

    
    // Mercadoria
    
    const unique_nota_fiscal_resumido = resViagens_temp !== [0] && resViagens_temp[0].nota_fiscal ? resViagens_temp[0].nota_fiscal.split('/',3).toString() :' '
    const unique_nota_fiscal_count = resViagens_temp !== [0] && resViagens_temp[0].nota_fiscal ? resViagens_temp[0].nota_fiscal.split('/').length :0
    let unique_nota_fiscal_extendido = resViagens_temp !== [0] && resViagens_temp[0].nota_fiscal ? resViagens_temp[0].nota_fiscal.split('/').toString() :0

    let notas_fiscais = unique_nota_fiscal_extendido && unique_nota_fiscal_count > 3 ? { resumido: unique_nota_fiscal_resumido, extendido: unique_nota_fiscal_extendido} : {resumido: unique_nota_fiscal_resumido}
    

    const unique_mercadoria_resumido =resViagens_temp !== [0] && resViagens_temp[0].mercadoria ? resViagens_temp[0].mercadoria.split('/',2).toString() : ' '
    const unique_mercadoria_count =resViagens_temp !== [0] && resViagens_temp[0].mercadoria ? resViagens_temp[0].mercadoria.split('/').length : 0
    let unique_mercadoria_extendido =resViagens_temp !== [0] && resViagens_temp[0].mercadoria ? resViagens_temp[0].mercadoria.split('/').toString() : 0

    let mercadoria= unique_mercadoria_extendido && unique_mercadoria_count > 3 ? { resumido: unique_mercadoria_resumido, extendido: unique_mercadoria_extendido} : {resumido: unique_mercadoria_resumido}



   
    // Veículos
    const placa_referencia = resViagens_temp !== [0] && resViagens_temp[0].placa_referencia ? resViagens_temp[0].placa_referencia : 0 //ok
    const modelo = resViagens_temp !== [0] && resViagens_temp[0].modelo ? resViagens_temp[0].modelo : 0 //ok
    const marca = resViagens_temp !== [0] && resViagens_temp[0].marca ? resViagens_temp[0].marca : 0 //ok
    const modelo_marca = modelo.toString() +" / "+marca.toString()
    const placa_controle = resViagens_temp !== [0] && resViagens_temp[0].placa_controle ? resViagens_temp[0].placa_controle : 0 //ok
    const rastreador = resViagens_temp !== [0] && resViagens_temp[0].rastreador ? resViagens_temp[0].rastreador : 0 //ok


        

    const obj: any = {
      indicadores:
      {
        status_logistico: {
          inicio_evento: inicio_evento,
          referencia: referencia,
          previsao_termino: previsao_termino,
          tempo_evento: tempo_em_evento_horas
        },
        documento_fiscal: {
          num_conhecimento: num_conhecimento,
          data_emissao: data_emissao,
          valor_documento: total_conhecimento,
        },
        mercadoria: {
          notas_fiscais: notas_fiscais,
          mercadoria: mercadoria
        },
        veiculos: {
          placa: placa_referencia,
          modelo_marca: modelo_marca,
          placa_carreta: placa_controle,
          rastreador: rastreador
        }
      },
      lista : lista_viagens
      
    }

    return obj
  }
}

export default new ViagensTempPage()
