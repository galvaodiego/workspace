/* eslint-disable camelcase */
/* eslint-disable @typescript-eslint/camelcase */
import { RotasService } from './rotas.service'
import { SessionService } from './session.service'
import { SessionTimeService } from './sessionTime.service'

class SessionController {
  private readonly sessioService
  private readonly urls = []
  private _rotasService = new RotasService()

  constructor () {
    this.sessioService = new SessionService()
    this.urls = this._rotasService.getRotas()
  }

  /**  Verifica se ulr etá mapeada
   *  Insere o ultimo acesso do usuário ou exclui caso a url não esteja mapeada
   */
  public async insertSession (base: string, usuario: string, url: string, modulo?:string): Promise<any> {

    const ultimoAcesso = await this.sessioService.find({ base: base, usuario: usuario })

    if (this.urls.includes(url) === true) {
      if (!!ultimoAcesso.url === true) {
        if (ultimoAcesso.url !== url) {
          this.insertTimeSession(ultimoAcesso.base, ultimoAcesso.usuario, ultimoAcesso.modulo, ultimoAcesso.url, ultimoAcesso.date_insert)
          Object.assign(ultimoAcesso, { modulo: modulo, url: url })
          this.sessioService.insert(ultimoAcesso)
        }
      }
      if (!!ultimoAcesso.url === false) {
        this.sessioService.insert({ base: base, usuario: usuario, modulo: modulo, url: url })
      }
    }
    if (this.urls.includes(url) === false) {
      if (!!ultimoAcesso.url === true) {
        await this.insertTimeSession(ultimoAcesso.base, ultimoAcesso.usuario, ultimoAcesso.modulo, ultimoAcesso.url, ultimoAcesso.date_insert)
        this.sessioService.delete({ base: ultimoAcesso.base, usuario: ultimoAcesso.usuario })
      }
    }
  }

  private async insertTimeSession (base: string, usuario: string, modulo: string, url: string, date_insert: Date): Promise<void> {
    const _sessionTimeService = new SessionTimeService()

    await _sessionTimeService.insert({ base: base, usuario: usuario, modulo: modulo, url: url, date_insert: date_insert })
  }
}

export default new SessionController()
