/* eslint-disable @typescript-eslint/camelcase */

import mongoose from 'mongoose'
export class SessionService {
  
  private readonly collection = 'session_dash'

  public async insert (req): Promise<boolean> {
    const tgSchema = new mongoose.Schema({}, { strict: false, _id: false })
    let tg
    try {
      tg = mongoose.model(this.collection)
    } catch (error) {
      tg = mongoose.model(this.collection, tgSchema, this.collection)
    }

    const id = {
      base: req.base,
      usuario: req.usuario
    }

    const date = new Date()

    if (await tg.updateOne({ _id: id }, {
      usuario: req.usuario,
      base: req.base,
      modulo: req.modulo,
      url: req.url,
      date_insert: new Date(date.setHours(date.getHours() - 3))

    }, { upsert: true })) {
      return true
    }
    return false
  }

  public async find (params): Promise<any> {
    const tgSchema = new mongoose.Schema({}, { strict: false, _id: false })
    let tg
    try {
      tg = mongoose.model(this.collection)
    } catch (error) {
      tg = mongoose.model(this.collection, tgSchema, this.collection)
    }


    const res = await tg.find({ _id: { base: params.base, usuario: params.usuario } }, (err) => {
      if (err) {
        return console.error(err)
      }
    })

    return res.length > 0 ? res[0]._doc : []
  }

  public async delete (req): Promise<any> {
    const tgSchema = new mongoose.Schema({}, { strict: false, _id: false })
    let tg
    try {
      tg = mongoose.model(this.collection)
    } catch (error) {
      tg = mongoose.model(this.collection, tgSchema, this.collection)
    }

    const id = {
      base: req.base,
      usuario: req.usuario
    }

    if (await tg.deleteOne({ _id: id })) {
      return true
    }
    return false
  }
}
