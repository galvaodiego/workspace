import mongoose from 'mongoose'

export class SessionTimeService {

  public async insert (req): Promise<any> {

    const nowDate = new Date()
    const now = new Date(nowDate.setHours(nowDate.getHours() - 3))
    const collection = 'sessionTime_dash'
    const oldDate = new Date(req.date_insert)
    const newDate = (now - oldDate)

    const acesso = {
      base: req.base,
      usuario: req.usuario,
      modulo: req.modulo,
      url: req.url,
      segundos: Number((newDate / 1000).toFixed(0)),
      data_entrada: oldDate,
      data_saida: nowDate
    }


    const tgSchema = new mongoose.Schema({}, { strict: false, _id: false })
    let tg
    try {
      tg = mongoose.model(collection)
    } catch (error) {
      tg = mongoose.model(collection, tgSchema, collection)
    }

    await tg.collection.insertOne(acesso, (err) => {
      if (err) {
        return console.error(err)
      }
    })
  }
}
