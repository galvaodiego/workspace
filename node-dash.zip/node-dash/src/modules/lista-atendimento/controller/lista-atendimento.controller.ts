
import { GatewayService } from '../../../services/gateway.service'
import { ListaAtendimentoPage } from '../resolvers/lista-atendimento.page'
import { ListaAtendimentoService } from '../service/lista-atendimentos.service'

class ListaAtendimentoController {
  private _page = new ListaAtendimentoPage()
  private _service = new ListaAtendimentoService()
  private _gatewayService = new GatewayService()

  public async getListaAtendimento (req: object, socket): Promise<void> {

    const logInicio = new Date()
    let retorno
    const exist = await this._service.exists(req.base)

    if (exist) {
      retorno = await this._page.getPage(req)
    }
    else {
      if (req.token && req.url) {
        retorno = await this._gatewayService.backendCall(req, 'M4002', 'getListaAtendimentos')
      }
    }

    console.log('lista_atendimento', req.base, ':', (new Date() - logInicio) / 1000, 'segundos')

    socket.emit('lista_atendimento', retorno)
  }
}

export default new ListaAtendimentoController()
