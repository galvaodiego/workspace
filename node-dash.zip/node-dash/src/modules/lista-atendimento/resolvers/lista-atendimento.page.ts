/* eslint-disable no-unused-vars */
/* eslint-disable camelcase */
/* eslint-disable dot-notation */
/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable no-undef */

import { ReturnComponents } from '../../../componentes/return.components'
import { ListaAtendimentoService } from '../service/lista-atendimentos.service'

export class ListaAtendimentoPage {
  private _service = new ListaAtendimentoService();
  private _component = new ReturnComponents();

  public async getPage (req: object): Promise<object> {
    const sort = { valor: -1 }
    
    const lista = await this._service.findAll(Object.assign({}, req, { retorno: 'lista_atendimento' }), sort, ['SITUACAO CATEGORIA CLIENTE CODIGO ABERTURA EXPECTATIVA TEMPO_ABERTO '])
    const resLista = await this._component.getLowerCase(lista)
  
    const tempoMedio = await this._service.findAll(Object.assign({}, req, { retorno: 'tempo_medio' }), sort)
    const tempo = await this._component.getLowerCase(tempoMedio)
    const resTempoMedio = tempo && tempo.length > 0 ? tempo[0].tempo_medio : 0

    const data = await this._service.findAll(Object.assign({}, req, { retorno: 'tempo_medio' }), sort, ['DATA_CARGA'], 1)
    const resData = await this._component.getLowerCase(data)
    const resAtualizacao = resData && resData.length > 0 ? resData[0].data_carga : 0

    const obj: any = {
      lista_atendimentos: resLista,
      tempo_medio: resTempoMedio,
      atualizacao: resAtualizacao
    }

    return obj
  }
}

export default new ListaAtendimentoPage()
