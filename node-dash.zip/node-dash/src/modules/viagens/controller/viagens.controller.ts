import { ViagensPage } from '../resolvers/viagens.page'
import { ViagensService } from '../service/viagens.service'
import { GatewayService } from '../../../services/gateway.service'

class ViagensController {
  private _page = new ViagensPage()
  private _service = new ViagensService()
  private _gatewayService = new GatewayService()

  public async getViagens (req: object, socket): Promise<void> {

    req.base = req.base === 'ciaverdelog' ? 'viaverde' : req.base
    
    const logInicio = new Date()
    let retorno
    const exist = await this._service.exists(req.base)

    if (exist) {
      retorno = await this._page.getPage(req)
    }

    else {
      if (req.token && req.url) {
        retorno = await this._gatewayService.backendCall(req, 'M4002', 'getViagens')
      }
    }

    console.log('viagens_v2', req.base, 'viagens_v2:', (new Date() - logInicio) / 1000, 'segundos')

    socket.emit('viagens_v2', retorno)
  }
}

export default new ViagensController()