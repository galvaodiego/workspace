/* eslint-disable no-unused-vars */
/* eslint-disable camelcase */
/* eslint-disable dot-notation */
/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable no-undef */

import { ReturnComponents } from '../../../componentes/return.components'
import { ViagensService } from '../service/viagens.service'

export class ViagensPage {
  private _service = new ViagensService();
  private _component = new ReturnComponents();

  public async getPage (req: object): Promise<object> {
    const sort = { valor: -1 }
    let filter: any = {}

    filter = Object.assign({}, req)
    const viagens = await this._service.findAll(filter, { DATA_ABERTURA: -1 } )
    const res_viagens = await this._component.getLowerCase(viagens)
    
 

    
    const obj: any = {
      viagens: res_viagens
      
    }
    console.log('vieagens aquiiiiiiiiiiiiiiiiiiiiiiiii',obj)


    return obj
  }
}

export default new ViagensPage()
