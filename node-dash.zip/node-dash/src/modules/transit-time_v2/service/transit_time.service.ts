
import mongoose from 'mongoose'
import { TransitTimeModel } from '../model/transit_time.model'
import { MongoHelper } from '../../../helpers/mongo-helper'

export class TransitTimeService {
  private _model = new TransitTimeModel();
  private dash = 'dash_transit_time_'

  async aggregate(req, agrupador, sort, limit?): Promise<object> {
    this._model.setMatch(req)
    this._model.setGroup(agrupador)

    const tgSchema = new mongoose.Schema({}, { strict: false })
    let tg
    const m = this.dash + req.base + '_v2'
    try {
      tg = mongoose.model(m)
    } catch (error) {
      tg = mongoose.model(m, tgSchema, m)
    }

    const res = !limit ? await tg.aggregate([{ $match: this._model.match }, { $group: this._model.group }]).sort(sort) :
      await tg.aggregate([{ $match: this._model.match }, { $group: this._model.group }]).sort(sort).limit(limit)

    this._model.cleanGroup()
    this._model.cleanMath()

    return MongoHelper.map(res)
  }

  async findAll(req, sort, limit?): Promise<object> {
    const m = this.dash + req.base + '_v2'
    this._model.setMatch(req)

    const tgSchema = new mongoose.Schema({}, { strict: false })
    let tg
    try {
      tg = mongoose.model(m)
    } catch (error) {
      tg = mongoose.model(m, tgSchema, m)
    }

    const res = !limit ? await tg.find(this._model.match).sort(sort) : await tg.find({ $match: this._model.match }).sort(sort).limit(limit)

    this._model.cleanMath()

    return res
  }

  async exists(base): Promise<boolean> {
    const tgSchema = new mongoose.Schema({}, { strict: false })
    let tg
    const m = this.dash + base + '_v2'
    try {
      tg = mongoose.model(m)
    } catch (error) {
      tg = mongoose.model(m, tgSchema, m)
    }

    const res = await tg.exists()

    return res
  }
}
