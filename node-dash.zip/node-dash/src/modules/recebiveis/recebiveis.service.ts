/* eslint-disable quote-props */

import mongoose from 'mongoose'
import { MongoHelper } from '../../helpers/mongo-helper'
import logger from '../../logger'
import { RecebiveisModel } from './recebiveis.model'

export class RecebiveisService {
  private _model = new RecebiveisModel();
  private dash = 'dash_recebiveis_'

  async aggregate (req, agrupador, sort, limit?): Promise<object> {
    this._model.setMatch(req)
    this._model.setGroup(agrupador)

    const tgSchema = new mongoose.Schema({}, { strict: false })
    let tg
    let result
    try {
      tg = mongoose.model(this.dash + req.base)
    } catch (error) {
      tg = mongoose.model(this.dash + req.base, tgSchema, this.dash + req.base)
    }

    try {
      result = !limit ? await tg.aggregate([{ $match: this._model.match }, { $group: this._model.group }]).sort(sort) :
        await tg.aggregate([{ $match: this._model.match }, { $group: this._model.group }]).sort(sort).limit(limit)
    } catch (error) {
      logger.error(error + ' path: recebiveis.service line 29')
    }

    this._model.cleanGroup()
    this._model.cleanMath()

    return MongoHelper.map(result)
  }

  async findAll (req, sort, select?, limit?): Promise<object> {
    let result
    this._model.setMatch(req)

    const tgSchema = new mongoose.Schema({}, { strict: false })
    let tg
    try {
      tg = mongoose.model(this.dash + req.base)
    } catch (error) {
      tg = mongoose.model(this.dash + req.base, tgSchema, this.dash + req.base)
    }

    try {
      result = !select ? await tg.find(this._model.match).sort(sort).limit(limit) : await tg.find(this._model.match).select('roll ' + select).sort(sort).limit(limit)
    } catch (error) {
      logger.error(error + ' path: recebiveis.service line 53')
    }

    this._model.cleanMath()

    return MongoHelper.mapFindAll(result)
  }

  async exists (base): Promise<boolean> {
    const tgSchema = new mongoose.Schema({}, { strict: false })
    let tg
    let result

    try {
      tg = mongoose.model(this.dash + base)
    } catch (error) {
      tg = mongoose.model(this.dash + base, tgSchema, this.dash + base)
    }

    try {
      result = await tg.exists()
    } catch (error) {
      logger.error(error + ' path: recebiveis.service line 75')
    }

    return result
  }
}
