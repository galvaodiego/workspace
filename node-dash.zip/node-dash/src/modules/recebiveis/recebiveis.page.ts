import { ReturnComponents } from '../../componentes/return.components'
import { RecebiveisService } from './recebiveis.service'

export class RecebiveisPage {
  private _service = new RecebiveisService();
  private _component = new ReturnComponents();

  public async getPage (req: object): Promise<object> {
    const sort = { valor: -1 }
    let filter: any = {}

    filter = Object.assign({}, req, { retorno: 'docSemComp' })
    const result1 = await this._service.findAll(filter, { TEMPO: -1 }, ['DOCUMENTO TEMPO CLIENTE'])
    const listaDocsSemComp = await this._component.getLowerCase(result1)

    filter = Object.assign({}, req, { retorno: 'docSemFaturar' })
    const result2 = await this._service.findAll(filter, { TEMPO: -1 }, ['DOCUMENTO TEMPO CLIENTE'])
    const listaDocsSemFaturar = await this._component.getLowerCase(result2)

    filter = Object.assign({}, req, { retorno: 'percAbertCliente' })
    const result3 = await this._service.findAll(filter, { PERC: -1 }, ['CLIENTE PERC'], 5)
    const listaPercAbertCliente = await this._component.getLowerCase(result3)

    filter = Object.assign({}, req, { retorno: 'percAbertoDia' })
    const result4 = await this._service.findAll(filter, sort, ['DIA PERC'])
    const listaPercAbertoDia = await this._component.getLowerCase(result4)

    filter = Object.assign({}, req, { retorno: 'tempoClientes' })
    const result5 = await this._service.findAll(filter, { VALOR: -1 }, ['CLIENTE VALOR'], 5)
    const listaTempoClientes = await this._component.getLowerCase(result5)

    filter = Object.assign({}, req, { retorno: 'tempoEmpresa' })
    const result6 = await this._service.findAll(filter, { VALOR: -1 }, ['DATA VALOR'])
    const listaTempoEmpresa = await this._component.getLowerCase(result6)

    filter = Object.assign({}, req, { retorno: 'tempoRecupClientes' })
    const result7 = await this._service.findAll(filter, { VALOR: -1 }, ['CLIENTE VALOR'], 5)
    const listaTempoRecupClientes = await this._component.getLowerCase(result7)

    filter = Object.assign({}, req, { retorno: 'tempoRecupEmpresa' })
    const result8 = await this._service.findAll(filter, { VALOR: -1 }, ['DATA VALOR'])
    const listaTempoRecupEmpresa = await this._component.getLowerCase(result8)

    const indicadores = await this._service.aggregate(req, [''], sort)
    const resAtualizacao = indicadores && indicadores.length > 0 ? indicadores[0].last_update : 0

    const obj: any = {
      telaTemposFinan: {
        docsSemComp: listaDocsSemComp,
        docsSemFaturar: listaDocsSemFaturar,
        percAbertCliente: listaPercAbertCliente,
        percAbertoDia: listaPercAbertoDia,
        tempoClientes: listaTempoClientes,
        tempoEmpresa: listaTempoEmpresa,
        tempoRecupClientes: listaTempoRecupClientes,
        tempoRecupEmpresa: listaTempoRecupEmpresa,
        atualizacao: resAtualizacao

      }
    }

    return obj
  }
}

export default new RecebiveisPage()
