import { RecebiveisPage } from './recebiveis.page'
import { RecebiveisService } from './recebiveis.service'
import { GatewayService } from '../../services/gateway.service'

class RecebiveisController {

  private _page = new RecebiveisPage()
  private _service = new RecebiveisService()
  private _gatewayService = new GatewayService()

  public async getRecebiveis (req: object, socket): Promise<void> {

    const logInicio = new Date()
    let retorno
    const exist = await this._service.exists(req.base)

    if (exist) {
      retorno = await this._page.getPage(req)
    }
    else {
      if (req.token && req.url) {
        retorno = await this._gatewayService.backendCall(req, 'M4002', 'getFinanceiroDash')
      }
    }

    console.log('recebiveis', req.base, 'Recebiveis:', (new Date() - logInicio) / 1000, 'segundos')

    socket.emit('recebiveis', retorno)
  }
}

export default new RecebiveisController()
