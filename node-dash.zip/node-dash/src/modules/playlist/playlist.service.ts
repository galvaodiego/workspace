/* eslint-disable no-undef */
/* eslint-disable @typescript-eslint/camelcase */
import mongoose from 'mongoose'
import { MongoHelper } from '../../helpers/mongo-helper'
import logger from '../../logger'

export class PlaylistService {

  private readonly collection = 'playlist_dash'

  public async insert (usuario: string, base: string, playlist: Array<any>): Promise<string> {
    const tgSchema = new mongoose.Schema({}, { strict: false, _id: false })
    let tg
    let result
    try {
      tg = mongoose.model(this.collection)
    } catch (error) {
      tg = mongoose.model(this.collection, tgSchema, this.collection)
    }

    const id = {
      base: base,
      usuario_bi: usuario
    }

    const date = new Date()

    try {
      result = (await tg.updateOne({ _id: id },
        {
          usuario_bi: usuario,
          base: base,
          playlist: playlist,
          date_insert: new Date(date.setHours(date.getHours() - 3))
        }, { upsert: true }))

      return 'Playlist inserida com sucesso'
    } catch (error) {
      logger.error(error)

      return error
    }

  }

  public async find (usuario: string, base: string): Promise<any> {
    const tgSchema = new mongoose.Schema({}, { strict: false, _id: false })
    let tg
    let result
    try {
      tg = mongoose.model(this.collection)
    } catch (error) {
      tg = mongoose.model(this.collection, tgSchema, this.collection)
    }

    const id = {
      base: base,
      usuario_bi: usuario
    }

    try {
      result = await tg.find({ _id: id })
    } catch (error) {
      logger.error(error + ' path: playlist.service line 51')
    }
    return MongoHelper.mapFindAll(result)
  }
}

export default new PlaylistService()
