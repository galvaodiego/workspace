import { DescargaPage } from '../resolvers/descarga.page'
import { DescargaService } from '../service/descarga.service'
import { GatewayService } from '../../../services/gateway.service'

class DescargaController {
  private _page = new DescargaPage()
  private _service = new DescargaService()
  private _gatewayService = new GatewayService()

  public async getDescarga (req: object, socket): Promise<void> {

    req.base = req.base === 'ciaverdelog' ? 'viaverde' : req.base
    
    const logInicio = new Date()
    let retorno
    const exist = await this._service.exists(req.base)

    if (exist) {
      retorno = await this._page.getPage(req)
    }
    else {
      if (req.token && req.url) {
        retorno = await this._gatewayService.backendCall(req, 'M4002', 'getDescarga')
      }
    }

    console.log('descarga', req.base, 'descarga:', (new Date() - logInicio) / 1000, 'segundos')

    socket.emit('descarga', retorno)
  }
}

export default new DescargaController()
