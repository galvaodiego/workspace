/* eslint-disable no-unused-vars */
/* eslint-disable camelcase */
/* eslint-disable dot-notation */
/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable no-undef */

import { ReturnComponents } from '../../../componentes/return.components'
import { DescargaService } from '../service/descarga.service'

export class DescargaPage {
  private _service = new DescargaService();
  private _component = new ReturnComponents();

  public async getPage (req: object): Promise<object> {
    const sort = { valor: -1 }
    let filter: any = {}
 
    filter = Object.assign({}, req, { status: 'Descarga' })
    // res = await this._integracaoService.findAll({ match: this._groupIntegracao.match, req: req }, { NR_DIA_MES: 1 }, ['CLIENTE FLAG_EMB AUTOMATIZADO INTEGRADO NR_DIA_MES DIA_MES'], 1000)
    const aguardando = await this._service.findAll(filter, { TEMPO_MIN: 1 }, ['CCG CLIENTE DESTINO FROTA IDENTIFICADOR INICIO_DESCARGA NUM_ROMANEIO OPERACAO ORIGEM PLACA_CARRETA PLACA_TRACAO PREVISAO_INICIO TEMPO_ATRASO TEMPO_EM_DESCARGA TEMPO_MIN GESTAO COD_GESTAO'])
    const resAguardando = await this._component.getLowerCase(aguardando)


    filter = Object.assign({}, req, { status: 'Viagem' })
    const viagem = await this._service.findAll(filter, { PREVISAO_CARREGADO: 1 }, ['CCG CLIENTE DESTINO FROTA IDENTIFICADOR NUM_ROMANEIO OPERACAO ORIGEM PLACA_CARRETA PLACA_TRACAO PREVISAO_CARREGADO TEMPO_MIN GESTAO COD_GESTAO'])
    const resViagem = await this._component.getLowerCase(viagem)

    const indicadores = await this._service.aggregate(req, [''], sort)
    const resAtualizacao = indicadores && indicadores.length > 0 ? indicadores[0].last_update : 0

    // Indicadores
    filter = Object.assign({}, req, { status: 'Viagem', atrasado: 1 })
    const atrasado = await this._service.aggregate(filter, [''], sort)

    filter = Object.assign({}, req, { status: 'Viagem', previsto: 1 })
    const previsto = await this._service.aggregate(filter, [''], sort)

    filter = Object.assign({}, req, { status: 'Viagem' })
    const viajando = await this._service.aggregate(filter, [''], sort)

    filter = Object.assign({}, req, { status: 'Descarga' })
    const descarga = await this._service.aggregate(filter, [''], sort)

    const resIndicadores = [{
      atrasado: atrasado && atrasado.length > 0 ? atrasado[0].total : 0,
      descarga: descarga && descarga.length > 0 ? descarga[0].total : 0,
      previsto: previsto && previsto.length > 0 ? previsto[0].total : 0,
      vajando: viajando && viajando.length > 0 ? viajando[0].total : 0
    }]

    const obj: any = {
      teladescarga: {
        descargaAguardando: resAguardando,
        descargaViagem: resViagem,
        descarga_indicadores: resIndicadores,
        atualizacao: resAtualizacao
      }
    }

    return obj
  }
}

export default new DescargaPage()
