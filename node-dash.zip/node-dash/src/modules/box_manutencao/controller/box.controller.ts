import { BoxPage } from '../resolvers/box.page'
import { BoxService } from '../service/box.service'
import { GatewayService } from '../../../services/gateway.service'

class BoxController {
  private _page = new BoxPage()
  private _service = new BoxService()
  private _gatewayService = new GatewayService()

  public async getBox (req: object, socket): Promise<void> {

    req.base = req.base === 'ciaverdelog' ? 'viaverde' : req.base
    
    const logInicio = new Date()
    let retorno
    const exist = await this._service.exists(req.base)

    if (exist) {
      retorno = await this._page.getPage(req)
    }

    else {
      if (req.token && req.url) {
        retorno = await this._gatewayService.backendCall(req, 'M4002', 'getBox')
      }
    }

    console.log('box', req.base, 'box:', (new Date() - logInicio) / 1000, 'segundos')

    socket.emit('box', retorno)
  }
}

export default new BoxController()