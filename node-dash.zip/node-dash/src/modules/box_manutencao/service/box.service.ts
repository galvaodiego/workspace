
import mongoose from 'mongoose'
import { MongoHelper } from '../../../helpers/mongo-helper'
import logger from '../../../logger'
import { BoxModel } from '../model/box.model'
import { Response } from 'express'

export class BoxService {
  private _model = new BoxModel();
  
  private dash = 'dash_box_manutencao_lista_os_'
  private dash_mec = 'dash_box_manutencao_lista_mec_disp_'
  private dash_box = 'dash_box_manutencao_lista_box_'
  private dash_num = 'dash_box_manutencao_os_numero_'

  res: Response

  async aggregate (req, agrupador, sort, limit?): Promise<object> {
    this._model.setMatch(req)
    this._model.setGroup(agrupador)
    let result

    const tgSchema = new mongoose.Schema({}, { strict: false })
    let tg
    try {
      tg = mongoose.model(this.dash + req.base)
    } catch (error) {
      tg = mongoose.model(this.dash + req.base, tgSchema, this.dash + req.base)
    }

    try {
      result = !limit ? await tg.aggregate([{ $match: this._model.match }, { $group: this._model.group }]).sort(sort) :
        await tg.aggregate([{ $match: this._model.match }, { $group: this._model.group }]).sort(sort).limit(limit)
    } catch (error) {
      logger.error(error + ' path: box.service line 31')
    }

    this._model.cleanGroup()
    this._model.cleanMath()

    return MongoHelper.map(result)
  }

  async findAll (req, sort, select?, limit?): Promise<object> {
    this._model.setMatch(req)
    let res

    const tgSchema = new mongoose.Schema({}, { strict: false })
    let tg
    try {
      tg = mongoose.model(this.dash + req.base)
    } catch (error) {
      tg = mongoose.model(this.dash + req.base, tgSchema, this.dash + req.base)
    }

    try {
      res = !select ? await tg.find(this._model.match).sort(sort) : await tg.find(this._model.match).select('roll ' + select).sort(sort) //.limit(limit)
    } catch (error) {
      logger.error(error + ' path: box.service line 55')
    }

    this._model.cleanMath()

    return res
  }

  async find_mec (req, sort, select?, limit?): Promise<object> {
    this._model.setMatch(req)
    let res

    const tgSchema = new mongoose.Schema({}, { strict: false })
    let tg
    try {
      tg = mongoose.model(this.dash_mec + req.base)
    } catch (error) {
      tg = mongoose.model(this.dash_mec + req.base, tgSchema, this.dash_mec + req.base)
    }

    try {
      res = !select ? await tg.find(this._model.match).sort(sort) : await tg.find(this._model.match).select('roll ' + select).sort(sort) //.limit(limit)
    } catch (error) {
      logger.error(error + ' path: box.service line 55')
    }

    this._model.cleanMath()

    return res
  }

  async find_box (req, sort, select?, limit?): Promise<object> {
    this._model.setMatch(req)
    let res

    const tgSchema = new mongoose.Schema({}, { strict: false })
    let tg
    try {
      tg = mongoose.model(this.dash_box + req.base)
    } catch (error) {
      tg = mongoose.model(this.dash_box + req.base, tgSchema, this.dash_box + req.base)
    }

    try {
      res = !select ? await tg.find(this._model.match).sort(sort) : await tg.find(this._model.match).select('roll ' + select).sort(sort) //.limit(limit)
    } catch (error) {
      logger.error(error + ' path: box.service line 55')
    }

    this._model.cleanMath()

    return res
  }

  async find_num (req, sort, select?, limit?): Promise<object> {
    this._model.setMatch(req)
    let res

    const tgSchema = new mongoose.Schema({}, { strict: false })
    let tg
    try {
      tg = mongoose.model(this.dash_num + req.base)
    } catch (error) {
      tg = mongoose.model(this.dash_num + req.base, tgSchema, this.dash_num + req.base)
    }

    try {
      res = !select ? await tg.find(this._model.match).sort(sort) : await tg.find(this._model.match).select('roll ' + select).sort(sort) //.limit(limit)
    } catch (error) {
      logger.error(error + ' path: box.service line 55')
    }

    this._model.cleanMath()

    return res
  }

  async exists (base): Promise<boolean> {
    const tgSchema = new mongoose.Schema({}, { strict: false })
    let tg
    try {
      tg = mongoose.model(this.dash + base)
    } catch (error) {
      tg = mongoose.model(this.dash + base, tgSchema, this.dash + base)
    }

    try {
      tg = mongoose.model(this.dash_mec + base)
    } catch (error) {
      tg = mongoose.model(this.dash_mec + base, tgSchema, this.dash_mec + base)
    }

    try {
      tg = mongoose.model(this.dash_box + base)
    } catch (error) {
      tg = mongoose.model(this.dash_box + base, tgSchema, this.dash_box + base)
    }

    try {
      tg = mongoose.model(this.dash_num + base)
    } catch (error) {
      tg = mongoose.model(this.dash_num + base, tgSchema, this.dash_num + base)
    }

    const res = await tg.exists()

    return res
  }
}
