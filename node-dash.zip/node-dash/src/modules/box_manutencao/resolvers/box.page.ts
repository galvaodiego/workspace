/* eslint-disable no-unused-vars */
/* eslint-disable camelcase */
/* eslint-disable dot-notation */
/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable no-undef */

import { ReturnComponents } from '../../../componentes/return.components'
import { BoxService } from '../service/box.service'
const _ = require('lodash')

export class BoxPage {
  private _service = new BoxService();
  private _component = new ReturnComponents();

  public async getPage (req: object): Promise<object> {
    const sort = { valor: -1 }
    let filter: any = {}

    filter = Object.assign({}, req)
    const lista_box = await this._service.find_box(filter, {}, ['BOX_ID COUNTOS DESCRICAO'] )
    const res_lista_box = await this._component.getLowerCase(lista_box)

    const key = 'box_id';

  const arrayUniqueByKey = [...new Map(res_lista_box.map(item =>[item[key], item])).values()];

// console.log(arrayUniqueByKey);



    filter = Object.assign({}, req)
    const lista_os = await this._service.find_box(filter, {}, ['BOX_ID DATA_ABERTURA DATA_ATENDIMENTO MECANICO NUM_OS ORDEM_SERVICO_ID PLACA PREVISAO_LIBERACAO STATUS_BOX STATUS_OS SITUACAO_ID STATUS'] )
    const res_lista_os = await this._component.getLowerCase(lista_os)


    arrayUniqueByKey.forEach(element => {
      let os: any[] = []
      res_lista_os.filter(function(e){
        if( e.box_id === 28/*element.box_id*/){
          console.log('e', {e})

          // os.push(e)
          // arrayUniqueByKey.push(os)
        }
      })
  
      
    });

  
   console.log('arrayUniqueByKey', {arrayUniqueByKey})

   


    // var groupBy = function(xs: any[], key: string) {
    //   return xs.reduce(function(rv, x) {
    //     (rv[x[key]] = rv[x[key]] || []).push(x);
    //     return rv;
    //   }, {});
    // };

    // let os = (groupBy(res_lista_box, 'box_id'));
    

    // objectzip
  
  //  console.log('teste_box',teste_box)
  //  console.log('os',{os})

    filter = Object.assign({}, req)
    const lista_manutencao_os = await this._service.findAll(filter, { DATA_ABERTURA: -1 },['PLACA NUM_ORDEM_SERVICO ORDEM_SERVICO_ID DATA_ABERTURA DATA_LIBERACAO ATRASADA'] )
    const res_lista_manutencao_os = await this._component.getLowerCase(lista_manutencao_os)
    
    filter = Object.assign({}, req)
    const lista_mec_disp = await this._service.find_mec(filter, {},['MECANICO'] )
    const res_lista_mec_disp = await this._component.getLowerCase(lista_mec_disp)

    

    filter = Object.assign({}, req)
    const lista_num = await this._service.find_num(filter, {}, ['SUITUACAO QUANTIDADE'] )
    const res_lista_num = await this._component.getLowerCase(lista_num)


    const obj: any = {
      oficina:{
        boxes:arrayUniqueByKey,
        ordem_servico: res_lista_manutencao_os,
        mecanicos_disponiveis: res_lista_mec_disp,
        os_indicadores:res_lista_num
      }   
    }


    return obj
  }
}

export default new BoxPage()
