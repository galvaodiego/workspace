/* eslint-disable camelcase */
/* eslint-disable @typescript-eslint/explicit-function-return-type */
/* eslint-disable no-self-assign */
/* eslint-disable @typescript-eslint/camelcase */

export class ViagensHistModel {
  public group
  public match

  constructor () {
    this.initGroup()
    this.initMatch()
  }

  private initGroup () {

    const group = {
      _id: {
        // grupo_negociador: '$GRUPO_NEGOCIADOR',
        status: '$STATUS',
      },
      last_update: { $max: '$DATA_CARGA' },
      total: { $sum: 1 }
    }
    this.group = group
  }

  private initMatch () {
    const match = {
      GRUPO_NEGOCIADOR: null, // vERIFICAR
      NUM_ROMANEIO: null,   
      PLACA: null,   
      STATUS: null,  
    }
    this.match = match
  }

  public setMatch (req): void {

    this.match.GRUPO_NEGOCIADOR = req.grupo_negociador ? {$in : req.grupo_negociador}: null
    this.match.NUM_ROMANEIO = req.num_romaneio ? {$eq : req.num_romaneio}: null
    this.match.PLACA = req.placa ? {$eq : req.placa}: null
    this.match.STATUS = req.status ? {$eq : req.status}: null
    Object.keys(this.match).forEach((key) => (this.match[key] == null) && delete this.match[key])
  }

  public setGroup (group: Array<string>): void {
    const obj = JSON.parse(JSON.stringify(this.group))
    Object.keys(obj._id).forEach((key) => (!group.includes(key)) && delete obj._id[key])
    this.group = obj
  }

  public cleanGroup (): void {
    this.initGroup()
  }

  public cleanMath (): void {
    this.initMatch()
  }
}

export default new ViagensHistModel()
