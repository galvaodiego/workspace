/* eslint-disable no-unused-vars */
/* eslint-disable camelcase */
/* eslint-disable dot-notation */
/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable no-undef */
// pegar como vem hoje e colocar nos filtros de
// socket->controllet->page->service->model->getLowerCase
import { ReturnComponents } from '../../../componentes/return.components'
import { ViagensHistService } from '../service/viagens_hist.service'

export class ViagensHistPage {
  private _service = new ViagensHistService();
  private _component = new ReturnComponents();

  public async getPage (req: object): Promise<object> {
    
    const sort = { data: -1 }
    let viagens_hist
    let resviagens_hist
    const local = 'pt-Br'
    const options_hours = { hour12: false, timeZone: 'America/Sao_Paulo' }
    
    function toLocaleDate (date: any){
      // const date_miliseconds = (new Date(date.valueOf(date) - date.getTimezoneOffset()*60000)).toISOString()
      const date_miliseconds = (new Date(date.valueOf(date))).toISOString()
      const date_brasil = date_miliseconds.slice(0, date_miliseconds.length -5)
      return date_brasil
    }
    
 
    viagens_hist = await this._service.findAll(req, {},['_id POSICAO_ID NUM_ROMANEIO DATA_TERMINO PLACA REFERENCIA DATA_POSICAO TEMPERATURA FLAG_TEMPERATURA']) // verificar o campo do sort
    resviagens_hist = await this._component.getLowerCase(viagens_hist)
    resviagens_hist = [...new Map(resviagens_hist.map(item => [item['num_romaneio'], item])).values()]
    const lista_viagens_hist_ajuste_data = resviagens_hist.map(element => 
        {
          element.data_posicao = toLocaleDate(element.data_posicao)
          element.data_termino = toLocaleDate(element.data_termino)
          return  element
        })
    
    resviagens_hist = lista_viagens_hist_ajuste_data.sort((a,b) => (a.data_termino > b.data_termino ? 1: -1))
    const lista = resviagens_hist && resviagens_hist.length > 0 ? resviagens_hist : 0

    const obj: any = {
      result:  [
            {
              lista: lista
            }]
    }

    return obj
  }
}

export default new ViagensHistPage()
function limit(req: object, arg1: { data_ultima_posicao: number; }, limit: any, arg3: number) {
  throw new Error('Function not implemented.');
}

