import { TransitTimePage } from '../resolvers/transit_time.page'
import { TransitTimeService } from '../service/transit_time.service'
import { GatewayService } from '../../../services/gateway.service'

class TransitTimeController {
  private _page = new TransitTimePage()
  private _service = new TransitTimeService()
  private _gatewayService = new GatewayService()

  public async getTransitTime (req: object, socket): Promise<void> {
    
    req.base = req.base === 'ciaverdelog' ? 'viaverde' : req.base

    const logInicio = new Date()
    let retorno
    const exist = await this._service.exists(req.base)

    if (exist) {
      retorno = await this._page.getPage(req)
    }
    else {
      if (req.token && req.url) {
        retorno = await this._gatewayService.backendCall(req, 'M4002', 'getTransitTime')
      }
    }

    console.log('transit_time', req.base, ':', (new Date() - logInicio) / 1000, 'segundos')

    socket.emit('transit_time', retorno)
  }
}

export default new TransitTimeController()
