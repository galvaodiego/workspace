/* eslint-disable camelcase */
/* eslint-disable dot-notation */
/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable no-undef */

import { ReturnComponents } from '../../../componentes/return.components'
import { TransitTimeService } from '../service/transit_time.service'

export class TransitTimePage {
  private _service = new TransitTimeService();
  private _component = new ReturnComponents();

  public async getPage (req: object): Promise<object> {
    const sort = { valor: -1 }

    const indicadores = await this._service.aggregate(req, [''], sort)

    // NAC_PREVISAO_CHEGADA: 1, PREVISAO_INICIO_CARGA_DESCARGA: 1

    const transit = await this._service.findAll(req, sort)
    const resTransit = await this._component.getLowerCase(transit)

    const resAtualizacao = indicadores && indicadores.length > 0 ? indicadores[0].last_update : 0

    const obj: any = {
      TransitTime: resTransit,
      atualizacao: resAtualizacao
    }

    return obj
  }
}

export default new TransitTimePage()
