
import mongoose from 'mongoose'
import { TransitTimeModel } from '../model/transit_time.model'
import { MongoHelper } from '../../../helpers/mongo-helper'

export class TransitTimeService {
  private _model = new TransitTimeModel();
  private dash = 'dash_transit_time_'

  async aggregate (req, agrupador, sort, limit?): Promise<object> {
    this._model.setMatch(req)
    this._model.setGroup(agrupador)

    const tgSchema = new mongoose.Schema({}, { strict: false })
    let tg
    try {
      tg = mongoose.model(this.dash + req.base)
    } catch (error) {
      tg = mongoose.model(this.dash + req.base, tgSchema, this.dash + req.base)
    }

    const res = !limit ? await tg.aggregate([{ $match: this._model.match }, { $group: this._model.group }]).sort(sort) :
      await tg.aggregate([{ $match: this._model.match }, { $group: this._model.group }]).sort(sort).limit(limit)

    this._model.cleanGroup()
    this._model.cleanMath()

    return MongoHelper.map(res)
  }

  async findAll (req, sort, limit?): Promise<object> {
    this._model.setMatch(req)

    const tgSchema = new mongoose.Schema({}, { strict: false })
    let tg
    try {
      tg = mongoose.model(this.dash + req.base)
    } catch (error) {
      tg = mongoose.model(this.dash + req.base, tgSchema, this.dash + req.base)
    }

    const res = !limit ? await tg.find(this._model.match).sort(sort) : await tg.find({ $match: this._model.match }).sort(sort).limit(limit)

    this._model.cleanMath()

    return res
  }

  async exists (base): Promise<boolean> {
    const tgSchema = new mongoose.Schema({}, { strict: false })
    let tg
    try {
      tg = mongoose.model(this.dash + base)
    } catch (error) {
      tg = mongoose.model(this.dash + base, tgSchema, this.dash + base)
    }

    const res = await tg.exists()

    return res
  }
}
