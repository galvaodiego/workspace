/* eslint-disable prefer-const */
/* eslint-disable no-unused-expressions */
import { Socket } from 'socket.io'
import { ReturnComponents } from '../../componentes/return.components'
import { IndicadorLogisticoService } from './indicador_log.service'

class IndicadorLogController {

  private _service = new IndicadorLogisticoService()
  private _component = new ReturnComponents()

  public async getIndicadorLogistico (req:any, socket: Socket): Promise<void> {

    const sort = { qtde: -1 }

    const logInicio = new Date()
    let res = null
    let filter

    filter = Object.assign({}, req)
    delete filter.atraso, delete filter.usuario
    const resLogistico = await this._service.aggregate(filter, ['status', 'cliente', 'ordem', 'atraso', 'previsto'], sort)
    const listaLower:any =  await this._component.getLowerCase(resLogistico)
    const resRetorno = await this._service.getRetorno(listaLower, 'cliente')

    if (req.atraso !== null) {
      const resLogAtrasado:any = await this._service.findAll(req, sort)
      const listaLowerCase:any = await this._component.getLowerCase(resLogAtrasado)
      res = await this._service.getDetalhe(listaLowerCase)
    }

    const retorno = {
      logistico: resRetorno,
      result: { logistico: res && res.length > 0 ? res : [] }
    }

    console.log('reqIndicador', req)

    console.log('base', req.base, 'INDICADOR. LOG: ', (new Date() - logInicio) / 1000, 'segundos')
    socket.emit('indicador_logistico', retorno)
  }

}

export default new IndicadorLogController()
