import { Socket } from 'socket.io'
import { ReturnComponents } from '../../componentes/return.components'
import { MonitoramentoService } from './monitoramento.service'

class MonitoramentoController {


  private _monitoramentoService = new MonitoramentoService()
  private _componet =  new ReturnComponents()

  public async getMonitoramento (req:any, socket: Socket): Promise<void> {
    const sort = { qtde: -1 }
    const logInicio = new Date()

    const resMonitoramento = await this._monitoramentoService.findAll(req, sort)
    const lista = await this._componet.getLowerCase(resMonitoramento)

    const retorno = {
      location: lista
    }

    console.log('base', req.base, 'MONITORAMENTO: ', (new Date() - logInicio) / 1000, 'segundos')
    socket.emit('monitoramento', retorno)
  }
}

export default new MonitoramentoController()
