
import mongoose from 'mongoose'
import { MongoHelper } from '../../helpers/mongo-helper';
import { IndicadorLogModel } from './indicador_logistico.model';

export class IndicadorLogisticoService {


  private dash = 'app_indicador_log_'
  private _model = new IndicadorLogModel()

  async aggregate(req, agrupador, sort, limit?): Promise<object> {
    this._model.setMatch(req)
    this._model.setGroup(agrupador)

    const tgSchema = new mongoose.Schema({}, { strict: false })
    let tg
    try {
      tg = mongoose.model(this.dash + req.base)
    } catch (error) {
      tg = mongoose.model(this.dash + req.base, tgSchema, this.dash + req.base)
    }

    const res = !limit ? await tg.aggregate([{ $match: this._model.match }, { $group: this._model.group }]).sort(sort)
      : await tg.aggregate([{ $match: this._model.match }, { $group: this._model.group }]).sort(sort).limit(limit)

    this._model.cleanGroup()
    this._model.cleanMath()

    return MongoHelper.map(res)
  }

  async findAll(req, sort, select?, limit?): Promise<object> {
    this._model.setMatch(req)

    const tgSchema = new mongoose.Schema({}, { strict: false })
    let tg
    try {
      tg = mongoose.model(this.dash + req.base)
    } catch (error) {
      tg = mongoose.model(this.dash + req.base, tgSchema, this.dash + req.base)
    }

    const res = !select ? await tg.find(this._model.match).sort(sort) : await tg.find(this._model.match).select('roll ' + select).sort(sort) //.limit(limit)

    this._model.cleanMath()

    return MongoHelper.mapFindAll(res)
  }


  /**
   * Função que retorna de maneira agrupada por status
   * 1 - Para cliente
   * 0 - Para Rota
   */

  public async getRetorno(data: Array<any>, values:string): any {

    let totalVi = 0
    let totalC = 0
    let totalD = 0
    const obj = []
    const ObjVi = []
    const ObjD = []
    const ObjC = []

    data.forEach((element) => {



      if (element.status === 'Viagem') {
        totalVi += element.previsto + element.atraso
        ObjVi.push({ descricao: element[values], previsto: element.previsto, atraso: element.atraso, ordem: element.ordem })
      }
      if (element.status === 'Carga') {
        totalC += element.previsto + element.atraso
        ObjC.push({ descricao: element[values], previsto: element.previsto, atraso: element.atraso, ordem: element.ordem })
      }
      if (element.status === 'Descarga') {
        totalD += element.previsto + element.atraso
        ObjD.push({ descricao: element[values], previsto: element.previsto, atraso: element.atraso, ordem: element.ordem })
      }

    })

    obj.push({ status: 'Carga', /* ordem: ObjC[0] ? ObjC[0].ordem : null*/ total: totalC, lista: ObjC },
      { status: 'Descarga', /*ordem: ObjD[0] ? ObjD[0].ordem : null*/ total: totalD, lista: ObjD },
      { status: 'Viagem', /*ordem: ObjVi[0] ? ObjVi[0].ordem : null*/ total: totalVi, lista: ObjVi }
    )

    return obj
  }

  public async getDetalhe(data: Array<any>): any {

    const obj = []
    const ObjVi = []
    const ObjD = []
    const ObjC = []
    let newElement

    if (data && data.length > 0) {
      let type = data[0]['_doc']

      data.forEach((element) => {
        newElement = type !== undefined ? element['_doc'] : element
        delete newElement._id

        if (newElement.status === 'Viagem') {
          ObjVi.push(newElement)
        }
        if (newElement.status === 'Carga') {
          ObjC.push(newElement)
        }
        if (newElement.status === 'Descarga') {
          ObjD.push(newElement)
        }

      })

      obj.push({ status: 'Carga', lista: ObjC },
        { status: 'Descarga', lista: ObjD },
        { status: 'Viagem', lista: ObjVi })
    }
    return obj
  }


}