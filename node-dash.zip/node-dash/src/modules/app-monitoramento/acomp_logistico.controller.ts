import { Socket } from 'socket.io'
import { ReturnComponents } from '../../componentes/return.components'
import { IndicadorLogisticoService } from './indicador_log.service'
// import GroupIndicadorLog from './indicador_log.group'

class AcompLogisticoController {

  // private _indicadorLogService = new IndicadorLogisticoService()
  // private _groupIndicadorLog = new GroupIndicadorLog()
  private _service =  new IndicadorLogisticoService()
  private _component = new ReturnComponents()

  public async getAcompLogistico (req:any, socket: Socket): Promise<void> {


    // const atraso = req.atraso
    // const cliente = req.base
    // const periodo = req.periodo
    // const usuario = req.usuario ? req.usuario : null
    // const sort = { qtde: -1 }

    // const retorno = {
    //   rota: [],
    //   result: { logistico: [] }
    // }

    // const logInicio = new Date()
    // let res = null

    // req = { base: cliente, periodo: periodo, usuario: usuario }
    // this._groupIndicadorLog.setMatchIndicadorLog(req)
    // res = await this._indicadorLogService.aggregate({ match: this._groupIndicadorLog.match, req: req }, ['status', 'rota', 'ordem', 'atraso', 'previsto'], sort)
    // retorno.rota = await this._indicadorLogService.getRetorno(res)
  
    // if (atraso != null) {
    //   req = { base: cliente, periodo: periodo, usuario: usuario, atraso: atraso }
    //   this._groupIndicadorLog.setMatchIndicadorLog(req)
    //   res = await this._indicadorLogService.find({ match: this._groupIndicadorLog.match, req: req }, sort)
      
    //   retorno.result.logistico = await this._indicadorLogService.getDetalhe(res)
    // }


    const sort = { qtde: -1 }

    const logInicio = new Date()
    let res = null
    let filter


    filter = Object.assign({}, req)
    delete filter.atraso
    const resAcomp = await this._service.aggregate(filter, ['status', 'rota', 'ordem', 'atraso', 'previsto'], sort)
    const acompLower:any =  await this._component.getLowerCase(resAcomp)
    const resAcompRetorno = await this._service.getRetorno(acompLower, 'rota')

    if (req.atraso !== null) {
      const resAcompAtrasado:any = await this._service.findAll(req, sort)
      const listaLowerCase:any = await this._component.getLowerCase(resAcompAtrasado)
      res = await this._service.getDetalhe(listaLowerCase)
    }


    const retorno = {
      rota: resAcompRetorno,
      result: { logistico: res && res.length > 0 ? res : [] }
    }

    console.log('base', req.base, 'ACOMP. LOG: ', (new Date() - logInicio) / 1000, 'segundos')
    socket.emit('acomp_logistico', retorno)
  }

}

export default new AcompLogisticoController()
