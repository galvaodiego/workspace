

import mongoose from 'mongoose'

import { IndicadorLogModel } from './indicador_logistico.model'
import { MongoHelper } from '../../helpers/mongo-helper'

export class MonitoramentoService {

  async findAll (req, sort, select?, limit?): Promise<object> {
    const model = new IndicadorLogModel()
    const dash = 'app_monitoramento_'

    const tgSchema = new mongoose.Schema({}, { strict: false })

    model.setMatch(req)

    let tg
    try {
      tg = mongoose.model(dash + req.base)
    } catch (error) {
      tg = mongoose.model(dash + req.base, tgSchema, dash + req.base)
    }

    const res = !select ? await tg.find(model.match).sort(sort) : await tg.find(model.match).select('roll ' + select).sort(sort).limit(limit)

    model.cleanMath()

    return MongoHelper.mapFindAll(res)
  }
}
