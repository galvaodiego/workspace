/* eslint-disable prefer-const */
/* eslint-disable camelcase */
/* eslint-disable @typescript-eslint/explicit-function-return-type */
/* eslint-disable no-self-assign */
/* eslint-disable @typescript-eslint/camelcase */

export class IndicadorLogModel {
  public group
  public match

  constructor () {
    this.initGroup()
    this.initMatch()
  }

  private initGroup () {
    const group = {
      _id: {
        cliente: '$CLIENTE',
        status: '$STATUS',
        rota: '$ROTA',
        ordem: '$ORDEM'

      },
      atraso: { $sum: '$ATRASO' },
      previsto: { $sum: '$PREVISTO' }
    }

    this.group = group
  }

  private initMatch () {
    const match = {
      ROTA: null,
      STATUS: null,
      ATRASO: null,
      CLIENTE: null,
      GRUPO: null
    }
    this.match = match
  }

  public setMatch (req): void {
    let grupo = null

    if (req.usuario) {
      if (req.usuario.toLowerCase() === 'quimica_amparo') {
        grupo = 'QUIMICA AMPARO'
      } if (req.usuario.toLowerCase() === 'arcelormittal') {
        grupo = 'ARCELOR MITTAL'
      } if (req.usuario.toLowerCase() === 'fs') {
        grupo = 'FS'
      } if (req.usuario.toLowerCase() === 'ambev') {
        grupo = 'AMBEV'
      } if (req.usuario.toLowerCase() === 'agraria') {
        grupo = 'AGRARIA'
      } if (req.usuario.toLowerCase() === 'camill') {
        grupo = 'CAMIL'
      } if (req.usuario.toLowerCase() === 'limagrin') {
        grupo = 'LIMAGRAIN'
      } if (req.usuario.toLowerCase() === 'rural_brasil') {
        grupo = 'RURAL SEMENTES'
      } if (req.usuario.toLowerCase() === 'usiminas') {
        grupo = 'USIMINAS'
      } if (req.usuario.toLowerCase() === 'cervejaria_imperial') {
        grupo = 'CERVEJARIA IMPERIAL'
      } if (req.usuario.toLowerCase() === 'kmm_suporte4' ||
        req.usuario.toLowerCase() === 'kmm_suporte3' ||
        req.usuario.toLowerCase() === 'kmm_suporte2' ||
        req.usuario.toLowerCase() === 'kmm_suporte') {
        grupo = null // total os 9 cliente
      }
    }

    this.match.ATRASO = req.atraso !== undefined ? { $eq: req.atraso } : null
    this.match.GRUPO = grupo ? { $eq: grupo } : null

    Object.keys(this.match).forEach((key) => (this.match[key] == null) && delete this.match[key])
  }

  public setGroup (group: Array<string>): void {
    const obj = JSON.parse(JSON.stringify(this.group))
    Object.keys(obj._id).forEach((key) => (!group.includes(key)) && delete obj._id[key])
    this.group = obj
  }

  public cleanGroup (): void {
    this.initGroup()
  }

  public cleanMath (): void {
    this.initMatch()
  }
}

export default new IndicadorLogModel()
