
import mongoose from 'mongoose'

export class DisponibilidadeMotoristaService {
  private readonly dash = 'dash_disponibilidade_motorista_'

  async findAll (req, sort, select?, limit?): Promise<object> {

    const tgSchema = new mongoose.Schema({}, { strict: false })
    let tg
    try {
      tg = mongoose.model(this.dash + req.base)
    } catch (error) {
      tg = mongoose.model(this.dash + req.base, tgSchema, this.dash + req.base)
    }

    const res = !select ? await tg.find().sort(sort) : await tg.find().select('roll ' + select).sort(sort).limit(limit)
    
    return res
  }

  async exists (base): Promise<boolean> {
    const tgSchema = new mongoose.Schema({}, { strict: false })
    let tg
    try {
      tg = mongoose.model(this.dash + base)
    } catch (error) {
      tg = mongoose.model(this.dash + base, tgSchema, this.dash + base)
    }

    const res = await tg.exists()

    return res
  }
}
