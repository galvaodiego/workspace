
import { GatewayService } from '../../../services/gateway.service'
import { DisponibilidadeMotoristaPage } from '../resolvers/disponibilidade-motorista.page'
import { DisponibilidadeMotoristaService } from '../service/disponibilidade-motorista.service'

class DisponibilidadeMotoristaController {
  private _page = new DisponibilidadeMotoristaPage()
  private _service = new DisponibilidadeMotoristaService()
  private _gatewayService = new GatewayService()

  public async getDisponibilidadeMotorista (req: object, socket): Promise<void> {

    const logInicio = new Date()
    let retorno
    const exist = await this._service.exists(req.base)

    if (exist) {
      retorno = await this._page.getPage(req)
    }
    else {
      if (req.token && req.url) {
        retorno = await this._gatewayService.backendCall(req, 'M4002', 'getMotoristaDash')
      }
    }

    console.log('disponibilidade_motorista', req.base, ':', (new Date() - logInicio) / 1000, 'segundos')

    socket.emit('disponibilidade_motorista', retorno)
  }
}

export default new DisponibilidadeMotoristaController()
