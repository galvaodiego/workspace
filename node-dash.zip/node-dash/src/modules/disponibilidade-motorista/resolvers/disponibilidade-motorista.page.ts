/* eslint-disable no-unused-vars */
/* eslint-disable camelcase */
/* eslint-disable dot-notation */
/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable no-undef */

import { ReturnComponents } from '../../../componentes/return.components'
import { DisponibilidadeMotoristaService } from '../service/disponibilidade-motorista.service';

export class DisponibilidadeMotoristaPage {
  private _service = new DisponibilidadeMotoristaService();
  private _component = new ReturnComponents();

  public async getPage (req: object): Promise<object> {
    const sort = { valor: -1 }

    const motoristas = await this._service.findAll(req, sort, ['CARGO DATA_ENTREGA LOCAL MODALIDADE MOTORISTA'])
    const resMotoristas = await this._component.getLowerCase(motoristas)

    const data = await this._service.findAll(req, sort, ['DATA_CARGA'], 1)
    const resData = await this._component.getLowerCase(data)
    const resAtualizacao = resData && resData.length > 0 ? resData[0].data_carga : 0

    const obj: any = {
      motorista_disp: resMotoristas,
      atualizacao: resAtualizacao
    }

    return obj
  }
}

export default new DisponibilidadeMotoristaPage()
