/* eslint-disable no-unused-vars */
/* eslint-disable camelcase */
/* eslint-disable dot-notation */
/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable no-undef */

import { ReturnComponents } from './../../componentes/return.components'
import { VelocidadeService } from './velocidade.service'

export class VelocidadePage {
  private _service = new VelocidadeService();
  private _component = new ReturnComponents();

  public async getPage (req: object): Promise<object> {
    const sort = { valor: -1 }
    let filter: any = {}
 
    filter = Object.assign({}, req, { status: 'Viagem', velocidadeMin:0, velocidadeMax:79 })
    const em_viagem = await this._service.findAll(filter, { VELOCIDADE: -1 }, ['FROTA INICIO MODALIDADE MOTORISTA PLACA REFERENCIA STATUS STATUS_ID TEMPO VELOCIDADE'])
    const resEmViagem = await this._component.getLowerCase(em_viagem)


    filter = Object.assign({}, req, { status: 'Viagem', velocidadeMin:80, velocidadeMax:200 })
    const viagem_alerta = await this._service.findAll(filter, { VELOCIDADE: -1 }, ['FROTA INICIO MODALIDADE MOTORISTA PLACA REFERENCIA STATUS STATUS_ID TEMPO VELOCIDADE'])
    const resViagemAlerta = await this._component.getLowerCase(viagem_alerta)

    filter = Object.assign({}, req, { status: 'Viagem', diferenteStatus: 1 })
    const outros = await this._service.findAll(filter, { VELOCIDADE: -1 }, ['FROTA INICIO MODALIDADE MOTORISTA PLACA REFERENCIA STATUS STATUS_ID TEMPO VELOCIDADE'])
    const resOutros = await this._component.getLowerCase(outros)

    const indicadores = await this._service.aggregate(req, [''], sort)
    const resAtualizacao = indicadores && indicadores.length > 0 ? indicadores[0].last_update : 0

    const obj: any = {
      alerta_velocidade: {
        em_viagem: resEmViagem,
        em_viagem_alerta: resViagemAlerta,
        outros: resOutros,
        atualizacao: resAtualizacao
      }
    }

    return obj
  }
}

export default new VelocidadePage()
