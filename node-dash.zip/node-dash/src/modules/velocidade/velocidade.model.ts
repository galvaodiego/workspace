/* eslint-disable camelcase */
/* eslint-disable @typescript-eslint/explicit-function-return-type */
/* eslint-disable no-self-assign */
/* eslint-disable @typescript-eslint/camelcase */

export class VelocidadeModel {
  public group
  public match

  constructor () {
    this.initGroup()
    this.initMatch()
  }

  private initGroup () {

    const group = {
      _id: {
        status: '$STATUS',
      },

      last_update: { $max: '$DATA_CARGA' },
      total: { $sum: 1 }
    }
    this.group = group
  }

  private initMatch () {
    const match = {
      STATUS: null,
      VELOCIDADE: null
    }
    this.match = match
  }

  public setMatch (req): void {

    this.match.STATUS = req.status ? req.diferenteStatus == undefined ? { $eq: req.status } : { $ne: req.status} : null
    this.match.VELOCIDADE = req.velocidadeMin !== undefined && req.velocidadeMax !== undefined ? { $gte: req.velocidadeMin, $lte: req.velocidadeMax } : null
   

    Object.keys(this.match).forEach((key) => (this.match[key] == null) && delete this.match[key])
  }

  public setGroup (group: Array<string>): void {
    const obj = JSON.parse(JSON.stringify(this.group))
    Object.keys(obj._id).forEach((key) => (!group.includes(key)) && delete obj._id[key])
    this.group = obj
  }

  public cleanGroup (): void {
    this.initGroup()
  }

  public cleanMath (): void {
    this.initMatch()
  }
}

export default new VelocidadeModel()
