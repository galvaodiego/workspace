import { VelocidadePage } from './velocidade.page'
import { VelocidadeService } from './velocidade.service'
import { GatewayService } from '../../services/gateway.service'

class VelocidadeController {
  private _page = new VelocidadePage()
  private _service = new VelocidadeService()
  private _gatewayService = new GatewayService()

  public async getVelocidade (req: object, socket): Promise<void> {

    const logInicio = new Date()
    let retorno
    const exist = await this._service.exists(req.base)

    if (exist) {
      retorno = await this._page.getPage(req)
    }
    else {
      if (req.token && req.url) {
        retorno = await this._gatewayService.backendCall(req, 'M4002', 'getVelocidadeDash')
      }
    }

    console.log('velocidade', req.base, 'Velocidade:', (new Date() - logInicio) / 1000, 'segundos')

    socket.emit('velocidade', retorno)
  }
}

export default new VelocidadeController()
