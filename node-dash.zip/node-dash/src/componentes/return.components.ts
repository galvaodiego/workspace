/* eslint-disable dot-notation */
import { GraficoBarraStackInterface, GraficoInterface } from './interfaces'

export class ReturnComponents {
  async getGraphicMultiValue (res, dataset, title?): Promise<GraficoBarraStackInterface> {
    const data = res
    const grafico = {
      titulo: title,
      dados: []
    }
    data.forEach(element => {
      grafico.dados.push({
        chave: element._id[dataset.key],
        valor: parseFloat(element[dataset.value]),
        valor2: parseFloat(element[dataset.value2])
      })
    })
    return grafico
  }

  // Implementar sem utilizar atributos pre definidos [mes, tipo_frete, faturamento]
  async getStackBar (res, dataset, title): Promise<object> {
    const o = {}
    const ar = []
    const captions = []
    res.forEach(element => {
      const m = element._id.mes
      const f = element._id.tipo_frete
      const ob = {}
      ob[f] = element.faturamento
      o[m] = {
        chave: m
      }
      if (!captions.includes(f)) {
        captions.push(f)
      }
    })

    res.forEach(el => {
      const m = el._id.mes
      const f = el._id.tipo_frete
      const ob = {}
      ob[f] = el.faturamento

      ar.forEach(e => {
        if (m === e.mes) {
          Object.assign(e, ob)
        }
      })
      Object.assign(o[m], ob)
    })

    const r = []
    const l = {}
    let j = 0
    captions.forEach(cap => {
      j++
      const oj = {}
      oj[cap] = 'valor' + j
      Object.assign(l, oj)
    })
    Object.keys(o).forEach(k => {
      captions.forEach(c => {
        o[k][c] = o[k][c] ? o[k][c] : 0
        const val = l[c]
        o[k][val] = o[k][c] || 0
        delete o[k][c]
      })
      r.push(o[k])
    })

    const x = []
    Object.keys(l).forEach((value, key) => {
      const objy = {
        valor: value
      }
      x.push(objy)
    })

    const stackBar = {
      dados: r,
      titulo: x
    }

    return stackBar
  }

  async getLista (res, dataset, title, notNull = ''): Promise<object> {
    const data = res
    const objRet = {
      titulo: title,
      dados: []
    }
    data.forEach((element, i) => {
      const obj = {}
      if (element._id) {
        Object.assign(element, element._id)
        Object.assign(obj, element._id)
        delete element._id
      }
      dataset.forEach(e => {
        obj[e] = parseFloat(element[e])
      })
      if (obj[notNull] !== null) {
        objRet.dados.push(obj)
      }
    })
    return objRet
  }

  async getIndicador (res, dataset): Promise<object> {
    const data = res
    const indicador = {}
    data.forEach(element => {
      dataset.forEach(e => {
        indicador[e] = parseFloat(element[e])
      })
    })
    return indicador
  }

  async getGraphic (res, dataset, title?): Promise<GraficoInterface> {
    const data = res
    const grafico = {
      titulo: title,
      dados: []
    }
    data.forEach(element => {
      if (element._id[dataset.key] !== null) {
        grafico.dados.push({
          chave: element._id[dataset.key],
          valor: parseFloat(element[dataset.value])
        })
      }
    })
    return grafico
  }

  async getRetFiltro (res, dataset, title?): Promise<object> {
    const data = res

    const grafico = {
      titulo: title,
      dados: []
    }
    data.forEach(element => {

      if (!!element._id[dataset.key] === true && !!element._id[dataset.value] === true) {
        grafico.dados.push({
          chave: element._id[dataset.key],
          valor: parseFloat(element._id[dataset.value])
        })

      } if (!!element._id[dataset.key] === true && !!element._id[dataset.value] === false) {
        grafico.dados.push({
          chave: element._id[dataset.key]
        })
      }
    })
    return grafico.dados
  }

  /**
   * @param res Dados do array do mongo
   * @param values lista de resultados
   * @param keys lista de como devera se chamar o atributo
   */
  async getRetStories (res, values: Array<any>, keys: Array<any>): Promise<object> {
    const data = []
    const grafico = {
      dados: []
    }

    if (res && res.length > 0) {
      Object.assign(data, res[0]['_doc']['dados'])

      if (keys.length === values.length) {
        data.forEach(element => {
          const attributes = {}
          keys.forEach((i, idx) => {
            Object.assign(attributes, {
              [keys[idx]]: isNaN(element[values[idx]] % 1) === false ? parseFloat(element[values[idx]]) : element[values[idx]]
            })
          })
          grafico.dados.push(attributes)
        })
      }
    }

    return grafico
  }

  async getRenameColumns (res, values: Array<any>, keys: Array<any>): Promise<object> {
    const data = res
    const grafico = {
      dados: []
    }

    data.forEach(element => {

      if (element._id) {
        Object.assign(element, element._id)
        delete element._id
      }
    })

    if (data && data.length > 0) {

      if (keys.length === values.length) {
        data.forEach(element => {
          const attributes = {}
          keys.forEach((i, idx) => {
            Object.assign(attributes, {
              [keys[idx]]: isNaN(element[values[idx]] % 1) === false ? parseFloat(element[values[idx]]) : element[values[idx]]
            })
          })
          grafico.dados.push(attributes)
        })
      }
    }

    return grafico
  }

  async getRenameColumns2 (res, values: Array<any>, keys: Array<any>): Promise<object> {
    const data = res
    const grafico = []

    if (data && data.length > 0) {

      if (keys.length === values.length) {
        data.forEach(element => {
          const attributes = {}
          keys.forEach((i, idx) => {
            Object.assign(attributes, {
              [keys[idx]]: isNaN(element[values[idx]] % 1) === false ? parseFloat(element[values[idx]]) : element[values[idx]]
            })
            // console.log(attributes)

          })
          grafico.push(attributes)
        })
      }
    }

    return grafico
  }

  async getLowerCase (res): Promise<object> {
    const data = res
    const lista = []
    let newElement: any

    if (data && data.length > 0) {

      data.forEach(element => {
        const entries = Object.entries(element)
        const type = entries[0][0] // padro ddos retornos find

        if (type === '$__') {
          newElement = element['_doc']

          Object.entries(newElement).map(([key, value]) =>
            Object.assign(newElement, {
              [key.toLowerCase()]: value
            }, delete newElement[key], delete newElement['_id'])
          )
        }
        else {
          newElement = element

          Object.entries(newElement).map(([key, value]) =>
            Object.assign(newElement, {
              [key.toLowerCase()]: value
            }, delete newElement[key], delete newElement['_id'])
          )
        }
        lista.push(newElement)
      })
    }
    return lista
  }

}
