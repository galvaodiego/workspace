
export interface DadoGraficoInterface {
    chave: string,
    valor: any
}

export interface DadoGraficoBarrasStackInterface {
    chave: string,
    valor: any
}

export interface GraficoInterface {
    titulo : string,
    dados : Array<DadoGraficoInterface>
}

export interface GraficoBarraStackInterface {
    titulo : string,
    dados : Array<DadoGraficoBarrasStackInterface>
}
