# Remote

obs: 
1 - yarn include (build e git add .)
2 - git commit
3 - yarn deploy


1 - Configuracao repositorio local
 1.1 Adicionar endereco remoto
 git remote add web suportetc@152.67.46.238:~/git_servers/node_dash.git ou git remote add web ssh://suportetc@152.67.46.238:9922/~/git_servers/node_dash.git

 1.2 Subir a atualizacao
 git push web master ou yarn deploy.
    Kww!@#2020

 # GERENCIADOR DE PROCESSO NODE PM2
 pm2 list
 pm2 start projeto/index.js --name projeto --watch (inicia um novo projeto no pm2 usando whatch como nodemon)
